//MOD@@ Guillermo Carrillo - v1.0.6.4 modo de descarga automatica de NG del MES (RCMD)
//  BTM linea 1 v1.0.0 (Unloader B1ST17): el mismo archivo de la Unloader de linea 2, con el limite que se
//  escogio para la BTM: 3 piezas seguidas o 10 en 10 minutos (antes 10 en una hora). Se prende en Sistema.
//  Avisos: 1220 (W, no para) cuando manda una pieza sola a NG y 1221 (E, para) cuando se apaga solo.
//  Cuando el MES contesta que una pieza no puede continuar (LGIT_PP_UPLOAD_FAIL / RCMD FAIL),
//  el programa de fabrica levanta la alarma 70106 (que PARA la maquina) y ademas abre una
//  ventana que se queda esperando a que alguien apriete "Retry", "CLOSE" o "NG Buffer".
//  Si nadie esta enfrente, la linea se queda parada sin que se vea por que.
//
//  Con este modo encendido, esa pieza se manda sola a la charola de NG (exactamente la misma
//  ruta que hace el boton "NG Buffer") y la maquina sigue corriendo, pero NO en silencio:
//    - queda una alarma de aviso (tipo W, no para la maquina) con el modulo y el texto
//      que mando el MES, o sea que se ve en la lista de alarmas y en el historial;
//    - se cuenta y se escribe en D:\EVMS\TP\EVENTOS\ModoNG_aaaa-MM-dd.txt;
//    - si se pasa del limite de piezas seguidas o de piezas en 10 minutos, el modo se apaga solo
//      y la maquina PARA, porque eso ya no es una pieza suelta.
//
//  Asi las alarmas de verdad (camera check, photo calculation, etc.) siguen igual que siempre:
//  rojas y con paro. Lo unico que deja de parar la linea es el NG que manda el MES.
//
//  Reglas que respeta esta clase:
//    - nunca lanza excepciones hacia el flujo;
//    - nunca abre ventanas desde un nodo de flujo (el dialogo de usuario y contrasena solo se
//      llama desde el clic del boton);
//    - no cambia ni un solo mensaje que se le manda al MES.
using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using static Alpha.FunctionForms.LogForm;

namespace Alpha.Classes
{
    public static class ModoNgMes
    {
        const string USUARIO = "admin";
        const string CONTRASENA = "admin";

        //  Limites de seguridad. Si se pasan, el modo se apaga solo y la maquina para.
        public const int MAX_SEGUIDAS = 3;
        public const int MAX_POR_HORA = 10;   // en VENTANA_MINUTOS (el nombre se dejo igual que en linea 2)
        public const int VENTANA_MINUTOS = 10;

        static readonly object candado = new object();
        static bool activo;
        static bool leido;
        static int seguidas;
        static int totalDelDia;
        static DateTime[] ultimas = new DateTime[MAX_POR_HORA];
        static int siguienteHueco;
        static string ultimoMotivo = "";

        // ------------------------------------------------------------------ estado

        /// <summary>true si el modo esta encendido. Se guarda en disco para que aguante un reinicio.</summary>
        public static bool Activo
        {
            get
            {
                lock (candado)
                {
                    if (!leido)
                    {
                        leido = true;
                        activo = LeerDeDisco();
                    }
                    return activo;
                }
            }
        }

        public static int Seguidas { get { lock (candado) return seguidas; } }
        public static int TotalDelDia { get { lock (candado) return totalDelDia; } }
        public static string UltimoMotivo { get { lock (candado) return ultimoMotivo; } }

        public static int EnLaUltimaHora
        {
            get
            {
                lock (candado) return ContarUltimaHora();
            }
        }

        public static string Resumen()
        {
            lock (candado)
            {
                return string.Format("seguidas {0}/{1}, en 10 min {2}/{3}, hoy {4}",
                    seguidas, MAX_SEGUIDAS, ContarUltimaHora(), MAX_POR_HORA, totalDelDia);
            }
        }

        // ------------------------------------------------------------------ lo que usa el flujo

        /// <summary>
        /// Contesta si esta pieza se puede mandar sola a la charola de NG. Si contesta false,
        /// "motivo" dice por que y el flujo tiene que seguir con el comportamiento de fabrica
        /// (alarma 70106 y ventana). No abre ninguna ventana ni frena el hilo.
        /// </summary>
        public static bool PuedeDescargar(out string motivo)
        {
            motivo = "";
            try
            {
                if (!Activo)
                {
                    motivo = "el modo de descarga automatica esta apagado";
                    return false;
                }
                lock (candado)
                {
                    if (seguidas >= MAX_SEGUIDAS)
                    {
                        motivo = string.Format(
                            "van {0} piezas NG del MES seguidas (limite {1}): se apaga el modo y para la maquina",
                            seguidas, MAX_SEGUIDAS);
                        return false;
                    }
                    if (ContarUltimaHora() >= MAX_POR_HORA)
                    {
                        motivo = string.Format(
                            "van {0} piezas NG del MES en los ultimos 10 minutos (limite {1}): se apaga el modo y para la maquina",
                            ContarUltimaHora(), MAX_POR_HORA);
                        return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                motivo = "error revisando el modo de descarga automatica: " + ex.Message;
                return false;
            }
        }

        /// <summary>Una pieza se mando sola a la charola de NG. Solo cuenta y escribe.</summary>
        public static void RegistrarDescarga(string moduleId, string textoDelMes)
        {
            try
            {
                lock (candado)
                {
                    seguidas++;
                    totalDelDia++;
                    ultimas[siguienteHueco] = DateTime.Now;
                    siguienteHueco = (siguienteHueco + 1) % ultimas.Length;
                    ultimoMotivo = textoDelMes ?? "";
                }
                Anotar(string.Format("NG del MES -> charola NG. Modulo: {0}. MES dice: {1}. {2}",
                    moduleId, textoDelMes, Resumen()));
            }
            catch
            {
            }
        }

        /// <summary>
        /// El modo no pudo atender esta pieza (limite pasado o no se encontro el modulo).
        /// Apaga el modo para que nadie se quede pensando que sigue trabajando solo.
        /// </summary>
        public static void RegistrarFallo(string motivo)
        {
            try
            {
                lock (candado)
                {
                    activo = false;
                    ultimoMotivo = motivo ?? "";
                }
                GuardarEnDisco(false);
                Anotar("MODO APAGADO SOLO: " + motivo);
            }
            catch
            {
            }
        }

        /// <summary>Paso un pallet bueno: se reinicia la cuenta de piezas seguidas.</summary>
        public static void RegistrarPalletBueno()
        {
            try
            {
                lock (candado)
                {
                    if (seguidas == 0) return;
                    seguidas = 0;
                }
                Anotar("Pallet bueno: se reinicia la cuenta de NG seguidas.");
            }
            catch
            {
            }
        }

        // ------------------------------------------------------------------ lo que usa la pantalla

        /// <summary>
        /// Enciende o apaga el modo. Encenderlo pide usuario y contrasena (admin/admin).
        /// SOLO se llama desde un clic, nunca desde un nodo de flujo.
        /// </summary>
        public static bool Cambiar(bool encender)
        {
            try
            {
                if (encender && !PedirAcceso())
                {
                    Anotar("Intento de encender el modo rechazado (usuario o contrasena mal).");
                    return Activo;
                }
                lock (candado)
                {
                    activo = encender;
                    leido = true;
                    if (encender)
                    {
                        seguidas = 0;
                        ultimas = new DateTime[MAX_POR_HORA];
                        siguienteHueco = 0;
                    }
                }
                GuardarEnDisco(encender);
                Anotar(encender
                    ? string.Format("MODO ENCENDIDO. Limites: {0} seguidas, {1} en 10 minutos. Usuario:{2}",
                        MAX_SEGUIDAS, MAX_POR_HORA, SeguroUsuario())
                    : "MODO APAGADO a mano. Usuario:" + SeguroUsuario());
                return encender;
            }
            catch
            {
                return Activo;
            }
        }

        static bool PedirAcceso()
        {
            using (var fuente = new Font("Microsoft Sans Serif", 14F))
            using (var dialogo = new Form())
            using (var lblAviso = new Label())
            using (var lblUsuario = new Label())
            using (var txtUsuario = new TextBox())
            using (var lblContrasena = new Label())
            using (var txtContrasena = new TextBox())
            using (var btnAceptar = new Button())
            using (var btnCancelar = new Button())
            {
                dialogo.Text = "Descarga automatica de NG del MES";
                dialogo.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialogo.StartPosition = FormStartPosition.CenterScreen;
                dialogo.TopMost = true;
                dialogo.MaximizeBox = false;
                dialogo.MinimizeBox = false;
                dialogo.ClientSize = new Size(620, 320);
                dialogo.Font = fuente;

                lblAviso.SetBounds(20, 15, 580, 110);
                lblAviso.Text = "Con este modo la maquina manda sola a la charola de NG las piezas que el MES\n"
                    + "rechaza, sin parar la linea. Las demas alarmas siguen parando igual que siempre.\n"
                    + "Se apaga solo si pasan " + MAX_SEGUIDAS + " piezas seguidas o " + MAX_POR_HORA + " en 10 minutos.\n"
                    + "Escriba usuario y contrasena para encenderlo.";

                lblUsuario.SetBounds(20, 140, 160, 30);
                lblUsuario.Text = "Usuario:";
                txtUsuario.SetBounds(190, 136, 400, 32);

                lblContrasena.SetBounds(20, 190, 160, 30);
                lblContrasena.Text = "Contrasena:";
                txtContrasena.SetBounds(190, 186, 400, 32);
                txtContrasena.UseSystemPasswordChar = true;

                btnAceptar.SetBounds(190, 245, 180, 46);
                btnAceptar.Text = "Encender";
                btnAceptar.DialogResult = DialogResult.OK;

                btnCancelar.SetBounds(410, 245, 180, 46);
                btnCancelar.Text = "Cancelar";
                btnCancelar.DialogResult = DialogResult.Cancel;

                dialogo.Controls.AddRange(new Control[] { lblAviso, lblUsuario, txtUsuario,
                    lblContrasena, txtContrasena, btnAceptar, btnCancelar });
                dialogo.AcceptButton = btnAceptar;
                dialogo.CancelButton = btnCancelar;

                if (dialogo.ShowDialog() != DialogResult.OK) return false;
                return txtUsuario.Text.Trim() == USUARIO && txtContrasena.Text == CONTRASENA;
            }
        }

        // ------------------------------------------------------------------ apoyo

        static int ContarUltimaHora()
        {
            DateTime limite = DateTime.Now.AddMinutes(-VENTANA_MINUTOS);
            int n = 0;
            for (int i = 0; i < ultimas.Length; i++)
                if (ultimas[i] > limite) n++;
            return n;
        }

        static string SeguroUsuario()
        {
            try { return SysPara.UserName + "/" + SysPara.UserPermission; }
            catch { return "?"; }
        }

        static string Archivo
        {
            get { return Path.Combine(Carpeta, "ModoNG_" + DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + ".txt"); }
        }

        static string ArchivoDeEstado
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ModuleData", "ModoNgMes.txt"); }
        }

        static string Carpeta
        {
            get
            {
                try
                {
                    Directory.CreateDirectory(@"D:\EVMS\TP\EVENTOS");
                    return @"D:\EVMS\TP\EVENTOS";
                }
                catch
                {
                    string c = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LogFile", "Eventos");
                    try { Directory.CreateDirectory(c); } catch { }
                    return c;
                }
            }
        }

        static bool LeerDeDisco()
        {
            try
            {
                if (!File.Exists(ArchivoDeEstado)) return false;
                return File.ReadAllText(ArchivoDeEstado).Trim() == "1";
            }
            catch
            {
                return false;
            }
        }

        static void GuardarEnDisco(bool valor)
        {
            try
            {
                string carpeta = Path.GetDirectoryName(ArchivoDeEstado);
                if (!Directory.Exists(carpeta)) Directory.CreateDirectory(carpeta);
                File.WriteAllText(ArchivoDeEstado, valor ? "1" : "0");
            }
            catch
            {
            }
        }

        /// <summary>Escribe en el archivo del dia y en el log de interfaz. Nunca truena.</summary>
        static void Anotar(string texto)
        {
            string linea = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
                + "  " + texto;
            try
            {
                using (var fs = new FileStream(Archivo, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                using (var sw = new StreamWriter(fs, new UTF8Encoding(false)))
                    sw.WriteLine(linea);
            }
            catch
            {
            }
            try
            {
                MiddleLayer.LogF.AddLog(LogType.UserInterface, "[ModoNG] " + texto, true);
            }
            catch
            {
            }
        }
    }
}
