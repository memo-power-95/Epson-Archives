﻿using System;
using System.IO;

namespace Alpha.Classes
{
    //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: las alarmas 500xx ("An unpredictable error occurred ...")
    //  salen cuando algo truena con una excepcion dentro de un paso del flujo (50005 en automatico, 50011 en la
    //  inicializacion, 50018 en el reinicio de Aaron) o en AlwaysRun (50007). El programa del proveedor la tragaba
    //  sin guardar nada (y la lista de excepciones de la pantalla no registra por un if al reves), asi que no se
    //  podia saber que paso fallo. Ahora se anota la excepcion completa (mensaje y pila, con el nombre del paso
    //  flowChartXX_FlowRun y la linea) en D:\EVMS\TP\EXCEPCIONES\Excepciones_aaaa-MM-dd.txt (sin D:, junto al
    //  programa en LogFile\Excepciones). Solo escribe: no cambia lo que hace la maquina.
    //  La misma excepcion repetida (AlwaysRun corre cada 1 ms) se anota una vez cada 10 s con cuantas veces paso.
    public static class RegistroExcepciones
    {
        static readonly object candado = new object();
        static string ultimaClave = "";
        static DateTime ultimaVez = DateTime.MinValue;
        static int repetidas = 0;

        public static void Anotar(string donde, Exception ex)
        {
            try
            {
                if (ex == null) return;
                string clave = donde + "|" + ex.GetType().FullName + "|" + ex.Message + "|" + (ex.StackTrace ?? "");
                lock (candado)
                {
                    DateTime ahora = DateTime.Now;
                    if (clave == ultimaClave && (ahora - ultimaVez).TotalSeconds < 10)
                    {
                        repetidas++;
                        return;
                    }
                    string extra = repetidas > 0 ? "(la anterior se repitio " + repetidas + " veces mas)\r\n" : "";
                    ultimaClave = clave;
                    ultimaVez = ahora;
                    repetidas = 0;
                    string carpeta = Directory.Exists(@"D:\") ? @"D:\EVMS\TP\EXCEPCIONES"
                        : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LogFile", "Excepciones");
                    Directory.CreateDirectory(carpeta);
                    string archivo = Path.Combine(carpeta, "Excepciones_" + ahora.ToString("yyyy-MM-dd") + ".txt");
                    File.AppendAllText(archivo, extra + ahora.ToString("yyyy-MM-dd HH:mm:ss.fff") + "  [" + donde + "]\r\n"
                        + ex.ToString() + "\r\n----------------------------------------\r\n");
                }
            }
            catch
            {
            }
        }
    }
}
