using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json.Linq;

namespace Alpha.Classes
{
    //MOD@@ Guillermo Carrillo - BTM linea 1 v1.0.0 (Cover Flip y Unloader B1ST17): el mismo archivo de la Unloader 2.1.1
    //  de linea 2 (y de la Screw 6.5.4 y la AVI 6.4.3): producto distinto 70101 y lote fallido 70106 / LOT ID FAIL.
    //  Los arreglos que recibe van SIEMPRE por indice del MES (0 a 11 = lugar 1 a 12 del pallet); cada maquina
    //  los arma con su propia numeracion.
    //
    //  Una pieza del pallet que el MES no deja procesar, sacada de la MISMA respuesta que ya leyo MESLib
    //  (solo lectura; aqui no se le manda nada al MES):
    //    - LOT START (respuesta al 10701) con otro modelo: PRODID distinto al de la maquina.
    //    - LOT FAIL (LGIT_LOT_ID_FAIL / RCMD FAIL): el MES dice que la pieza no puede procesarse aqui.
    //  Las dos traen LOTINFOLIST con una entrada por pieza (MODULEID, POCKETID, LOTID, PRODID, PROCID) y el
    //  LOT FAIL ademas TEXT, el motivo que escribe el MES.
    //
    //  Antes el programa solo tomaba el PRIMER MODULEID de la respuesta y lo buscaba, texto exacto, entre
    //  los lugares del pallet; si no coincidia salia "LOT_ID_FAIL, No Pallet ID Information" y la maquina
    //  paraba aunque se apretara NG Buffer. Ahora se leen TODAS las piezas y cada una se busca por:
    //    1. POCKETID en los pockets del MES (igual que MesManager.GetIndex);
    //    2. MODULEID contra el QR del lugar del pallet (ThreeResultDatas[i].PalletCode y
    //       TRAY_POSITION_QRCODEs), sin espacios ni mayusculas;
    //    3. LOTID contra el codigo de la PCB que leyo la camara (ThreeResultDatas[i].ProductCode).
    //
    //  Numeracion de la Unloader (del proveedor): indice 0 a 11 = lugar del pallet; MesOK, POCKETIDs y
    //  ThreeResultDatas van por ese indice. Lugar (1 a 12) = indice + 1, el que usa pickUpProductIndex.
    public class PiezaRechazada
    {
        public string Modulo = "";      // QR del lugar del pallet que mando el MES, por ejemplo LG2T-08-05
        public string Pocket = "";
        public string Lote = "";        // LOTID: el codigo de la PCB para el MES
        public string Modelo = "";      // PRODID que dice el MES para esa pieza
        public string Proceso = "";     // PROCID, si lo manda
        public string Otros = "";       // cualquier otro dato que mande el MES de esa pieza
        public string CodigoLeido = ""; // el codigo de la PCB que leyo la camara en ese lugar
        public string ComoSeEncontro = "";
        public int IndiceMes = -1;      // 0 a 11, -1 si no se encontro
        public int Lugar = -1;          // 1 a 12, -1 si no se encontro

        static readonly string[] CamposConocidos = { "MODULEID", "POCKETID", "LOTID", "PRODID", "PROCID" };

        //  70101: piezas del LOT START cuyo PRODID no es el de la maquina (misma comparacion que MESLib).
        public static List<PiezaRechazada> DeOtroModelo(string respuestaLotStart, string modeloMaquina, string[] pockets,
                                                        string[] qrs, string[] qrsPallet, string[] codigosPcb)
        {
            List<PiezaRechazada> lista = new List<PiezaRechazada>();
            foreach (JObject lote in Lotes(respuestaLotStart))
            {
                JToken prodid = lote["PRODID"];
                string modelo = prodid == null ? "" : prodid.ToString();
                if (modelo == (modeloMaquina ?? "")) continue;
                lista.Add(DeLote(lote, pockets, qrs, qrsPallet, codigosPcb));
            }
            return lista;
        }

        //  70106: todas las piezas que trae el LOT FAIL, y el motivo que escribio el MES (TEXT).
        public static List<PiezaRechazada> DeLoteFallido(string respuestaLotFail, string[] pockets, string[] qrs,
                                                         string[] qrsPallet, string[] codigosPcb, out string textoMes)
        {
            textoMes = "";
            List<PiezaRechazada> lista = new List<PiezaRechazada>();
            if (string.IsNullOrEmpty(respuestaLotFail)) return lista;
            JObject raiz = JObject.Parse(respuestaLotFail);
            JToken texto = raiz["TEXT"];
            textoMes = texto == null ? "" : texto.ToString().Trim();
            foreach (JObject lote in Lotes(respuestaLotFail))
            {
                lista.Add(DeLote(lote, pockets, qrs, qrsPallet, codigosPcb));
            }
            return lista;
        }

        public override string ToString()
        {
            string s = Lugar > 0 ? "lugar " + Lugar : "(no se encontro en el pallet)";
            if (Modulo != "") s += " " + Modulo;
            string codigo = CodigoLeido != "" ? CodigoLeido : Lote;
            if (codigo != "") s += " PCB " + codigo;
            if (Modelo != "") s += " modelo " + Modelo;
            if (Proceso != "") s += " proceso " + Proceso;
            return s;
        }

        static IEnumerable<JObject> Lotes(string respuesta)
        {
            if (string.IsNullOrEmpty(respuesta)) yield break;
            JObject raiz = JObject.Parse(respuesta);
            JObject lotes = raiz["LOTINFOLIST"] as JObject;
            if (lotes == null) yield break;
            foreach (JProperty propiedad in lotes.Properties())
            {
                JObject lote = propiedad.Value as JObject;
                if (lote == null)
                {
                    try { lote = JObject.Parse(propiedad.Value.ToString()); }
                    catch { continue; }
                }
                yield return lote;
            }
        }

        static PiezaRechazada DeLote(JObject lote, string[] pockets, string[] qrs, string[] qrsPallet, string[] codigosPcb)
        {
            PiezaRechazada pieza = new PiezaRechazada();
            pieza.Modulo = Texto(lote, "MODULEID");
            pieza.Pocket = Texto(lote, "POCKETID");
            pieza.Lote = Texto(lote, "LOTID");
            pieza.Modelo = Texto(lote, "PRODID");
            pieza.Proceso = Texto(lote, "PROCID");
            StringBuilder otros = new StringBuilder();
            foreach (JProperty campo in lote.Properties())
            {
                if (Array.IndexOf(CamposConocidos, campo.Name.ToUpperInvariant()) >= 0) continue;
                if (campo.Value == null || campo.Value.Type == JTokenType.Object || campo.Value.Type == JTokenType.Array) continue;
                string valor = campo.Value.ToString().Trim();
                if (valor == "") continue;
                if (otros.Length > 0) otros.Append(", ");
                otros.Append(campo.Name).Append(" = ").Append(valor);
            }
            pieza.Otros = otros.ToString();

            pieza.IndiceMes = Exacto(pieza.Pocket, pockets);
            if (pieza.IndiceMes >= 0) pieza.ComoSeEncontro = "pocket";
            if (pieza.IndiceMes < 0)
            {
                pieza.IndiceMes = Parecido(pieza.Modulo, qrsPallet);
                if (pieza.IndiceMes < 0) pieza.IndiceMes = Parecido(pieza.Modulo, qrs);
                if (pieza.IndiceMes >= 0) pieza.ComoSeEncontro = "QR del lugar";
            }
            if (pieza.IndiceMes < 0)
            {
                pieza.IndiceMes = Parecido(pieza.Lote, codigosPcb);
                if (pieza.IndiceMes >= 0) pieza.ComoSeEncontro = "codigo de la PCB";
            }
            if (pieza.IndiceMes >= 12) pieza.IndiceMes = -1;
            pieza.Lugar = pieza.IndiceMes >= 0 ? pieza.IndiceMes + 1 : -1;
            if (pieza.IndiceMes >= 0 && codigosPcb != null && pieza.IndiceMes < codigosPcb.Length && codigosPcb[pieza.IndiceMes] != null)
                pieza.CodigoLeido = codigosPcb[pieza.IndiceMes].Trim();
            return pieza;
        }

        static string Texto(JObject lote, string campo)
        {
            JToken valor = lote[campo];
            return valor == null ? "" : valor.ToString().Trim();
        }

        //  Igual que MesManager.GetIndex: comparacion exacta.
        static int Exacto(string valor, string[] lista)
        {
            if (string.IsNullOrEmpty(valor) || lista == null) return -1;
            for (int i = 0; i < lista.Length; i++)
            {
                if (lista[i] == valor) return i;
            }
            return -1;
        }

        //  Sin espacios ni caracteres de control, sin importar mayusculas. Solo si hay UNA coincidencia.
        static int Parecido(string valor, string[] lista)
        {
            string buscado = Limpio(valor);
            if (buscado == "" || lista == null) return -1;
            int encontrado = -1;
            for (int i = 0; i < lista.Length; i++)
            {
                if (Limpio(lista[i]) != buscado) continue;
                if (encontrado >= 0) return -1;   // dos lugares iguales: no se adivina
                encontrado = i;
            }
            return encontrado;
        }

        static string Limpio(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            StringBuilder b = new StringBuilder(s.Length);
            foreach (char c in s)
            {
                if (char.IsWhiteSpace(c) || char.IsControl(c)) continue;
                b.Append(char.ToUpperInvariant(c));
            }
            string r = b.ToString();
            return r == "NULL" || r == "ERROR" || r == "N/A" ? "" : r;
        }
    }
}
