
namespace Alpha._0.ModuleForms
{
    partial class GantryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GantryForm));
            this.IB_FeederAlarm = new NPSDK.NPInput();
            this.IB_FeederInPlace = new NPSDK.NPInput();
            this.IB_FeederEmergencyStop = new NPSDK.NPInput();
            this.IB_FeederReady = new NPSDK.NPInput();
            this.IB_FeederLack = new NPSDK.NPInput();
            this.OB_FeederAlmReset = new NPSDK.NPOutput();
            this.OB_FeederSafetySignal = new NPSDK.NPOutput();
            this.OB_FeederEmgStop = new NPSDK.NPOutput();
            this.OB_FeederStart = new NPSDK.NPOutput();
            this.OB_FeederCompleted = new NPSDK.NPOutput();
            this.tmRefresh = new System.Windows.Forms.Timer(this.components);
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.dataColumn37 = new System.Data.DataColumn();
            this.dataTable2 = new System.Data.DataTable();
            this.dataColumn38 = new System.Data.DataColumn();
            this.dataColumn39 = new System.Data.DataColumn();
            this.button28 = new System.Windows.Forms.Button();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.button27 = new System.Windows.Forms.Button();
            this.CTtime2 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.CTtime1 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.txtBarcodeResult2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBarcodeResult = new System.Windows.Forms.TextBox();
            this.dataTable3 = new System.Data.DataTable();
            this.dataColumn40 = new System.Data.DataColumn();
            this.dataColumn41 = new System.Data.DataColumn();
            this.dataColumn42 = new System.Data.DataColumn();
            this.dataColumn43 = new System.Data.DataColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataColumn44 = new System.Data.DataColumn();
            this.dataColumn45 = new System.Data.DataColumn();
            this.dataColumn46 = new System.Data.DataColumn();
            this.dataColumn47 = new System.Data.DataColumn();
            this.dataTable4 = new System.Data.DataTable();
            this.dataColumn48 = new System.Data.DataColumn();
            this.dataColumn49 = new System.Data.DataColumn();
            this.dataColumn50 = new System.Data.DataColumn();
            this.dataColumn51 = new System.Data.DataColumn();
            this.dataColumn52 = new System.Data.DataColumn();
            this.dataColumn53 = new System.Data.DataColumn();
            this.dataColumn54 = new System.Data.DataColumn();
            this.dataColumn55 = new System.Data.DataColumn();
            this.dataColumn56 = new System.Data.DataColumn();
            this.dataColumn57 = new System.Data.DataColumn();
            this.dataColumn58 = new System.Data.DataColumn();
            this.dataColumn59 = new System.Data.DataColumn();
            this.dataColumn60 = new System.Data.DataColumn();
            this.dataColumn61 = new System.Data.DataColumn();
            this.dataColumn62 = new System.Data.DataColumn();
            this.dataColumn63 = new System.Data.DataColumn();
            this.dataColumn64 = new System.Data.DataColumn();
            this.dataColumn65 = new System.Data.DataColumn();
            this.dataColumn66 = new System.Data.DataColumn();
            this.dataColumn67 = new System.Data.DataColumn();
            this.dataColumn68 = new System.Data.DataColumn();
            this.dataColumn69 = new System.Data.DataColumn();
            this.dataColumn70 = new System.Data.DataColumn();
            this.dataColumn71 = new System.Data.DataColumn();
            this.dataColumn72 = new System.Data.DataColumn();
            this.dataColumn73 = new System.Data.DataColumn();
            this.dataTable5 = new System.Data.DataTable();
            this.dataColumn74 = new System.Data.DataColumn();
            this.dataColumn75 = new System.Data.DataColumn();
            this.dataColumn76 = new System.Data.DataColumn();
            this.dataColumn77 = new System.Data.DataColumn();
            this.dataColumn78 = new System.Data.DataColumn();
            this.dataColumn79 = new System.Data.DataColumn();
            this.dataColumn80 = new System.Data.DataColumn();
            this.dataColumn81 = new System.Data.DataColumn();
            this.dataColumn82 = new System.Data.DataColumn();
            this.dataColumn83 = new System.Data.DataColumn();
            this.dataColumn84 = new System.Data.DataColumn();
            this.dataColumn85 = new System.Data.DataColumn();
            this.dataColumn86 = new System.Data.DataColumn();
            this.dataColumn87 = new System.Data.DataColumn();
            this.dataColumn88 = new System.Data.DataColumn();
            this.dataColumn89 = new System.Data.DataColumn();
            this.dataColumn90 = new System.Data.DataColumn();
            this.dataColumn91 = new System.Data.DataColumn();
            this.dataColumn92 = new System.Data.DataColumn();
            this.dataColumn93 = new System.Data.DataColumn();
            this.dataColumn94 = new System.Data.DataColumn();
            this.dataColumn95 = new System.Data.DataColumn();
            this.dataColumn96 = new System.Data.DataColumn();
            this.dataColumn97 = new System.Data.DataColumn();
            this.tb_Robot1AlarmInfo = new System.Windows.Forms.TabPage();
            this.fcNgMes = new NPSDK.NPFlowChart();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0
            this.flowChart101 = new NPSDK.NPFlowChart();
            this.fc_ReflashR1AlramInfo = new NPSDK.NPFlowChart();
            this.flowChart102 = new NPSDK.NPFlowChart();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.npFlowChart30 = new NPSDK.NPFlowChart();
            this.flowChart24 = new NPSDK.NPFlowChart();
            this.flowChart25 = new NPSDK.NPFlowChart();
            this.flowChart36 = new NPSDK.NPFlowChart();
            this.flowChart43 = new NPSDK.NPFlowChart();
            this.flowChart53 = new NPSDK.NPFlowChart();
            this.flowChart42 = new NPSDK.NPFlowChart();
            this.npFlowChart8 = new NPSDK.NPFlowChart();
            this.npFlowChart10 = new NPSDK.NPFlowChart();
            this.npFlowChart9 = new NPSDK.NPFlowChart();
            this.npFlowChart11 = new NPSDK.NPFlowChart();
            this.npFlowChart13 = new NPSDK.NPFlowChart();
            this.npFlowChart12 = new NPSDK.NPFlowChart();
            this.npFlowChart18 = new NPSDK.NPFlowChart();
            this.npFlowChart17 = new NPSDK.NPFlowChart();
            this.npFlowChart28 = new NPSDK.NPFlowChart();
            this.npFlowChart29 = new NPSDK.NPFlowChart();
            this.npFlowChart14 = new NPSDK.NPFlowChart();
            this.npFlowChart15 = new NPSDK.NPFlowChart();
            this.npFlowChart16 = new NPSDK.NPFlowChart();
            this.npFlowChart19 = new NPSDK.NPFlowChart();
            this.flowChart66 = new NPSDK.NPFlowChart();
            this.flowChart41 = new NPSDK.NPFlowChart();
            this.flowChart20 = new NPSDK.NPFlowChart();
            this.flowChart63 = new NPSDK.NPFlowChart();
            this.flowChart64 = new NPSDK.NPFlowChart();
            this.flowChart44 = new NPSDK.NPFlowChart();
            this.flowChart32 = new NPSDK.NPFlowChart();
            this.flowChart71 = new NPSDK.NPFlowChart();
            this.flowChart15 = new NPSDK.NPFlowChart();
            this.flowChart81 = new NPSDK.NPFlowChart();
            this.flowChart82 = new NPSDK.NPFlowChart();
            this.flowChart17 = new NPSDK.NPFlowChart();
            this.flowChart38 = new NPSDK.NPFlowChart();
            this.flowChart14 = new NPSDK.NPFlowChart();
            this.flowChart50 = new NPSDK.NPFlowChart();
            this.flowChart26 = new NPSDK.NPFlowChart();
            this.flowChart27 = new NPSDK.NPFlowChart();
            this.flowChart3 = new NPSDK.NPFlowChart();
            this.flowChart62 = new NPSDK.NPFlowChart();
            this.flowChart29 = new NPSDK.NPFlowChart();
            this.flowChart35 = new NPSDK.NPFlowChart();
            this.flowChart39 = new NPSDK.NPFlowChart();
            this.flowChart51 = new NPSDK.NPFlowChart();
            this.flowChart58 = new NPSDK.NPFlowChart();
            this.flowChart28 = new NPSDK.NPFlowChart();
            this.flowChart45 = new NPSDK.NPFlowChart();
            this.flowChart40 = new NPSDK.NPFlowChart();
            this.flowChart16 = new NPSDK.NPFlowChart();
            this.flowChart8 = new NPSDK.NPFlowChart();
            this.flowChart18 = new NPSDK.NPFlowChart();
            this.flowChart65 = new NPSDK.NPFlowChart();
            this.flowChart10 = new NPSDK.NPFlowChart();
            this.flowChart19 = new NPSDK.NPFlowChart();
            this.flowChart21 = new NPSDK.NPFlowChart();
            this.npFlowChart2 = new NPSDK.NPFlowChart();
            this.flowChart80 = new NPSDK.NPFlowChart();
            this.flowChart37 = new NPSDK.NPFlowChart();
            this.flowChart22 = new NPSDK.NPFlowChart();
            this.flowChart60 = new NPSDK.NPFlowChart();
            this.flowChart67 = new NPSDK.NPFlowChart();
            this.flowChart23 = new NPSDK.NPFlowChart();
            this.flowChart34 = new NPSDK.NPFlowChart();
            this.flowChart52 = new NPSDK.NPFlowChart();
            this.flowChart61 = new NPSDK.NPFlowChart();
            this.flowChart68 = new NPSDK.NPFlowChart();
            this.flowChart70 = new NPSDK.NPFlowChart();
            this.npFlowChart7 = new NPSDK.NPFlowChart();
            this.fc_RobotStart = new NPSDK.NPFlowChart();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.flowChart83 = new NPSDK.NPFlowChart();
            this.flowChart79 = new NPSDK.NPFlowChart();
            this.flowChart78 = new NPSDK.NPFlowChart();
            this.flowChart76 = new NPSDK.NPFlowChart();
            this.flowChart77 = new NPSDK.NPFlowChart();
            this.flowChart73 = new NPSDK.NPFlowChart();
            this.flowChart74 = new NPSDK.NPFlowChart();
            this.flowChart75 = new NPSDK.NPFlowChart();
            this.flowChart72 = new NPSDK.NPFlowChart();
            this.flowChart69 = new NPSDK.NPFlowChart();
            this.dataColumn98 = new System.Data.DataColumn();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.chk_Output_1 = new System.Windows.Forms.CheckBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.bt_WriteIO = new System.Windows.Forms.Button();
            this.chk_Output_2 = new System.Windows.Forms.CheckBox();
            this.chk_Output_3 = new System.Windows.Forms.CheckBox();
            this.chk_Output_4 = new System.Windows.Forms.CheckBox();
            this.chk_Output_5 = new System.Windows.Forms.CheckBox();
            this.chk_Output_6 = new System.Windows.Forms.CheckBox();
            this.chk_Output_7 = new System.Windows.Forms.CheckBox();
            this.chk_Output_8 = new System.Windows.Forms.CheckBox();
            this.chk_Output_9 = new System.Windows.Forms.CheckBox();
            this.chk_Output_10 = new System.Windows.Forms.CheckBox();
            this.chk_Output_11 = new System.Windows.Forms.CheckBox();
            this.chk_Output_12 = new System.Windows.Forms.CheckBox();
            this.chk_Output_13 = new System.Windows.Forms.CheckBox();
            this.chk_Output_14 = new System.Windows.Forms.CheckBox();
            this.chk_Output_15 = new System.Windows.Forms.CheckBox();
            this.chk_Output_16 = new System.Windows.Forms.CheckBox();
            this.label87 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.IB_RobotLimit = new NPSDK.NPInput();
            this.IB_RobotPause = new NPSDK.NPInput();
            this.OB_RobotPause = new NPSDK.NPOutput();
            this.IB_RobotError = new NPSDK.NPInput();
            this.IB_RobotEStop = new NPSDK.NPInput();
            this.OB_RobotStart = new NPSDK.NPOutput();
            this.IB_RobotBusy = new NPSDK.NPInput();
            this.IB_RobotReady = new NPSDK.NPInput();
            this.OB_RobotLight = new NPSDK.NPOutput();
            this.OB_RobotReset = new NPSDK.NPOutput();
            this.OB_RobotStop = new NPSDK.NPOutput();
            this.OB_RobotContinue = new NPSDK.NPOutput();
            this.OB_RobotProg3 = new NPSDK.NPOutput();
            this.OB_RobotProg2 = new NPSDK.NPOutput();
            this.OB_RobotProg1 = new NPSDK.NPOutput();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.bt_Input_1 = new System.Windows.Forms.Button();
            this.bt_Input_2 = new System.Windows.Forms.Button();
            this.bt_Input_3 = new System.Windows.Forms.Button();
            this.bt_Input_4 = new System.Windows.Forms.Button();
            this.bt_Input_5 = new System.Windows.Forms.Button();
            this.bt_Input_6 = new System.Windows.Forms.Button();
            this.bt_Input_7 = new System.Windows.Forms.Button();
            this.bt_Input_8 = new System.Windows.Forms.Button();
            this.bt_Input_9 = new System.Windows.Forms.Button();
            this.bt_Input_10 = new System.Windows.Forms.Button();
            this.bt_Input_11 = new System.Windows.Forms.Button();
            this.bt_Input_12 = new System.Windows.Forms.Button();
            this.bt_Input_13 = new System.Windows.Forms.Button();
            this.bt_Input_14 = new System.Windows.Forms.Button();
            this.bt_Input_15 = new System.Windows.Forms.Button();
            this.bt_Input_16 = new System.Windows.Forms.Button();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.bt_ReadIO = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.flowChart12 = new NPSDK.NPFlowChart();
            this.flowChart13 = new NPSDK.NPFlowChart();
            this.flowChart11 = new NPSDK.NPFlowChart();
            this.flowChart9 = new NPSDK.NPFlowChart();
            this.flowChart7 = new NPSDK.NPFlowChart();
            this.flowChart96 = new NPSDK.NPFlowChart();
            this.npFlowChart3 = new NPSDK.NPFlowChart();
            this.npFlowChart4 = new NPSDK.NPFlowChart();
            this.npFlowChart5 = new NPSDK.NPFlowChart();
            this.npFlowChart6 = new NPSDK.NPFlowChart();
            this.fc_ConnectScanner = new NPSDK.NPFlowChart();
            this.fc_CloseVisLight = new NPSDK.NPFlowChart();
            this.fc_ResetR1 = new NPSDK.NPFlowChart();
            this.fc_StartR1 = new NPSDK.NPFlowChart();
            this.fc_WaitR1Reset = new NPSDK.NPFlowChart();
            this.flowChart31 = new NPSDK.NPFlowChart();
            this.flowChart33 = new NPSDK.NPFlowChart();
            this.npFlowChart24 = new NPSDK.NPFlowChart();
            this.npFlowChart23 = new NPSDK.NPFlowChart();
            this.npFlowChart22 = new NPSDK.NPFlowChart();
            this.npFlowChart21 = new NPSDK.NPFlowChart();
            this.npFlowChart20 = new NPSDK.NPFlowChart();
            this.npFlowChart25 = new NPSDK.NPFlowChart();
            this.npFlowChart26 = new NPSDK.NPFlowChart();
            this.npFlowChart27 = new NPSDK.NPFlowChart();
            this.flowChart54 = new NPSDK.NPFlowChart();
            this.flowChart55 = new NPSDK.NPFlowChart();
            this.flowChart56 = new NPSDK.NPFlowChart();
            this.flowChart57 = new NPSDK.NPFlowChart();
            this.flowChart1 = new NPSDK.NPFlowChart();
            this.flowChart2 = new NPSDK.NPFlowChart();
            this.npFlowChart1 = new NPSDK.NPFlowChart();
            this.fc_InitialStart = new NPSDK.NPFlowChart();
            this.npFlowChart31 = new NPSDK.NPFlowChart();
            this.npFlowChart32 = new NPSDK.NPFlowChart();
            this.dataColumn99 = new System.Data.DataColumn();
            this.dataColumn100 = new System.Data.DataColumn();
            this.cogRecDisp_H5_Recipe = new Cognex.VisionPro.CogRecordDisplay();
            this.cogRecordDisplay_Discharge = new Cognex.VisionPro.CogRecordDisplay();
            this.cogRecordDisplay_Pickup = new Cognex.VisionPro.CogRecordDisplay();
            this.dataColumn101 = new System.Data.DataColumn();
            this.dataColumn102 = new System.Data.DataColumn();
            this.dataColumn103 = new System.Data.DataColumn();
            this.dataColumn104 = new System.Data.DataColumn();
            this.dataColumn105 = new System.Data.DataColumn();
            this.dataColumn106 = new System.Data.DataColumn();
            this.dataColumn107 = new System.Data.DataColumn();
            this.dataColumn108 = new System.Data.DataColumn();
            this.dataColumn109 = new System.Data.DataColumn();
            this.dataColumn110 = new System.Data.DataColumn();
            this.dataColumn111 = new System.Data.DataColumn();
            this.dataColumn112 = new System.Data.DataColumn();
            this.dataColumn113 = new System.Data.DataColumn();
            this.dataColumn114 = new System.Data.DataColumn();
            this.dataColumn115 = new System.Data.DataColumn();
            this.dataColumn116 = new System.Data.DataColumn();
            this.dataColumn117 = new System.Data.DataColumn();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.dgv_EpsonErrInfo = new VUControl.VUDatagridView();
            this.dgv_EpsonPosition = new VUControl.VUDatagridView();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.button3 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.txtDisChargeRobotY3 = new System.Windows.Forms.TextBox();
            this.txtDisChargePosVisionX3 = new System.Windows.Forms.TextBox();
            this.txtDisChargeRobotX3 = new System.Windows.Forms.TextBox();
            this.txtDisChargeRobotU2 = new System.Windows.Forms.TextBox();
            this.txtDisChargeRobotY2 = new System.Windows.Forms.TextBox();
            this.txtDisChargeRobotX2 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.txtDisChargePosVisionX1 = new System.Windows.Forms.TextBox();
            this.txtDisChargePosVisionY1 = new System.Windows.Forms.TextBox();
            this.btnTeachDiscVisPos = new System.Windows.Forms.Button();
            this.txtDisChargeRobotX1 = new System.Windows.Forms.TextBox();
            this.txtDisChargeRobotY1 = new System.Windows.Forms.TextBox();
            this.txtDisChargeRobotU1 = new System.Windows.Forms.TextBox();
            this.btnTeachDiscRobotPos = new System.Windows.Forms.Button();
            this.txtDisChargePosVisionU1 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.btnTeachDiscRobotPos2 = new System.Windows.Forms.Button();
            this.txtDisChargePosVisionX2 = new System.Windows.Forms.TextBox();
            this.txtDisChargePosVisionU2 = new System.Windows.Forms.TextBox();
            this.txtDisChargePosVisionY2 = new System.Windows.Forms.TextBox();
            this.btnTeachDiscVisPos2 = new System.Windows.Forms.Button();
            this.txtDisChargePosVisionY3 = new System.Windows.Forms.TextBox();
            this.txtDisChargePosVisionU3 = new System.Windows.Forms.TextBox();
            this.txtDisChargeRobotU3 = new System.Windows.Forms.TextBox();
            this.btnTeachDiscVisPos3 = new System.Windows.Forms.Button();
            this.btnTeachDiscRobotPos3 = new System.Windows.Forms.Button();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ResetPick = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.flowChart108 = new NPSDK.NPFlowChart();
            this.flowChart109 = new NPSDK.NPFlowChart();
            this.flowChart110 = new NPSDK.NPFlowChart();
            this.flowChart111 = new NPSDK.NPFlowChart();
            this.flowChart112 = new NPSDK.NPFlowChart();
            this.flowChart113 = new NPSDK.NPFlowChart();
            this.flowChart114 = new NPSDK.NPFlowChart();
            this.flowChart115 = new NPSDK.NPFlowChart();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.dgv_H2_PickPos = new System.Windows.Forms.DataGridView();
            this.calibIndexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calibPixelXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calibPixelYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calibRobotXDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calibRobotYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnPickPos1AlogrithmEditing = new System.Windows.Forms.Button();
            this.btnPickPosStartCalib = new System.Windows.Forms.Button();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.txtPickPosRobotU3 = new System.Windows.Forms.TextBox();
            this.txtPickPosRobotX3 = new System.Windows.Forms.TextBox();
            this.txtPickPosVisionX3 = new System.Windows.Forms.TextBox();
            this.txtPickPosRobotY3 = new System.Windows.Forms.TextBox();
            this.txtPickPosRobotX2 = new System.Windows.Forms.TextBox();
            this.txtPickPosRobotY2 = new System.Windows.Forms.TextBox();
            this.txtPickPosRobotU2 = new System.Windows.Forms.TextBox();
            this.lb_PickVisU = new System.Windows.Forms.Label();
            this.lb_PickVisY = new System.Windows.Forms.Label();
            this.txtPickPosVisionX1 = new System.Windows.Forms.TextBox();
            this.txtPickPosVisionY1 = new System.Windows.Forms.TextBox();
            this.btnTeachPickVisPos = new System.Windows.Forms.Button();
            this.txtPickPosRobotX1 = new System.Windows.Forms.TextBox();
            this.txtPickPosRobotY1 = new System.Windows.Forms.TextBox();
            this.txtPickPosRobotU1 = new System.Windows.Forms.TextBox();
            this.btnTeachPickRobotPos = new System.Windows.Forms.Button();
            this.txtPickPosVisionU1 = new System.Windows.Forms.TextBox();
            this.lb_PickVisX = new System.Windows.Forms.Label();
            this.btnTeachPickRobotPos2 = new System.Windows.Forms.Button();
            this.txtPickPosVisionX2 = new System.Windows.Forms.TextBox();
            this.txtPickPosVisionU2 = new System.Windows.Forms.TextBox();
            this.txtPickPosVisionY2 = new System.Windows.Forms.TextBox();
            this.btnTeachPickVisPos2 = new System.Windows.Forms.Button();
            this.txtPickPosVisionY3 = new System.Windows.Forms.TextBox();
            this.txtPickPosVisionU3 = new System.Windows.Forms.TextBox();
            this.btnTeachPickVisPos3 = new System.Windows.Forms.Button();
            this.btnTeachPickRobotPos3 = new System.Windows.Forms.Button();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.flowChart92 = new NPSDK.NPFlowChart();
            this.flowChart93 = new NPSDK.NPFlowChart();
            this.flowChart94 = new NPSDK.NPFlowChart();
            this.flowChart95 = new NPSDK.NPFlowChart();
            this.flowChart97 = new NPSDK.NPFlowChart();
            this.flowChart98 = new NPSDK.NPFlowChart();
            this.flowChart99 = new NPSDK.NPFlowChart();
            this.flowChart100 = new NPSDK.NPFlowChart();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.cogRecDisp1 = new Cognex.VisionPro.CogRecordDisplay();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.MName = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tbMassage = new System.Windows.Forms.TextBox();
            this.tbNO = new System.Windows.Forms.TextBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.btndisConScan1 = new System.Windows.Forms.Button();
            this.btnConScan1 = new System.Windows.Forms.Button();
            this.btnStarScan1 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.button77 = new System.Windows.Forms.Button();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.myCheckBox3 = new tstCkBox.MyCheckBox();
            this.myCheckBox1 = new tstCkBox.MyCheckBox();
            this.myCheckBox2 = new tstCkBox.MyCheckBox();
            this.myCheckBox4 = new tstCkBox.MyCheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.ResetDischarge = new System.Windows.Forms.Button();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button25 = new System.Windows.Forms.Button();
            this.num_maxFY = new System.Windows.Forms.NumericUpDown();
            this.num_maxFX = new System.Windows.Forms.NumericUpDown();
            this.num_minFY = new System.Windows.Forms.NumericUpDown();
            this.num_minFX = new System.Windows.Forms.NumericUpDown();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.num_maxPY = new System.Windows.Forms.NumericUpDown();
            this.num_maxPX = new System.Windows.Forms.NumericUpDown();
            this.num_minPY = new System.Windows.Forms.NumericUpDown();
            this.num_minPX = new System.Windows.Forms.NumericUpDown();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnConnectResult = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnEnableRbt = new System.Windows.Forms.Button();
            this.Btn_ConnectRobot = new System.Windows.Forms.Button();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.txtReadData = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnWriteR = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.btnReadR = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnWritePR = new System.Windows.Forms.Button();
            this.txtReadPRX = new System.Windows.Forms.TextBox();
            this.numWritePR3 = new System.Windows.Forms.NumericUpDown();
            this.txtReadPRY = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.numWritePR2 = new System.Windows.Forms.NumericUpDown();
            this.txtReadPRZ = new System.Windows.Forms.TextBox();
            this.numWritePR1 = new System.Windows.Forms.NumericUpDown();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_PickPos = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tabControl7 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.button12 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.button17 = new System.Windows.Forms.Button();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.flowChart4 = new NPSDK.NPFlowChart();
            this.flowChart5 = new NPSDK.NPFlowChart();
            this.flowChart6 = new NPSDK.NPFlowChart();
            this.flowChart30 = new NPSDK.NPFlowChart();
            this.flowChart46 = new NPSDK.NPFlowChart();
            this.flowChart47 = new NPSDK.NPFlowChart();
            this.flowChart48 = new NPSDK.NPFlowChart();
            this.flowChart49 = new NPSDK.NPFlowChart();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.txtTaskValue = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.DownCCDExpTime = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.ScanExpTime = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.LiveExpTime = new System.Windows.Forms.NumericUpDown();
            this.DisChargeExpTime = new System.Windows.Forms.NumericUpDown();
            this.PickExpTime = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.chk_SaveImg = new tstCkBox.MyCheckBox();
            this.txtSavePath = new System.Windows.Forms.TextBox();
            this.chk_SaveJpgImg = new tstCkBox.MyCheckBox();
            this.btnPathSelect = new System.Windows.Forms.Button();
            this.dataColumn118 = new System.Data.DataColumn();
            this.dataColumn119 = new System.Data.DataColumn();
            this.dataColumn120 = new System.Data.DataColumn();
            this.dataTable6 = new System.Data.DataTable();
            this.dataColumn121 = new System.Data.DataColumn();
            this.dataColumn122 = new System.Data.DataColumn();
            this.dataColumn123 = new System.Data.DataColumn();
            this.dataColumn124 = new System.Data.DataColumn();
            this.dataColumn125 = new System.Data.DataColumn();
            this.dataColumn126 = new System.Data.DataColumn();
            this.dataColumn127 = new System.Data.DataColumn();
            this.dataColumn128 = new System.Data.DataColumn();
            this.dataColumn129 = new System.Data.DataColumn();
            this.dataColumn130 = new System.Data.DataColumn();
            this.dataColumn131 = new System.Data.DataColumn();
            this.dataColumn132 = new System.Data.DataColumn();
            this.dataColumn133 = new System.Data.DataColumn();
            this.dataColumn134 = new System.Data.DataColumn();
            this.dataColumn135 = new System.Data.DataColumn();
            this.dataColumn136 = new System.Data.DataColumn();
            this.dataColumn137 = new System.Data.DataColumn();
            this.dataColumn138 = new System.Data.DataColumn();
            this.dataColumn139 = new System.Data.DataColumn();
            this.dataColumn140 = new System.Data.DataColumn();
            this.dataColumn141 = new System.Data.DataColumn();
            this.dataColumn142 = new System.Data.DataColumn();
            this.dataColumn143 = new System.Data.DataColumn();
            this.dataColumn144 = new System.Data.DataColumn();
            this.dataColumn145 = new System.Data.DataColumn();
            this.dataColumn146 = new System.Data.DataColumn();
            this.dataColumn147 = new System.Data.DataColumn();
            this.dataColumn148 = new System.Data.DataColumn();
            this.dataColumn149 = new System.Data.DataColumn();
            this.dataColumn150 = new System.Data.DataColumn();
            this.dataColumn151 = new System.Data.DataColumn();
            this.dataColumn152 = new System.Data.DataColumn();
            this.label42 = new System.Windows.Forms.Label();
            this.lbR2SpeedRatio = new System.Windows.Forms.Label();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.label43 = new System.Windows.Forms.Label();
            this.dataColumn153 = new System.Data.DataColumn();
            this.dataColumn154 = new System.Data.DataColumn();
            this.dataColumn155 = new System.Data.DataColumn();
            this.dataColumn156 = new System.Data.DataColumn();
            this.dataColumn157 = new System.Data.DataColumn();
            this.dataColumn158 = new System.Data.DataColumn();
            this.dataColumn159 = new System.Data.DataColumn();
            this.dataColumn160 = new System.Data.DataColumn();
            this.dataColumn161 = new System.Data.DataColumn();
            this.dataColumn162 = new System.Data.DataColumn();
            this.dataColumn163 = new System.Data.DataColumn();
            this.dataColumn164 = new System.Data.DataColumn();
            this.dataColumn165 = new System.Data.DataColumn();
            this.dataColumn166 = new System.Data.DataColumn();
            this.dataColumn167 = new System.Data.DataColumn();
            this.dataColumn168 = new System.Data.DataColumn();
            this.dataColumn169 = new System.Data.DataColumn();
            this.tabControl8 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.RGP_0001 = new NPSDK.NPFlowChart();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel108 = new System.Windows.Forms.TableLayoutPanel();
            this.dataColumn170 = new System.Data.DataColumn();
            this.plMaintenance.SuspendLayout();
            this.plProductionSetting.SuspendLayout();
            this.plRecipeEditor.SuspendLayout();
            this.plFlowInitial.SuspendLayout();
            this.plFlowAuto.SuspendLayout();
            this.plMachineStatus.SuspendLayout();
            this.plMotionSetup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SettingData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RecipeData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable5)).BeginInit();
            this.tb_Robot1AlarmInfo.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogRecDisp_H5_Recipe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogRecordDisplay_Discharge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogRecordDisplay_Pickup)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_H2_PickPos)).BeginInit();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogRecDisp1)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox16.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxFY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxFX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minFY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minFX)).BeginInit();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxPY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxPX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minPY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minPX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWritePR3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWritePR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWritePR1)).BeginInit();
            this.tabControl7.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DownCCDExpTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScanExpTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LiveExpTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisChargeExpTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PickExpTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            this.tabControl8.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel108.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Size = new System.Drawing.Size(796, 1480);
            // 
            // plMaintenance
            // 
            this.plMaintenance.Controls.Add(this.tabControl4);
            this.plMaintenance.Margin = new System.Windows.Forms.Padding(2);
            this.plMaintenance.Size = new System.Drawing.Size(788, 1437);
            // 
            // plProductionSetting
            // 
            this.plProductionSetting.Controls.Add(this.tableLayoutPanel108);
            this.plProductionSetting.Margin = new System.Windows.Forms.Padding(1);
            this.plProductionSetting.Size = new System.Drawing.Size(672, 1437);
            // 
            // plRecipeEditor
            // 
            this.plRecipeEditor.Controls.Add(this.tabControl7);
            this.plRecipeEditor.Controls.Add(this.groupBox9);
            this.plRecipeEditor.Controls.Add(this.label36);
            this.plRecipeEditor.Controls.Add(this.txt_PickPos);
            this.plRecipeEditor.Controls.Add(this.button2);
            this.plRecipeEditor.Margin = new System.Windows.Forms.Padding(1);
            this.plRecipeEditor.Size = new System.Drawing.Size(672, 1437);
            // 
            // plFlowInitial
            // 
            this.plFlowInitial.Controls.Add(this.tabControl8);
            this.plFlowInitial.Margin = new System.Windows.Forms.Padding(1);
            this.plFlowInitial.Size = new System.Drawing.Size(788, 1437);
            // 
            // plFlowAuto
            // 
            this.plFlowAuto.Controls.Add(this.tabControl2);
            this.plFlowAuto.Margin = new System.Windows.Forms.Padding(2);
            this.plFlowAuto.Size = new System.Drawing.Size(672, 1437);
            // 
            // plMachineStatus
            // 
            this.plMachineStatus.Controls.Add(this.tableLayoutPanel14);
            this.plMachineStatus.Controls.Add(this.button28);
            this.plMachineStatus.Controls.Add(this.textBox24);
            this.plMachineStatus.Controls.Add(this.button27);
            this.plMachineStatus.Controls.Add(this.CTtime2);
            this.plMachineStatus.Controls.Add(this.label78);
            this.plMachineStatus.Controls.Add(this.CTtime1);
            this.plMachineStatus.Controls.Add(this.label77);
            this.plMachineStatus.Controls.Add(this.label63);
            this.plMachineStatus.Controls.Add(this.txtBarcodeResult2);
            this.plMachineStatus.Controls.Add(this.label4);
            this.plMachineStatus.Controls.Add(this.txtBarcodeResult);
            this.plMachineStatus.Margin = new System.Windows.Forms.Padding(1);
            this.plMachineStatus.Size = new System.Drawing.Size(672, 1437);
            // 
            // plMotionSetup
            // 
            this.plMotionSetup.Controls.Add(this.label42);
            this.plMotionSetup.Controls.Add(this.lbR2SpeedRatio);
            this.plMotionSetup.Controls.Add(this.trackBar2);
            this.plMotionSetup.Controls.Add(this.label43);
            this.plMotionSetup.Margin = new System.Windows.Forms.Padding(1);
            this.plMotionSetup.Size = new System.Drawing.Size(672, 1437);
            // 
            // plMotorControl
            // 
            this.plMotorControl.Margin = new System.Windows.Forms.Padding(1);
            this.plMotorControl.Size = new System.Drawing.Size(672, 1437);
            // 
            // SettingData
            // 
            this.SettingData.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1});
            // 
            // MSet
            // 
            this.MSet.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn69,
            this.dataColumn101,
            this.dataColumn102,
            this.dataColumn103,
            this.dataColumn104,
            this.dataColumn105,
            this.dataColumn148,
            this.dataColumn149,
            this.dataColumn150,
            this.dataColumn151,
            this.dataColumn152});
            // 
            // PSet
            // 
            this.PSet.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn91,
            this.dataColumn92,
            this.dataColumn93,
            this.dataColumn118,
            this.dataColumn119,
            this.dataColumn120,
            this.dataColumn144,
            this.dataColumn145,
            this.dataColumn146,
            this.dataColumn153,
            this.dataColumn154,
            this.dataColumn155,
            this.dataColumn160});
            // 
            // RecipeData
            // 
            this.RecipeData.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable2,
            this.dataTable3,
            this.dataTable4,
            this.dataTable5,
            this.dataTable6});
            // 
            // RSet
            // 
            this.RSet.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn44,
            this.dataColumn45,
            this.dataColumn18,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27,
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36,
            this.dataColumn37,
            this.dataColumn46,
            this.dataColumn47,
            this.dataColumn53,
            this.dataColumn54,
            this.dataColumn55,
            this.dataColumn56,
            this.dataColumn57,
            this.dataColumn58,
            this.dataColumn59,
            this.dataColumn60,
            this.dataColumn61,
            this.dataColumn62,
            this.dataColumn63,
            this.dataColumn64,
            this.dataColumn65,
            this.dataColumn66,
            this.dataColumn67,
            this.dataColumn68,
            this.dataColumn70,
            this.dataColumn71,
            this.dataColumn72,
            this.dataColumn73,
            this.dataColumn79,
            this.dataColumn80,
            this.dataColumn81,
            this.dataColumn82,
            this.dataColumn83,
            this.dataColumn84,
            this.dataColumn85,
            this.dataColumn86,
            this.dataColumn87,
            this.dataColumn88,
            this.dataColumn89,
            this.dataColumn90,
            this.dataColumn94,
            this.dataColumn95,
            this.dataColumn96,
            this.dataColumn97,
            this.dataColumn98,
            this.dataColumn99,
            this.dataColumn100,
            this.dataColumn106,
            this.dataColumn107,
            this.dataColumn108,
            this.dataColumn109,
            this.dataColumn110,
            this.dataColumn111,
            this.dataColumn112,
            this.dataColumn113,
            this.dataColumn114,
            this.dataColumn115,
            this.dataColumn116,
            this.dataColumn117,
            this.dataColumn126,
            this.dataColumn127,
            this.dataColumn128,
            this.dataColumn129,
            this.dataColumn130,
            this.dataColumn131,
            this.dataColumn132,
            this.dataColumn133,
            this.dataColumn134,
            this.dataColumn135,
            this.dataColumn136,
            this.dataColumn137,
            this.dataColumn138,
            this.dataColumn139,
            this.dataColumn140,
            this.dataColumn141,
            this.dataColumn142,
            this.dataColumn143,
            this.dataColumn147,
            this.dataColumn156,
            this.dataColumn157,
            this.dataColumn158,
            this.dataColumn159,
            this.dataColumn161,
            this.dataColumn162,
            this.dataColumn163,
            this.dataColumn164,
            this.dataColumn165,
            this.dataColumn166,
            this.dataColumn167,
            this.dataColumn168,
            this.dataColumn169,
            this.dataColumn170});
            // 
            // IB_FeederAlarm
            // 
            this.IB_FeederAlarm.BackColor = System.Drawing.Color.White;
            this.IB_FeederAlarm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_FeederAlarm.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_FeederAlarm.FieldName = null;
            this.IB_FeederAlarm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_FeederAlarm.IP = null;
            this.IB_FeederAlarm.Location = new System.Drawing.Point(61, 150);
            this.IB_FeederAlarm.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_FeederAlarm.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_FeederAlarm.Name = "IB_FeederAlarm";
            this.IB_FeederAlarm.Port = "00203";
            this.IB_FeederAlarm.ReverseState = false;
            this.IB_FeederAlarm.Size = new System.Drawing.Size(297, 39);
            this.IB_FeederAlarm.TabIndex = 0;
            this.IB_FeederAlarm.Text = "FeederAlarm";
            this.IB_FeederAlarm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_FeederInPlace
            // 
            this.IB_FeederInPlace.BackColor = System.Drawing.Color.White;
            this.IB_FeederInPlace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_FeederInPlace.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_FeederInPlace.FieldName = null;
            this.IB_FeederInPlace.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_FeederInPlace.IP = null;
            this.IB_FeederInPlace.Location = new System.Drawing.Point(61, 202);
            this.IB_FeederInPlace.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_FeederInPlace.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_FeederInPlace.Name = "IB_FeederInPlace";
            this.IB_FeederInPlace.Port = "00204";
            this.IB_FeederInPlace.ReverseState = false;
            this.IB_FeederInPlace.Size = new System.Drawing.Size(297, 39);
            this.IB_FeederInPlace.TabIndex = 2;
            this.IB_FeederInPlace.Text = "FeederlnPlace";
            this.IB_FeederInPlace.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_FeederEmergencyStop
            // 
            this.IB_FeederEmergencyStop.BackColor = System.Drawing.Color.White;
            this.IB_FeederEmergencyStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_FeederEmergencyStop.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_FeederEmergencyStop.FieldName = null;
            this.IB_FeederEmergencyStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_FeederEmergencyStop.IP = null;
            this.IB_FeederEmergencyStop.Location = new System.Drawing.Point(61, 306);
            this.IB_FeederEmergencyStop.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_FeederEmergencyStop.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_FeederEmergencyStop.Name = "IB_FeederEmergencyStop";
            this.IB_FeederEmergencyStop.Port = "00206";
            this.IB_FeederEmergencyStop.ReverseState = false;
            this.IB_FeederEmergencyStop.Size = new System.Drawing.Size(297, 39);
            this.IB_FeederEmergencyStop.TabIndex = 3;
            this.IB_FeederEmergencyStop.Text = "FeederEmergencyStop";
            this.IB_FeederEmergencyStop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_FeederReady
            // 
            this.IB_FeederReady.BackColor = System.Drawing.Color.White;
            this.IB_FeederReady.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_FeederReady.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_FeederReady.FieldName = null;
            this.IB_FeederReady.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_FeederReady.IP = null;
            this.IB_FeederReady.Location = new System.Drawing.Point(61, 98);
            this.IB_FeederReady.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_FeederReady.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_FeederReady.Name = "IB_FeederReady";
            this.IB_FeederReady.Port = "00202";
            this.IB_FeederReady.ReverseState = false;
            this.IB_FeederReady.Size = new System.Drawing.Size(297, 39);
            this.IB_FeederReady.TabIndex = 4;
            this.IB_FeederReady.Text = "FeederReady";
            this.IB_FeederReady.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_FeederLack
            // 
            this.IB_FeederLack.BackColor = System.Drawing.Color.White;
            this.IB_FeederLack.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_FeederLack.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_FeederLack.FieldName = null;
            this.IB_FeederLack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_FeederLack.IP = null;
            this.IB_FeederLack.Location = new System.Drawing.Point(61, 254);
            this.IB_FeederLack.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_FeederLack.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_FeederLack.Name = "IB_FeederLack";
            this.IB_FeederLack.Port = "00205";
            this.IB_FeederLack.ReverseState = false;
            this.IB_FeederLack.Size = new System.Drawing.Size(297, 39);
            this.IB_FeederLack.TabIndex = 5;
            this.IB_FeederLack.Text = "FeederLack";
            this.IB_FeederLack.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_FeederAlmReset
            // 
            this.OB_FeederAlmReset.BackColor = System.Drawing.Color.White;
            this.OB_FeederAlmReset.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_FeederAlmReset.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_FeederAlmReset.FieldName = null;
            this.OB_FeederAlmReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_FeederAlmReset.IP = null;
            this.OB_FeederAlmReset.Location = new System.Drawing.Point(41, 98);
            this.OB_FeederAlmReset.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_FeederAlmReset.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_FeederAlmReset.Name = "OB_FeederAlmReset";
            this.OB_FeederAlmReset.Port = "00910";
            this.OB_FeederAlmReset.ReverseState = false;
            this.OB_FeederAlmReset.Size = new System.Drawing.Size(297, 39);
            this.OB_FeederAlmReset.TabIndex = 13;
            this.OB_FeederAlmReset.Text = "FeederAlarmReset";
            this.OB_FeederAlmReset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_FeederSafetySignal
            // 
            this.OB_FeederSafetySignal.BackColor = System.Drawing.Color.White;
            this.OB_FeederSafetySignal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_FeederSafetySignal.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_FeederSafetySignal.FieldName = null;
            this.OB_FeederSafetySignal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_FeederSafetySignal.IP = null;
            this.OB_FeederSafetySignal.Location = new System.Drawing.Point(41, 150);
            this.OB_FeederSafetySignal.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_FeederSafetySignal.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_FeederSafetySignal.Name = "OB_FeederSafetySignal";
            this.OB_FeederSafetySignal.Port = "00912";
            this.OB_FeederSafetySignal.ReverseState = false;
            this.OB_FeederSafetySignal.Size = new System.Drawing.Size(297, 39);
            this.OB_FeederSafetySignal.TabIndex = 14;
            this.OB_FeederSafetySignal.Text = "FeederSafetySignal";
            this.OB_FeederSafetySignal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_FeederEmgStop
            // 
            this.OB_FeederEmgStop.BackColor = System.Drawing.Color.White;
            this.OB_FeederEmgStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_FeederEmgStop.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_FeederEmgStop.FieldName = null;
            this.OB_FeederEmgStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_FeederEmgStop.IP = null;
            this.OB_FeederEmgStop.Location = new System.Drawing.Point(41, 202);
            this.OB_FeederEmgStop.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_FeederEmgStop.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_FeederEmgStop.Name = "OB_FeederEmgStop";
            this.OB_FeederEmgStop.Port = "00913";
            this.OB_FeederEmgStop.ReverseState = false;
            this.OB_FeederEmgStop.Size = new System.Drawing.Size(297, 39);
            this.OB_FeederEmgStop.TabIndex = 15;
            this.OB_FeederEmgStop.Text = "FeederEmgStop";
            this.OB_FeederEmgStop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_FeederStart
            // 
            this.OB_FeederStart.BackColor = System.Drawing.Color.White;
            this.OB_FeederStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_FeederStart.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_FeederStart.FieldName = null;
            this.OB_FeederStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_FeederStart.IP = null;
            this.OB_FeederStart.Location = new System.Drawing.Point(41, 254);
            this.OB_FeederStart.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_FeederStart.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_FeederStart.Name = "OB_FeederStart";
            this.OB_FeederStart.Port = "00909";
            this.OB_FeederStart.ReverseState = false;
            this.OB_FeederStart.Size = new System.Drawing.Size(297, 39);
            this.OB_FeederStart.TabIndex = 16;
            this.OB_FeederStart.Text = "FeederStart";
            this.OB_FeederStart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_FeederCompleted
            // 
            this.OB_FeederCompleted.BackColor = System.Drawing.Color.White;
            this.OB_FeederCompleted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_FeederCompleted.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_FeederCompleted.FieldName = null;
            this.OB_FeederCompleted.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_FeederCompleted.IP = null;
            this.OB_FeederCompleted.Location = new System.Drawing.Point(41, 306);
            this.OB_FeederCompleted.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_FeederCompleted.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_FeederCompleted.Name = "OB_FeederCompleted";
            this.OB_FeederCompleted.Port = "00911";
            this.OB_FeederCompleted.ReverseState = false;
            this.OB_FeederCompleted.Size = new System.Drawing.Size(297, 39);
            this.OB_FeederCompleted.TabIndex = 17;
            this.OB_FeederCompleted.Text = "FeederCompleted";
            this.OB_FeederCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tmRefresh
            // 
            this.tmRefresh.Enabled = true;
            this.tmRefresh.Interval = 500;
            this.tmRefresh.Tick += new System.EventHandler(this.tmRefresh_Tick);
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "WorkSpeedX";
            this.dataColumn1.DataType = typeof(double);
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "WorkSpeedY";
            this.dataColumn2.DataType = typeof(double);
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "AccelerationX";
            this.dataColumn3.DataType = typeof(double);
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "AccelerationY";
            this.dataColumn4.DataType = typeof(double);
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "DecelerationX";
            this.dataColumn5.DataType = typeof(double);
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "DecelerationY";
            this.dataColumn6.DataType = typeof(double);
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "FaceID_Enable";
            this.dataColumn7.DataType = typeof(bool);
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "FaceID_SerialPort";
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "FaceID_BaudRate";
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn13});
            this.dataTable1.TableName = "VisCalib";
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "PixelX";
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "PixelY";
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "RobotX";
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "RobotY";
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "RobotPoint1";
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "RobotPoint2";
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "ScannerIP";
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "ScannerPort";
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "H1_Fid1RefX";
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "H1_Fid1RefY";
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "H1_Fid2RefX";
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "H1_Fid2RefY";
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "H1_Fid1RefA";
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "H1_Fid2RefA";
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "ScrewDriverIP";
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "CurrentN";
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "PCN";
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "StationN";
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "NN";
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "ON";
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "LineN";
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "PN";
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "Length";
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "MN";
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "PS";
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "cm";
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "ScanIGBTIP";
            // 
            // dataColumn37
            // 
            this.dataColumn37.ColumnName = "ScanIGBTPORT";
            // 
            // dataTable2
            // 
            this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn38,
            this.dataColumn39});
            this.dataTable2.TableName = "Route";
            // 
            // dataColumn38
            // 
            this.dataColumn38.ColumnName = "PositionX";
            this.dataColumn38.DataType = typeof(double);
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "PositionY";
            this.dataColumn39.DataType = typeof(double);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(30, 767);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(127, 35);
            this.button28.TabIndex = 150;
            this.button28.Text = "Query Screw";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Visible = false;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(163, 770);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(162, 28);
            this.textBox24.TabIndex = 149;
            this.textBox24.Visible = false;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(627, 731);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(111, 36);
            this.button27.TabIndex = 148;
            this.button27.Text = "Chinese / English";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Visible = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // CTtime2
            // 
            this.CTtime2.Location = new System.Drawing.Point(452, 731);
            this.CTtime2.Name = "CTtime2";
            this.CTtime2.Size = new System.Drawing.Size(162, 28);
            this.CTtime2.TabIndex = 147;
            this.CTtime2.Visible = false;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(343, 738);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(124, 24);
            this.label78.TabIndex = 146;
            this.label78.Text = "SCREW  CT：";
            this.label78.Visible = false;
            // 
            // CTtime1
            // 
            this.CTtime1.Location = new System.Drawing.Point(163, 738);
            this.CTtime1.Name = "CTtime1";
            this.CTtime1.Size = new System.Drawing.Size(162, 28);
            this.CTtime1.TabIndex = 145;
            this.CTtime1.Visible = false;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(34, 741);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(111, 24);
            this.label77.TabIndex = 144;
            this.label77.Text = "LASER CT：";
            this.label77.Visible = false;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(34, 696);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(105, 24);
            this.label63.TabIndex = 143;
            this.label63.Text = "IGBTcode：";
            this.label63.Visible = false;
            // 
            // txtBarcodeResult2
            // 
            this.txtBarcodeResult2.Location = new System.Drawing.Point(163, 692);
            this.txtBarcodeResult2.Name = "txtBarcodeResult2";
            this.txtBarcodeResult2.Size = new System.Drawing.Size(578, 28);
            this.txtBarcodeResult2.TabIndex = 142;
            this.txtBarcodeResult2.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 648);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 24);
            this.label4.TabIndex = 140;
            this.label4.Text = "Barcode：";
            this.label4.Visible = false;
            // 
            // txtBarcodeResult
            // 
            this.txtBarcodeResult.Location = new System.Drawing.Point(163, 648);
            this.txtBarcodeResult.Name = "txtBarcodeResult";
            this.txtBarcodeResult.Size = new System.Drawing.Size(578, 28);
            this.txtBarcodeResult.TabIndex = 139;
            this.txtBarcodeResult.Visible = false;
            // 
            // dataTable3
            // 
            this.dataTable3.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn40,
            this.dataColumn41,
            this.dataColumn42,
            this.dataColumn43});
            this.dataTable3.TableName = "tb_H1_WorkPost";
            // 
            // dataColumn40
            // 
            this.dataColumn40.AllowDBNull = false;
            this.dataColumn40.ColumnName = "X";
            this.dataColumn40.DataType = typeof(double);
            // 
            // dataColumn41
            // 
            this.dataColumn41.AllowDBNull = false;
            this.dataColumn41.ColumnName = "Y";
            this.dataColumn41.DataType = typeof(double);
            // 
            // dataColumn42
            // 
            this.dataColumn42.AllowDBNull = false;
            this.dataColumn42.ColumnName = "Z";
            this.dataColumn42.DataType = typeof(double);
            // 
            // dataColumn43
            // 
            this.dataColumn43.ColumnName = "Annotation";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.IB_FeederAlarm);
            this.groupBox1.Controls.Add(this.IB_FeederLack);
            this.groupBox1.Controls.Add(this.IB_FeederReady);
            this.groupBox1.Controls.Add(this.IB_FeederEmergencyStop);
            this.groupBox1.Controls.Add(this.IB_FeederInPlace);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(2, 2);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(387, 1392);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Feeder Input";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.OB_FeederAlmReset);
            this.groupBox6.Controls.Add(this.OB_FeederCompleted);
            this.groupBox6.Controls.Add(this.OB_FeederStart);
            this.groupBox6.Controls.Add(this.OB_FeederEmgStop);
            this.groupBox6.Controls.Add(this.OB_FeederSafetySignal);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(393, 2);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(379, 1392);
            this.groupBox6.TabIndex = 42;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Feeder Output";
            // 
            // dataColumn44
            // 
            this.dataColumn44.ColumnName = "Scanner2IP";
            // 
            // dataColumn45
            // 
            this.dataColumn45.ColumnName = "Scanner2Port";
            // 
            // dataColumn46
            // 
            this.dataColumn46.ColumnName = "LaserIP";
            // 
            // dataColumn47
            // 
            this.dataColumn47.ColumnName = "LaserPort";
            // 
            // dataTable4
            // 
            this.dataTable4.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn48,
            this.dataColumn49,
            this.dataColumn50,
            this.dataColumn51,
            this.dataColumn52});
            this.dataTable4.TableName = "R1_PickVisCalib";
            // 
            // dataColumn48
            // 
            this.dataColumn48.ColumnName = "Calib_Index";
            this.dataColumn48.DataType = typeof(int);
            // 
            // dataColumn49
            // 
            this.dataColumn49.ColumnName = "Calib_PixelX";
            this.dataColumn49.DataType = typeof(double);
            // 
            // dataColumn50
            // 
            this.dataColumn50.ColumnName = "Calib_PixelY";
            this.dataColumn50.DataType = typeof(double);
            // 
            // dataColumn51
            // 
            this.dataColumn51.ColumnName = "Calib_RobotX";
            this.dataColumn51.DataType = typeof(double);
            // 
            // dataColumn52
            // 
            this.dataColumn52.ColumnName = "Calib_RobotY";
            this.dataColumn52.DataType = typeof(double);
            // 
            // dataColumn53
            // 
            this.dataColumn53.ColumnName = "PickTeachVisX";
            this.dataColumn53.DataType = typeof(double);
            // 
            // dataColumn54
            // 
            this.dataColumn54.ColumnName = "PickTeachVisY";
            this.dataColumn54.DataType = typeof(double);
            // 
            // dataColumn55
            // 
            this.dataColumn55.ColumnName = "PickTeachVisU";
            this.dataColumn55.DataType = typeof(double);
            // 
            // dataColumn56
            // 
            this.dataColumn56.ColumnName = "PickTeachRobotX";
            this.dataColumn56.DataType = typeof(double);
            // 
            // dataColumn57
            // 
            this.dataColumn57.ColumnName = "PickTeachRobotY";
            this.dataColumn57.DataType = typeof(double);
            // 
            // dataColumn58
            // 
            this.dataColumn58.ColumnName = "PickTeachRobotU";
            this.dataColumn58.DataType = typeof(double);
            // 
            // dataColumn59
            // 
            this.dataColumn59.ColumnName = "PickTeachVisX2";
            this.dataColumn59.DataType = typeof(double);
            // 
            // dataColumn60
            // 
            this.dataColumn60.ColumnName = "PickTeachVisY2";
            this.dataColumn60.DataType = typeof(double);
            // 
            // dataColumn61
            // 
            this.dataColumn61.ColumnName = "PickTeachVisU2";
            this.dataColumn61.DataType = typeof(double);
            // 
            // dataColumn62
            // 
            this.dataColumn62.ColumnName = "PickTeachRobotX2";
            this.dataColumn62.DataType = typeof(double);
            // 
            // dataColumn63
            // 
            this.dataColumn63.ColumnName = "PickTeachRobotY2";
            this.dataColumn63.DataType = typeof(double);
            // 
            // dataColumn64
            // 
            this.dataColumn64.ColumnName = "PickTeachRobotU2";
            this.dataColumn64.DataType = typeof(double);
            // 
            // dataColumn65
            // 
            this.dataColumn65.ColumnName = "PickPosIndex";
            this.dataColumn65.DataType = typeof(short);
            // 
            // dataColumn66
            // 
            this.dataColumn66.ColumnName = "HeightHLim";
            this.dataColumn66.DataType = typeof(double);
            // 
            // dataColumn67
            // 
            this.dataColumn67.ColumnName = "HeightLLim";
            this.dataColumn67.DataType = typeof(double);
            // 
            // dataColumn68
            // 
            this.dataColumn68.ColumnName = "PressMax";
            this.dataColumn68.DataType = typeof(double);
            // 
            // dataColumn69
            // 
            this.dataColumn69.ColumnName = "ComPort";
            // 
            // dataColumn70
            // 
            this.dataColumn70.ColumnName = "COMIndex";
            this.dataColumn70.DataType = typeof(int);
            // 
            // dataColumn71
            // 
            this.dataColumn71.ColumnName = "PressMin";
            this.dataColumn71.DataType = typeof(double);
            // 
            // dataColumn72
            // 
            this.dataColumn72.ColumnName = "PCBAMin";
            this.dataColumn72.DataType = typeof(double);
            // 
            // dataColumn73
            // 
            this.dataColumn73.ColumnName = "PCBAMax";
            this.dataColumn73.DataType = typeof(double);
            // 
            // dataTable5
            // 
            this.dataTable5.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn74,
            this.dataColumn75,
            this.dataColumn76,
            this.dataColumn77,
            this.dataColumn78});
            this.dataTable5.TableName = "R1_DischargeVisCalib";
            // 
            // dataColumn74
            // 
            this.dataColumn74.ColumnName = "Calib_Index";
            this.dataColumn74.DataType = typeof(int);
            // 
            // dataColumn75
            // 
            this.dataColumn75.ColumnName = "Calib_PixelX";
            this.dataColumn75.DataType = typeof(double);
            // 
            // dataColumn76
            // 
            this.dataColumn76.ColumnName = "Calib_PixelY";
            this.dataColumn76.DataType = typeof(double);
            // 
            // dataColumn77
            // 
            this.dataColumn77.ColumnName = "Calib_RobotX";
            this.dataColumn77.DataType = typeof(double);
            // 
            // dataColumn78
            // 
            this.dataColumn78.ColumnName = "Calib_RobotY";
            this.dataColumn78.DataType = typeof(double);
            // 
            // dataColumn79
            // 
            this.dataColumn79.ColumnName = "DischargeTeachVisX";
            this.dataColumn79.DataType = typeof(double);
            // 
            // dataColumn80
            // 
            this.dataColumn80.ColumnName = "DischargeTeachVisY";
            this.dataColumn80.DataType = typeof(double);
            // 
            // dataColumn81
            // 
            this.dataColumn81.ColumnName = "DischargeTeachVisU";
            this.dataColumn81.DataType = typeof(double);
            // 
            // dataColumn82
            // 
            this.dataColumn82.ColumnName = "DischargeTeachRobotX";
            this.dataColumn82.DataType = typeof(double);
            // 
            // dataColumn83
            // 
            this.dataColumn83.ColumnName = "DischargeTeachRobotY";
            this.dataColumn83.DataType = typeof(double);
            // 
            // dataColumn84
            // 
            this.dataColumn84.ColumnName = "DischargeTeachRobotU";
            this.dataColumn84.DataType = typeof(double);
            // 
            // dataColumn85
            // 
            this.dataColumn85.ColumnName = "DischargeTeachVisX2";
            this.dataColumn85.DataType = typeof(double);
            // 
            // dataColumn86
            // 
            this.dataColumn86.ColumnName = "DischargeTeachVisY2";
            this.dataColumn86.DataType = typeof(double);
            // 
            // dataColumn87
            // 
            this.dataColumn87.ColumnName = "DischargeTeachVisU2";
            this.dataColumn87.DataType = typeof(double);
            // 
            // dataColumn88
            // 
            this.dataColumn88.ColumnName = "DischargeTeachRobotX2";
            this.dataColumn88.DataType = typeof(double);
            // 
            // dataColumn89
            // 
            this.dataColumn89.ColumnName = "DischargeTeachRobotY2";
            this.dataColumn89.DataType = typeof(double);
            // 
            // dataColumn90
            // 
            this.dataColumn90.ColumnName = "DischargeTeachRobotU2";
            this.dataColumn90.DataType = typeof(double);
            // 
            // dataColumn91
            // 
            this.dataColumn91.ColumnName = "TarslinkPath";
            // 
            // dataColumn92
            // 
            this.dataColumn92.ColumnName = "DataSavePath";
            // 
            // dataColumn93
            // 
            this.dataColumn93.ColumnName = "JabilSavePath";
            // 
            // dataColumn94
            // 
            this.dataColumn94.ColumnName = "TN";
            // 
            // dataColumn95
            // 
            this.dataColumn95.ColumnName = "TISEnable";
            this.dataColumn95.DataType = typeof(bool);
            // 
            // dataColumn96
            // 
            this.dataColumn96.ColumnName = "JabilSaveEnable";
            this.dataColumn96.DataType = typeof(bool);
            // 
            // dataColumn97
            // 
            this.dataColumn97.ColumnName = "TISPath";
            // 
            // tb_Robot1AlarmInfo
            // 
            this.tb_Robot1AlarmInfo.Controls.Add(this.flowChart101);
            this.tb_Robot1AlarmInfo.Controls.Add(this.flowChart102);
            this.tb_Robot1AlarmInfo.Controls.Add(this.fc_ReflashR1AlramInfo);
            this.tb_Robot1AlarmInfo.Location = new System.Drawing.Point(4, 31);
            this.tb_Robot1AlarmInfo.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tb_Robot1AlarmInfo.Name = "tb_Robot1AlarmInfo";
            this.tb_Robot1AlarmInfo.Size = new System.Drawing.Size(780, 1402);
            this.tb_Robot1AlarmInfo.TabIndex = 11;
            this.tb_Robot1AlarmInfo.Text = "Robot alarm message";
            this.tb_Robot1AlarmInfo.UseVisualStyleBackColor = true;
            // fcNgMes
            // 
            this.fcNgMes.AlarmCode = "";
            this.fcNgMes.ArrowSeparation = 20;
            this.fcNgMes.ArrowsWidth = 1;
            this.fcNgMes.BackColor = System.Drawing.Color.White;
            this.fcNgMes.bClearTrace = false;
            this.fcNgMes.bIsLastFlowChart = false;
            this.fcNgMes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fcNgMes.bSkip = false;
            this.fcNgMes.bStepByStepMode = false;
            this.fcNgMes.CASE1 = null;
            this.fcNgMes.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fcNgMes.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fcNgMes.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.CASE2 = null;
            this.fcNgMes.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fcNgMes.CASE2Color = System.Drawing.Color.Red;
            this.fcNgMes.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.CASE3 = null;
            this.fcNgMes.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fcNgMes.CASE3Color = System.Drawing.Color.Blue;
            this.fcNgMes.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.DefaultColor = System.Drawing.Color.White;
            this.fcNgMes.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fcNgMes.ExecutedColor = System.Drawing.Color.LightGray;
            this.fcNgMes.ExecutingColor = System.Drawing.Color.Lime;
            this.fcNgMes.Location = new System.Drawing.Point(943, 822);
            this.fcNgMes.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fcNgMes.menuOpening = false;
            this.fcNgMes.Name = "fcNgMes";
            this.fcNgMes.NEXT = this.flowChart26;
            this.fcNgMes.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fcNgMes.NEXTColor = System.Drawing.Color.Black;
            this.fcNgMes.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fcNgMes.Size = new System.Drawing.Size(132, 50);
            this.fcNgMes.SkipColor = System.Drawing.Color.Yellow;
            this.fcNgMes.SubFlowChart = null;
            this.fcNgMes.TabIndex = 500;
            this.fcNgMes.Text = "MES NG -> NG buffer";
            this.fcNgMes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fcNgMes.TimeOut = 60000;
            this.fcNgMes.TimeoutColor = System.Drawing.Color.Red;
            this.fcNgMes.tmrTimeOut = null;
            this.fcNgMes.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fcNgMes_FlowRun);
            // 
            // 
            // flowChart101
            // 
            this.flowChart101.AlarmCode = "";
            this.flowChart101.ArrowSeparation = 20;
            this.flowChart101.ArrowsWidth = 1;
            this.flowChart101.BackColor = System.Drawing.Color.White;
            this.flowChart101.bClearTrace = false;
            this.flowChart101.bIsLastFlowChart = false;
            this.flowChart101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart101.bSkip = false;
            this.flowChart101.bStepByStepMode = false;
            this.flowChart101.CASE1 = null;
            this.flowChart101.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart101.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart101.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart101.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart101.CASE2 = null;
            this.flowChart101.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart101.CASE2Color = System.Drawing.Color.Red;
            this.flowChart101.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart101.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart101.CASE3 = null;
            this.flowChart101.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart101.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart101.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart101.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart101.DefaultColor = System.Drawing.Color.White;
            this.flowChart101.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart101.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart101.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart101.Location = new System.Drawing.Point(59, 432);
            this.flowChart101.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart101.menuOpening = false;
            this.flowChart101.Name = "flowChart101";
            this.flowChart101.NEXT = this.fc_ReflashR1AlramInfo;
            this.flowChart101.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart101.NEXTColor = System.Drawing.Color.Black;
            this.flowChart101.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart101.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart101.Size = new System.Drawing.Size(160, 48);
            this.flowChart101.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart101.SubFlowChart = null;
            this.flowChart101.TabIndex = 12;
            this.flowChart101.Text = "NULL";
            this.flowChart101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart101.TimeOut = 10000;
            this.flowChart101.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart101.tmrTimeOut = null;
            this.flowChart101.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart101_FlowRun);
            // 
            // fc_ReflashR1AlramInfo
            // 
            this.fc_ReflashR1AlramInfo.AlarmCode = "";
            this.fc_ReflashR1AlramInfo.ArrowSeparation = 20;
            this.fc_ReflashR1AlramInfo.ArrowsWidth = 1;
            this.fc_ReflashR1AlramInfo.BackColor = System.Drawing.Color.White;
            this.fc_ReflashR1AlramInfo.bClearTrace = false;
            this.fc_ReflashR1AlramInfo.bIsLastFlowChart = false;
            this.fc_ReflashR1AlramInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_ReflashR1AlramInfo.bSkip = false;
            this.fc_ReflashR1AlramInfo.bStepByStepMode = false;
            this.fc_ReflashR1AlramInfo.CASE1 = null;
            this.fc_ReflashR1AlramInfo.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ReflashR1AlramInfo.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_ReflashR1AlramInfo.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.CASE2 = null;
            this.fc_ReflashR1AlramInfo.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ReflashR1AlramInfo.CASE2Color = System.Drawing.Color.Red;
            this.fc_ReflashR1AlramInfo.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.CASE3 = null;
            this.fc_ReflashR1AlramInfo.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ReflashR1AlramInfo.CASE3Color = System.Drawing.Color.Blue;
            this.fc_ReflashR1AlramInfo.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.DefaultColor = System.Drawing.Color.White;
            this.fc_ReflashR1AlramInfo.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_ReflashR1AlramInfo.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_ReflashR1AlramInfo.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_ReflashR1AlramInfo.Location = new System.Drawing.Point(266, 163);
            this.fc_ReflashR1AlramInfo.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_ReflashR1AlramInfo.menuOpening = false;
            this.fc_ReflashR1AlramInfo.Name = "fc_ReflashR1AlramInfo";
            this.fc_ReflashR1AlramInfo.NEXT = this.flowChart102;
            this.fc_ReflashR1AlramInfo.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ReflashR1AlramInfo.NEXTColor = System.Drawing.Color.Black;
            this.fc_ReflashR1AlramInfo.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ReflashR1AlramInfo.Size = new System.Drawing.Size(275, 48);
            this.fc_ReflashR1AlramInfo.SkipColor = System.Drawing.Color.Yellow;
            this.fc_ReflashR1AlramInfo.SubFlowChart = null;
            this.fc_ReflashR1AlramInfo.TabIndex = 14;
            this.fc_ReflashR1AlramInfo.Text = "R1 refresh alarm";
            this.fc_ReflashR1AlramInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_ReflashR1AlramInfo.TimeOut = 10000;
            this.fc_ReflashR1AlramInfo.TimeoutColor = System.Drawing.Color.Red;
            this.fc_ReflashR1AlramInfo.tmrTimeOut = null;
            this.fc_ReflashR1AlramInfo.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_ReflashR1AlramInfo_FlowRun);
            // 
            // flowChart102
            // 
            this.flowChart102.AlarmCode = "";
            this.flowChart102.ArrowSeparation = 20;
            this.flowChart102.ArrowsWidth = 1;
            this.flowChart102.BackColor = System.Drawing.Color.White;
            this.flowChart102.bClearTrace = false;
            this.flowChart102.bIsLastFlowChart = false;
            this.flowChart102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart102.bSkip = false;
            this.flowChart102.bStepByStepMode = false;
            this.flowChart102.CASE1 = null;
            this.flowChart102.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart102.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart102.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart102.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart102.CASE2 = null;
            this.flowChart102.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart102.CASE2Color = System.Drawing.Color.Red;
            this.flowChart102.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart102.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart102.CASE3 = null;
            this.flowChart102.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart102.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart102.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart102.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart102.DefaultColor = System.Drawing.Color.White;
            this.flowChart102.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart102.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart102.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart102.Location = new System.Drawing.Point(266, 432);
            this.flowChart102.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart102.menuOpening = false;
            this.flowChart102.Name = "flowChart102";
            this.flowChart102.NEXT = this.flowChart101;
            this.flowChart102.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart102.NEXTColor = System.Drawing.Color.Black;
            this.flowChart102.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart102.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart102.Size = new System.Drawing.Size(275, 48);
            this.flowChart102.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart102.SubFlowChart = null;
            this.flowChart102.TabIndex = 13;
            this.flowChart102.Text = "Refresh alarm message";
            this.flowChart102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart102.TimeOut = 10000;
            this.flowChart102.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart102.tmrTimeOut = null;
            this.flowChart102.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart102_FlowRun);
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.fcNgMes);   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0
            this.tabPage15.Controls.Add(this.npFlowChart30);
            this.tabPage15.Controls.Add(this.npFlowChart29);
            this.tabPage15.Controls.Add(this.npFlowChart28);
            this.tabPage15.Controls.Add(this.npFlowChart19);
            this.tabPage15.Controls.Add(this.npFlowChart14);
            this.tabPage15.Controls.Add(this.npFlowChart15);
            this.tabPage15.Controls.Add(this.npFlowChart16);
            this.tabPage15.Controls.Add(this.npFlowChart17);
            this.tabPage15.Controls.Add(this.npFlowChart18);
            this.tabPage15.Controls.Add(this.npFlowChart11);
            this.tabPage15.Controls.Add(this.npFlowChart12);
            this.tabPage15.Controls.Add(this.npFlowChart13);
            this.tabPage15.Controls.Add(this.npFlowChart10);
            this.tabPage15.Controls.Add(this.npFlowChart9);
            this.tabPage15.Controls.Add(this.npFlowChart8);
            this.tabPage15.Controls.Add(this.npFlowChart7);
            this.tabPage15.Controls.Add(this.npFlowChart2);
            this.tabPage15.Controls.Add(this.flowChart66);
            this.tabPage15.Controls.Add(this.flowChart82);
            this.tabPage15.Controls.Add(this.flowChart81);
            this.tabPage15.Controls.Add(this.flowChart80);
            this.tabPage15.Controls.Add(this.flowChart71);
            this.tabPage15.Controls.Add(this.flowChart70);
            this.tabPage15.Controls.Add(this.flowChart68);
            this.tabPage15.Controls.Add(this.flowChart64);
            this.tabPage15.Controls.Add(this.flowChart63);
            this.tabPage15.Controls.Add(this.flowChart61);
            this.tabPage15.Controls.Add(this.flowChart51);
            this.tabPage15.Controls.Add(this.flowChart50);
            this.tabPage15.Controls.Add(this.flowChart65);
            this.tabPage15.Controls.Add(this.flowChart62);
            this.tabPage15.Controls.Add(this.flowChart67);
            this.tabPage15.Controls.Add(this.flowChart3);
            this.tabPage15.Controls.Add(this.flowChart60);
            this.tabPage15.Controls.Add(this.flowChart43);
            this.tabPage15.Controls.Add(this.flowChart52);
            this.tabPage15.Controls.Add(this.flowChart25);
            this.tabPage15.Controls.Add(this.flowChart19);
            this.tabPage15.Controls.Add(this.flowChart21);
            this.tabPage15.Controls.Add(this.flowChart26);
            this.tabPage15.Controls.Add(this.flowChart24);
            this.tabPage15.Controls.Add(this.flowChart29);
            this.tabPage15.Controls.Add(this.flowChart35);
            this.tabPage15.Controls.Add(this.flowChart34);
            this.tabPage15.Controls.Add(this.flowChart23);
            this.tabPage15.Controls.Add(this.flowChart27);
            this.tabPage15.Controls.Add(this.flowChart37);
            this.tabPage15.Controls.Add(this.flowChart22);
            this.tabPage15.Controls.Add(this.flowChart20);
            this.tabPage15.Controls.Add(this.flowChart10);
            this.tabPage15.Controls.Add(this.flowChart18);
            this.tabPage15.Controls.Add(this.flowChart8);
            this.tabPage15.Controls.Add(this.flowChart16);
            this.tabPage15.Controls.Add(this.flowChart15);
            this.tabPage15.Controls.Add(this.flowChart44);
            this.tabPage15.Controls.Add(this.flowChart14);
            this.tabPage15.Controls.Add(this.flowChart58);
            this.tabPage15.Controls.Add(this.flowChart39);
            this.tabPage15.Controls.Add(this.fc_RobotStart);
            this.tabPage15.Controls.Add(this.flowChart17);
            this.tabPage15.Controls.Add(this.flowChart38);
            this.tabPage15.Controls.Add(this.flowChart28);
            this.tabPage15.Controls.Add(this.flowChart32);
            this.tabPage15.Controls.Add(this.flowChart41);
            this.tabPage15.Controls.Add(this.flowChart53);
            this.tabPage15.Controls.Add(this.flowChart42);
            this.tabPage15.Controls.Add(this.flowChart36);
            this.tabPage15.Controls.Add(this.flowChart40);
            this.tabPage15.Controls.Add(this.flowChart45);
            this.tabPage15.Location = new System.Drawing.Point(4, 31);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Size = new System.Drawing.Size(780, 1402);
            this.tabPage15.TabIndex = 7;
            this.tabPage15.Text = "Robot";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // npFlowChart30
            // 
            this.npFlowChart30.AlarmCode = "";
            this.npFlowChart30.ArrowSeparation = 20;
            this.npFlowChart30.ArrowsWidth = 1;
            this.npFlowChart30.BackColor = System.Drawing.Color.White;
            this.npFlowChart30.bClearTrace = false;
            this.npFlowChart30.bIsLastFlowChart = false;
            this.npFlowChart30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart30.bSkip = false;
            this.npFlowChart30.bStepByStepMode = false;
            this.npFlowChart30.CASE1 = null;
            this.npFlowChart30.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart30.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart30.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart30.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart30.CASE2 = null;
            this.npFlowChart30.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.npFlowChart30.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart30.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.npFlowChart30.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart30.CASE3 = null;
            this.npFlowChart30.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart30.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart30.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart30.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart30.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart30.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart30.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart30.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart30.Location = new System.Drawing.Point(16, 1100);
            this.npFlowChart30.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart30.menuOpening = false;
            this.npFlowChart30.Name = "npFlowChart30";
            this.npFlowChart30.NEXT = this.flowChart24;
            this.npFlowChart30.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart30.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart30.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.npFlowChart30.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.npFlowChart30.Size = new System.Drawing.Size(202, 35);
            this.npFlowChart30.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart30.SubFlowChart = null;
            this.npFlowChart30.TabIndex = 131;
            this.npFlowChart30.Text = "Save image";
            this.npFlowChart30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart30.TimeOut = 10000;
            this.npFlowChart30.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart30.tmrTimeOut = null;
            this.npFlowChart30.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart30_FlowRun);
            // 
            // flowChart24
            // 
            this.flowChart24.AlarmCode = "";
            this.flowChart24.ArrowSeparation = 20;
            this.flowChart24.ArrowsWidth = 1;
            this.flowChart24.BackColor = System.Drawing.Color.White;
            this.flowChart24.bClearTrace = false;
            this.flowChart24.bIsLastFlowChart = false;
            this.flowChart24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart24.bSkip = false;
            this.flowChart24.bStepByStepMode = false;
            this.flowChart24.CASE1 = this.flowChart25;
            this.flowChart24.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart24.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart24.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart24.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart24.CASE2 = this.flowChart66;
            this.flowChart24.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart24.CASE2Color = System.Drawing.Color.Red;
            this.flowChart24.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart24.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart24.CASE3 = null;
            this.flowChart24.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart24.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart24.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart24.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart24.DefaultColor = System.Drawing.Color.White;
            this.flowChart24.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart24.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart24.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart24.Location = new System.Drawing.Point(5, 1016);
            this.flowChart24.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart24.menuOpening = false;
            this.flowChart24.Name = "flowChart24";
            this.flowChart24.NEXT = this.flowChart38;
            this.flowChart24.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart24.NEXTColor = System.Drawing.Color.Black;
            this.flowChart24.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart24.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart24.Size = new System.Drawing.Size(258, 35);
            this.flowChart24.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart24.SubFlowChart = null;
            this.flowChart24.TabIndex = 98;
            this.flowChart24.Text = "Judge one group completed";
            this.flowChart24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart24.TimeOut = 10000;
            this.flowChart24.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart24.tmrTimeOut = null;
            this.flowChart24.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart24_FlowRun);
            // 
            // flowChart25
            // 
            this.flowChart25.AlarmCode = "";
            this.flowChart25.ArrowSeparation = 20;
            this.flowChart25.ArrowsWidth = 1;
            this.flowChart25.BackColor = System.Drawing.Color.White;
            this.flowChart25.bClearTrace = false;
            this.flowChart25.bIsLastFlowChart = false;
            this.flowChart25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart25.bSkip = false;
            this.flowChart25.bStepByStepMode = false;
            this.flowChart25.CASE1 = null;
            this.flowChart25.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart25.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart25.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.CASE2 = null;
            this.flowChart25.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart25.CASE2Color = System.Drawing.Color.Red;
            this.flowChart25.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.CASE3 = null;
            this.flowChart25.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart25.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart25.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.DefaultColor = System.Drawing.Color.White;
            this.flowChart25.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart25.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart25.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart25.Location = new System.Drawing.Point(23, 774);
            this.flowChart25.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart25.menuOpening = false;
            this.flowChart25.Name = "flowChart25";
            this.flowChart25.NEXT = this.flowChart36;
            this.flowChart25.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart25.NEXTColor = System.Drawing.Color.Black;
            this.flowChart25.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart25.Size = new System.Drawing.Size(114, 35);
            this.flowChart25.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart25.SubFlowChart = null;
            this.flowChart25.TabIndex = 98;
            this.flowChart25.Text = "Pick Loop";
            this.flowChart25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart25.TimeOut = 10000;
            this.flowChart25.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart25.tmrTimeOut = null;
            this.flowChart25.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart25_FlowRun);
            // 
            // flowChart36
            // 
            this.flowChart36.AlarmCode = "";
            this.flowChart36.ArrowSeparation = 20;
            this.flowChart36.ArrowsWidth = 1;
            this.flowChart36.BackColor = System.Drawing.Color.White;
            this.flowChart36.bClearTrace = false;
            this.flowChart36.bIsLastFlowChart = false;
            this.flowChart36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart36.bSkip = false;
            this.flowChart36.bStepByStepMode = false;
            this.flowChart36.CASE1 = this.flowChart43;
            this.flowChart36.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart36.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart36.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart36.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart36.CASE2 = null;
            this.flowChart36.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart36.CASE2Color = System.Drawing.Color.Red;
            this.flowChart36.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart36.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart36.CASE3 = null;
            this.flowChart36.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart36.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart36.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart36.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart36.DefaultColor = System.Drawing.Color.White;
            this.flowChart36.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart36.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart36.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart36.Location = new System.Drawing.Point(189, 870);
            this.flowChart36.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart36.menuOpening = false;
            this.flowChart36.Name = "flowChart36";
            this.flowChart36.NEXT = this.flowChart53;
            this.flowChart36.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart36.NEXTColor = System.Drawing.Color.Black;
            this.flowChart36.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart36.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart36.Size = new System.Drawing.Size(280, 35);
            this.flowChart36.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart36.SubFlowChart = null;
            this.flowChart36.TabIndex = 95;
            this.flowChart36.Text = "Take a product";
            this.flowChart36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart36.TimeOut = 10000;
            this.flowChart36.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart36.tmrTimeOut = null;
            this.flowChart36.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart36_FlowRun);
            // 
            // flowChart43
            // 
            this.flowChart43.AlarmCode = "";
            this.flowChart43.ArrowSeparation = 20;
            this.flowChart43.ArrowsWidth = 1;
            this.flowChart43.BackColor = System.Drawing.Color.White;
            this.flowChart43.bClearTrace = false;
            this.flowChart43.bIsLastFlowChart = false;
            this.flowChart43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart43.bSkip = false;
            this.flowChart43.bStepByStepMode = false;
            this.flowChart43.CASE1 = null;
            this.flowChart43.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart43.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart43.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.CASE2 = null;
            this.flowChart43.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart43.CASE2Color = System.Drawing.Color.Red;
            this.flowChart43.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.CASE3 = null;
            this.flowChart43.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart43.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart43.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.DefaultColor = System.Drawing.Color.White;
            this.flowChart43.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart43.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart43.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart43.Location = new System.Drawing.Point(23, 842);
            this.flowChart43.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart43.menuOpening = false;
            this.flowChart43.Name = "flowChart43";
            this.flowChart43.NEXT = this.flowChart24;
            this.flowChart43.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart43.NEXTColor = System.Drawing.Color.Black;
            this.flowChart43.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart43.Size = new System.Drawing.Size(114, 35);
            this.flowChart43.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart43.SubFlowChart = null;
            this.flowChart43.TabIndex = 98;
            this.flowChart43.Text = "Skip picking";
            this.flowChart43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart43.TimeOut = 10000;
            this.flowChart43.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart43.tmrTimeOut = null;
            this.flowChart43.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart43_FlowRun);
            // 
            // flowChart53
            // 
            this.flowChart53.AlarmCode = "";
            this.flowChart53.ArrowSeparation = 20;
            this.flowChart53.ArrowsWidth = 1;
            this.flowChart53.BackColor = System.Drawing.Color.White;
            this.flowChart53.bClearTrace = false;
            this.flowChart53.bIsLastFlowChart = false;
            this.flowChart53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart53.bSkip = false;
            this.flowChart53.bStepByStepMode = false;
            this.flowChart53.CASE1 = null;
            this.flowChart53.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart53.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart53.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.CASE2 = null;
            this.flowChart53.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart53.CASE2Color = System.Drawing.Color.Red;
            this.flowChart53.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.CASE3 = null;
            this.flowChart53.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart53.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart53.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.DefaultColor = System.Drawing.Color.White;
            this.flowChart53.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart53.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart53.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart53.Location = new System.Drawing.Point(189, 918);
            this.flowChart53.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart53.menuOpening = false;
            this.flowChart53.Name = "flowChart53";
            this.flowChart53.NEXT = this.flowChart42;
            this.flowChart53.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart53.NEXTColor = System.Drawing.Color.Black;
            this.flowChart53.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart53.Size = new System.Drawing.Size(280, 35);
            this.flowChart53.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart53.SubFlowChart = null;
            this.flowChart53.TabIndex = 95;
            this.flowChart53.Text = "Send pick instruction";
            this.flowChart53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart53.TimeOut = 10000;
            this.flowChart53.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart53.tmrTimeOut = null;
            this.flowChart53.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart53_FlowRun);
            // 
            // flowChart42
            // 
            this.flowChart42.AlarmCode = "";
            this.flowChart42.ArrowSeparation = 20;
            this.flowChart42.ArrowsWidth = 1;
            this.flowChart42.BackColor = System.Drawing.Color.White;
            this.flowChart42.bClearTrace = false;
            this.flowChart42.bIsLastFlowChart = false;
            this.flowChart42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart42.bSkip = false;
            this.flowChart42.bStepByStepMode = false;
            this.flowChart42.CASE1 = null;
            this.flowChart42.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart42.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart42.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.CASE2 = null;
            this.flowChart42.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart42.CASE2Color = System.Drawing.Color.Red;
            this.flowChart42.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.CASE3 = null;
            this.flowChart42.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart42.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart42.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.DefaultColor = System.Drawing.Color.White;
            this.flowChart42.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart42.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart42.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart42.Location = new System.Drawing.Point(189, 967);
            this.flowChart42.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart42.menuOpening = false;
            this.flowChart42.Name = "flowChart42";
            this.flowChart42.NEXT = this.npFlowChart8;
            this.flowChart42.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart42.NEXTColor = System.Drawing.Color.Black;
            this.flowChart42.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart42.Size = new System.Drawing.Size(280, 35);
            this.flowChart42.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart42.SubFlowChart = null;
            this.flowChart42.TabIndex = 95;
            this.flowChart42.Text = "Wait picked up completed";
            this.flowChart42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart42.TimeOut = 10000;
            this.flowChart42.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart42.tmrTimeOut = null;
            this.flowChart42.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart42_FlowRun);
            // 
            // npFlowChart8
            // 
            this.npFlowChart8.AlarmCode = "";
            this.npFlowChart8.ArrowSeparation = 20;
            this.npFlowChart8.ArrowsWidth = 1;
            this.npFlowChart8.BackColor = System.Drawing.Color.White;
            this.npFlowChart8.bClearTrace = false;
            this.npFlowChart8.bIsLastFlowChart = false;
            this.npFlowChart8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart8.bSkip = false;
            this.npFlowChart8.bStepByStepMode = false;
            this.npFlowChart8.CASE1 = this.flowChart24;
            this.npFlowChart8.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart8.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart8.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.CASE2 = null;
            this.npFlowChart8.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart8.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart8.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.CASE3 = null;
            this.npFlowChart8.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart8.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart8.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart8.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart8.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart8.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart8.Location = new System.Drawing.Point(793, 1214);
            this.npFlowChart8.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart8.menuOpening = false;
            this.npFlowChart8.Name = "npFlowChart8";
            this.npFlowChart8.NEXT = this.npFlowChart10;
            this.npFlowChart8.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart8.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart8.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart8.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart8.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart8.SubFlowChart = null;
            this.npFlowChart8.TabIndex = 116;
            this.npFlowChart8.Text = "MES 10701";
            this.npFlowChart8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart8.TimeOut = 10000;
            this.npFlowChart8.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart8.tmrTimeOut = null;
            this.npFlowChart8.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart8_FlowRun);
            // 
            // npFlowChart10
            // 
            this.npFlowChart10.AlarmCode = "";
            this.npFlowChart10.ArrowSeparation = 20;
            this.npFlowChart10.ArrowsWidth = 1;
            this.npFlowChart10.BackColor = System.Drawing.Color.White;
            this.npFlowChart10.bClearTrace = false;
            this.npFlowChart10.bIsLastFlowChart = false;
            this.npFlowChart10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart10.bSkip = false;
            this.npFlowChart10.bStepByStepMode = false;
            this.npFlowChart10.CASE1 = this.npFlowChart8;
            this.npFlowChart10.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart10.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart10.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.CASE2 = null;
            this.npFlowChart10.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart10.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart10.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.CASE3 = null;
            this.npFlowChart10.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart10.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart10.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart10.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart10.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart10.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart10.Location = new System.Drawing.Point(793, 1265);
            this.npFlowChart10.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart10.menuOpening = false;
            this.npFlowChart10.Name = "npFlowChart10";
            this.npFlowChart10.NEXT = this.npFlowChart9;
            this.npFlowChart10.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart10.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart10.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart10.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart10.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart10.SubFlowChart = null;
            this.npFlowChart10.TabIndex = 118;
            this.npFlowChart10.Text = "LOT_START";
            this.npFlowChart10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart10.TimeOut = 10000;
            this.npFlowChart10.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart10.tmrTimeOut = null;
            this.npFlowChart10.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart10_FlowRun);
            // 
            // npFlowChart9
            // 
            this.npFlowChart9.AlarmCode = "";
            this.npFlowChart9.ArrowSeparation = 20;
            this.npFlowChart9.ArrowsWidth = 1;
            this.npFlowChart9.BackColor = System.Drawing.Color.White;
            this.npFlowChart9.bClearTrace = false;
            this.npFlowChart9.bIsLastFlowChart = false;
            this.npFlowChart9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart9.bSkip = false;
            this.npFlowChart9.bStepByStepMode = false;
            this.npFlowChart9.CASE1 = null;
            this.npFlowChart9.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart9.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart9.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.CASE2 = null;
            this.npFlowChart9.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart9.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart9.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.CASE3 = null;
            this.npFlowChart9.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart9.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart9.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart9.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart9.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart9.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart9.Location = new System.Drawing.Point(793, 1312);
            this.npFlowChart9.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart9.menuOpening = false;
            this.npFlowChart9.Name = "npFlowChart9";
            this.npFlowChart9.NEXT = this.npFlowChart11;
            this.npFlowChart9.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart9.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart9.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart9.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart9.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart9.SubFlowChart = null;
            this.npFlowChart9.TabIndex = 117;
            this.npFlowChart9.Text = "WaitACK";
            this.npFlowChart9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart9.TimeOut = 10000;
            this.npFlowChart9.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart9.tmrTimeOut = null;
            this.npFlowChart9.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart9_FlowRun);
            // 
            // npFlowChart11
            // 
            this.npFlowChart11.AlarmCode = "";
            this.npFlowChart11.ArrowSeparation = 20;
            this.npFlowChart11.ArrowsWidth = 1;
            this.npFlowChart11.BackColor = System.Drawing.Color.White;
            this.npFlowChart11.bClearTrace = false;
            this.npFlowChart11.bIsLastFlowChart = false;
            this.npFlowChart11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart11.bSkip = false;
            this.npFlowChart11.bStepByStepMode = false;
            this.npFlowChart11.CASE1 = null;
            this.npFlowChart11.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart11.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart11.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.CASE2 = null;
            this.npFlowChart11.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart11.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart11.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.CASE3 = null;
            this.npFlowChart11.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart11.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart11.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart11.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart11.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart11.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart11.Location = new System.Drawing.Point(639, 1312);
            this.npFlowChart11.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart11.menuOpening = false;
            this.npFlowChart11.Name = "npFlowChart11";
            this.npFlowChart11.NEXT = this.npFlowChart13;
            this.npFlowChart11.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart11.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart11.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart11.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart11.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart11.SubFlowChart = null;
            this.npFlowChart11.TabIndex = 121;
            this.npFlowChart11.Text = "MES 10704";
            this.npFlowChart11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart11.TimeOut = 10000;
            this.npFlowChart11.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart11.tmrTimeOut = null;
            this.npFlowChart11.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart11_FlowRun);
            // 
            // npFlowChart13
            // 
            this.npFlowChart13.AlarmCode = "";
            this.npFlowChart13.ArrowSeparation = 20;
            this.npFlowChart13.ArrowsWidth = 1;
            this.npFlowChart13.BackColor = System.Drawing.Color.White;
            this.npFlowChart13.bClearTrace = false;
            this.npFlowChart13.bIsLastFlowChart = false;
            this.npFlowChart13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart13.bSkip = false;
            this.npFlowChart13.bStepByStepMode = false;
            this.npFlowChart13.CASE1 = this.npFlowChart8;
            this.npFlowChart13.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart13.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart13.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.CASE2 = null;
            this.npFlowChart13.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart13.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart13.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.CASE3 = null;
            this.npFlowChart13.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart13.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart13.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart13.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart13.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart13.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart13.Location = new System.Drawing.Point(639, 1263);
            this.npFlowChart13.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart13.menuOpening = false;
            this.npFlowChart13.Name = "npFlowChart13";
            this.npFlowChart13.NEXT = this.npFlowChart12;
            this.npFlowChart13.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart13.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart13.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart13.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart13.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart13.SubFlowChart = null;
            this.npFlowChart13.TabIndex = 119;
            this.npFlowChart13.Text = "LOT_ID_FAIL";
            this.npFlowChart13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart13.TimeOut = 10000;
            this.npFlowChart13.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart13.tmrTimeOut = null;
            this.npFlowChart13.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart13_FlowRun);
            // 
            // npFlowChart12
            // 
            this.npFlowChart12.AlarmCode = "";
            this.npFlowChart12.ArrowSeparation = 20;
            this.npFlowChart12.ArrowsWidth = 1;
            this.npFlowChart12.BackColor = System.Drawing.Color.White;
            this.npFlowChart12.bClearTrace = false;
            this.npFlowChart12.bIsLastFlowChart = false;
            this.npFlowChart12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart12.bSkip = false;
            this.npFlowChart12.bStepByStepMode = false;
            this.npFlowChart12.CASE1 = null;
            this.npFlowChart12.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart12.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart12.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.CASE2 = null;
            this.npFlowChart12.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart12.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart12.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.CASE3 = null;
            this.npFlowChart12.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart12.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart12.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart12.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart12.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart12.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart12.Location = new System.Drawing.Point(639, 1214);
            this.npFlowChart12.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart12.menuOpening = false;
            this.npFlowChart12.Name = "npFlowChart12";
            this.npFlowChart12.NEXT = this.npFlowChart18;
            this.npFlowChart12.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart12.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart12.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart12.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart12.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart12.SubFlowChart = null;
            this.npFlowChart12.TabIndex = 120;
            this.npFlowChart12.Text = "WaiACK";
            this.npFlowChart12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart12.TimeOut = 10000;
            this.npFlowChart12.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart12.tmrTimeOut = null;
            this.npFlowChart12.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart12_FlowRun);
            // 
            // npFlowChart18
            // 
            this.npFlowChart18.AlarmCode = "";
            this.npFlowChart18.ArrowSeparation = 20;
            this.npFlowChart18.ArrowsWidth = 1;
            this.npFlowChart18.BackColor = System.Drawing.Color.White;
            this.npFlowChart18.bClearTrace = false;
            this.npFlowChart18.bIsLastFlowChart = false;
            this.npFlowChart18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart18.bSkip = false;
            this.npFlowChart18.bStepByStepMode = false;
            this.npFlowChart18.CASE1 = null;
            this.npFlowChart18.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart18.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart18.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.CASE2 = null;
            this.npFlowChart18.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart18.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart18.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.CASE3 = null;
            this.npFlowChart18.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart18.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart18.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart18.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart18.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart18.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart18.Location = new System.Drawing.Point(485, 1214);
            this.npFlowChart18.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart18.menuOpening = false;
            this.npFlowChart18.Name = "npFlowChart18";
            this.npFlowChart18.NEXT = this.npFlowChart17;
            this.npFlowChart18.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart18.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart18.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart18.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart18.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart18.SubFlowChart = null;
            this.npFlowChart18.TabIndex = 123;
            this.npFlowChart18.Text = "MES 10401";
            this.npFlowChart18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart18.TimeOut = 10000;
            this.npFlowChart18.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart18.tmrTimeOut = null;
            this.npFlowChart18.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart18_FlowRun);
            // 
            // npFlowChart17
            // 
            this.npFlowChart17.AlarmCode = "";
            this.npFlowChart17.ArrowSeparation = 20;
            this.npFlowChart17.ArrowsWidth = 1;
            this.npFlowChart17.BackColor = System.Drawing.Color.White;
            this.npFlowChart17.bClearTrace = false;
            this.npFlowChart17.bIsLastFlowChart = false;
            this.npFlowChart17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart17.bSkip = false;
            this.npFlowChart17.bStepByStepMode = false;
            this.npFlowChart17.CASE1 = null;
            this.npFlowChart17.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart17.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart17.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.CASE2 = null;
            this.npFlowChart17.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart17.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart17.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.CASE3 = null;
            this.npFlowChart17.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart17.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart17.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart17.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart17.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart17.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart17.Location = new System.Drawing.Point(485, 1263);
            this.npFlowChart17.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart17.menuOpening = false;
            this.npFlowChart17.Name = "npFlowChart17";
            this.npFlowChart17.NEXT = this.npFlowChart28;
            this.npFlowChart17.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart17.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart17.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart17.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart17.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart17.SubFlowChart = null;
            this.npFlowChart17.TabIndex = 124;
            this.npFlowChart17.Text = "WaitACK";
            this.npFlowChart17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart17.TimeOut = 10000;
            this.npFlowChart17.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart17.tmrTimeOut = null;
            this.npFlowChart17.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart17_FlowRun);
            // 
            // npFlowChart28
            // 
            this.npFlowChart28.AlarmCode = "";
            this.npFlowChart28.ArrowSeparation = 20;
            this.npFlowChart28.ArrowsWidth = 1;
            this.npFlowChart28.BackColor = System.Drawing.Color.White;
            this.npFlowChart28.bClearTrace = false;
            this.npFlowChart28.bIsLastFlowChart = false;
            this.npFlowChart28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart28.bSkip = false;
            this.npFlowChart28.bStepByStepMode = false;
            this.npFlowChart28.CASE1 = null;
            this.npFlowChart28.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart28.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart28.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.CASE2 = null;
            this.npFlowChart28.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart28.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart28.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.CASE3 = null;
            this.npFlowChart28.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart28.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart28.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart28.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart28.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart28.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart28.Location = new System.Drawing.Point(485, 1312);
            this.npFlowChart28.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart28.menuOpening = false;
            this.npFlowChart28.Name = "npFlowChart28";
            this.npFlowChart28.NEXT = this.npFlowChart29;
            this.npFlowChart28.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart28.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart28.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart28.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart28.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart28.SubFlowChart = null;
            this.npFlowChart28.TabIndex = 129;
            this.npFlowChart28.Text = "MES 10711";
            this.npFlowChart28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart28.TimeOut = 10000;
            this.npFlowChart28.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart28.tmrTimeOut = null;
            this.npFlowChart28.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart28_FlowRun);
            // 
            // npFlowChart29
            // 
            this.npFlowChart29.AlarmCode = "";
            this.npFlowChart29.ArrowSeparation = 20;
            this.npFlowChart29.ArrowsWidth = 1;
            this.npFlowChart29.BackColor = System.Drawing.Color.White;
            this.npFlowChart29.bClearTrace = false;
            this.npFlowChart29.bIsLastFlowChart = false;
            this.npFlowChart29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart29.bSkip = false;
            this.npFlowChart29.bStepByStepMode = false;
            this.npFlowChart29.CASE1 = null;
            this.npFlowChart29.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart29.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart29.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.CASE2 = null;
            this.npFlowChart29.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart29.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart29.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.CASE3 = null;
            this.npFlowChart29.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart29.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart29.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart29.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart29.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart29.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart29.Location = new System.Drawing.Point(331, 1312);
            this.npFlowChart29.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart29.menuOpening = false;
            this.npFlowChart29.Name = "npFlowChart29";
            this.npFlowChart29.NEXT = this.npFlowChart14;
            this.npFlowChart29.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart29.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart29.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart29.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart29.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart29.SubFlowChart = null;
            this.npFlowChart29.TabIndex = 130;
            this.npFlowChart29.Text = "WaitACK";
            this.npFlowChart29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart29.TimeOut = 10000;
            this.npFlowChart29.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart29.tmrTimeOut = null;
            this.npFlowChart29.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart29_FlowRun);
            // 
            // npFlowChart14
            // 
            this.npFlowChart14.AlarmCode = "";
            this.npFlowChart14.ArrowSeparation = 20;
            this.npFlowChart14.ArrowsWidth = 1;
            this.npFlowChart14.BackColor = System.Drawing.Color.White;
            this.npFlowChart14.bClearTrace = false;
            this.npFlowChart14.bIsLastFlowChart = false;
            this.npFlowChart14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart14.bSkip = false;
            this.npFlowChart14.bStepByStepMode = false;
            this.npFlowChart14.CASE1 = null;
            this.npFlowChart14.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart14.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart14.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.CASE2 = null;
            this.npFlowChart14.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart14.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart14.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.CASE3 = null;
            this.npFlowChart14.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart14.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart14.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart14.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart14.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart14.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart14.Location = new System.Drawing.Point(331, 1263);
            this.npFlowChart14.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart14.menuOpening = false;
            this.npFlowChart14.Name = "npFlowChart14";
            this.npFlowChart14.NEXT = this.npFlowChart15;
            this.npFlowChart14.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart14.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart14.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart14.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart14.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart14.SubFlowChart = null;
            this.npFlowChart14.TabIndex = 127;
            this.npFlowChart14.Text = "MES 10710";
            this.npFlowChart14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart14.TimeOut = 10000;
            this.npFlowChart14.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart14.tmrTimeOut = null;
            this.npFlowChart14.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart14_FlowRun);
            // 
            // npFlowChart15
            // 
            this.npFlowChart15.AlarmCode = "";
            this.npFlowChart15.ArrowSeparation = 20;
            this.npFlowChart15.ArrowsWidth = 1;
            this.npFlowChart15.BackColor = System.Drawing.Color.White;
            this.npFlowChart15.bClearTrace = false;
            this.npFlowChart15.bIsLastFlowChart = false;
            this.npFlowChart15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart15.bSkip = false;
            this.npFlowChart15.bStepByStepMode = false;
            this.npFlowChart15.CASE1 = null;
            this.npFlowChart15.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart15.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart15.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.CASE2 = null;
            this.npFlowChart15.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart15.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart15.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.CASE3 = null;
            this.npFlowChart15.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart15.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart15.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart15.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart15.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart15.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart15.Location = new System.Drawing.Point(331, 1214);
            this.npFlowChart15.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart15.menuOpening = false;
            this.npFlowChart15.Name = "npFlowChart15";
            this.npFlowChart15.NEXT = this.npFlowChart16;
            this.npFlowChart15.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart15.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart15.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart15.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart15.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart15.SubFlowChart = null;
            this.npFlowChart15.TabIndex = 126;
            this.npFlowChart15.Text = "WaitACK";
            this.npFlowChart15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart15.TimeOut = 10000;
            this.npFlowChart15.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart15.tmrTimeOut = null;
            this.npFlowChart15.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart15_FlowRun);
            // 
            // npFlowChart16
            // 
            this.npFlowChart16.AlarmCode = "";
            this.npFlowChart16.ArrowSeparation = 20;
            this.npFlowChart16.ArrowsWidth = 1;
            this.npFlowChart16.BackColor = System.Drawing.Color.White;
            this.npFlowChart16.bClearTrace = false;
            this.npFlowChart16.bIsLastFlowChart = false;
            this.npFlowChart16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart16.bSkip = false;
            this.npFlowChart16.bStepByStepMode = false;
            this.npFlowChart16.CASE1 = null;
            this.npFlowChart16.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart16.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart16.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.CASE2 = null;
            this.npFlowChart16.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart16.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart16.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.CASE3 = null;
            this.npFlowChart16.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart16.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart16.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart16.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart16.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart16.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart16.Location = new System.Drawing.Point(167, 1263);
            this.npFlowChart16.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart16.menuOpening = false;
            this.npFlowChart16.Name = "npFlowChart16";
            this.npFlowChart16.NEXT = this.npFlowChart19;
            this.npFlowChart16.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart16.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart16.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart16.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart16.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart16.SubFlowChart = null;
            this.npFlowChart16.TabIndex = 125;
            this.npFlowChart16.Text = "MES 10401";
            this.npFlowChart16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart16.TimeOut = 10000;
            this.npFlowChart16.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart16.tmrTimeOut = null;
            this.npFlowChart16.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart16_FlowRun);
            // 
            // npFlowChart19
            // 
            this.npFlowChart19.AlarmCode = "";
            this.npFlowChart19.ArrowSeparation = 20;
            this.npFlowChart19.ArrowsWidth = 1;
            this.npFlowChart19.BackColor = System.Drawing.Color.White;
            this.npFlowChart19.bClearTrace = false;
            this.npFlowChart19.bIsLastFlowChart = false;
            this.npFlowChart19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart19.bSkip = false;
            this.npFlowChart19.bStepByStepMode = false;
            this.npFlowChart19.CASE1 = null;
            this.npFlowChart19.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart19.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart19.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.CASE2 = null;
            this.npFlowChart19.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart19.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart19.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.CASE3 = null;
            this.npFlowChart19.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart19.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart19.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart19.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart19.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart19.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npFlowChart19.Location = new System.Drawing.Point(167, 1214);
            this.npFlowChart19.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart19.menuOpening = false;
            this.npFlowChart19.Name = "npFlowChart19";
            this.npFlowChart19.NEXT = this.npFlowChart30;
            this.npFlowChart19.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart19.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart19.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart19.Size = new System.Drawing.Size(138, 35);
            this.npFlowChart19.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart19.SubFlowChart = null;
            this.npFlowChart19.TabIndex = 128;
            this.npFlowChart19.Text = "WaitACK";
            this.npFlowChart19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart19.TimeOut = 10000;
            this.npFlowChart19.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart19.tmrTimeOut = null;
            this.npFlowChart19.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart19_FlowRun);
            // 
            // flowChart66
            // 
            this.flowChart66.AlarmCode = "";
            this.flowChart66.ArrowSeparation = 20;
            this.flowChart66.ArrowsWidth = 1;
            this.flowChart66.BackColor = System.Drawing.Color.White;
            this.flowChart66.bClearTrace = false;
            this.flowChart66.bIsLastFlowChart = false;
            this.flowChart66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart66.bSkip = false;
            this.flowChart66.bStepByStepMode = false;
            this.flowChart66.CASE1 = null;
            this.flowChart66.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart66.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart66.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart66.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart66.CASE2 = null;
            this.flowChart66.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart66.CASE2Color = System.Drawing.Color.Red;
            this.flowChart66.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart66.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart66.CASE3 = null;
            this.flowChart66.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart66.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart66.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart66.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart66.DefaultColor = System.Drawing.Color.White;
            this.flowChart66.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart66.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart66.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart66.Location = new System.Drawing.Point(619, 250);
            this.flowChart66.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart66.menuOpening = false;
            this.flowChart66.Name = "flowChart66";
            this.flowChart66.NEXT = this.flowChart41;
            this.flowChart66.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart66.NEXTColor = System.Drawing.Color.Black;
            this.flowChart66.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart66.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart66.Size = new System.Drawing.Size(275, 46);
            this.flowChart66.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart66.SubFlowChart = null;
            this.flowChart66.TabIndex = 113;
            this.flowChart66.Text = "Alarm Product abnormal";
            this.flowChart66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart66.TimeOut = 10000;
            this.flowChart66.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart66.tmrTimeOut = null;
            this.flowChart66.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart66_FlowRun_1);
            // 
            // flowChart41
            // 
            this.flowChart41.AlarmCode = "";
            this.flowChart41.ArrowSeparation = 20;
            this.flowChart41.ArrowsWidth = 1;
            this.flowChart41.BackColor = System.Drawing.Color.White;
            this.flowChart41.bClearTrace = false;
            this.flowChart41.bIsLastFlowChart = false;
            this.flowChart41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart41.bSkip = false;
            this.flowChart41.bStepByStepMode = false;
            this.flowChart41.CASE1 = this.flowChart20;
            this.flowChart41.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart41.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart41.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart41.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart41.CASE2 = this.flowChart61;
            this.flowChart41.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart41.CASE2Color = System.Drawing.Color.Red;
            this.flowChart41.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart41.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart41.CASE3 = this.flowChart68;
            this.flowChart41.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart41.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart41.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart41.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart41.DefaultColor = System.Drawing.Color.White;
            this.flowChart41.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart41.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart41.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart41.Location = new System.Drawing.Point(619, 310);
            this.flowChart41.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart41.menuOpening = false;
            this.flowChart41.Name = "flowChart41";
            this.flowChart41.NEXT = this.flowChart63;
            this.flowChart41.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart41.NEXTColor = System.Drawing.Color.Black;
            this.flowChart41.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart41.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart41.Size = new System.Drawing.Size(275, 35);
            this.flowChart41.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart41.SubFlowChart = null;
            this.flowChart41.TabIndex = 94;
            this.flowChart41.Text = "Judge all four groups completed";
            this.flowChart41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart41.TimeOut = 10000;
            this.flowChart41.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart41.tmrTimeOut = null;
            this.flowChart41.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart41_FlowRun);
            // 
            // flowChart20
            // 
            this.flowChart20.AlarmCode = "";
            this.flowChart20.ArrowSeparation = 20;
            this.flowChart20.ArrowsWidth = 1;
            this.flowChart20.BackColor = System.Drawing.Color.White;
            this.flowChart20.bClearTrace = false;
            this.flowChart20.bIsLastFlowChart = false;
            this.flowChart20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart20.bSkip = false;
            this.flowChart20.bStepByStepMode = false;
            this.flowChart20.CASE1 = this.flowChart63;
            this.flowChart20.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart20.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart20.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart20.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart20.CASE2 = null;
            this.flowChart20.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart20.CASE2Color = System.Drawing.Color.Red;
            this.flowChart20.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart20.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart20.CASE3 = null;
            this.flowChart20.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart20.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart20.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart20.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart20.DefaultColor = System.Drawing.Color.White;
            this.flowChart20.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart20.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart20.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart20.Location = new System.Drawing.Point(189, 528);
            this.flowChart20.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart20.menuOpening = false;
            this.flowChart20.Name = "flowChart20";
            this.flowChart20.NEXT = this.flowChart37;
            this.flowChart20.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart20.NEXTColor = System.Drawing.Color.Black;
            this.flowChart20.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart20.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart20.Size = new System.Drawing.Size(280, 35);
            this.flowChart20.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart20.SubFlowChart = null;
            this.flowChart20.TabIndex = 98;
            this.flowChart20.Text = "Robot to next picture pos";
            this.flowChart20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart20.TimeOut = 10000;
            this.flowChart20.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart20.tmrTimeOut = null;
            this.flowChart20.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart20_FlowRun);
            // 
            // flowChart63
            // 
            this.flowChart63.AlarmCode = "";
            this.flowChart63.ArrowSeparation = 20;
            this.flowChart63.ArrowsWidth = 1;
            this.flowChart63.BackColor = System.Drawing.Color.White;
            this.flowChart63.bClearTrace = false;
            this.flowChart63.bIsLastFlowChart = false;
            this.flowChart63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart63.bSkip = false;
            this.flowChart63.bStepByStepMode = false;
            this.flowChart63.CASE1 = this.flowChart64;
            this.flowChart63.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart63.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart63.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.CASE2 = null;
            this.flowChart63.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart63.CASE2Color = System.Drawing.Color.Red;
            this.flowChart63.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.CASE3 = null;
            this.flowChart63.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart63.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart63.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.DefaultColor = System.Drawing.Color.White;
            this.flowChart63.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart63.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart63.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart63.Location = new System.Drawing.Point(619, 202);
            this.flowChart63.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart63.menuOpening = false;
            this.flowChart63.Name = "flowChart63";
            this.flowChart63.NEXT = this.flowChart44;
            this.flowChart63.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart63.NEXTColor = System.Drawing.Color.Black;
            this.flowChart63.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart63.Size = new System.Drawing.Size(275, 35);
            this.flowChart63.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart63.SubFlowChart = null;
            this.flowChart63.TabIndex = 105;
            this.flowChart63.Text = "put fall robot return to safety";
            this.flowChart63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart63.TimeOut = 10000;
            this.flowChart63.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart63.tmrTimeOut = null;
            this.flowChart63.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart63_FlowRun);
            // 
            // flowChart64
            // 
            this.flowChart64.AlarmCode = "";
            this.flowChart64.ArrowSeparation = 20;
            this.flowChart64.ArrowsWidth = 1;
            this.flowChart64.BackColor = System.Drawing.Color.White;
            this.flowChart64.bClearTrace = false;
            this.flowChart64.bIsLastFlowChart = false;
            this.flowChart64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart64.bSkip = false;
            this.flowChart64.bStepByStepMode = false;
            this.flowChart64.CASE1 = null;
            this.flowChart64.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart64.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart64.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart64.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart64.CASE2 = null;
            this.flowChart64.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart64.CASE2Color = System.Drawing.Color.Red;
            this.flowChart64.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart64.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart64.CASE3 = null;
            this.flowChart64.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart64.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart64.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart64.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart64.DefaultColor = System.Drawing.Color.White;
            this.flowChart64.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart64.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart64.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart64.Location = new System.Drawing.Point(910, 202);
            this.flowChart64.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart64.menuOpening = false;
            this.flowChart64.Name = "flowChart64";
            this.flowChart64.NEXT = this.flowChart44;
            this.flowChart64.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart64.NEXTColor = System.Drawing.Color.Black;
            this.flowChart64.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart64.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart64.Size = new System.Drawing.Size(166, 35);
            this.flowChart64.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart64.SubFlowChart = null;
            this.flowChart64.TabIndex = 106;
            this.flowChart64.Text = "wait on safety";
            this.flowChart64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart64.TimeOut = 10000;
            this.flowChart64.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart64.tmrTimeOut = null;
            this.flowChart64.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart64_FlowRun);
            // 
            // flowChart44
            // 
            this.flowChart44.AlarmCode = "";
            this.flowChart44.ArrowSeparation = 20;
            this.flowChart44.ArrowsWidth = 1;
            this.flowChart44.BackColor = System.Drawing.Color.White;
            this.flowChart44.bClearTrace = false;
            this.flowChart44.bIsLastFlowChart = false;
            this.flowChart44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart44.bSkip = false;
            this.flowChart44.bStepByStepMode = false;
            this.flowChart44.CASE1 = null;
            this.flowChart44.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart44.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart44.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart44.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart44.CASE2 = null;
            this.flowChart44.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart44.CASE2Color = System.Drawing.Color.Red;
            this.flowChart44.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart44.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart44.CASE3 = null;
            this.flowChart44.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart44.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart44.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart44.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart44.DefaultColor = System.Drawing.Color.White;
            this.flowChart44.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart44.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart44.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart44.Location = new System.Drawing.Point(619, 152);
            this.flowChart44.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart44.menuOpening = false;
            this.flowChart44.Name = "flowChart44";
            this.flowChart44.NEXT = this.flowChart32;
            this.flowChart44.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart44.NEXTColor = System.Drawing.Color.Black;
            this.flowChart44.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart44.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart44.Size = new System.Drawing.Size(275, 35);
            this.flowChart44.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart44.SubFlowChart = null;
            this.flowChart44.TabIndex = 88;
            this.flowChart44.Text = "Judge exist NG product";
            this.flowChart44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart44.TimeOut = 10000;
            this.flowChart44.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart44.tmrTimeOut = null;
            this.flowChart44.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart44_FlowRun);
            // 
            // flowChart32
            // 
            this.flowChart32.AlarmCode = "";
            this.flowChart32.ArrowSeparation = 20;
            this.flowChart32.ArrowsWidth = 1;
            this.flowChart32.BackColor = System.Drawing.Color.White;
            this.flowChart32.bClearTrace = false;
            this.flowChart32.bIsLastFlowChart = false;
            this.flowChart32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart32.bSkip = false;
            this.flowChart32.bStepByStepMode = false;
            this.flowChart32.CASE1 = null;
            this.flowChart32.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart32.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart32.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.CASE2 = null;
            this.flowChart32.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart32.CASE2Color = System.Drawing.Color.Red;
            this.flowChart32.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.CASE3 = null;
            this.flowChart32.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart32.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart32.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.DefaultColor = System.Drawing.Color.White;
            this.flowChart32.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart32.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart32.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart32.Location = new System.Drawing.Point(619, 103);
            this.flowChart32.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart32.menuOpening = false;
            this.flowChart32.Name = "flowChart32";
            this.flowChart32.NEXT = this.flowChart71;
            this.flowChart32.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart32.NEXTColor = System.Drawing.Color.Black;
            this.flowChart32.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart32.Size = new System.Drawing.Size(275, 35);
            this.flowChart32.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart32.SubFlowChart = null;
            this.flowChart32.TabIndex = 94;
            this.flowChart32.Text = "Notify Unload completed";
            this.flowChart32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart32.TimeOut = 10000;
            this.flowChart32.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart32.tmrTimeOut = null;
            this.flowChart32.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart32_FlowRun);
            // 
            // flowChart71
            // 
            this.flowChart71.AlarmCode = "";
            this.flowChart71.ArrowSeparation = 20;
            this.flowChart71.ArrowsWidth = 1;
            this.flowChart71.BackColor = System.Drawing.Color.White;
            this.flowChart71.bClearTrace = false;
            this.flowChart71.bIsLastFlowChart = false;
            this.flowChart71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart71.bSkip = false;
            this.flowChart71.bStepByStepMode = false;
            this.flowChart71.CASE1 = this.flowChart15;
            this.flowChart71.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart71.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart71.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart71.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart71.CASE2 = null;
            this.flowChart71.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart71.CASE2Color = System.Drawing.Color.Red;
            this.flowChart71.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart71.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart71.CASE3 = null;
            this.flowChart71.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart71.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart71.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart71.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart71.DefaultColor = System.Drawing.Color.White;
            this.flowChart71.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart71.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart71.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart71.Location = new System.Drawing.Point(619, 55);
            this.flowChart71.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart71.menuOpening = false;
            this.flowChart71.Name = "flowChart71";
            this.flowChart71.NEXT = this.flowChart80;
            this.flowChart71.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart71.NEXTColor = System.Drawing.Color.Black;
            this.flowChart71.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart71.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart71.Size = new System.Drawing.Size(275, 35);
            this.flowChart71.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart71.SubFlowChart = null;
            this.flowChart71.TabIndex = 109;
            this.flowChart71.Text = "One group finished to safe";
            this.flowChart71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart71.TimeOut = 10000;
            this.flowChart71.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart71.tmrTimeOut = null;
            this.flowChart71.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart71_FlowRun);
            // 
            // flowChart15
            // 
            this.flowChart15.AlarmCode = "";
            this.flowChart15.ArrowSeparation = 20;
            this.flowChart15.ArrowsWidth = 1;
            this.flowChart15.BackColor = System.Drawing.Color.White;
            this.flowChart15.bClearTrace = false;
            this.flowChart15.bIsLastFlowChart = false;
            this.flowChart15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart15.bSkip = false;
            this.flowChart15.bStepByStepMode = false;
            this.flowChart15.CASE1 = null;
            this.flowChart15.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart15.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart15.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.CASE2 = null;
            this.flowChart15.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart15.CASE2Color = System.Drawing.Color.Red;
            this.flowChart15.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.CASE3 = null;
            this.flowChart15.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart15.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart15.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.DefaultColor = System.Drawing.Color.White;
            this.flowChart15.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart15.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart15.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart15.Location = new System.Drawing.Point(189, 46);
            this.flowChart15.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart15.menuOpening = false;
            this.flowChart15.Name = "flowChart15";
            this.flowChart15.NEXT = this.flowChart81;
            this.flowChart15.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart15.NEXTColor = System.Drawing.Color.Black;
            this.flowChart15.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart15.Size = new System.Drawing.Size(280, 35);
            this.flowChart15.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart15.SubFlowChart = null;
            this.flowChart15.TabIndex = 97;
            this.flowChart15.Text = "Judge feeder ready";
            this.flowChart15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart15.TimeOut = 10000;
            this.flowChart15.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart15.tmrTimeOut = null;
            this.flowChart15.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart15_FlowRun);
            // 
            // flowChart81
            // 
            this.flowChart81.AlarmCode = "";
            this.flowChart81.ArrowSeparation = 20;
            this.flowChart81.ArrowsWidth = 1;
            this.flowChart81.BackColor = System.Drawing.Color.White;
            this.flowChart81.bClearTrace = false;
            this.flowChart81.bIsLastFlowChart = false;
            this.flowChart81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart81.bSkip = false;
            this.flowChart81.bStepByStepMode = false;
            this.flowChart81.CASE1 = this.flowChart82;
            this.flowChart81.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart81.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart81.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart81.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart81.CASE2 = null;
            this.flowChart81.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart81.CASE2Color = System.Drawing.Color.Red;
            this.flowChart81.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart81.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart81.CASE3 = null;
            this.flowChart81.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart81.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart81.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart81.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart81.DefaultColor = System.Drawing.Color.White;
            this.flowChart81.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart81.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart81.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart81.Location = new System.Drawing.Point(189, 95);
            this.flowChart81.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart81.menuOpening = false;
            this.flowChart81.Name = "flowChart81";
            this.flowChart81.NEXT = this.flowChart17;
            this.flowChart81.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart81.NEXTColor = System.Drawing.Color.Black;
            this.flowChart81.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart81.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart81.Size = new System.Drawing.Size(280, 35);
            this.flowChart81.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart81.SubFlowChart = null;
            this.flowChart81.TabIndex = 111;
            this.flowChart81.Text = "Clear Grapper finished to safe";
            this.flowChart81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart81.TimeOut = 10000;
            this.flowChart81.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart81.tmrTimeOut = null;
            this.flowChart81.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart81_FlowRun);
            // 
            // flowChart82
            // 
            this.flowChart82.AlarmCode = "";
            this.flowChart82.ArrowSeparation = 20;
            this.flowChart82.ArrowsWidth = 1;
            this.flowChart82.BackColor = System.Drawing.Color.White;
            this.flowChart82.bClearTrace = false;
            this.flowChart82.bIsLastFlowChart = false;
            this.flowChart82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart82.bSkip = false;
            this.flowChart82.bStepByStepMode = false;
            this.flowChart82.CASE1 = null;
            this.flowChart82.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart82.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart82.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart82.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart82.CASE2 = null;
            this.flowChart82.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart82.CASE2Color = System.Drawing.Color.Red;
            this.flowChart82.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart82.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart82.CASE3 = null;
            this.flowChart82.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart82.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart82.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart82.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart82.DefaultColor = System.Drawing.Color.White;
            this.flowChart82.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart82.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart82.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart82.Location = new System.Drawing.Point(35, 153);
            this.flowChart82.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart82.menuOpening = false;
            this.flowChart82.Name = "flowChart82";
            this.flowChart82.NEXT = this.flowChart17;
            this.flowChart82.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart82.NEXTColor = System.Drawing.Color.Black;
            this.flowChart82.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart82.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart82.Size = new System.Drawing.Size(114, 35);
            this.flowChart82.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart82.SubFlowChart = null;
            this.flowChart82.TabIndex = 112;
            this.flowChart82.Text = "wait on safe";
            this.flowChart82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart82.TimeOut = 10000;
            this.flowChart82.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart82.tmrTimeOut = null;
            this.flowChart82.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart82_FlowRun);
            // 
            // flowChart17
            // 
            this.flowChart17.AlarmCode = "";
            this.flowChart17.ArrowSeparation = 20;
            this.flowChart17.ArrowsWidth = 1;
            this.flowChart17.BackColor = System.Drawing.Color.White;
            this.flowChart17.bClearTrace = false;
            this.flowChart17.bIsLastFlowChart = false;
            this.flowChart17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart17.bSkip = false;
            this.flowChart17.bStepByStepMode = false;
            this.flowChart17.CASE1 = null;
            this.flowChart17.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart17.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart17.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart17.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart17.CASE2 = this.flowChart38;
            this.flowChart17.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart17.CASE2Color = System.Drawing.Color.Red;
            this.flowChart17.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart17.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart17.CASE3 = null;
            this.flowChart17.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart17.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart17.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart17.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart17.DefaultColor = System.Drawing.Color.White;
            this.flowChart17.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart17.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart17.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart17.Location = new System.Drawing.Point(189, 143);
            this.flowChart17.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart17.menuOpening = false;
            this.flowChart17.Name = "flowChart17";
            this.flowChart17.NEXT = this.flowChart16;
            this.flowChart17.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart17.NEXTColor = System.Drawing.Color.Black;
            this.flowChart17.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart17.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart17.Size = new System.Drawing.Size(280, 35);
            this.flowChart17.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart17.SubFlowChart = null;
            this.flowChart17.TabIndex = 92;
            this.flowChart17.Text = "Wait for unload notice";
            this.flowChart17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart17.TimeOut = 10000;
            this.flowChart17.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart17.tmrTimeOut = null;
            this.flowChart17.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart17_FlowRun);
            // 
            // flowChart38
            // 
            this.flowChart38.AlarmCode = "";
            this.flowChart38.ArrowSeparation = 20;
            this.flowChart38.ArrowsWidth = 1;
            this.flowChart38.BackColor = System.Drawing.Color.White;
            this.flowChart38.bClearTrace = false;
            this.flowChart38.bIsLastFlowChart = false;
            this.flowChart38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart38.bSkip = false;
            this.flowChart38.bStepByStepMode = false;
            this.flowChart38.CASE1 = this.flowChart14;
            this.flowChart38.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart38.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart38.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart38.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart38.CASE2 = null;
            this.flowChart38.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart38.CASE2Color = System.Drawing.Color.Red;
            this.flowChart38.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart38.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart38.CASE3 = null;
            this.flowChart38.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart38.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart38.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart38.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart38.DefaultColor = System.Drawing.Color.White;
            this.flowChart38.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart38.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart38.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart38.Location = new System.Drawing.Point(619, 900);
            this.flowChart38.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart38.menuOpening = false;
            this.flowChart38.Name = "flowChart38";
            this.flowChart38.NEXT = this.flowChart50;
            this.flowChart38.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart38.NEXTColor = System.Drawing.Color.Black;
            this.flowChart38.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart38.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart38.Size = new System.Drawing.Size(275, 35);
            this.flowChart38.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart38.SubFlowChart = null;
            this.flowChart38.TabIndex = 92;
            this.flowChart38.Text = "Check Gripper and available Vacant";
            this.flowChart38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart38.TimeOut = 10000;
            this.flowChart38.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart38.tmrTimeOut = null;
            this.flowChart38.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart38_FlowRun);
            // 
            // flowChart14
            // 
            this.flowChart14.AlarmCode = "";
            this.flowChart14.ArrowSeparation = 20;
            this.flowChart14.ArrowsWidth = 1;
            this.flowChart14.BackColor = System.Drawing.Color.White;
            this.flowChart14.bClearTrace = false;
            this.flowChart14.bIsLastFlowChart = false;
            this.flowChart14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart14.bSkip = false;
            this.flowChart14.bStepByStepMode = false;
            this.flowChart14.CASE1 = null;
            this.flowChart14.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart14.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart14.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart14.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart14.CASE2 = null;
            this.flowChart14.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart14.CASE2Color = System.Drawing.Color.Red;
            this.flowChart14.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart14.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart14.CASE3 = null;
            this.flowChart14.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart14.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart14.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart14.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart14.DefaultColor = System.Drawing.Color.White;
            this.flowChart14.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart14.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart14.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart14.Location = new System.Drawing.Point(943, 935);
            this.flowChart14.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart14.menuOpening = false;
            this.flowChart14.Name = "flowChart14";
            this.flowChart14.NEXT = this.flowChart50;
            this.flowChart14.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart14.NEXTColor = System.Drawing.Color.Black;
            this.flowChart14.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart14.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart14.Size = new System.Drawing.Size(132, 55);
            this.flowChart14.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart14.SubFlowChart = null;
            this.flowChart14.TabIndex = 89;
            this.flowChart14.Text = "Alarm Product abnormal";
            this.flowChart14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart14.TimeOut = 10000;
            this.flowChart14.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart14.tmrTimeOut = null;
            this.flowChart14.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart14_FlowRun);
            // 
            // flowChart50
            // 
            this.flowChart50.AlarmCode = "";
            this.flowChart50.ArrowSeparation = 20;
            this.flowChart50.ArrowsWidth = 1;
            this.flowChart50.BackColor = System.Drawing.Color.White;
            this.flowChart50.bClearTrace = false;
            this.flowChart50.bIsLastFlowChart = false;
            this.flowChart50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart50.bSkip = false;
            this.flowChart50.bStepByStepMode = false;
            this.flowChart50.CASE1 = null;
            this.flowChart50.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart50.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart50.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.CASE2 = null;
            this.flowChart50.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart50.CASE2Color = System.Drawing.Color.Red;
            this.flowChart50.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.CASE3 = null;
            this.flowChart50.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart50.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart50.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.DefaultColor = System.Drawing.Color.White;
            this.flowChart50.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart50.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart50.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart50.Location = new System.Drawing.Point(619, 852);
            this.flowChart50.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart50.menuOpening = false;
            this.flowChart50.Name = "flowChart50";
            this.flowChart50.NEXT = this.fcNgMes;   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0 (antes: this.flowChart26)
            this.flowChart50.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart50.NEXTColor = System.Drawing.Color.Black;
            this.flowChart50.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart50.Size = new System.Drawing.Size(275, 35);
            this.flowChart50.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart50.SubFlowChart = null;
            this.flowChart50.TabIndex = 102;
            this.flowChart50.Text = "wait and judge feeder inplace";
            this.flowChart50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart50.TimeOut = 10000;
            this.flowChart50.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart50.tmrTimeOut = null;
            this.flowChart50.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart50_FlowRun);
            // 
            // flowChart26
            // 
            this.flowChart26.AlarmCode = "";
            this.flowChart26.ArrowSeparation = 20;
            this.flowChart26.ArrowsWidth = 1;
            this.flowChart26.BackColor = System.Drawing.Color.White;
            this.flowChart26.bClearTrace = false;
            this.flowChart26.bIsLastFlowChart = false;
            this.flowChart26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart26.bSkip = false;
            this.flowChart26.bStepByStepMode = false;
            this.flowChart26.CASE1 = null;
            this.flowChart26.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart26.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart26.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.CASE2 = null;
            this.flowChart26.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart26.CASE2Color = System.Drawing.Color.Red;
            this.flowChart26.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.CASE3 = null;
            this.flowChart26.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart26.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart26.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.DefaultColor = System.Drawing.Color.White;
            this.flowChart26.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart26.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart26.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart26.Location = new System.Drawing.Point(619, 802);
            this.flowChart26.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart26.menuOpening = false;
            this.flowChart26.Name = "flowChart26";
            this.flowChart26.NEXT = this.flowChart27;
            this.flowChart26.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart26.NEXTColor = System.Drawing.Color.Black;
            this.flowChart26.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart26.Size = new System.Drawing.Size(275, 35);
            this.flowChart26.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart26.SubFlowChart = null;
            this.flowChart26.TabIndex = 98;
            this.flowChart26.Text = "Robot to discharge picture pos";
            this.flowChart26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart26.TimeOut = 10000;
            this.flowChart26.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart26.tmrTimeOut = null;
            this.flowChart26.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart26_FlowRun);
            // 
            // flowChart27
            // 
            this.flowChart27.AlarmCode = "";
            this.flowChart27.ArrowSeparation = 20;
            this.flowChart27.ArrowsWidth = 1;
            this.flowChart27.BackColor = System.Drawing.Color.White;
            this.flowChart27.bClearTrace = false;
            this.flowChart27.bIsLastFlowChart = false;
            this.flowChart27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart27.bSkip = false;
            this.flowChart27.bStepByStepMode = false;
            this.flowChart27.CASE1 = null;
            this.flowChart27.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart27.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart27.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.CASE2 = null;
            this.flowChart27.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart27.CASE2Color = System.Drawing.Color.Red;
            this.flowChart27.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.CASE3 = null;
            this.flowChart27.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart27.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart27.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.DefaultColor = System.Drawing.Color.White;
            this.flowChart27.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart27.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart27.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart27.Location = new System.Drawing.Point(619, 754);
            this.flowChart27.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart27.menuOpening = false;
            this.flowChart27.Name = "flowChart27";
            this.flowChart27.NEXT = this.flowChart3;
            this.flowChart27.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart27.NEXTColor = System.Drawing.Color.Black;
            this.flowChart27.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart27.Size = new System.Drawing.Size(275, 35);
            this.flowChart27.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart27.SubFlowChart = null;
            this.flowChart27.TabIndex = 98;
            this.flowChart27.Text = "Wait robot  in place";
            this.flowChart27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart27.TimeOut = 10000;
            this.flowChart27.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart27.tmrTimeOut = null;
            this.flowChart27.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart27_FlowRun);
            // 
            // flowChart3
            // 
            this.flowChart3.AlarmCode = "";
            this.flowChart3.ArrowSeparation = 20;
            this.flowChart3.ArrowsWidth = 1;
            this.flowChart3.BackColor = System.Drawing.Color.White;
            this.flowChart3.bClearTrace = false;
            this.flowChart3.bIsLastFlowChart = false;
            this.flowChart3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart3.bSkip = false;
            this.flowChart3.bStepByStepMode = false;
            this.flowChart3.CASE1 = null;
            this.flowChart3.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart3.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart3.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.CASE2 = null;
            this.flowChart3.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart3.CASE2Color = System.Drawing.Color.Red;
            this.flowChart3.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.CASE3 = null;
            this.flowChart3.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart3.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart3.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.DefaultColor = System.Drawing.Color.White;
            this.flowChart3.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart3.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart3.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart3.Location = new System.Drawing.Point(619, 702);
            this.flowChart3.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart3.menuOpening = false;
            this.flowChart3.Name = "flowChart3";
            this.flowChart3.NEXT = this.flowChart62;
            this.flowChart3.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart3.NEXTColor = System.Drawing.Color.Black;
            this.flowChart3.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart3.Size = new System.Drawing.Size(275, 38);
            this.flowChart3.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart3.SubFlowChart = null;
            this.flowChart3.TabIndex = 99;
            this.flowChart3.Text = "Send command to get position";
            this.flowChart3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart3.TimeOut = 10000;
            this.flowChart3.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart3.tmrTimeOut = null;
            this.flowChart3.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart3_FlowRun);
            // 
            // flowChart62
            // 
            this.flowChart62.AlarmCode = "";
            this.flowChart62.ArrowSeparation = 20;
            this.flowChart62.ArrowsWidth = 1;
            this.flowChart62.BackColor = System.Drawing.Color.White;
            this.flowChart62.bClearTrace = false;
            this.flowChart62.bIsLastFlowChart = false;
            this.flowChart62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart62.bSkip = false;
            this.flowChart62.bStepByStepMode = false;
            this.flowChart62.CASE1 = this.flowChart3;
            this.flowChart62.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart62.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart62.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.CASE2 = null;
            this.flowChart62.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart62.CASE2Color = System.Drawing.Color.Red;
            this.flowChart62.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.CASE3 = null;
            this.flowChart62.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart62.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart62.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.DefaultColor = System.Drawing.Color.White;
            this.flowChart62.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart62.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart62.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart62.Location = new System.Drawing.Point(619, 651);
            this.flowChart62.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart62.menuOpening = false;
            this.flowChart62.Name = "flowChart62";
            this.flowChart62.NEXT = this.flowChart29;
            this.flowChart62.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart62.NEXTColor = System.Drawing.Color.Black;
            this.flowChart62.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart62.Size = new System.Drawing.Size(275, 38);
            this.flowChart62.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart62.SubFlowChart = null;
            this.flowChart62.TabIndex = 99;
            this.flowChart62.Text = "Get robot position";
            this.flowChart62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart62.TimeOut = 10000;
            this.flowChart62.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart62.tmrTimeOut = null;
            this.flowChart62.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart62_FlowRun);
            // 
            // flowChart29
            // 
            this.flowChart29.AlarmCode = "";
            this.flowChart29.ArrowSeparation = 20;
            this.flowChart29.ArrowsWidth = 1;
            this.flowChart29.BackColor = System.Drawing.Color.White;
            this.flowChart29.bClearTrace = false;
            this.flowChart29.bIsLastFlowChart = false;
            this.flowChart29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart29.bSkip = false;
            this.flowChart29.bStepByStepMode = false;
            this.flowChart29.CASE1 = null;
            this.flowChart29.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart29.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart29.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.CASE2 = null;
            this.flowChart29.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart29.CASE2Color = System.Drawing.Color.Red;
            this.flowChart29.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.CASE3 = null;
            this.flowChart29.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart29.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart29.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.DefaultColor = System.Drawing.Color.White;
            this.flowChart29.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart29.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart29.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart29.Location = new System.Drawing.Point(619, 602);
            this.flowChart29.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart29.menuOpening = false;
            this.flowChart29.Name = "flowChart29";
            this.flowChart29.NEXT = this.flowChart35;
            this.flowChart29.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart29.NEXTColor = System.Drawing.Color.Black;
            this.flowChart29.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart29.Size = new System.Drawing.Size(275, 35);
            this.flowChart29.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart29.SubFlowChart = null;
            this.flowChart29.TabIndex = 98;
            this.flowChart29.Text = "Take a picture";
            this.flowChart29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart29.TimeOut = 10000;
            this.flowChart29.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart29.tmrTimeOut = null;
            this.flowChart29.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart29_FlowRun_1);
            // 
            // flowChart35
            // 
            this.flowChart35.AlarmCode = "";
            this.flowChart35.ArrowSeparation = 20;
            this.flowChart35.ArrowsWidth = 1;
            this.flowChart35.BackColor = System.Drawing.Color.White;
            this.flowChart35.bClearTrace = false;
            this.flowChart35.bIsLastFlowChart = false;
            this.flowChart35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart35.bSkip = false;
            this.flowChart35.bStepByStepMode = false;
            this.flowChart35.CASE1 = this.flowChart39;
            this.flowChart35.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart35.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart35.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart35.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart35.CASE2 = this.flowChart51;
            this.flowChart35.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart35.CASE2Color = System.Drawing.Color.Red;
            this.flowChart35.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart35.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart35.CASE3 = null;
            this.flowChart35.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart35.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart35.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart35.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart35.DefaultColor = System.Drawing.Color.White;
            this.flowChart35.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart35.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart35.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart35.Location = new System.Drawing.Point(619, 555);
            this.flowChart35.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart35.menuOpening = false;
            this.flowChart35.Name = "flowChart35";
            this.flowChart35.NEXT = this.flowChart58;
            this.flowChart35.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart35.NEXTColor = System.Drawing.Color.Black;
            this.flowChart35.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart35.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart35.Size = new System.Drawing.Size(275, 35);
            this.flowChart35.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart35.SubFlowChart = null;
            this.flowChart35.TabIndex = 98;
            this.flowChart35.Text = "Judge picture result";
            this.flowChart35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart35.TimeOut = 10000;
            this.flowChart35.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart35.tmrTimeOut = null;
            this.flowChart35.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart35_FlowRun);
            // 
            // flowChart39
            // 
            this.flowChart39.AlarmCode = "";
            this.flowChart39.ArrowSeparation = 20;
            this.flowChart39.ArrowsWidth = 1;
            this.flowChart39.BackColor = System.Drawing.Color.White;
            this.flowChart39.bClearTrace = false;
            this.flowChart39.bIsLastFlowChart = false;
            this.flowChart39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart39.bSkip = false;
            this.flowChart39.bStepByStepMode = false;
            this.flowChart39.CASE1 = null;
            this.flowChart39.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart39.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart39.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.CASE2 = null;
            this.flowChart39.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart39.CASE2Color = System.Drawing.Color.Red;
            this.flowChart39.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.CASE3 = null;
            this.flowChart39.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart39.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart39.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.DefaultColor = System.Drawing.Color.White;
            this.flowChart39.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart39.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart39.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart39.Location = new System.Drawing.Point(943, 888);
            this.flowChart39.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart39.menuOpening = false;
            this.flowChart39.Name = "flowChart39";
            this.flowChart39.NEXT = this.flowChart38;
            this.flowChart39.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart39.NEXTColor = System.Drawing.Color.Black;
            this.flowChart39.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart39.Size = new System.Drawing.Size(132, 35);
            this.flowChart39.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart39.SubFlowChart = null;
            this.flowChart39.TabIndex = 90;
            this.flowChart39.Text = "Next grasping position";
            this.flowChart39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart39.TimeOut = 10000;
            this.flowChart39.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart39.tmrTimeOut = null;
            this.flowChart39.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart39_FlowRun);
            // 
            // flowChart51
            // 
            this.flowChart51.AlarmCode = "";
            this.flowChart51.ArrowSeparation = 20;
            this.flowChart51.ArrowsWidth = 1;
            this.flowChart51.BackColor = System.Drawing.Color.White;
            this.flowChart51.bClearTrace = false;
            this.flowChart51.bIsLastFlowChart = false;
            this.flowChart51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart51.bSkip = false;
            this.flowChart51.bStepByStepMode = false;
            this.flowChart51.CASE1 = null;
            this.flowChart51.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart51.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart51.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.CASE2 = null;
            this.flowChart51.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart51.CASE2Color = System.Drawing.Color.Red;
            this.flowChart51.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.CASE3 = null;
            this.flowChart51.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart51.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart51.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.DefaultColor = System.Drawing.Color.White;
            this.flowChart51.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart51.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart51.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart51.Location = new System.Drawing.Point(910, 537);
            this.flowChart51.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart51.menuOpening = false;
            this.flowChart51.Name = "flowChart51";
            this.flowChart51.NEXT = this.flowChart39;
            this.flowChart51.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart51.NEXTColor = System.Drawing.Color.Black;
            this.flowChart51.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart51.Size = new System.Drawing.Size(132, 35);
            this.flowChart51.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart51.SubFlowChart = null;
            this.flowChart51.TabIndex = 103;
            this.flowChart51.Text = "wait on safety";
            this.flowChart51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart51.TimeOut = 10000;
            this.flowChart51.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart51.tmrTimeOut = null;
            this.flowChart51.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart51_FlowRun);
            // 
            // flowChart58
            // 
            this.flowChart58.AlarmCode = "";
            this.flowChart58.ArrowSeparation = 20;
            this.flowChart58.ArrowsWidth = 1;
            this.flowChart58.BackColor = System.Drawing.Color.White;
            this.flowChart58.bClearTrace = false;
            this.flowChart58.bIsLastFlowChart = false;
            this.flowChart58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart58.bSkip = false;
            this.flowChart58.bStepByStepMode = false;
            this.flowChart58.CASE1 = null;
            this.flowChart58.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart58.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart58.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.CASE2 = null;
            this.flowChart58.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart58.CASE2Color = System.Drawing.Color.Red;
            this.flowChart58.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.CASE3 = null;
            this.flowChart58.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart58.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart58.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.DefaultColor = System.Drawing.Color.White;
            this.flowChart58.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart58.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart58.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart58.Location = new System.Drawing.Point(619, 506);
            this.flowChart58.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart58.menuOpening = false;
            this.flowChart58.Name = "flowChart58";
            this.flowChart58.NEXT = this.flowChart28;
            this.flowChart58.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart58.NEXTColor = System.Drawing.Color.Black;
            this.flowChart58.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart58.Size = new System.Drawing.Size(275, 35);
            this.flowChart58.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart58.SubFlowChart = null;
            this.flowChart58.TabIndex = 90;
            this.flowChart58.Text = "Start discharging";
            this.flowChart58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart58.TimeOut = 10000;
            this.flowChart58.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart58.tmrTimeOut = null;
            this.flowChart58.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart58_FlowRun);
            // 
            // flowChart28
            // 
            this.flowChart28.AlarmCode = "";
            this.flowChart28.ArrowSeparation = 20;
            this.flowChart28.ArrowsWidth = 1;
            this.flowChart28.BackColor = System.Drawing.Color.White;
            this.flowChart28.bClearTrace = false;
            this.flowChart28.bIsLastFlowChart = false;
            this.flowChart28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart28.bSkip = false;
            this.flowChart28.bStepByStepMode = false;
            this.flowChart28.CASE1 = null;
            this.flowChart28.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart28.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart28.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.CASE2 = null;
            this.flowChart28.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart28.CASE2Color = System.Drawing.Color.Red;
            this.flowChart28.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.CASE3 = null;
            this.flowChart28.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart28.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart28.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.DefaultColor = System.Drawing.Color.White;
            this.flowChart28.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart28.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart28.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart28.Location = new System.Drawing.Point(619, 457);
            this.flowChart28.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart28.menuOpening = false;
            this.flowChart28.Name = "flowChart28";
            this.flowChart28.NEXT = this.flowChart45;
            this.flowChart28.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart28.NEXTColor = System.Drawing.Color.Black;
            this.flowChart28.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart28.Size = new System.Drawing.Size(275, 35);
            this.flowChart28.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart28.SubFlowChart = null;
            this.flowChart28.TabIndex = 93;
            this.flowChart28.Text = "Send release instruction";
            this.flowChart28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart28.TimeOut = 10000;
            this.flowChart28.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart28.tmrTimeOut = null;
            this.flowChart28.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart28_FlowRun);
            // 
            // flowChart45
            // 
            this.flowChart45.AlarmCode = "";
            this.flowChart45.ArrowSeparation = 20;
            this.flowChart45.ArrowsWidth = 1;
            this.flowChart45.BackColor = System.Drawing.Color.White;
            this.flowChart45.bClearTrace = false;
            this.flowChart45.bIsLastFlowChart = false;
            this.flowChart45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart45.bSkip = false;
            this.flowChart45.bStepByStepMode = false;
            this.flowChart45.CASE1 = null;
            this.flowChart45.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart45.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart45.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.CASE2 = null;
            this.flowChart45.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart45.CASE2Color = System.Drawing.Color.Red;
            this.flowChart45.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.CASE3 = null;
            this.flowChart45.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart45.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart45.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.DefaultColor = System.Drawing.Color.White;
            this.flowChart45.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart45.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart45.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart45.Location = new System.Drawing.Point(619, 410);
            this.flowChart45.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart45.menuOpening = false;
            this.flowChart45.Name = "flowChart45";
            this.flowChart45.NEXT = this.flowChart40;
            this.flowChart45.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart45.NEXTColor = System.Drawing.Color.Black;
            this.flowChart45.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart45.Size = new System.Drawing.Size(275, 35);
            this.flowChart45.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart45.SubFlowChart = null;
            this.flowChart45.TabIndex = 95;
            this.flowChart45.Text = "Wait release completed";
            this.flowChart45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart45.TimeOut = 10000;
            this.flowChart45.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart45.tmrTimeOut = null;
            this.flowChart45.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart45_FlowRun);
            // 
            // flowChart40
            // 
            this.flowChart40.AlarmCode = "";
            this.flowChart40.ArrowSeparation = 20;
            this.flowChart40.ArrowsWidth = 1;
            this.flowChart40.BackColor = System.Drawing.Color.White;
            this.flowChart40.bClearTrace = false;
            this.flowChart40.bIsLastFlowChart = false;
            this.flowChart40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart40.bSkip = false;
            this.flowChart40.bStepByStepMode = false;
            this.flowChart40.CASE1 = null;
            this.flowChart40.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart40.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart40.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.CASE2 = null;
            this.flowChart40.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart40.CASE2Color = System.Drawing.Color.Red;
            this.flowChart40.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.CASE3 = null;
            this.flowChart40.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart40.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart40.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.DefaultColor = System.Drawing.Color.White;
            this.flowChart40.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart40.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart40.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart40.Location = new System.Drawing.Point(619, 361);
            this.flowChart40.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart40.menuOpening = false;
            this.flowChart40.Name = "flowChart40";
            this.flowChart40.NEXT = this.flowChart41;
            this.flowChart40.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart40.NEXTColor = System.Drawing.Color.Black;
            this.flowChart40.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart40.Size = new System.Drawing.Size(275, 35);
            this.flowChart40.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart40.SubFlowChart = null;
            this.flowChart40.TabIndex = 95;
            this.flowChart40.Text = "Judge gripper released";
            this.flowChart40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart40.TimeOut = 10000;
            this.flowChart40.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart40.tmrTimeOut = null;
            this.flowChart40.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart40_FlowRun_1);
            // 
            // flowChart16
            // 
            this.flowChart16.AlarmCode = "";
            this.flowChart16.ArrowSeparation = 20;
            this.flowChart16.ArrowsWidth = 1;
            this.flowChart16.BackColor = System.Drawing.Color.White;
            this.flowChart16.bClearTrace = false;
            this.flowChart16.bIsLastFlowChart = false;
            this.flowChart16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart16.bSkip = false;
            this.flowChart16.bStepByStepMode = false;
            this.flowChart16.CASE1 = null;
            this.flowChart16.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart16.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart16.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.CASE2 = null;
            this.flowChart16.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart16.CASE2Color = System.Drawing.Color.Red;
            this.flowChart16.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.CASE3 = null;
            this.flowChart16.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart16.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart16.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.DefaultColor = System.Drawing.Color.White;
            this.flowChart16.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart16.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart16.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart16.Location = new System.Drawing.Point(189, 190);
            this.flowChart16.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart16.menuOpening = false;
            this.flowChart16.Name = "flowChart16";
            this.flowChart16.NEXT = this.flowChart8;
            this.flowChart16.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart16.NEXTColor = System.Drawing.Color.Black;
            this.flowChart16.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart16.Size = new System.Drawing.Size(280, 35);
            this.flowChart16.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart16.SubFlowChart = null;
            this.flowChart16.TabIndex = 98;
            this.flowChart16.Text = "Robot to scan position";
            this.flowChart16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart16.TimeOut = 10000;
            this.flowChart16.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart16.tmrTimeOut = null;
            this.flowChart16.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart16_FlowRun);
            // 
            // flowChart8
            // 
            this.flowChart8.AlarmCode = "";
            this.flowChart8.ArrowSeparation = 20;
            this.flowChart8.ArrowsWidth = 1;
            this.flowChart8.BackColor = System.Drawing.Color.White;
            this.flowChart8.bClearTrace = false;
            this.flowChart8.bIsLastFlowChart = false;
            this.flowChart8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart8.bSkip = false;
            this.flowChart8.bStepByStepMode = false;
            this.flowChart8.CASE1 = null;
            this.flowChart8.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart8.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart8.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.CASE2 = null;
            this.flowChart8.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart8.CASE2Color = System.Drawing.Color.Red;
            this.flowChart8.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.CASE3 = null;
            this.flowChart8.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart8.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart8.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.DefaultColor = System.Drawing.Color.White;
            this.flowChart8.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart8.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart8.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart8.Location = new System.Drawing.Point(189, 238);
            this.flowChart8.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart8.menuOpening = false;
            this.flowChart8.Name = "flowChart8";
            this.flowChart8.NEXT = this.flowChart18;
            this.flowChart8.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart8.NEXTColor = System.Drawing.Color.Black;
            this.flowChart8.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart8.Size = new System.Drawing.Size(280, 35);
            this.flowChart8.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart8.SubFlowChart = null;
            this.flowChart8.TabIndex = 98;
            this.flowChart8.Text = "Wait robot  in place";
            this.flowChart8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart8.TimeOut = 10000;
            this.flowChart8.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart8.tmrTimeOut = null;
            this.flowChart8.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart8_FlowRun_1);
            // 
            // flowChart18
            // 
            this.flowChart18.AlarmCode = "";
            this.flowChart18.ArrowSeparation = 20;
            this.flowChart18.ArrowsWidth = 1;
            this.flowChart18.BackColor = System.Drawing.Color.White;
            this.flowChart18.bClearTrace = false;
            this.flowChart18.bIsLastFlowChart = false;
            this.flowChart18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart18.bSkip = false;
            this.flowChart18.bStepByStepMode = false;
            this.flowChart18.CASE1 = null;
            this.flowChart18.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart18.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart18.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.CASE2 = null;
            this.flowChart18.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart18.CASE2Color = System.Drawing.Color.Red;
            this.flowChart18.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.CASE3 = null;
            this.flowChart18.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart18.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart18.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.DefaultColor = System.Drawing.Color.White;
            this.flowChart18.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart18.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart18.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart18.Location = new System.Drawing.Point(189, 286);
            this.flowChart18.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart18.menuOpening = false;
            this.flowChart18.Name = "flowChart18";
            this.flowChart18.NEXT = this.flowChart65;
            this.flowChart18.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart18.NEXTColor = System.Drawing.Color.Black;
            this.flowChart18.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart18.Size = new System.Drawing.Size(280, 35);
            this.flowChart18.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart18.SubFlowChart = null;
            this.flowChart18.TabIndex = 98;
            this.flowChart18.Text = "Scanning pallet barcode";
            this.flowChart18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart18.TimeOut = 10000;
            this.flowChart18.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart18.tmrTimeOut = null;
            this.flowChart18.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart18_FlowRun);
            // 
            // flowChart65
            // 
            this.flowChart65.AlarmCode = "";
            this.flowChart65.ArrowSeparation = 20;
            this.flowChart65.ArrowsWidth = 1;
            this.flowChart65.BackColor = System.Drawing.Color.White;
            this.flowChart65.bClearTrace = false;
            this.flowChart65.bIsLastFlowChart = false;
            this.flowChart65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart65.bSkip = false;
            this.flowChart65.bStepByStepMode = false;
            this.flowChart65.CASE1 = null;
            this.flowChart65.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart65.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart65.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.CASE2 = null;
            this.flowChart65.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart65.CASE2Color = System.Drawing.Color.Red;
            this.flowChart65.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.CASE3 = null;
            this.flowChart65.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart65.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart65.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.DefaultColor = System.Drawing.Color.White;
            this.flowChart65.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart65.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart65.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart65.Location = new System.Drawing.Point(189, 333);
            this.flowChart65.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart65.menuOpening = false;
            this.flowChart65.Name = "flowChart65";
            this.flowChart65.NEXT = this.flowChart10;
            this.flowChart65.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart65.NEXTColor = System.Drawing.Color.Black;
            this.flowChart65.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart65.Size = new System.Drawing.Size(280, 36);
            this.flowChart65.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart65.SubFlowChart = null;
            this.flowChart65.TabIndex = 100;
            this.flowChart65.Text = "Judge scanning result";
            this.flowChart65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart65.TimeOut = 10000;
            this.flowChart65.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart65.tmrTimeOut = null;
            this.flowChart65.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.FlowChart65_FlowRun);
            // 
            // flowChart10
            // 
            this.flowChart10.AlarmCode = "";
            this.flowChart10.ArrowSeparation = 20;
            this.flowChart10.ArrowsWidth = 1;
            this.flowChart10.BackColor = System.Drawing.Color.White;
            this.flowChart10.bClearTrace = false;
            this.flowChart10.bIsLastFlowChart = false;
            this.flowChart10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart10.bSkip = false;
            this.flowChart10.bStepByStepMode = false;
            this.flowChart10.CASE1 = this.flowChart19;
            this.flowChart10.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart10.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart10.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart10.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart10.CASE2 = null;
            this.flowChart10.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart10.CASE2Color = System.Drawing.Color.Red;
            this.flowChart10.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart10.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart10.CASE3 = null;
            this.flowChart10.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart10.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart10.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart10.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart10.DefaultColor = System.Drawing.Color.White;
            this.flowChart10.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart10.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart10.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart10.Location = new System.Drawing.Point(189, 382);
            this.flowChart10.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart10.menuOpening = false;
            this.flowChart10.Name = "flowChart10";
            this.flowChart10.NEXT = this.flowChart21;
            this.flowChart10.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart10.NEXTColor = System.Drawing.Color.Black;
            this.flowChart10.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart10.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart10.Size = new System.Drawing.Size(280, 35);
            this.flowChart10.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart10.SubFlowChart = null;
            this.flowChart10.TabIndex = 98;
            this.flowChart10.Text = "Judge go on scanning";
            this.flowChart10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart10.TimeOut = 10000;
            this.flowChart10.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart10.tmrTimeOut = null;
            this.flowChart10.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart10_FlowRun_1);
            // 
            // flowChart19
            // 
            this.flowChart19.AlarmCode = "";
            this.flowChart19.ArrowSeparation = 20;
            this.flowChart19.ArrowsWidth = 1;
            this.flowChart19.BackColor = System.Drawing.Color.White;
            this.flowChart19.bClearTrace = false;
            this.flowChart19.bIsLastFlowChart = false;
            this.flowChart19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart19.bSkip = false;
            this.flowChart19.bStepByStepMode = false;
            this.flowChart19.CASE1 = null;
            this.flowChart19.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart19.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart19.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart19.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart19.CASE2 = null;
            this.flowChart19.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart19.CASE2Color = System.Drawing.Color.Red;
            this.flowChart19.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart19.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart19.CASE3 = null;
            this.flowChart19.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart19.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart19.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart19.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart19.DefaultColor = System.Drawing.Color.White;
            this.flowChart19.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart19.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart19.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart19.Location = new System.Drawing.Point(35, 392);
            this.flowChart19.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart19.menuOpening = false;
            this.flowChart19.Name = "flowChart19";
            this.flowChart19.NEXT = this.flowChart16;
            this.flowChart19.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart19.NEXTColor = System.Drawing.Color.Black;
            this.flowChart19.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart19.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart19.Size = new System.Drawing.Size(114, 35);
            this.flowChart19.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart19.SubFlowChart = null;
            this.flowChart19.TabIndex = 98;
            this.flowChart19.Text = "Loop 4 times";
            this.flowChart19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart19.TimeOut = 10000;
            this.flowChart19.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart19.tmrTimeOut = null;
            this.flowChart19.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart19_FlowRun);
            // 
            // flowChart21
            // 
            this.flowChart21.AlarmCode = "";
            this.flowChart21.ArrowSeparation = 20;
            this.flowChart21.ArrowsWidth = 1;
            this.flowChart21.BackColor = System.Drawing.Color.White;
            this.flowChart21.bClearTrace = false;
            this.flowChart21.bIsLastFlowChart = false;
            this.flowChart21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart21.bSkip = false;
            this.flowChart21.bStepByStepMode = false;
            this.flowChart21.CASE1 = null;
            this.flowChart21.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart21.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart21.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.CASE2 = null;
            this.flowChart21.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart21.CASE2Color = System.Drawing.Color.Red;
            this.flowChart21.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.CASE3 = null;
            this.flowChart21.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart21.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart21.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.DefaultColor = System.Drawing.Color.White;
            this.flowChart21.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart21.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart21.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart21.Location = new System.Drawing.Point(189, 430);
            this.flowChart21.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart21.menuOpening = false;
            this.flowChart21.Name = "flowChart21";
            this.flowChart21.NEXT = this.npFlowChart2;
            this.flowChart21.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart21.NEXTColor = System.Drawing.Color.Black;
            this.flowChart21.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart21.Size = new System.Drawing.Size(280, 35);
            this.flowChart21.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart21.SubFlowChart = null;
            this.flowChart21.TabIndex = 98;
            this.flowChart21.Text = "Upload MES to Query ";
            this.flowChart21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart21.TimeOut = 10000;
            this.flowChart21.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart21.tmrTimeOut = null;
            this.flowChart21.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart21_FlowRun);
            // 
            // npFlowChart2
            // 
            this.npFlowChart2.AlarmCode = "";
            this.npFlowChart2.ArrowSeparation = 20;
            this.npFlowChart2.ArrowsWidth = 1;
            this.npFlowChart2.BackColor = System.Drawing.Color.White;
            this.npFlowChart2.bClearTrace = false;
            this.npFlowChart2.bIsLastFlowChart = false;
            this.npFlowChart2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart2.bSkip = false;
            this.npFlowChart2.bStepByStepMode = false;
            this.npFlowChart2.CASE1 = null;
            this.npFlowChart2.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart2.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart2.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.CASE2 = null;
            this.npFlowChart2.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart2.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart2.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.CASE3 = null;
            this.npFlowChart2.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart2.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart2.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart2.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart2.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart2.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart2.Location = new System.Drawing.Point(189, 479);
            this.npFlowChart2.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart2.menuOpening = false;
            this.npFlowChart2.Name = "npFlowChart2";
            this.npFlowChart2.NEXT = this.flowChart20;
            this.npFlowChart2.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart2.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart2.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart2.Size = new System.Drawing.Size(280, 35);
            this.npFlowChart2.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart2.SubFlowChart = null;
            this.npFlowChart2.TabIndex = 114;
            this.npFlowChart2.Text = "Upload MES ";
            this.npFlowChart2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart2.TimeOut = 10000;
            this.npFlowChart2.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart2.tmrTimeOut = null;
            this.npFlowChart2.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart2_FlowRun);
            // 
            // flowChart80
            // 
            this.flowChart80.AlarmCode = "";
            this.flowChart80.ArrowSeparation = 20;
            this.flowChart80.ArrowsWidth = 1;
            this.flowChart80.BackColor = System.Drawing.Color.White;
            this.flowChart80.bClearTrace = false;
            this.flowChart80.bIsLastFlowChart = false;
            this.flowChart80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart80.bSkip = false;
            this.flowChart80.bStepByStepMode = false;
            this.flowChart80.CASE1 = null;
            this.flowChart80.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart80.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart80.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart80.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart80.CASE2 = null;
            this.flowChart80.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart80.CASE2Color = System.Drawing.Color.Red;
            this.flowChart80.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart80.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart80.CASE3 = null;
            this.flowChart80.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart80.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart80.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart80.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart80.DefaultColor = System.Drawing.Color.White;
            this.flowChart80.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart80.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart80.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart80.Location = new System.Drawing.Point(619, 7);
            this.flowChart80.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart80.menuOpening = false;
            this.flowChart80.Name = "flowChart80";
            this.flowChart80.NEXT = this.flowChart15;
            this.flowChart80.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart80.NEXTColor = System.Drawing.Color.Black;
            this.flowChart80.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart80.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart80.Size = new System.Drawing.Size(275, 35);
            this.flowChart80.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart80.SubFlowChart = null;
            this.flowChart80.TabIndex = 110;
            this.flowChart80.Text = "wait on safe";
            this.flowChart80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart80.TimeOut = 10000;
            this.flowChart80.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart80.tmrTimeOut = null;
            this.flowChart80.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart80_FlowRun);
            // 
            // flowChart37
            // 
            this.flowChart37.AlarmCode = "";
            this.flowChart37.ArrowSeparation = 20;
            this.flowChart37.ArrowsWidth = 1;
            this.flowChart37.BackColor = System.Drawing.Color.White;
            this.flowChart37.bClearTrace = false;
            this.flowChart37.bIsLastFlowChart = false;
            this.flowChart37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart37.bSkip = false;
            this.flowChart37.bStepByStepMode = false;
            this.flowChart37.CASE1 = null;
            this.flowChart37.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart37.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart37.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.CASE2 = null;
            this.flowChart37.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart37.CASE2Color = System.Drawing.Color.Red;
            this.flowChart37.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.CASE3 = null;
            this.flowChart37.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart37.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart37.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.DefaultColor = System.Drawing.Color.White;
            this.flowChart37.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart37.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart37.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart37.Location = new System.Drawing.Point(189, 576);
            this.flowChart37.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart37.menuOpening = false;
            this.flowChart37.Name = "flowChart37";
            this.flowChart37.NEXT = this.flowChart22;
            this.flowChart37.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart37.NEXTColor = System.Drawing.Color.Black;
            this.flowChart37.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart37.Size = new System.Drawing.Size(280, 35);
            this.flowChart37.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart37.SubFlowChart = null;
            this.flowChart37.TabIndex = 98;
            this.flowChart37.Text = "Send robot command";
            this.flowChart37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart37.TimeOut = 10000;
            this.flowChart37.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart37.tmrTimeOut = null;
            this.flowChart37.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart37_FlowRun);
            // 
            // flowChart22
            // 
            this.flowChart22.AlarmCode = "";
            this.flowChart22.ArrowSeparation = 20;
            this.flowChart22.ArrowsWidth = 1;
            this.flowChart22.BackColor = System.Drawing.Color.White;
            this.flowChart22.bClearTrace = false;
            this.flowChart22.bIsLastFlowChart = false;
            this.flowChart22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart22.bSkip = false;
            this.flowChart22.bStepByStepMode = false;
            this.flowChart22.CASE1 = null;
            this.flowChart22.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart22.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart22.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.CASE2 = null;
            this.flowChart22.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart22.CASE2Color = System.Drawing.Color.Red;
            this.flowChart22.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.CASE3 = null;
            this.flowChart22.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart22.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart22.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.DefaultColor = System.Drawing.Color.White;
            this.flowChart22.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart22.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart22.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart22.Location = new System.Drawing.Point(189, 624);
            this.flowChart22.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart22.menuOpening = false;
            this.flowChart22.Name = "flowChart22";
            this.flowChart22.NEXT = this.flowChart60;
            this.flowChart22.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart22.NEXTColor = System.Drawing.Color.Black;
            this.flowChart22.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart22.Size = new System.Drawing.Size(280, 35);
            this.flowChart22.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart22.SubFlowChart = null;
            this.flowChart22.TabIndex = 98;
            this.flowChart22.Text = "Wait robot  in place";
            this.flowChart22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart22.TimeOut = 10000;
            this.flowChart22.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart22.tmrTimeOut = null;
            this.flowChart22.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart22_FlowRun);
            // 
            // flowChart60
            // 
            this.flowChart60.AlarmCode = "";
            this.flowChart60.ArrowSeparation = 20;
            this.flowChart60.ArrowsWidth = 1;
            this.flowChart60.BackColor = System.Drawing.Color.White;
            this.flowChart60.bClearTrace = false;
            this.flowChart60.bIsLastFlowChart = false;
            this.flowChart60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart60.bSkip = false;
            this.flowChart60.bStepByStepMode = false;
            this.flowChart60.CASE1 = null;
            this.flowChart60.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart60.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart60.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.CASE2 = null;
            this.flowChart60.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart60.CASE2Color = System.Drawing.Color.Red;
            this.flowChart60.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.CASE3 = null;
            this.flowChart60.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart60.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart60.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.DefaultColor = System.Drawing.Color.White;
            this.flowChart60.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart60.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart60.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart60.Location = new System.Drawing.Point(189, 671);
            this.flowChart60.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart60.menuOpening = false;
            this.flowChart60.Name = "flowChart60";
            this.flowChart60.NEXT = this.flowChart67;
            this.flowChart60.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart60.NEXTColor = System.Drawing.Color.Black;
            this.flowChart60.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart60.Size = new System.Drawing.Size(280, 38);
            this.flowChart60.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart60.SubFlowChart = null;
            this.flowChart60.TabIndex = 99;
            this.flowChart60.Text = "Send command to get position";
            this.flowChart60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart60.TimeOut = 10000;
            this.flowChart60.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart60.tmrTimeOut = null;
            this.flowChart60.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.FlowChart60_FlowRun);
            // 
            // flowChart67
            // 
            this.flowChart67.AlarmCode = "";
            this.flowChart67.ArrowSeparation = 20;
            this.flowChart67.ArrowsWidth = 1;
            this.flowChart67.BackColor = System.Drawing.Color.White;
            this.flowChart67.bClearTrace = false;
            this.flowChart67.bIsLastFlowChart = false;
            this.flowChart67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart67.bSkip = false;
            this.flowChart67.bStepByStepMode = false;
            this.flowChart67.CASE1 = null;
            this.flowChart67.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart67.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart67.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.CASE2 = null;
            this.flowChart67.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart67.CASE2Color = System.Drawing.Color.Red;
            this.flowChart67.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.CASE3 = null;
            this.flowChart67.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart67.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart67.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.DefaultColor = System.Drawing.Color.White;
            this.flowChart67.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart67.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart67.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart67.Location = new System.Drawing.Point(189, 722);
            this.flowChart67.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart67.menuOpening = false;
            this.flowChart67.Name = "flowChart67";
            this.flowChart67.NEXT = this.flowChart23;
            this.flowChart67.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart67.NEXTColor = System.Drawing.Color.Black;
            this.flowChart67.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart67.Size = new System.Drawing.Size(280, 38);
            this.flowChart67.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart67.SubFlowChart = null;
            this.flowChart67.TabIndex = 99;
            this.flowChart67.Text = "Get location";
            this.flowChart67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart67.TimeOut = 10000;
            this.flowChart67.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart67.tmrTimeOut = null;
            this.flowChart67.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart67_FlowRun);
            // 
            // flowChart23
            // 
            this.flowChart23.AlarmCode = "";
            this.flowChart23.ArrowSeparation = 20;
            this.flowChart23.ArrowsWidth = 1;
            this.flowChart23.BackColor = System.Drawing.Color.White;
            this.flowChart23.bClearTrace = false;
            this.flowChart23.bIsLastFlowChart = false;
            this.flowChart23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart23.bSkip = false;
            this.flowChart23.bStepByStepMode = false;
            this.flowChart23.CASE1 = this.flowChart60;
            this.flowChart23.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart23.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart23.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.CASE2 = null;
            this.flowChart23.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart23.CASE2Color = System.Drawing.Color.Red;
            this.flowChart23.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.CASE3 = null;
            this.flowChart23.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart23.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart23.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.DefaultColor = System.Drawing.Color.White;
            this.flowChart23.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart23.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart23.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart23.Location = new System.Drawing.Point(189, 774);
            this.flowChart23.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart23.menuOpening = false;
            this.flowChart23.Name = "flowChart23";
            this.flowChart23.NEXT = this.flowChart34;
            this.flowChart23.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart23.NEXTColor = System.Drawing.Color.Black;
            this.flowChart23.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart23.Size = new System.Drawing.Size(280, 35);
            this.flowChart23.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart23.SubFlowChart = null;
            this.flowChart23.TabIndex = 98;
            this.flowChart23.Text = "Take a picture";
            this.flowChart23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart23.TimeOut = 10000;
            this.flowChart23.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart23.tmrTimeOut = null;
            this.flowChart23.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart23_FlowRun);
            // 
            // flowChart34
            // 
            this.flowChart34.AlarmCode = "";
            this.flowChart34.ArrowSeparation = 20;
            this.flowChart34.ArrowsWidth = 1;
            this.flowChart34.BackColor = System.Drawing.Color.White;
            this.flowChart34.bClearTrace = false;
            this.flowChart34.bIsLastFlowChart = false;
            this.flowChart34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart34.bSkip = false;
            this.flowChart34.bStepByStepMode = false;
            this.flowChart34.CASE1 = this.flowChart52;
            this.flowChart34.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart34.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart34.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart34.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart34.CASE2 = null;
            this.flowChart34.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart34.CASE2Color = System.Drawing.Color.Red;
            this.flowChart34.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart34.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart34.CASE3 = null;
            this.flowChart34.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart34.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart34.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart34.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart34.DefaultColor = System.Drawing.Color.White;
            this.flowChart34.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart34.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart34.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart34.Location = new System.Drawing.Point(189, 821);
            this.flowChart34.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart34.menuOpening = false;
            this.flowChart34.Name = "flowChart34";
            this.flowChart34.NEXT = this.flowChart36;
            this.flowChart34.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart34.NEXTColor = System.Drawing.Color.Black;
            this.flowChart34.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart34.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart34.Size = new System.Drawing.Size(280, 35);
            this.flowChart34.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart34.SubFlowChart = null;
            this.flowChart34.TabIndex = 98;
            this.flowChart34.Text = "Get picture results";
            this.flowChart34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart34.TimeOut = 10000;
            this.flowChart34.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart34.tmrTimeOut = null;
            this.flowChart34.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart34_FlowRun);
            // 
            // flowChart52
            // 
            this.flowChart52.AlarmCode = "";
            this.flowChart52.ArrowSeparation = 20;
            this.flowChart52.ArrowsWidth = 1;
            this.flowChart52.BackColor = System.Drawing.Color.White;
            this.flowChart52.bClearTrace = false;
            this.flowChart52.bIsLastFlowChart = false;
            this.flowChart52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart52.bSkip = false;
            this.flowChart52.bStepByStepMode = false;
            this.flowChart52.CASE1 = null;
            this.flowChart52.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart52.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart52.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart52.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart52.CASE2 = null;
            this.flowChart52.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart52.CASE2Color = System.Drawing.Color.Red;
            this.flowChart52.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart52.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart52.CASE3 = null;
            this.flowChart52.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart52.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart52.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart52.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart52.DefaultColor = System.Drawing.Color.White;
            this.flowChart52.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart52.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart52.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart52.Location = new System.Drawing.Point(35, 705);
            this.flowChart52.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart52.menuOpening = false;
            this.flowChart52.Name = "flowChart52";
            this.flowChart52.NEXT = this.flowChart20;
            this.flowChart52.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart52.NEXTColor = System.Drawing.Color.Black;
            this.flowChart52.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart52.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart52.Size = new System.Drawing.Size(114, 35);
            this.flowChart52.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart52.SubFlowChart = null;
            this.flowChart52.TabIndex = 98;
            this.flowChart52.Text = "Loop Picture";
            this.flowChart52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart52.TimeOut = 10000;
            this.flowChart52.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart52.tmrTimeOut = null;
            this.flowChart52.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart52_FlowRun);
            // 
            // flowChart61
            // 
            this.flowChart61.AlarmCode = "";
            this.flowChart61.ArrowSeparation = 20;
            this.flowChart61.ArrowsWidth = 1;
            this.flowChart61.BackColor = System.Drawing.Color.White;
            this.flowChart61.bClearTrace = false;
            this.flowChart61.bIsLastFlowChart = false;
            this.flowChart61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart61.bSkip = false;
            this.flowChart61.bStepByStepMode = false;
            this.flowChart61.CASE1 = null;
            this.flowChart61.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart61.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart61.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart61.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart61.CASE2 = null;
            this.flowChart61.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart61.CASE2Color = System.Drawing.Color.Red;
            this.flowChart61.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart61.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart61.CASE3 = null;
            this.flowChart61.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart61.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart61.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart61.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart61.DefaultColor = System.Drawing.Color.White;
            this.flowChart61.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart61.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart61.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart61.Location = new System.Drawing.Point(511, 528);
            this.flowChart61.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart61.menuOpening = false;
            this.flowChart61.Name = "flowChart61";
            this.flowChart61.NEXT = this.flowChart20;
            this.flowChart61.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart61.NEXTColor = System.Drawing.Color.Black;
            this.flowChart61.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart61.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart61.Size = new System.Drawing.Size(82, 35);
            this.flowChart61.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart61.SubFlowChart = null;
            this.flowChart61.TabIndex = 104;
            this.flowChart61.Text = "Safe";
            this.flowChart61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart61.TimeOut = 10000;
            this.flowChart61.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart61.tmrTimeOut = null;
            this.flowChart61.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart61_FlowRun);
            // 
            // flowChart68
            // 
            this.flowChart68.AlarmCode = "";
            this.flowChart68.ArrowSeparation = 20;
            this.flowChart68.ArrowsWidth = 1;
            this.flowChart68.BackColor = System.Drawing.Color.White;
            this.flowChart68.bClearTrace = false;
            this.flowChart68.bIsLastFlowChart = false;
            this.flowChart68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart68.bSkip = false;
            this.flowChart68.bStepByStepMode = false;
            this.flowChart68.CASE1 = this.flowChart70;
            this.flowChart68.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart68.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart68.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart68.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart68.CASE2 = null;
            this.flowChart68.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart68.CASE2Color = System.Drawing.Color.Red;
            this.flowChart68.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart68.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart68.CASE3 = null;
            this.flowChart68.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart68.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart68.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart68.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart68.DefaultColor = System.Drawing.Color.White;
            this.flowChart68.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart68.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart68.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart68.Location = new System.Drawing.Point(545, 125);
            this.flowChart68.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart68.menuOpening = false;
            this.flowChart68.Name = "flowChart68";
            this.flowChart68.NEXT = this.flowChart15;
            this.flowChart68.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart68.NEXTColor = System.Drawing.Color.Black;
            this.flowChart68.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart68.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart68.Size = new System.Drawing.Size(48, 35);
            this.flowChart68.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart68.SubFlowChart = null;
            this.flowChart68.TabIndex = 107;
            this.flowChart68.Text = "Null";
            this.flowChart68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart68.TimeOut = 10000;
            this.flowChart68.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart68.tmrTimeOut = null;
            this.flowChart68.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart68_FlowRun);
            // 
            // flowChart70
            // 
            this.flowChart70.AlarmCode = "";
            this.flowChart70.ArrowSeparation = 20;
            this.flowChart70.ArrowsWidth = 1;
            this.flowChart70.BackColor = System.Drawing.Color.White;
            this.flowChart70.bClearTrace = false;
            this.flowChart70.bIsLastFlowChart = false;
            this.flowChart70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart70.bSkip = false;
            this.flowChart70.bStepByStepMode = false;
            this.flowChart70.CASE1 = null;
            this.flowChart70.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart70.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart70.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart70.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart70.CASE2 = null;
            this.flowChart70.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart70.CASE2Color = System.Drawing.Color.Red;
            this.flowChart70.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart70.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart70.CASE3 = null;
            this.flowChart70.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart70.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart70.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart70.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart70.DefaultColor = System.Drawing.Color.White;
            this.flowChart70.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart70.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart70.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart70.Location = new System.Drawing.Point(473, 125);
            this.flowChart70.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart70.menuOpening = false;
            this.flowChart70.Name = "flowChart70";
            this.flowChart70.NEXT = this.flowChart15;
            this.flowChart70.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart70.NEXTColor = System.Drawing.Color.Black;
            this.flowChart70.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart70.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Top;
            this.flowChart70.Size = new System.Drawing.Size(49, 35);
            this.flowChart70.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart70.SubFlowChart = null;
            this.flowChart70.TabIndex = 108;
            this.flowChart70.Text = "Safe";
            this.flowChart70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart70.TimeOut = 10000;
            this.flowChart70.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart70.tmrTimeOut = null;
            this.flowChart70.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart70_FlowRun);
            // 
            // npFlowChart7
            // 
            this.npFlowChart7.AlarmCode = "";
            this.npFlowChart7.ArrowSeparation = 20;
            this.npFlowChart7.ArrowsWidth = 1;
            this.npFlowChart7.BackColor = System.Drawing.Color.White;
            this.npFlowChart7.bClearTrace = false;
            this.npFlowChart7.bIsLastFlowChart = false;
            this.npFlowChart7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart7.bSkip = false;
            this.npFlowChart7.bStepByStepMode = false;
            this.npFlowChart7.CASE1 = null;
            this.npFlowChart7.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart7.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart7.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart7.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart7.CASE2 = null;
            this.npFlowChart7.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart7.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart7.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart7.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart7.CASE3 = null;
            this.npFlowChart7.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart7.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart7.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart7.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart7.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart7.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart7.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart7.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart7.Location = new System.Drawing.Point(8, 29);
            this.npFlowChart7.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart7.menuOpening = false;
            this.npFlowChart7.Name = "npFlowChart7";
            this.npFlowChart7.NEXT = this.flowChart15;
            this.npFlowChart7.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart7.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart7.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.npFlowChart7.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.npFlowChart7.Size = new System.Drawing.Size(141, 35);
            this.npFlowChart7.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart7.SubFlowChart = null;
            this.npFlowChart7.TabIndex = 115;
            this.npFlowChart7.Text = "CheckModuleID";
            this.npFlowChart7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart7.TimeOut = 10000;
            this.npFlowChart7.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart7.tmrTimeOut = null;
            this.npFlowChart7.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart7_FlowRun);
            // 
            // fc_RobotStart
            // 
            this.fc_RobotStart.AlarmCode = "";
            this.fc_RobotStart.ArrowSeparation = 20;
            this.fc_RobotStart.ArrowsWidth = 1;
            this.fc_RobotStart.BackColor = System.Drawing.Color.White;
            this.fc_RobotStart.bClearTrace = false;
            this.fc_RobotStart.bIsLastFlowChart = false;
            this.fc_RobotStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_RobotStart.bSkip = false;
            this.fc_RobotStart.bStepByStepMode = false;
            this.fc_RobotStart.CASE1 = null;
            this.fc_RobotStart.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_RobotStart.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_RobotStart.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.CASE2 = null;
            this.fc_RobotStart.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_RobotStart.CASE2Color = System.Drawing.Color.Red;
            this.fc_RobotStart.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.CASE3 = null;
            this.fc_RobotStart.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_RobotStart.CASE3Color = System.Drawing.Color.Blue;
            this.fc_RobotStart.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.DefaultColor = System.Drawing.Color.White;
            this.fc_RobotStart.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_RobotStart.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_RobotStart.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_RobotStart.Location = new System.Drawing.Point(189, 7);
            this.fc_RobotStart.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_RobotStart.menuOpening = false;
            this.fc_RobotStart.Name = "fc_RobotStart";
            this.fc_RobotStart.NEXT = this.npFlowChart7;
            this.fc_RobotStart.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_RobotStart.NEXTColor = System.Drawing.Color.Black;
            this.fc_RobotStart.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_RobotStart.Size = new System.Drawing.Size(280, 35);
            this.fc_RobotStart.SkipColor = System.Drawing.Color.Yellow;
            this.fc_RobotStart.SubFlowChart = null;
            this.fc_RobotStart.TabIndex = 92;
            this.fc_RobotStart.Text = "Robot process start";
            this.fc_RobotStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_RobotStart.TimeOut = 10000;
            this.fc_RobotStart.TimeoutColor = System.Drawing.Color.Red;
            this.fc_RobotStart.tmrTimeOut = null;
            this.fc_RobotStart.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_RobotStart_FlowRun);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage15);
            this.tabControl2.Controls.Add(this.tb_Robot1AlarmInfo);
            this.tabControl2.Controls.Add(this.tabPage23);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(672, 1437);
            this.tabControl2.TabIndex = 25;
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.flowChart83);
            this.tabPage23.Controls.Add(this.flowChart76);
            this.tabPage23.Controls.Add(this.flowChart79);
            this.tabPage23.Controls.Add(this.flowChart75);
            this.tabPage23.Controls.Add(this.flowChart78);
            this.tabPage23.Controls.Add(this.flowChart77);
            this.tabPage23.Controls.Add(this.flowChart74);
            this.tabPage23.Controls.Add(this.flowChart73);
            this.tabPage23.Controls.Add(this.flowChart72);
            this.tabPage23.Controls.Add(this.flowChart69);
            this.tabPage23.Location = new System.Drawing.Point(4, 31);
            this.tabPage23.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Size = new System.Drawing.Size(780, 1402);
            this.tabPage23.TabIndex = 12;
            this.tabPage23.Text = "Feeder";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // flowChart83
            // 
            this.flowChart83.AlarmCode = "";
            this.flowChart83.ArrowSeparation = 20;
            this.flowChart83.ArrowsWidth = 1;
            this.flowChart83.BackColor = System.Drawing.Color.White;
            this.flowChart83.bClearTrace = false;
            this.flowChart83.bIsLastFlowChart = false;
            this.flowChart83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart83.bSkip = false;
            this.flowChart83.bStepByStepMode = false;
            this.flowChart83.CASE1 = null;
            this.flowChart83.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart83.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart83.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart83.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart83.CASE2 = null;
            this.flowChart83.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart83.CASE2Color = System.Drawing.Color.Red;
            this.flowChart83.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart83.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart83.CASE3 = null;
            this.flowChart83.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart83.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart83.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart83.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart83.DefaultColor = System.Drawing.Color.White;
            this.flowChart83.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart83.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart83.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart83.Location = new System.Drawing.Point(133, 475);
            this.flowChart83.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart83.menuOpening = false;
            this.flowChart83.Name = "flowChart83";
            this.flowChart83.NEXT = this.flowChart79;
            this.flowChart83.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart83.NEXTColor = System.Drawing.Color.Black;
            this.flowChart83.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart83.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart83.Size = new System.Drawing.Size(258, 32);
            this.flowChart83.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart83.SubFlowChart = null;
            this.flowChart83.TabIndex = 91;
            this.flowChart83.Text = "feeder not ready";
            this.flowChart83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart83.TimeOut = 10000;
            this.flowChart83.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart83.tmrTimeOut = null;
            this.flowChart83.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart83_FlowRun);
            // 
            // flowChart79
            // 
            this.flowChart79.AlarmCode = "";
            this.flowChart79.ArrowSeparation = 20;
            this.flowChart79.ArrowsWidth = 1;
            this.flowChart79.BackColor = System.Drawing.Color.White;
            this.flowChart79.bClearTrace = false;
            this.flowChart79.bIsLastFlowChart = false;
            this.flowChart79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart79.bSkip = false;
            this.flowChart79.bStepByStepMode = false;
            this.flowChart79.CASE1 = null;
            this.flowChart79.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart79.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart79.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart79.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart79.CASE2 = null;
            this.flowChart79.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart79.CASE2Color = System.Drawing.Color.Red;
            this.flowChart79.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart79.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart79.CASE3 = null;
            this.flowChart79.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart79.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart79.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart79.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart79.DefaultColor = System.Drawing.Color.White;
            this.flowChart79.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart79.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart79.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart79.Location = new System.Drawing.Point(133, 551);
            this.flowChart79.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart79.menuOpening = false;
            this.flowChart79.Name = "flowChart79";
            this.flowChart79.NEXT = this.flowChart78;
            this.flowChart79.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart79.NEXTColor = System.Drawing.Color.Black;
            this.flowChart79.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart79.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.flowChart79.Size = new System.Drawing.Size(258, 32);
            this.flowChart79.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart79.SubFlowChart = null;
            this.flowChart79.TabIndex = 89;
            this.flowChart79.Text = "wait feeder ready";
            this.flowChart79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart79.TimeOut = 10000;
            this.flowChart79.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart79.tmrTimeOut = null;
            this.flowChart79.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart79_FlowRun);
            // 
            // flowChart78
            // 
            this.flowChart78.AlarmCode = "";
            this.flowChart78.ArrowSeparation = 20;
            this.flowChart78.ArrowsWidth = 1;
            this.flowChart78.BackColor = System.Drawing.Color.White;
            this.flowChart78.bClearTrace = false;
            this.flowChart78.bIsLastFlowChart = false;
            this.flowChart78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart78.bSkip = false;
            this.flowChart78.bStepByStepMode = false;
            this.flowChart78.CASE1 = null;
            this.flowChart78.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart78.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart78.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.CASE2 = null;
            this.flowChart78.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart78.CASE2Color = System.Drawing.Color.Red;
            this.flowChart78.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.CASE3 = null;
            this.flowChart78.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart78.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart78.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.DefaultColor = System.Drawing.Color.White;
            this.flowChart78.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart78.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart78.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart78.Location = new System.Drawing.Point(502, 437);
            this.flowChart78.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart78.menuOpening = false;
            this.flowChart78.Name = "flowChart78";
            this.flowChart78.NEXT = this.flowChart76;
            this.flowChart78.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart78.NEXTColor = System.Drawing.Color.Black;
            this.flowChart78.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart78.Size = new System.Drawing.Size(258, 32);
            this.flowChart78.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart78.SubFlowChart = null;
            this.flowChart78.TabIndex = 87;
            this.flowChart78.Text = "Notice feeder supply";
            this.flowChart78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart78.TimeOut = 10000;
            this.flowChart78.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart78.tmrTimeOut = null;
            this.flowChart78.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart78_FlowRun);
            // 
            // flowChart76
            // 
            this.flowChart76.AlarmCode = "";
            this.flowChart76.ArrowSeparation = 20;
            this.flowChart76.ArrowsWidth = 1;
            this.flowChart76.BackColor = System.Drawing.Color.White;
            this.flowChart76.bClearTrace = false;
            this.flowChart76.bIsLastFlowChart = false;
            this.flowChart76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart76.bSkip = false;
            this.flowChart76.bStepByStepMode = false;
            this.flowChart76.CASE1 = null;
            this.flowChart76.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart76.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart76.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.CASE2 = null;
            this.flowChart76.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart76.CASE2Color = System.Drawing.Color.Red;
            this.flowChart76.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.CASE3 = null;
            this.flowChart76.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart76.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart76.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.DefaultColor = System.Drawing.Color.White;
            this.flowChart76.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart76.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart76.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart76.Location = new System.Drawing.Point(502, 371);
            this.flowChart76.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart76.menuOpening = false;
            this.flowChart76.Name = "flowChart76";
            this.flowChart76.NEXT = this.flowChart77;
            this.flowChart76.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart76.NEXTColor = System.Drawing.Color.Black;
            this.flowChart76.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart76.Size = new System.Drawing.Size(258, 32);
            this.flowChart76.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart76.SubFlowChart = null;
            this.flowChart76.TabIndex = 90;
            this.flowChart76.Text = "wait inplace off";
            this.flowChart76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart76.TimeOut = 10000;
            this.flowChart76.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart76.tmrTimeOut = null;
            this.flowChart76.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart76_FlowRun);
            // 
            // flowChart77
            // 
            this.flowChart77.AlarmCode = "";
            this.flowChart77.ArrowSeparation = 20;
            this.flowChart77.ArrowsWidth = 1;
            this.flowChart77.BackColor = System.Drawing.Color.White;
            this.flowChart77.bClearTrace = false;
            this.flowChart77.bIsLastFlowChart = false;
            this.flowChart77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart77.bSkip = false;
            this.flowChart77.bStepByStepMode = false;
            this.flowChart77.CASE1 = null;
            this.flowChart77.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart77.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart77.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.CASE2 = null;
            this.flowChart77.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart77.CASE2Color = System.Drawing.Color.Red;
            this.flowChart77.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.CASE3 = null;
            this.flowChart77.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart77.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart77.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.DefaultColor = System.Drawing.Color.White;
            this.flowChart77.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart77.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart77.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart77.Location = new System.Drawing.Point(502, 306);
            this.flowChart77.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart77.menuOpening = false;
            this.flowChart77.Name = "flowChart77";
            this.flowChart77.NEXT = this.flowChart73;
            this.flowChart77.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart77.NEXTColor = System.Drawing.Color.Black;
            this.flowChart77.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart77.Size = new System.Drawing.Size(258, 32);
            this.flowChart77.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart77.SubFlowChart = null;
            this.flowChart77.TabIndex = 86;
            this.flowChart77.Text = "wait product inplace";
            this.flowChart77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart77.TimeOut = 10000;
            this.flowChart77.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart77.tmrTimeOut = null;
            this.flowChart77.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart77_FlowRun);
            // 
            // flowChart73
            // 
            this.flowChart73.AlarmCode = "";
            this.flowChart73.ArrowSeparation = 20;
            this.flowChart73.ArrowsWidth = 1;
            this.flowChart73.BackColor = System.Drawing.Color.White;
            this.flowChart73.bClearTrace = false;
            this.flowChart73.bIsLastFlowChart = false;
            this.flowChart73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart73.bSkip = false;
            this.flowChart73.bStepByStepMode = false;
            this.flowChart73.CASE1 = null;
            this.flowChart73.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart73.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart73.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.CASE2 = null;
            this.flowChart73.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart73.CASE2Color = System.Drawing.Color.Red;
            this.flowChart73.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.CASE3 = null;
            this.flowChart73.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart73.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart73.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.DefaultColor = System.Drawing.Color.White;
            this.flowChart73.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart73.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart73.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart73.Location = new System.Drawing.Point(133, 306);
            this.flowChart73.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart73.menuOpening = false;
            this.flowChart73.Name = "flowChart73";
            this.flowChart73.NEXT = this.flowChart74;
            this.flowChart73.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart73.NEXTColor = System.Drawing.Color.Black;
            this.flowChart73.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart73.Size = new System.Drawing.Size(258, 32);
            this.flowChart73.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart73.SubFlowChart = null;
            this.flowChart73.TabIndex = 84;
            this.flowChart73.Text = "judge tray inplace";
            this.flowChart73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart73.TimeOut = 10000;
            this.flowChart73.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart73.tmrTimeOut = null;
            this.flowChart73.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart73_FlowRun);
            // 
            // flowChart74
            // 
            this.flowChart74.AlarmCode = "";
            this.flowChart74.ArrowSeparation = 20;
            this.flowChart74.ArrowsWidth = 1;
            this.flowChart74.BackColor = System.Drawing.Color.White;
            this.flowChart74.bClearTrace = false;
            this.flowChart74.bIsLastFlowChart = false;
            this.flowChart74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart74.bSkip = false;
            this.flowChart74.bStepByStepMode = false;
            this.flowChart74.CASE1 = this.flowChart83;
            this.flowChart74.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart74.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart74.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart74.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart74.CASE2 = null;
            this.flowChart74.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart74.CASE2Color = System.Drawing.Color.Red;
            this.flowChart74.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart74.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart74.CASE3 = null;
            this.flowChart74.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart74.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart74.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart74.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart74.DefaultColor = System.Drawing.Color.White;
            this.flowChart74.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart74.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart74.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart74.Location = new System.Drawing.Point(133, 389);
            this.flowChart74.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart74.menuOpening = false;
            this.flowChart74.Name = "flowChart74";
            this.flowChart74.NEXT = this.flowChart78;
            this.flowChart74.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.flowChart74.NEXTColor = System.Drawing.Color.Black;
            this.flowChart74.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.flowChart74.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart74.Size = new System.Drawing.Size(258, 32);
            this.flowChart74.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart74.SubFlowChart = null;
            this.flowChart74.TabIndex = 85;
            this.flowChart74.Text = "wait pick compelet";
            this.flowChart74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart74.TimeOut = 10000;
            this.flowChart74.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart74.tmrTimeOut = null;
            this.flowChart74.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart74_FlowRun);
            // 
            // flowChart75
            // 
            this.flowChart75.AlarmCode = "";
            this.flowChart75.ArrowSeparation = 20;
            this.flowChart75.ArrowsWidth = 1;
            this.flowChart75.BackColor = System.Drawing.Color.White;
            this.flowChart75.bClearTrace = false;
            this.flowChart75.bIsLastFlowChart = false;
            this.flowChart75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart75.bSkip = false;
            this.flowChart75.bStepByStepMode = false;
            this.flowChart75.CASE1 = null;
            this.flowChart75.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart75.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart75.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.CASE2 = null;
            this.flowChart75.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart75.CASE2Color = System.Drawing.Color.Red;
            this.flowChart75.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.CASE3 = null;
            this.flowChart75.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart75.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart75.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.DefaultColor = System.Drawing.Color.White;
            this.flowChart75.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart75.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart75.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart75.Location = new System.Drawing.Point(133, 145);
            this.flowChart75.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart75.menuOpening = false;
            this.flowChart75.Name = "flowChart75";
            this.flowChart75.NEXT = this.flowChart72;
            this.flowChart75.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart75.NEXTColor = System.Drawing.Color.Black;
            this.flowChart75.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart75.Size = new System.Drawing.Size(258, 32);
            this.flowChart75.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart75.SubFlowChart = null;
            this.flowChart75.TabIndex = 88;
            this.flowChart75.Text = "feeder alarm";
            this.flowChart75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart75.TimeOut = 10000;
            this.flowChart75.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart75.tmrTimeOut = null;
            this.flowChart75.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart75_FlowRun);
            // 
            // flowChart72
            // 
            this.flowChart72.AlarmCode = "";
            this.flowChart72.ArrowSeparation = 20;
            this.flowChart72.ArrowsWidth = 1;
            this.flowChart72.BackColor = System.Drawing.Color.White;
            this.flowChart72.bClearTrace = false;
            this.flowChart72.bIsLastFlowChart = false;
            this.flowChart72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart72.bSkip = false;
            this.flowChart72.bStepByStepMode = false;
            this.flowChart72.CASE1 = null;
            this.flowChart72.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart72.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart72.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.CASE2 = null;
            this.flowChart72.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart72.CASE2Color = System.Drawing.Color.Red;
            this.flowChart72.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.CASE3 = null;
            this.flowChart72.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart72.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart72.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.DefaultColor = System.Drawing.Color.White;
            this.flowChart72.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart72.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart72.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart72.Location = new System.Drawing.Point(133, 224);
            this.flowChart72.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart72.menuOpening = false;
            this.flowChart72.Name = "flowChart72";
            this.flowChart72.NEXT = this.flowChart73;
            this.flowChart72.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart72.NEXTColor = System.Drawing.Color.Black;
            this.flowChart72.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart72.Size = new System.Drawing.Size(258, 32);
            this.flowChart72.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart72.SubFlowChart = null;
            this.flowChart72.TabIndex = 83;
            this.flowChart72.Text = "feeder ready";
            this.flowChart72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart72.TimeOut = 10000;
            this.flowChart72.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart72.tmrTimeOut = null;
            this.flowChart72.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart72_FlowRun);
            // 
            // flowChart69
            // 
            this.flowChart69.AlarmCode = "";
            this.flowChart69.ArrowSeparation = 20;
            this.flowChart69.ArrowsWidth = 1;
            this.flowChart69.BackColor = System.Drawing.Color.White;
            this.flowChart69.bClearTrace = false;
            this.flowChart69.bIsLastFlowChart = false;
            this.flowChart69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart69.bSkip = false;
            this.flowChart69.bStepByStepMode = false;
            this.flowChart69.CASE1 = null;
            this.flowChart69.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart69.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart69.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.CASE2 = null;
            this.flowChart69.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart69.CASE2Color = System.Drawing.Color.Red;
            this.flowChart69.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.CASE3 = null;
            this.flowChart69.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart69.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart69.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.DefaultColor = System.Drawing.Color.White;
            this.flowChart69.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart69.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart69.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart69.Location = new System.Drawing.Point(133, 67);
            this.flowChart69.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.flowChart69.menuOpening = false;
            this.flowChart69.Name = "flowChart69";
            this.flowChart69.NEXT = this.flowChart75;
            this.flowChart69.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart69.NEXTColor = System.Drawing.Color.Black;
            this.flowChart69.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart69.Size = new System.Drawing.Size(258, 32);
            this.flowChart69.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart69.SubFlowChart = null;
            this.flowChart69.TabIndex = 82;
            this.flowChart69.Text = "start";
            this.flowChart69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart69.TimeOut = 10000;
            this.flowChart69.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart69.tmrTimeOut = null;
            this.flowChart69.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart69_FlowRun);
            // 
            // dataColumn98
            // 
            this.dataColumn98.ColumnName = "RobotPort";
            this.dataColumn98.DataType = typeof(int);
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage20);
            this.tabControl4.Controls.Add(this.tabPage21);
            this.tabControl4.Controls.Add(this.tabPage22);
            this.tabControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl4.Location = new System.Drawing.Point(0, 0);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(788, 1437);
            this.tabControl4.TabIndex = 46;
            this.tabControl4.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl4_Selected);
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.tableLayoutPanel20);
            this.tabPage20.Location = new System.Drawing.Point(4, 31);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(780, 1402);
            this.tabPage20.TabIndex = 0;
            this.tabPage20.Text = "Feeder";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 2;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.54152F));
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.45848F));
            this.tableLayoutPanel20.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.groupBox6, 1, 0);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 1;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(774, 1396);
            this.tableLayoutPanel20.TabIndex = 0;
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.tableLayoutPanel21);
            this.tabPage21.Location = new System.Drawing.Point(4, 31);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(664, 1402);
            this.tabPage21.TabIndex = 3;
            this.tabPage21.Text = "Robot";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 3;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.97763F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.35347F));
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.57401F));
            this.tableLayoutPanel21.Controls.Add(this.groupBox17, 2, 0);
            this.tableLayoutPanel21.Controls.Add(this.groupBox5, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.groupBox14, 1, 0);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 1;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(658, 1396);
            this.tableLayoutPanel21.TabIndex = 0;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.tableLayoutPanel25);
            this.groupBox17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox17.Location = new System.Drawing.Point(439, 3);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(216, 1390);
            this.groupBox17.TabIndex = 43;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Robot DO";
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 1;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.tableLayoutPanel26, 0, 0);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 1;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1363F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(210, 1363);
            this.tableLayoutPanel25.TabIndex = 0;
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 2;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_1, 1, 1);
            this.tableLayoutPanel26.Controls.Add(this.textBox54, 1, 0);
            this.tableLayoutPanel26.Controls.Add(this.bt_WriteIO, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_2, 1, 2);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_3, 1, 3);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_4, 1, 4);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_5, 1, 5);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_6, 1, 6);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_7, 1, 7);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_8, 1, 8);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_9, 1, 9);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_10, 1, 10);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_11, 1, 11);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_12, 1, 12);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_13, 1, 13);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_14, 1, 14);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_15, 1, 15);
            this.tableLayoutPanel26.Controls.Add(this.chk_Output_16, 1, 16);
            this.tableLayoutPanel26.Controls.Add(this.label87, 0, 1);
            this.tableLayoutPanel26.Controls.Add(this.label95, 0, 2);
            this.tableLayoutPanel26.Controls.Add(this.label23, 0, 3);
            this.tableLayoutPanel26.Controls.Add(this.label93, 0, 4);
            this.tableLayoutPanel26.Controls.Add(this.label94, 0, 5);
            this.tableLayoutPanel26.Controls.Add(this.label96, 0, 6);
            this.tableLayoutPanel26.Controls.Add(this.label97, 0, 7);
            this.tableLayoutPanel26.Controls.Add(this.label98, 0, 8);
            this.tableLayoutPanel26.Controls.Add(this.label99, 0, 9);
            this.tableLayoutPanel26.Controls.Add(this.label100, 0, 10);
            this.tableLayoutPanel26.Controls.Add(this.label101, 0, 11);
            this.tableLayoutPanel26.Controls.Add(this.label102, 0, 12);
            this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 17;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(204, 1357);
            this.tableLayoutPanel26.TabIndex = 0;
            // 
            // chk_Output_1
            // 
            this.chk_Output_1.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_1.AutoSize = true;
            this.chk_Output_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_1.BackgroundImage")));
            this.chk_Output_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_1.Location = new System.Drawing.Point(145, 126);
            this.chk_Output_1.Name = "chk_Output_1";
            this.chk_Output_1.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_1.TabIndex = 40;
            this.chk_Output_1.Text = "           ";
            this.chk_Output_1.UseVisualStyleBackColor = true;
            this.chk_Output_1.CheckedChanged += new System.EventHandler(this.chk_Output_1_CheckedChanged);
            // 
            // textBox54
            // 
            this.textBox54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox54.Location = new System.Drawing.Point(145, 3);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(56, 28);
            this.textBox54.TabIndex = 1;
            this.textBox54.Visible = false;
            // 
            // bt_WriteIO
            // 
            this.bt_WriteIO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_WriteIO.Location = new System.Drawing.Point(3, 3);
            this.bt_WriteIO.Name = "bt_WriteIO";
            this.bt_WriteIO.Size = new System.Drawing.Size(136, 117);
            this.bt_WriteIO.TabIndex = 2;
            this.bt_WriteIO.Text = "Write IO";
            this.bt_WriteIO.UseVisualStyleBackColor = true;
            this.bt_WriteIO.Click += new System.EventHandler(this.bt_WriteIO_Click);
            // 
            // chk_Output_2
            // 
            this.chk_Output_2.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_2.AutoSize = true;
            this.chk_Output_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_2.BackgroundImage")));
            this.chk_Output_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_2.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_2.Location = new System.Drawing.Point(145, 203);
            this.chk_Output_2.Name = "chk_Output_2";
            this.chk_Output_2.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_2.TabIndex = 40;
            this.chk_Output_2.Text = "           ";
            this.chk_Output_2.UseVisualStyleBackColor = true;
            this.chk_Output_2.CheckedChanged += new System.EventHandler(this.chk_Output_2_CheckedChanged);
            // 
            // chk_Output_3
            // 
            this.chk_Output_3.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_3.AutoSize = true;
            this.chk_Output_3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_3.BackgroundImage")));
            this.chk_Output_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_3.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_3.Location = new System.Drawing.Point(145, 280);
            this.chk_Output_3.Name = "chk_Output_3";
            this.chk_Output_3.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_3.TabIndex = 40;
            this.chk_Output_3.Text = "           ";
            this.chk_Output_3.UseVisualStyleBackColor = true;
            this.chk_Output_3.CheckedChanged += new System.EventHandler(this.chk_Output_3_CheckedChanged);
            // 
            // chk_Output_4
            // 
            this.chk_Output_4.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_4.AutoSize = true;
            this.chk_Output_4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_4.BackgroundImage")));
            this.chk_Output_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_4.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_4.Location = new System.Drawing.Point(145, 357);
            this.chk_Output_4.Name = "chk_Output_4";
            this.chk_Output_4.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_4.TabIndex = 40;
            this.chk_Output_4.Text = "           ";
            this.chk_Output_4.UseVisualStyleBackColor = true;
            this.chk_Output_4.CheckedChanged += new System.EventHandler(this.chk_Output_4_CheckedChanged);
            // 
            // chk_Output_5
            // 
            this.chk_Output_5.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_5.AutoSize = true;
            this.chk_Output_5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_5.BackgroundImage")));
            this.chk_Output_5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_5.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_5.Location = new System.Drawing.Point(145, 434);
            this.chk_Output_5.Name = "chk_Output_5";
            this.chk_Output_5.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_5.TabIndex = 40;
            this.chk_Output_5.Text = "           ";
            this.chk_Output_5.UseVisualStyleBackColor = true;
            this.chk_Output_5.CheckedChanged += new System.EventHandler(this.chk_Output_5_CheckedChanged);
            // 
            // chk_Output_6
            // 
            this.chk_Output_6.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_6.AutoSize = true;
            this.chk_Output_6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_6.BackgroundImage")));
            this.chk_Output_6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_6.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_6.Location = new System.Drawing.Point(145, 511);
            this.chk_Output_6.Name = "chk_Output_6";
            this.chk_Output_6.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_6.TabIndex = 40;
            this.chk_Output_6.Text = "           ";
            this.chk_Output_6.UseVisualStyleBackColor = true;
            this.chk_Output_6.CheckedChanged += new System.EventHandler(this.chk_Output_6_CheckedChanged);
            // 
            // chk_Output_7
            // 
            this.chk_Output_7.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_7.AutoSize = true;
            this.chk_Output_7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_7.BackgroundImage")));
            this.chk_Output_7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_7.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_7.Location = new System.Drawing.Point(145, 588);
            this.chk_Output_7.Name = "chk_Output_7";
            this.chk_Output_7.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_7.TabIndex = 40;
            this.chk_Output_7.Text = "           ";
            this.chk_Output_7.UseVisualStyleBackColor = true;
            this.chk_Output_7.CheckedChanged += new System.EventHandler(this.chk_Output_7_CheckedChanged);
            // 
            // chk_Output_8
            // 
            this.chk_Output_8.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_8.AutoSize = true;
            this.chk_Output_8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_8.BackgroundImage")));
            this.chk_Output_8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_8.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_8.Location = new System.Drawing.Point(145, 665);
            this.chk_Output_8.Name = "chk_Output_8";
            this.chk_Output_8.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_8.TabIndex = 40;
            this.chk_Output_8.Text = "           ";
            this.chk_Output_8.UseVisualStyleBackColor = true;
            this.chk_Output_8.CheckedChanged += new System.EventHandler(this.chk_Output_8_CheckedChanged);
            // 
            // chk_Output_9
            // 
            this.chk_Output_9.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_9.AutoSize = true;
            this.chk_Output_9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_9.BackgroundImage")));
            this.chk_Output_9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_9.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_9.Location = new System.Drawing.Point(145, 742);
            this.chk_Output_9.Name = "chk_Output_9";
            this.chk_Output_9.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_9.TabIndex = 40;
            this.chk_Output_9.Text = "           ";
            this.chk_Output_9.UseVisualStyleBackColor = true;
            this.chk_Output_9.CheckedChanged += new System.EventHandler(this.chk_Output_9_CheckedChanged);
            // 
            // chk_Output_10
            // 
            this.chk_Output_10.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_10.AutoSize = true;
            this.chk_Output_10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_10.BackgroundImage")));
            this.chk_Output_10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_10.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_10.Location = new System.Drawing.Point(145, 819);
            this.chk_Output_10.Name = "chk_Output_10";
            this.chk_Output_10.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_10.TabIndex = 40;
            this.chk_Output_10.Text = "           ";
            this.chk_Output_10.UseVisualStyleBackColor = true;
            this.chk_Output_10.CheckedChanged += new System.EventHandler(this.chk_Output_10_CheckedChanged);
            // 
            // chk_Output_11
            // 
            this.chk_Output_11.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_11.AutoSize = true;
            this.chk_Output_11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_11.BackgroundImage")));
            this.chk_Output_11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_11.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_11.Location = new System.Drawing.Point(145, 896);
            this.chk_Output_11.Name = "chk_Output_11";
            this.chk_Output_11.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_11.TabIndex = 40;
            this.chk_Output_11.Text = "           ";
            this.chk_Output_11.UseVisualStyleBackColor = true;
            this.chk_Output_11.CheckedChanged += new System.EventHandler(this.chk_Output_11_CheckedChanged);
            // 
            // chk_Output_12
            // 
            this.chk_Output_12.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_12.AutoSize = true;
            this.chk_Output_12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_12.BackgroundImage")));
            this.chk_Output_12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_12.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_12.Location = new System.Drawing.Point(145, 973);
            this.chk_Output_12.Name = "chk_Output_12";
            this.chk_Output_12.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_12.TabIndex = 40;
            this.chk_Output_12.Text = "           ";
            this.chk_Output_12.UseVisualStyleBackColor = true;
            this.chk_Output_12.CheckedChanged += new System.EventHandler(this.chk_Output_12_CheckedChanged);
            // 
            // chk_Output_13
            // 
            this.chk_Output_13.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_13.AutoSize = true;
            this.chk_Output_13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_13.BackgroundImage")));
            this.chk_Output_13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_13.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_13.Location = new System.Drawing.Point(145, 1050);
            this.chk_Output_13.Name = "chk_Output_13";
            this.chk_Output_13.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_13.TabIndex = 40;
            this.chk_Output_13.Text = "           ";
            this.chk_Output_13.UseVisualStyleBackColor = true;
            this.chk_Output_13.Visible = false;
            // 
            // chk_Output_14
            // 
            this.chk_Output_14.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_14.AutoSize = true;
            this.chk_Output_14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_14.BackgroundImage")));
            this.chk_Output_14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_14.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_14.Location = new System.Drawing.Point(145, 1127);
            this.chk_Output_14.Name = "chk_Output_14";
            this.chk_Output_14.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_14.TabIndex = 40;
            this.chk_Output_14.Text = "           ";
            this.chk_Output_14.UseVisualStyleBackColor = true;
            this.chk_Output_14.Visible = false;
            // 
            // chk_Output_15
            // 
            this.chk_Output_15.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_15.AutoSize = true;
            this.chk_Output_15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_15.BackgroundImage")));
            this.chk_Output_15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_15.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_15.Location = new System.Drawing.Point(145, 1204);
            this.chk_Output_15.Name = "chk_Output_15";
            this.chk_Output_15.Size = new System.Drawing.Size(56, 71);
            this.chk_Output_15.TabIndex = 40;
            this.chk_Output_15.Text = "           ";
            this.chk_Output_15.UseVisualStyleBackColor = true;
            this.chk_Output_15.Visible = false;
            // 
            // chk_Output_16
            // 
            this.chk_Output_16.Appearance = System.Windows.Forms.Appearance.Button;
            this.chk_Output_16.AutoSize = true;
            this.chk_Output_16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chk_Output_16.BackgroundImage")));
            this.chk_Output_16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.chk_Output_16.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_Output_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_Output_16.Location = new System.Drawing.Point(145, 1281);
            this.chk_Output_16.Name = "chk_Output_16";
            this.chk_Output_16.Size = new System.Drawing.Size(56, 73);
            this.chk_Output_16.TabIndex = 40;
            this.chk_Output_16.Text = "           ";
            this.chk_Output_16.UseVisualStyleBackColor = true;
            this.chk_Output_16.Visible = false;
            // 
            // label87
            // 
            this.label87.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(18, 145);
            this.label87.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(105, 32);
            this.label87.TabIndex = 41;
            this.label87.Text = "The gripper 1 cylinder up";
            // 
            // label95
            // 
            this.label95.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(18, 222);
            this.label95.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(105, 32);
            this.label95.TabIndex = 42;
            this.label95.Text = "The gripper 1 cylinder down";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(18, 299);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 32);
            this.label23.TabIndex = 43;
            this.label23.Text = "The gripper 2 cylinder up";
            // 
            // label93
            // 
            this.label93.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(18, 376);
            this.label93.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(105, 32);
            this.label93.TabIndex = 44;
            this.label93.Text = "The gripper 2 cylinder down";
            // 
            // label94
            // 
            this.label94.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(18, 453);
            this.label94.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(105, 32);
            this.label94.TabIndex = 45;
            this.label94.Text = "The gripper 3 cylinder up";
            // 
            // label96
            // 
            this.label96.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(18, 530);
            this.label96.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(105, 32);
            this.label96.TabIndex = 46;
            this.label96.Text = "The gripper 3 cylinder down";
            // 
            // label97
            // 
            this.label97.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(3, 607);
            this.label97.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(135, 32);
            this.label97.TabIndex = 47;
            this.label97.Text = "Gripper 1  cylinder open";
            // 
            // label98
            // 
            this.label98.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(3, 684);
            this.label98.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(135, 32);
            this.label98.TabIndex = 48;
            this.label98.Text = "Gripper 1  cylinder close";
            // 
            // label99
            // 
            this.label99.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(3, 761);
            this.label99.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(135, 32);
            this.label99.TabIndex = 49;
            this.label99.Text = "Gripper 2  cylinder open";
            // 
            // label100
            // 
            this.label100.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(3, 838);
            this.label100.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(135, 32);
            this.label100.TabIndex = 50;
            this.label100.Text = "Gripper 2  cylinder close";
            // 
            // label101
            // 
            this.label101.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(3, 915);
            this.label101.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(135, 32);
            this.label101.TabIndex = 51;
            this.label101.Text = "Gripper 3  cylinder open";
            // 
            // label102
            // 
            this.label102.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(3, 992);
            this.label102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(135, 32);
            this.label102.TabIndex = 52;
            this.label102.Text = "Gripper 3  cylinder close";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.IB_RobotLimit);
            this.groupBox5.Controls.Add(this.IB_RobotPause);
            this.groupBox5.Controls.Add(this.OB_RobotPause);
            this.groupBox5.Controls.Add(this.IB_RobotError);
            this.groupBox5.Controls.Add(this.IB_RobotEStop);
            this.groupBox5.Controls.Add(this.OB_RobotStart);
            this.groupBox5.Controls.Add(this.IB_RobotBusy);
            this.groupBox5.Controls.Add(this.IB_RobotReady);
            this.groupBox5.Controls.Add(this.OB_RobotLight);
            this.groupBox5.Controls.Add(this.OB_RobotReset);
            this.groupBox5.Controls.Add(this.OB_RobotStop);
            this.groupBox5.Controls.Add(this.OB_RobotContinue);
            this.groupBox5.Controls.Add(this.OB_RobotProg3);
            this.groupBox5.Controls.Add(this.OB_RobotProg2);
            this.groupBox5.Controls.Add(this.OB_RobotProg1);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(2, 1);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.groupBox5.Size = new System.Drawing.Size(193, 1394);
            this.groupBox5.TabIndex = 41;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Robot";
            // 
            // IB_RobotLimit
            // 
            this.IB_RobotLimit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IB_RobotLimit.BackColor = System.Drawing.Color.White;
            this.IB_RobotLimit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_RobotLimit.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_RobotLimit.FieldName = null;
            this.IB_RobotLimit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_RobotLimit.IP = null;
            this.IB_RobotLimit.Location = new System.Drawing.Point(7, 337);
            this.IB_RobotLimit.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_RobotLimit.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_RobotLimit.Name = "IB_RobotLimit";
            this.IB_RobotLimit.Port = "00405";
            this.IB_RobotLimit.ReverseState = false;
            this.IB_RobotLimit.Size = new System.Drawing.Size(147, 40);
            this.IB_RobotLimit.TabIndex = 41;
            this.IB_RobotLimit.Text = "RobotLimit";
            this.IB_RobotLimit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_RobotPause
            // 
            this.IB_RobotPause.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IB_RobotPause.BackColor = System.Drawing.Color.White;
            this.IB_RobotPause.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_RobotPause.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_RobotPause.FieldName = null;
            this.IB_RobotPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_RobotPause.IP = null;
            this.IB_RobotPause.Location = new System.Drawing.Point(7, 176);
            this.IB_RobotPause.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_RobotPause.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_RobotPause.Name = "IB_RobotPause";
            this.IB_RobotPause.Port = "00402";
            this.IB_RobotPause.ReverseState = false;
            this.IB_RobotPause.Size = new System.Drawing.Size(147, 40);
            this.IB_RobotPause.TabIndex = 40;
            this.IB_RobotPause.Text = "RobotPause";
            this.IB_RobotPause.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotPause
            // 
            this.OB_RobotPause.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotPause.BackColor = System.Drawing.Color.White;
            this.OB_RobotPause.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotPause.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotPause.FieldName = null;
            this.OB_RobotPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotPause.IP = null;
            this.OB_RobotPause.Location = new System.Drawing.Point(7, 501);
            this.OB_RobotPause.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotPause.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotPause.Name = "OB_RobotPause";
            this.OB_RobotPause.Port = "00905";
            this.OB_RobotPause.ReverseState = false;
            this.OB_RobotPause.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotPause.TabIndex = 32;
            this.OB_RobotPause.Text = "RobotPause";
            this.OB_RobotPause.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_RobotError
            // 
            this.IB_RobotError.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IB_RobotError.BackColor = System.Drawing.Color.White;
            this.IB_RobotError.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_RobotError.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_RobotError.FieldName = null;
            this.IB_RobotError.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_RobotError.IP = null;
            this.IB_RobotError.Location = new System.Drawing.Point(7, 229);
            this.IB_RobotError.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_RobotError.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_RobotError.Name = "IB_RobotError";
            this.IB_RobotError.Port = "00403";
            this.IB_RobotError.ReverseState = false;
            this.IB_RobotError.Size = new System.Drawing.Size(147, 40);
            this.IB_RobotError.TabIndex = 39;
            this.IB_RobotError.Text = "RobotError";
            this.IB_RobotError.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_RobotEStop
            // 
            this.IB_RobotEStop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IB_RobotEStop.BackColor = System.Drawing.Color.White;
            this.IB_RobotEStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_RobotEStop.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_RobotEStop.FieldName = null;
            this.IB_RobotEStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_RobotEStop.IP = null;
            this.IB_RobotEStop.Location = new System.Drawing.Point(7, 283);
            this.IB_RobotEStop.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_RobotEStop.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_RobotEStop.Name = "IB_RobotEStop";
            this.IB_RobotEStop.Port = "00404";
            this.IB_RobotEStop.ReverseState = false;
            this.IB_RobotEStop.Size = new System.Drawing.Size(147, 40);
            this.IB_RobotEStop.TabIndex = 38;
            this.IB_RobotEStop.Text = "RobotEStop";
            this.IB_RobotEStop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotStart
            // 
            this.OB_RobotStart.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotStart.BackColor = System.Drawing.Color.White;
            this.OB_RobotStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotStart.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotStart.FieldName = null;
            this.OB_RobotStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotStart.IP = null;
            this.OB_RobotStart.Location = new System.Drawing.Point(7, 392);
            this.OB_RobotStart.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotStart.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotStart.Name = "OB_RobotStart";
            this.OB_RobotStart.Port = "00900";
            this.OB_RobotStart.ReverseState = false;
            this.OB_RobotStart.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotStart.TabIndex = 37;
            this.OB_RobotStart.Text = "RobotStart";
            this.OB_RobotStart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_RobotBusy
            // 
            this.IB_RobotBusy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IB_RobotBusy.BackColor = System.Drawing.Color.White;
            this.IB_RobotBusy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_RobotBusy.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_RobotBusy.FieldName = null;
            this.IB_RobotBusy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_RobotBusy.IP = null;
            this.IB_RobotBusy.Location = new System.Drawing.Point(7, 121);
            this.IB_RobotBusy.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_RobotBusy.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_RobotBusy.Name = "IB_RobotBusy";
            this.IB_RobotBusy.Port = "00401";
            this.IB_RobotBusy.ReverseState = false;
            this.IB_RobotBusy.Size = new System.Drawing.Size(147, 40);
            this.IB_RobotBusy.TabIndex = 36;
            this.IB_RobotBusy.Text = "RobotBusy";
            this.IB_RobotBusy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // IB_RobotReady
            // 
            this.IB_RobotReady.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IB_RobotReady.BackColor = System.Drawing.Color.White;
            this.IB_RobotReady.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IB_RobotReady.CardType = NPSDK.IOCardType.BECKHOFF;
            this.IB_RobotReady.FieldName = null;
            this.IB_RobotReady.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IB_RobotReady.IP = null;
            this.IB_RobotReady.Location = new System.Drawing.Point(7, 67);
            this.IB_RobotReady.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.IB_RobotReady.MaximumSize = new System.Drawing.Size(500, 108);
            this.IB_RobotReady.Name = "IB_RobotReady";
            this.IB_RobotReady.Port = "00400";
            this.IB_RobotReady.ReverseState = false;
            this.IB_RobotReady.Size = new System.Drawing.Size(147, 40);
            this.IB_RobotReady.TabIndex = 35;
            this.IB_RobotReady.Text = "RobotReady";
            this.IB_RobotReady.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotLight
            // 
            this.OB_RobotLight.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotLight.BackColor = System.Drawing.Color.White;
            this.OB_RobotLight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotLight.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotLight.FieldName = null;
            this.OB_RobotLight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotLight.IP = null;
            this.OB_RobotLight.Location = new System.Drawing.Point(7, 662);
            this.OB_RobotLight.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotLight.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotLight.Name = "OB_RobotLight";
            this.OB_RobotLight.Port = "00700";
            this.OB_RobotLight.ReverseState = false;
            this.OB_RobotLight.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotLight.TabIndex = 34;
            this.OB_RobotLight.Text = "RobotLight";
            this.OB_RobotLight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotReset
            // 
            this.OB_RobotReset.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotReset.BackColor = System.Drawing.Color.White;
            this.OB_RobotReset.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotReset.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotReset.FieldName = null;
            this.OB_RobotReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotReset.IP = null;
            this.OB_RobotReset.Location = new System.Drawing.Point(7, 446);
            this.OB_RobotReset.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotReset.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotReset.Name = "OB_RobotReset";
            this.OB_RobotReset.Port = "00907";
            this.OB_RobotReset.ReverseState = false;
            this.OB_RobotReset.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotReset.TabIndex = 33;
            this.OB_RobotReset.Text = "RobotReset";
            this.OB_RobotReset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotStop
            // 
            this.OB_RobotStop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotStop.BackColor = System.Drawing.Color.White;
            this.OB_RobotStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotStop.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotStop.FieldName = null;
            this.OB_RobotStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotStop.IP = null;
            this.OB_RobotStop.Location = new System.Drawing.Point(7, 554);
            this.OB_RobotStop.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotStop.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotStop.Name = "OB_RobotStop";
            this.OB_RobotStop.Port = "00904";
            this.OB_RobotStop.ReverseState = false;
            this.OB_RobotStop.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotStop.TabIndex = 23;
            this.OB_RobotStop.Text = "RobotStop";
            this.OB_RobotStop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotContinue
            // 
            this.OB_RobotContinue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotContinue.BackColor = System.Drawing.Color.White;
            this.OB_RobotContinue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotContinue.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotContinue.FieldName = null;
            this.OB_RobotContinue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotContinue.IP = null;
            this.OB_RobotContinue.Location = new System.Drawing.Point(7, 608);
            this.OB_RobotContinue.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotContinue.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotContinue.Name = "OB_RobotContinue";
            this.OB_RobotContinue.Port = "00906";
            this.OB_RobotContinue.ReverseState = false;
            this.OB_RobotContinue.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotContinue.TabIndex = 31;
            this.OB_RobotContinue.Text = "RobotContinue";
            this.OB_RobotContinue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotProg3
            // 
            this.OB_RobotProg3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotProg3.BackColor = System.Drawing.Color.White;
            this.OB_RobotProg3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotProg3.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotProg3.FieldName = null;
            this.OB_RobotProg3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotProg3.IP = null;
            this.OB_RobotProg3.Location = new System.Drawing.Point(7, 822);
            this.OB_RobotProg3.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotProg3.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotProg3.Name = "OB_RobotProg3";
            this.OB_RobotProg3.Port = "00903";
            this.OB_RobotProg3.ReverseState = false;
            this.OB_RobotProg3.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotProg3.TabIndex = 29;
            this.OB_RobotProg3.Text = "RobotProg3";
            this.OB_RobotProg3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotProg2
            // 
            this.OB_RobotProg2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotProg2.BackColor = System.Drawing.Color.White;
            this.OB_RobotProg2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotProg2.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotProg2.FieldName = null;
            this.OB_RobotProg2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotProg2.IP = null;
            this.OB_RobotProg2.Location = new System.Drawing.Point(7, 769);
            this.OB_RobotProg2.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotProg2.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotProg2.Name = "OB_RobotProg2";
            this.OB_RobotProg2.Port = "00902";
            this.OB_RobotProg2.ReverseState = false;
            this.OB_RobotProg2.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotProg2.TabIndex = 27;
            this.OB_RobotProg2.Text = "RobotProg2";
            this.OB_RobotProg2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OB_RobotProg1
            // 
            this.OB_RobotProg1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OB_RobotProg1.BackColor = System.Drawing.Color.White;
            this.OB_RobotProg1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OB_RobotProg1.CardType = NPSDK.IOCardType.BECKHOFF;
            this.OB_RobotProg1.FieldName = null;
            this.OB_RobotProg1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OB_RobotProg1.IP = null;
            this.OB_RobotProg1.Location = new System.Drawing.Point(7, 716);
            this.OB_RobotProg1.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.OB_RobotProg1.MaximumSize = new System.Drawing.Size(500, 108);
            this.OB_RobotProg1.Name = "OB_RobotProg1";
            this.OB_RobotProg1.Port = "00901";
            this.OB_RobotProg1.ReverseState = false;
            this.OB_RobotProg1.Size = new System.Drawing.Size(147, 40);
            this.OB_RobotProg1.TabIndex = 25;
            this.OB_RobotProg1.Text = "RobotProg1";
            this.OB_RobotProg1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.tableLayoutPanel22);
            this.groupBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox14.Location = new System.Drawing.Point(200, 3);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(233, 1390);
            this.groupBox14.TabIndex = 42;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Robot DI";
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 1;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Controls.Add(this.tableLayoutPanel23, 0, 0);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(3, 24);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 1;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1363F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(227, 1363);
            this.tableLayoutPanel22.TabIndex = 0;
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 2;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_1, 1, 1);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_2, 1, 2);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_3, 1, 3);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_4, 1, 4);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_5, 1, 5);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_6, 1, 6);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_7, 1, 7);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_8, 1, 8);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_9, 1, 9);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_10, 1, 10);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_11, 1, 11);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_12, 1, 12);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_13, 1, 13);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_14, 1, 14);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_15, 1, 15);
            this.tableLayoutPanel23.Controls.Add(this.bt_Input_16, 1, 16);
            this.tableLayoutPanel23.Controls.Add(this.textBox53, 1, 0);
            this.tableLayoutPanel23.Controls.Add(this.bt_ReadIO, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.label68, 0, 1);
            this.tableLayoutPanel23.Controls.Add(this.label70, 0, 2);
            this.tableLayoutPanel23.Controls.Add(this.label69, 0, 3);
            this.tableLayoutPanel23.Controls.Add(this.label74, 0, 4);
            this.tableLayoutPanel23.Controls.Add(this.label75, 0, 5);
            this.tableLayoutPanel23.Controls.Add(this.label76, 0, 6);
            this.tableLayoutPanel23.Controls.Add(this.label79, 0, 7);
            this.tableLayoutPanel23.Controls.Add(this.label82, 0, 8);
            this.tableLayoutPanel23.Controls.Add(this.label83, 0, 9);
            this.tableLayoutPanel23.Controls.Add(this.label67, 0, 10);
            this.tableLayoutPanel23.Controls.Add(this.label88, 0, 11);
            this.tableLayoutPanel23.Controls.Add(this.label103, 0, 12);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 17;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.681818F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(221, 1357);
            this.tableLayoutPanel23.TabIndex = 0;
            // 
            // bt_Input_1
            // 
            this.bt_Input_1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_1.BackgroundImage")));
            this.bt_Input_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_1.Enabled = false;
            this.bt_Input_1.Location = new System.Drawing.Point(157, 126);
            this.bt_Input_1.Name = "bt_Input_1";
            this.bt_Input_1.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_1.TabIndex = 0;
            this.bt_Input_1.UseVisualStyleBackColor = true;
            // 
            // bt_Input_2
            // 
            this.bt_Input_2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_2.BackgroundImage")));
            this.bt_Input_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_2.Enabled = false;
            this.bt_Input_2.Location = new System.Drawing.Point(157, 203);
            this.bt_Input_2.Name = "bt_Input_2";
            this.bt_Input_2.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_2.TabIndex = 0;
            this.bt_Input_2.UseVisualStyleBackColor = true;
            // 
            // bt_Input_3
            // 
            this.bt_Input_3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_3.BackgroundImage")));
            this.bt_Input_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_3.Enabled = false;
            this.bt_Input_3.Location = new System.Drawing.Point(157, 280);
            this.bt_Input_3.Name = "bt_Input_3";
            this.bt_Input_3.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_3.TabIndex = 0;
            this.bt_Input_3.UseVisualStyleBackColor = true;
            // 
            // bt_Input_4
            // 
            this.bt_Input_4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_4.BackgroundImage")));
            this.bt_Input_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_4.Enabled = false;
            this.bt_Input_4.Location = new System.Drawing.Point(157, 357);
            this.bt_Input_4.Name = "bt_Input_4";
            this.bt_Input_4.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_4.TabIndex = 0;
            this.bt_Input_4.UseVisualStyleBackColor = true;
            // 
            // bt_Input_5
            // 
            this.bt_Input_5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_5.BackgroundImage")));
            this.bt_Input_5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_5.Enabled = false;
            this.bt_Input_5.Location = new System.Drawing.Point(157, 434);
            this.bt_Input_5.Name = "bt_Input_5";
            this.bt_Input_5.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_5.TabIndex = 0;
            this.bt_Input_5.UseVisualStyleBackColor = true;
            // 
            // bt_Input_6
            // 
            this.bt_Input_6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_6.BackgroundImage")));
            this.bt_Input_6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_6.Enabled = false;
            this.bt_Input_6.Location = new System.Drawing.Point(157, 511);
            this.bt_Input_6.Name = "bt_Input_6";
            this.bt_Input_6.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_6.TabIndex = 0;
            this.bt_Input_6.UseVisualStyleBackColor = true;
            // 
            // bt_Input_7
            // 
            this.bt_Input_7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_7.BackgroundImage")));
            this.bt_Input_7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_7.Enabled = false;
            this.bt_Input_7.Location = new System.Drawing.Point(157, 588);
            this.bt_Input_7.Name = "bt_Input_7";
            this.bt_Input_7.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_7.TabIndex = 0;
            this.bt_Input_7.UseVisualStyleBackColor = true;
            // 
            // bt_Input_8
            // 
            this.bt_Input_8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_8.BackgroundImage")));
            this.bt_Input_8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_8.Enabled = false;
            this.bt_Input_8.Location = new System.Drawing.Point(157, 665);
            this.bt_Input_8.Name = "bt_Input_8";
            this.bt_Input_8.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_8.TabIndex = 0;
            this.bt_Input_8.UseVisualStyleBackColor = true;
            // 
            // bt_Input_9
            // 
            this.bt_Input_9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_9.BackgroundImage")));
            this.bt_Input_9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_9.Enabled = false;
            this.bt_Input_9.Location = new System.Drawing.Point(157, 742);
            this.bt_Input_9.Name = "bt_Input_9";
            this.bt_Input_9.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_9.TabIndex = 0;
            this.bt_Input_9.UseVisualStyleBackColor = true;
            // 
            // bt_Input_10
            // 
            this.bt_Input_10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_10.BackgroundImage")));
            this.bt_Input_10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_10.Enabled = false;
            this.bt_Input_10.Location = new System.Drawing.Point(157, 819);
            this.bt_Input_10.Name = "bt_Input_10";
            this.bt_Input_10.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_10.TabIndex = 0;
            this.bt_Input_10.UseVisualStyleBackColor = true;
            // 
            // bt_Input_11
            // 
            this.bt_Input_11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_11.BackgroundImage")));
            this.bt_Input_11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_11.Enabled = false;
            this.bt_Input_11.Location = new System.Drawing.Point(157, 896);
            this.bt_Input_11.Name = "bt_Input_11";
            this.bt_Input_11.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_11.TabIndex = 0;
            this.bt_Input_11.UseVisualStyleBackColor = true;
            // 
            // bt_Input_12
            // 
            this.bt_Input_12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_12.BackgroundImage")));
            this.bt_Input_12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_12.Enabled = false;
            this.bt_Input_12.Location = new System.Drawing.Point(157, 973);
            this.bt_Input_12.Name = "bt_Input_12";
            this.bt_Input_12.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_12.TabIndex = 0;
            this.bt_Input_12.UseVisualStyleBackColor = true;
            // 
            // bt_Input_13
            // 
            this.bt_Input_13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_13.BackgroundImage")));
            this.bt_Input_13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_13.Enabled = false;
            this.bt_Input_13.Location = new System.Drawing.Point(157, 1050);
            this.bt_Input_13.Name = "bt_Input_13";
            this.bt_Input_13.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_13.TabIndex = 0;
            this.bt_Input_13.UseVisualStyleBackColor = true;
            this.bt_Input_13.Visible = false;
            // 
            // bt_Input_14
            // 
            this.bt_Input_14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_14.BackgroundImage")));
            this.bt_Input_14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_14.Enabled = false;
            this.bt_Input_14.Location = new System.Drawing.Point(157, 1127);
            this.bt_Input_14.Name = "bt_Input_14";
            this.bt_Input_14.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_14.TabIndex = 0;
            this.bt_Input_14.UseVisualStyleBackColor = true;
            this.bt_Input_14.Visible = false;
            // 
            // bt_Input_15
            // 
            this.bt_Input_15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_15.BackgroundImage")));
            this.bt_Input_15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_15.Enabled = false;
            this.bt_Input_15.Location = new System.Drawing.Point(157, 1204);
            this.bt_Input_15.Name = "bt_Input_15";
            this.bt_Input_15.Size = new System.Drawing.Size(61, 71);
            this.bt_Input_15.TabIndex = 0;
            this.bt_Input_15.UseVisualStyleBackColor = true;
            this.bt_Input_15.Visible = false;
            // 
            // bt_Input_16
            // 
            this.bt_Input_16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bt_Input_16.BackgroundImage")));
            this.bt_Input_16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bt_Input_16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_Input_16.Enabled = false;
            this.bt_Input_16.Location = new System.Drawing.Point(157, 1281);
            this.bt_Input_16.Name = "bt_Input_16";
            this.bt_Input_16.Size = new System.Drawing.Size(61, 73);
            this.bt_Input_16.TabIndex = 0;
            this.bt_Input_16.UseVisualStyleBackColor = true;
            this.bt_Input_16.Visible = false;
            // 
            // textBox53
            // 
            this.textBox53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox53.Location = new System.Drawing.Point(157, 3);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(61, 28);
            this.textBox53.TabIndex = 1;
            this.textBox53.Visible = false;
            this.textBox53.WordWrap = false;
            // 
            // bt_ReadIO
            // 
            this.bt_ReadIO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bt_ReadIO.Location = new System.Drawing.Point(3, 3);
            this.bt_ReadIO.Name = "bt_ReadIO";
            this.bt_ReadIO.Size = new System.Drawing.Size(148, 117);
            this.bt_ReadIO.TabIndex = 2;
            this.bt_ReadIO.Text = "Read IO";
            this.bt_ReadIO.UseVisualStyleBackColor = true;
            this.bt_ReadIO.Click += new System.EventHandler(this.bt_ReadIO_Click);
            // 
            // label68
            // 
            this.label68.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(22, 145);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(110, 32);
            this.label68.TabIndex = 4;
            this.label68.Text = " The up signal gripper 1";
            // 
            // label70
            // 
            this.label70.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(14, 222);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(125, 32);
            this.label70.TabIndex = 5;
            this.label70.Text = "The down signal gripper 1";
            // 
            // label69
            // 
            this.label69.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(24, 299);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(106, 32);
            this.label69.TabIndex = 6;
            this.label69.Text = "The up signal gripper 2";
            // 
            // label74
            // 
            this.label74.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(14, 376);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(125, 32);
            this.label74.TabIndex = 7;
            this.label74.Text = "The down signal gripper 2";
            // 
            // label75
            // 
            this.label75.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(24, 453);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(106, 32);
            this.label75.TabIndex = 8;
            this.label75.Text = "The up signal gripper 3";
            // 
            // label76
            // 
            this.label76.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(14, 530);
            this.label76.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(125, 32);
            this.label76.TabIndex = 9;
            this.label76.Text = "The down signal gripper 3";
            // 
            // label79
            // 
            this.label79.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(9, 607);
            this.label79.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(135, 32);
            this.label79.TabIndex = 10;
            this.label79.Text = "Gripper 1 cylinder open signal";
            // 
            // label82
            // 
            this.label82.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(9, 684);
            this.label82.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(135, 32);
            this.label82.TabIndex = 11;
            this.label82.Text = "Gripper 1 cylinder close signal";
            // 
            // label83
            // 
            this.label83.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(9, 761);
            this.label83.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(135, 32);
            this.label83.TabIndex = 12;
            this.label83.Text = "Gripper 2 cylinder open signal";
            // 
            // label67
            // 
            this.label67.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(9, 838);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(135, 32);
            this.label67.TabIndex = 13;
            this.label67.Text = "Gripper 2 cylinder close signal";
            // 
            // label88
            // 
            this.label88.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(9, 915);
            this.label88.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(135, 32);
            this.label88.TabIndex = 14;
            this.label88.Text = "Gripper 3 cylinder open signal";
            // 
            // label103
            // 
            this.label103.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(9, 992);
            this.label103.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(135, 32);
            this.label103.TabIndex = 15;
            this.label103.Text = "Gripper 3 cylinder close signal";
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.tableLayoutPanel24);
            this.tabPage22.Location = new System.Drawing.Point(4, 31);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Size = new System.Drawing.Size(664, 1402);
            this.tabPage22.TabIndex = 2;
            this.tabPage22.Text = "Robot IO";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 2;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel24.Controls.Add(this.groupBox15, 0, 0);
            this.tableLayoutPanel24.Location = new System.Drawing.Point(144, 68);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 1;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(667, 446);
            this.tableLayoutPanel24.TabIndex = 0;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.flowChart12);
            this.groupBox15.Controls.Add(this.flowChart13);
            this.groupBox15.Controls.Add(this.flowChart11);
            this.groupBox15.Controls.Add(this.flowChart7);
            this.groupBox15.Controls.Add(this.flowChart9);
            this.groupBox15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox15.Location = new System.Drawing.Point(3, 3);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(327, 440);
            this.groupBox15.TabIndex = 0;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "ReadIOFlow";
            // 
            // flowChart12
            // 
            this.flowChart12.AlarmCode = "";
            this.flowChart12.ArrowSeparation = 20;
            this.flowChart12.ArrowsWidth = 1;
            this.flowChart12.BackColor = System.Drawing.Color.White;
            this.flowChart12.bClearTrace = false;
            this.flowChart12.bIsLastFlowChart = false;
            this.flowChart12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart12.bSkip = false;
            this.flowChart12.bStepByStepMode = false;
            this.flowChart12.CASE1 = null;
            this.flowChart12.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart12.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart12.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.CASE2 = null;
            this.flowChart12.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart12.CASE2Color = System.Drawing.Color.Red;
            this.flowChart12.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.CASE3 = null;
            this.flowChart12.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart12.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart12.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.DefaultColor = System.Drawing.Color.White;
            this.flowChart12.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart12.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart12.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart12.Location = new System.Drawing.Point(22, 302);
            this.flowChart12.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart12.menuOpening = false;
            this.flowChart12.Name = "flowChart12";
            this.flowChart12.NEXT = null;
            this.flowChart12.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart12.NEXTColor = System.Drawing.Color.Black;
            this.flowChart12.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart12.Size = new System.Drawing.Size(275, 48);
            this.flowChart12.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart12.SubFlowChart = null;
            this.flowChart12.TabIndex = 21;
            this.flowChart12.Text = "Wait DO data";
            this.flowChart12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart12.TimeOut = 10000;
            this.flowChart12.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart12.tmrTimeOut = null;
            this.flowChart12.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart12_FlowRun);
            // 
            // flowChart13
            // 
            this.flowChart13.AlarmCode = "";
            this.flowChart13.ArrowSeparation = 20;
            this.flowChart13.ArrowsWidth = 1;
            this.flowChart13.BackColor = System.Drawing.Color.White;
            this.flowChart13.bClearTrace = false;
            this.flowChart13.bIsLastFlowChart = false;
            this.flowChart13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart13.bSkip = false;
            this.flowChart13.bStepByStepMode = false;
            this.flowChart13.CASE1 = null;
            this.flowChart13.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart13.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart13.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.CASE2 = null;
            this.flowChart13.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart13.CASE2Color = System.Drawing.Color.Red;
            this.flowChart13.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.CASE3 = null;
            this.flowChart13.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart13.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart13.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.DefaultColor = System.Drawing.Color.White;
            this.flowChart13.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart13.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart13.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart13.Location = new System.Drawing.Point(22, 237);
            this.flowChart13.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart13.menuOpening = false;
            this.flowChart13.Name = "flowChart13";
            this.flowChart13.NEXT = this.flowChart12;
            this.flowChart13.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart13.NEXTColor = System.Drawing.Color.Black;
            this.flowChart13.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart13.Size = new System.Drawing.Size(275, 48);
            this.flowChart13.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart13.SubFlowChart = null;
            this.flowChart13.TabIndex = 20;
            this.flowChart13.Text = "Send reading DO instruction";
            this.flowChart13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart13.TimeOut = 10000;
            this.flowChart13.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart13.tmrTimeOut = null;
            this.flowChart13.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart13_FlowRun);
            // 
            // flowChart11
            // 
            this.flowChart11.AlarmCode = "";
            this.flowChart11.ArrowSeparation = 20;
            this.flowChart11.ArrowsWidth = 1;
            this.flowChart11.BackColor = System.Drawing.Color.White;
            this.flowChart11.bClearTrace = false;
            this.flowChart11.bIsLastFlowChart = false;
            this.flowChart11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart11.bSkip = false;
            this.flowChart11.bStepByStepMode = false;
            this.flowChart11.CASE1 = null;
            this.flowChart11.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart11.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart11.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.CASE2 = null;
            this.flowChart11.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart11.CASE2Color = System.Drawing.Color.Red;
            this.flowChart11.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.CASE3 = null;
            this.flowChart11.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart11.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart11.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.DefaultColor = System.Drawing.Color.White;
            this.flowChart11.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart11.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart11.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart11.Location = new System.Drawing.Point(22, 46);
            this.flowChart11.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart11.menuOpening = false;
            this.flowChart11.Name = "flowChart11";
            this.flowChart11.NEXT = this.flowChart9;
            this.flowChart11.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart11.NEXTColor = System.Drawing.Color.Black;
            this.flowChart11.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart11.Size = new System.Drawing.Size(275, 48);
            this.flowChart11.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart11.SubFlowChart = null;
            this.flowChart11.TabIndex = 19;
            this.flowChart11.Text = "START";
            this.flowChart11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart11.TimeOut = 10000;
            this.flowChart11.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart11.tmrTimeOut = null;
            this.flowChart11.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart11_FlowRun);
            // 
            // flowChart9
            // 
            this.flowChart9.AlarmCode = "";
            this.flowChart9.ArrowSeparation = 20;
            this.flowChart9.ArrowsWidth = 1;
            this.flowChart9.BackColor = System.Drawing.Color.White;
            this.flowChart9.bClearTrace = false;
            this.flowChart9.bIsLastFlowChart = false;
            this.flowChart9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart9.bSkip = false;
            this.flowChart9.bStepByStepMode = false;
            this.flowChart9.CASE1 = null;
            this.flowChart9.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart9.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart9.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.CASE2 = null;
            this.flowChart9.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart9.CASE2Color = System.Drawing.Color.Red;
            this.flowChart9.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.CASE3 = null;
            this.flowChart9.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart9.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart9.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.DefaultColor = System.Drawing.Color.White;
            this.flowChart9.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart9.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart9.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart9.Location = new System.Drawing.Point(22, 111);
            this.flowChart9.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart9.menuOpening = false;
            this.flowChart9.Name = "flowChart9";
            this.flowChart9.NEXT = this.flowChart7;
            this.flowChart9.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart9.NEXTColor = System.Drawing.Color.Black;
            this.flowChart9.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart9.Size = new System.Drawing.Size(275, 48);
            this.flowChart9.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart9.SubFlowChart = null;
            this.flowChart9.TabIndex = 17;
            this.flowChart9.Text = "Send reading DI instruction";
            this.flowChart9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart9.TimeOut = 10000;
            this.flowChart9.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart9.tmrTimeOut = null;
            this.flowChart9.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart9_FlowRun);
            // 
            // flowChart7
            // 
            this.flowChart7.AlarmCode = "";
            this.flowChart7.ArrowSeparation = 20;
            this.flowChart7.ArrowsWidth = 1;
            this.flowChart7.BackColor = System.Drawing.Color.White;
            this.flowChart7.bClearTrace = false;
            this.flowChart7.bIsLastFlowChart = false;
            this.flowChart7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart7.bSkip = false;
            this.flowChart7.bStepByStepMode = false;
            this.flowChart7.CASE1 = null;
            this.flowChart7.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart7.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart7.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.CASE2 = null;
            this.flowChart7.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart7.CASE2Color = System.Drawing.Color.Red;
            this.flowChart7.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.CASE3 = null;
            this.flowChart7.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart7.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart7.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.DefaultColor = System.Drawing.Color.White;
            this.flowChart7.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart7.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart7.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart7.Location = new System.Drawing.Point(22, 173);
            this.flowChart7.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart7.menuOpening = false;
            this.flowChart7.Name = "flowChart7";
            this.flowChart7.NEXT = this.flowChart13;
            this.flowChart7.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart7.NEXTColor = System.Drawing.Color.Black;
            this.flowChart7.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart7.Size = new System.Drawing.Size(275, 48);
            this.flowChart7.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart7.SubFlowChart = null;
            this.flowChart7.TabIndex = 18;
            this.flowChart7.Text = "Wait for DI data";
            this.flowChart7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart7.TimeOut = 10000;
            this.flowChart7.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart7.tmrTimeOut = null;
            this.flowChart7.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart7_FlowRun);
            // 
            // flowChart96
            // 
            this.flowChart96.AlarmCode = "";
            this.flowChart96.ArrowSeparation = 20;
            this.flowChart96.ArrowsWidth = 1;
            this.flowChart96.BackColor = System.Drawing.Color.White;
            this.flowChart96.bClearTrace = false;
            this.flowChart96.bIsLastFlowChart = false;
            this.flowChart96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart96.bSkip = false;
            this.flowChart96.bStepByStepMode = false;
            this.flowChart96.CASE1 = null;
            this.flowChart96.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart96.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart96.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.CASE2 = null;
            this.flowChart96.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart96.CASE2Color = System.Drawing.Color.Red;
            this.flowChart96.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.CASE3 = null;
            this.flowChart96.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart96.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart96.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.DefaultColor = System.Drawing.Color.White;
            this.flowChart96.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart96.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart96.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart96.Location = new System.Drawing.Point(743, 134);
            this.flowChart96.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart96.menuOpening = false;
            this.flowChart96.Name = "flowChart96";
            this.flowChart96.NEXT = this.npFlowChart3;
            this.flowChart96.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart96.NEXTColor = System.Drawing.Color.Black;
            this.flowChart96.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart96.Size = new System.Drawing.Size(197, 35);
            this.flowChart96.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart96.SubFlowChart = null;
            this.flowChart96.TabIndex = 10;
            this.flowChart96.Text = "Initial MES";
            this.flowChart96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart96.TimeOut = 10000;
            this.flowChart96.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart96.tmrTimeOut = null;
            this.flowChart96.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart96_FlowRun);
            // 
            // npFlowChart3
            // 
            this.npFlowChart3.AlarmCode = "";
            this.npFlowChart3.ArrowSeparation = 20;
            this.npFlowChart3.ArrowsWidth = 1;
            this.npFlowChart3.BackColor = System.Drawing.Color.White;
            this.npFlowChart3.bClearTrace = false;
            this.npFlowChart3.bIsLastFlowChart = false;
            this.npFlowChart3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart3.bSkip = false;
            this.npFlowChart3.bStepByStepMode = false;
            this.npFlowChart3.CASE1 = null;
            this.npFlowChart3.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart3.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart3.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.CASE2 = null;
            this.npFlowChart3.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart3.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart3.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.CASE3 = null;
            this.npFlowChart3.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart3.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart3.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart3.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart3.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart3.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart3.Location = new System.Drawing.Point(743, 192);
            this.npFlowChart3.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart3.menuOpening = false;
            this.npFlowChart3.Name = "npFlowChart3";
            this.npFlowChart3.NEXT = this.npFlowChart4;
            this.npFlowChart3.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart3.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart3.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart3.Size = new System.Drawing.Size(197, 35);
            this.npFlowChart3.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart3.SubFlowChart = null;
            this.npFlowChart3.TabIndex = 86;
            this.npFlowChart3.Text = "OFFLINE";
            this.npFlowChart3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart3.TimeOut = 10000;
            this.npFlowChart3.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart3.tmrTimeOut = null;
            this.npFlowChart3.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart3_FlowRun);
            // 
            // npFlowChart4
            // 
            this.npFlowChart4.AlarmCode = "";
            this.npFlowChart4.ArrowSeparation = 20;
            this.npFlowChart4.ArrowsWidth = 1;
            this.npFlowChart4.BackColor = System.Drawing.Color.White;
            this.npFlowChart4.bClearTrace = false;
            this.npFlowChart4.bIsLastFlowChart = false;
            this.npFlowChart4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart4.bSkip = false;
            this.npFlowChart4.bStepByStepMode = false;
            this.npFlowChart4.CASE1 = null;
            this.npFlowChart4.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart4.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart4.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.CASE2 = null;
            this.npFlowChart4.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart4.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart4.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.CASE3 = null;
            this.npFlowChart4.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart4.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart4.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart4.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart4.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart4.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart4.Location = new System.Drawing.Point(743, 251);
            this.npFlowChart4.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart4.menuOpening = false;
            this.npFlowChart4.Name = "npFlowChart4";
            this.npFlowChart4.NEXT = this.npFlowChart5;
            this.npFlowChart4.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart4.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart4.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart4.Size = new System.Drawing.Size(197, 35);
            this.npFlowChart4.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart4.SubFlowChart = null;
            this.npFlowChart4.TabIndex = 87;
            this.npFlowChart4.Text = "IDLE REASON";
            this.npFlowChart4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart4.TimeOut = 10000;
            this.npFlowChart4.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart4.tmrTimeOut = null;
            this.npFlowChart4.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart4_FlowRun);
            // 
            // npFlowChart5
            // 
            this.npFlowChart5.AlarmCode = "";
            this.npFlowChart5.ArrowSeparation = 20;
            this.npFlowChart5.ArrowsWidth = 1;
            this.npFlowChart5.BackColor = System.Drawing.Color.White;
            this.npFlowChart5.bClearTrace = false;
            this.npFlowChart5.bIsLastFlowChart = false;
            this.npFlowChart5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart5.bSkip = false;
            this.npFlowChart5.bStepByStepMode = false;
            this.npFlowChart5.CASE1 = null;
            this.npFlowChart5.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart5.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart5.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.CASE2 = null;
            this.npFlowChart5.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart5.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart5.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.CASE3 = null;
            this.npFlowChart5.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart5.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart5.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart5.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart5.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart5.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart5.Location = new System.Drawing.Point(743, 310);
            this.npFlowChart5.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart5.menuOpening = false;
            this.npFlowChart5.Name = "npFlowChart5";
            this.npFlowChart5.NEXT = this.npFlowChart6;
            this.npFlowChart5.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart5.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart5.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart5.Size = new System.Drawing.Size(197, 35);
            this.npFlowChart5.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart5.SubFlowChart = null;
            this.npFlowChart5.TabIndex = 88;
            this.npFlowChart5.Text = "MOUDLE LIST";
            this.npFlowChart5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart5.TimeOut = 10000;
            this.npFlowChart5.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart5.tmrTimeOut = null;
            this.npFlowChart5.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart5_FlowRun);
            // 
            // npFlowChart6
            // 
            this.npFlowChart6.AlarmCode = "";
            this.npFlowChart6.ArrowSeparation = 20;
            this.npFlowChart6.ArrowsWidth = 1;
            this.npFlowChart6.BackColor = System.Drawing.Color.White;
            this.npFlowChart6.bClearTrace = false;
            this.npFlowChart6.bIsLastFlowChart = false;
            this.npFlowChart6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart6.bSkip = false;
            this.npFlowChart6.bStepByStepMode = false;
            this.npFlowChart6.CASE1 = null;
            this.npFlowChart6.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart6.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart6.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.CASE2 = null;
            this.npFlowChart6.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart6.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart6.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.CASE3 = null;
            this.npFlowChart6.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart6.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart6.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart6.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart6.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart6.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart6.Location = new System.Drawing.Point(743, 368);
            this.npFlowChart6.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart6.menuOpening = false;
            this.npFlowChart6.Name = "npFlowChart6";
            this.npFlowChart6.NEXT = this.fc_ConnectScanner;
            this.npFlowChart6.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart6.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart6.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart6.Size = new System.Drawing.Size(197, 35);
            this.npFlowChart6.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart6.SubFlowChart = null;
            this.npFlowChart6.TabIndex = 89;
            this.npFlowChart6.Text = "OP CALL";
            this.npFlowChart6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart6.TimeOut = 10000;
            this.npFlowChart6.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart6.tmrTimeOut = null;
            this.npFlowChart6.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart6_FlowRun);
            // 
            // fc_ConnectScanner
            // 
            this.fc_ConnectScanner.AlarmCode = "";
            this.fc_ConnectScanner.ArrowSeparation = 20;
            this.fc_ConnectScanner.ArrowsWidth = 1;
            this.fc_ConnectScanner.BackColor = System.Drawing.Color.White;
            this.fc_ConnectScanner.bClearTrace = false;
            this.fc_ConnectScanner.bIsLastFlowChart = false;
            this.fc_ConnectScanner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_ConnectScanner.bSkip = false;
            this.fc_ConnectScanner.bStepByStepMode = false;
            this.fc_ConnectScanner.CASE1 = null;
            this.fc_ConnectScanner.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ConnectScanner.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_ConnectScanner.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.CASE2 = null;
            this.fc_ConnectScanner.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ConnectScanner.CASE2Color = System.Drawing.Color.Red;
            this.fc_ConnectScanner.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.CASE3 = null;
            this.fc_ConnectScanner.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ConnectScanner.CASE3Color = System.Drawing.Color.Blue;
            this.fc_ConnectScanner.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.DefaultColor = System.Drawing.Color.White;
            this.fc_ConnectScanner.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_ConnectScanner.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_ConnectScanner.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_ConnectScanner.Location = new System.Drawing.Point(371, 192);
            this.fc_ConnectScanner.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_ConnectScanner.menuOpening = false;
            this.fc_ConnectScanner.Name = "fc_ConnectScanner";
            this.fc_ConnectScanner.NEXT = this.fc_CloseVisLight;
            this.fc_ConnectScanner.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ConnectScanner.NEXTColor = System.Drawing.Color.Black;
            this.fc_ConnectScanner.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ConnectScanner.Size = new System.Drawing.Size(280, 35);
            this.fc_ConnectScanner.SkipColor = System.Drawing.Color.Yellow;
            this.fc_ConnectScanner.SubFlowChart = null;
            this.fc_ConnectScanner.TabIndex = 74;
            this.fc_ConnectScanner.Text = "Connect Scanner";
            this.fc_ConnectScanner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_ConnectScanner.TimeOut = 10000;
            this.fc_ConnectScanner.TimeoutColor = System.Drawing.Color.Red;
            this.fc_ConnectScanner.tmrTimeOut = null;
            this.fc_ConnectScanner.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_ConnectScanner_FlowRun);
            // 
            // fc_CloseVisLight
            // 
            this.fc_CloseVisLight.AlarmCode = "";
            this.fc_CloseVisLight.ArrowSeparation = 20;
            this.fc_CloseVisLight.ArrowsWidth = 1;
            this.fc_CloseVisLight.BackColor = System.Drawing.Color.White;
            this.fc_CloseVisLight.bClearTrace = false;
            this.fc_CloseVisLight.bIsLastFlowChart = false;
            this.fc_CloseVisLight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_CloseVisLight.bSkip = false;
            this.fc_CloseVisLight.bStepByStepMode = false;
            this.fc_CloseVisLight.CASE1 = null;
            this.fc_CloseVisLight.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_CloseVisLight.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_CloseVisLight.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.CASE2 = null;
            this.fc_CloseVisLight.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_CloseVisLight.CASE2Color = System.Drawing.Color.Red;
            this.fc_CloseVisLight.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.CASE3 = null;
            this.fc_CloseVisLight.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_CloseVisLight.CASE3Color = System.Drawing.Color.Blue;
            this.fc_CloseVisLight.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.DefaultColor = System.Drawing.Color.White;
            this.fc_CloseVisLight.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_CloseVisLight.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_CloseVisLight.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_CloseVisLight.Location = new System.Drawing.Point(371, 251);
            this.fc_CloseVisLight.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_CloseVisLight.menuOpening = false;
            this.fc_CloseVisLight.Name = "fc_CloseVisLight";
            this.fc_CloseVisLight.NEXT = this.fc_ResetR1;
            this.fc_CloseVisLight.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_CloseVisLight.NEXTColor = System.Drawing.Color.Black;
            this.fc_CloseVisLight.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_CloseVisLight.Size = new System.Drawing.Size(280, 35);
            this.fc_CloseVisLight.SkipColor = System.Drawing.Color.Yellow;
            this.fc_CloseVisLight.SubFlowChart = null;
            this.fc_CloseVisLight.TabIndex = 75;
            this.fc_CloseVisLight.Text = "Turn off all lights";
            this.fc_CloseVisLight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_CloseVisLight.TimeOut = 10000;
            this.fc_CloseVisLight.TimeoutColor = System.Drawing.Color.Red;
            this.fc_CloseVisLight.tmrTimeOut = null;
            this.fc_CloseVisLight.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_CloseVisLight_FlowRun);
            // 
            // fc_ResetR1
            // 
            this.fc_ResetR1.AlarmCode = "";
            this.fc_ResetR1.ArrowSeparation = 20;
            this.fc_ResetR1.ArrowsWidth = 1;
            this.fc_ResetR1.BackColor = System.Drawing.Color.White;
            this.fc_ResetR1.bClearTrace = false;
            this.fc_ResetR1.bIsLastFlowChart = false;
            this.fc_ResetR1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_ResetR1.bSkip = false;
            this.fc_ResetR1.bStepByStepMode = false;
            this.fc_ResetR1.CASE1 = null;
            this.fc_ResetR1.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ResetR1.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_ResetR1.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.CASE2 = null;
            this.fc_ResetR1.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ResetR1.CASE2Color = System.Drawing.Color.Red;
            this.fc_ResetR1.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.CASE3 = null;
            this.fc_ResetR1.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ResetR1.CASE3Color = System.Drawing.Color.Blue;
            this.fc_ResetR1.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.DefaultColor = System.Drawing.Color.White;
            this.fc_ResetR1.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_ResetR1.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_ResetR1.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_ResetR1.Location = new System.Drawing.Point(371, 310);
            this.fc_ResetR1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_ResetR1.menuOpening = false;
            this.fc_ResetR1.Name = "fc_ResetR1";
            this.fc_ResetR1.NEXT = this.fc_StartR1;
            this.fc_ResetR1.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_ResetR1.NEXTColor = System.Drawing.Color.Black;
            this.fc_ResetR1.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_ResetR1.Size = new System.Drawing.Size(280, 35);
            this.fc_ResetR1.SkipColor = System.Drawing.Color.Yellow;
            this.fc_ResetR1.SubFlowChart = null;
            this.fc_ResetR1.TabIndex = 78;
            this.fc_ResetR1.Text = "Reset robot1";
            this.fc_ResetR1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_ResetR1.TimeOut = 10000;
            this.fc_ResetR1.TimeoutColor = System.Drawing.Color.Red;
            this.fc_ResetR1.tmrTimeOut = null;
            this.fc_ResetR1.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_ResetR1_FlowRun);
            // 
            // fc_StartR1
            // 
            this.fc_StartR1.AlarmCode = "";
            this.fc_StartR1.ArrowSeparation = 20;
            this.fc_StartR1.ArrowsWidth = 1;
            this.fc_StartR1.BackColor = System.Drawing.Color.White;
            this.fc_StartR1.bClearTrace = false;
            this.fc_StartR1.bIsLastFlowChart = false;
            this.fc_StartR1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_StartR1.bSkip = false;
            this.fc_StartR1.bStepByStepMode = false;
            this.fc_StartR1.CASE1 = null;
            this.fc_StartR1.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_StartR1.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_StartR1.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.CASE2 = null;
            this.fc_StartR1.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_StartR1.CASE2Color = System.Drawing.Color.Red;
            this.fc_StartR1.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.CASE3 = null;
            this.fc_StartR1.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_StartR1.CASE3Color = System.Drawing.Color.Blue;
            this.fc_StartR1.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.DefaultColor = System.Drawing.Color.White;
            this.fc_StartR1.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_StartR1.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_StartR1.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_StartR1.Location = new System.Drawing.Point(371, 368);
            this.fc_StartR1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_StartR1.menuOpening = false;
            this.fc_StartR1.Name = "fc_StartR1";
            this.fc_StartR1.NEXT = this.fc_WaitR1Reset;
            this.fc_StartR1.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_StartR1.NEXTColor = System.Drawing.Color.Black;
            this.fc_StartR1.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_StartR1.Size = new System.Drawing.Size(280, 35);
            this.fc_StartR1.SkipColor = System.Drawing.Color.Yellow;
            this.fc_StartR1.SubFlowChart = null;
            this.fc_StartR1.TabIndex = 76;
            this.fc_StartR1.Text = "Start robot 1";
            this.fc_StartR1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_StartR1.TimeOut = 10000;
            this.fc_StartR1.TimeoutColor = System.Drawing.Color.Red;
            this.fc_StartR1.tmrTimeOut = null;
            this.fc_StartR1.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_StartR1_FlowRun);
            // 
            // fc_WaitR1Reset
            // 
            this.fc_WaitR1Reset.AlarmCode = "";
            this.fc_WaitR1Reset.ArrowSeparation = 20;
            this.fc_WaitR1Reset.ArrowsWidth = 1;
            this.fc_WaitR1Reset.BackColor = System.Drawing.Color.White;
            this.fc_WaitR1Reset.bClearTrace = false;
            this.fc_WaitR1Reset.bIsLastFlowChart = false;
            this.fc_WaitR1Reset.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_WaitR1Reset.bSkip = false;
            this.fc_WaitR1Reset.bStepByStepMode = false;
            this.fc_WaitR1Reset.CASE1 = null;
            this.fc_WaitR1Reset.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_WaitR1Reset.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_WaitR1Reset.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.CASE2 = null;
            this.fc_WaitR1Reset.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_WaitR1Reset.CASE2Color = System.Drawing.Color.Red;
            this.fc_WaitR1Reset.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.CASE3 = null;
            this.fc_WaitR1Reset.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_WaitR1Reset.CASE3Color = System.Drawing.Color.Blue;
            this.fc_WaitR1Reset.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.DefaultColor = System.Drawing.Color.White;
            this.fc_WaitR1Reset.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_WaitR1Reset.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_WaitR1Reset.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_WaitR1Reset.Location = new System.Drawing.Point(371, 426);
            this.fc_WaitR1Reset.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_WaitR1Reset.menuOpening = false;
            this.fc_WaitR1Reset.Name = "fc_WaitR1Reset";
            this.fc_WaitR1Reset.NEXT = this.flowChart31;
            this.fc_WaitR1Reset.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_WaitR1Reset.NEXTColor = System.Drawing.Color.Black;
            this.fc_WaitR1Reset.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_WaitR1Reset.Size = new System.Drawing.Size(280, 35);
            this.fc_WaitR1Reset.SkipColor = System.Drawing.Color.Yellow;
            this.fc_WaitR1Reset.SubFlowChart = null;
            this.fc_WaitR1Reset.TabIndex = 77;
            this.fc_WaitR1Reset.Text = "Wait reset complete";
            this.fc_WaitR1Reset.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_WaitR1Reset.TimeOut = 10000;
            this.fc_WaitR1Reset.TimeoutColor = System.Drawing.Color.Red;
            this.fc_WaitR1Reset.tmrTimeOut = null;
            this.fc_WaitR1Reset.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_WaitR1Reset_FlowRun);
            // 
            // flowChart31
            // 
            this.flowChart31.AlarmCode = "";
            this.flowChart31.ArrowSeparation = 20;
            this.flowChart31.ArrowsWidth = 1;
            this.flowChart31.BackColor = System.Drawing.Color.White;
            this.flowChart31.bClearTrace = false;
            this.flowChart31.bIsLastFlowChart = false;
            this.flowChart31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart31.bSkip = false;
            this.flowChart31.bStepByStepMode = false;
            this.flowChart31.CASE1 = null;
            this.flowChart31.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart31.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart31.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.CASE2 = null;
            this.flowChart31.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart31.CASE2Color = System.Drawing.Color.Red;
            this.flowChart31.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.CASE3 = null;
            this.flowChart31.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart31.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart31.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.DefaultColor = System.Drawing.Color.White;
            this.flowChart31.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart31.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart31.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart31.Location = new System.Drawing.Point(371, 485);
            this.flowChart31.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart31.menuOpening = false;
            this.flowChart31.Name = "flowChart31";
            this.flowChart31.NEXT = this.flowChart33;
            this.flowChart31.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart31.NEXTColor = System.Drawing.Color.Black;
            this.flowChart31.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart31.Size = new System.Drawing.Size(280, 31);
            this.flowChart31.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart31.SubFlowChart = null;
            this.flowChart31.TabIndex = 83;
            this.flowChart31.Text = "Robot to safe position";
            this.flowChart31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart31.TimeOut = 10000;
            this.flowChart31.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart31.tmrTimeOut = null;
            this.flowChart31.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart31_FlowRun);
            // 
            // flowChart33
            // 
            this.flowChart33.AlarmCode = "";
            this.flowChart33.ArrowSeparation = 20;
            this.flowChart33.ArrowsWidth = 1;
            this.flowChart33.BackColor = System.Drawing.Color.White;
            this.flowChart33.bClearTrace = false;
            this.flowChart33.bIsLastFlowChart = false;
            this.flowChart33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart33.bSkip = false;
            this.flowChart33.bStepByStepMode = false;
            this.flowChart33.CASE1 = this.npFlowChart24;
            this.flowChart33.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart33.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart33.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.CASE2 = this.fc_ResetR1;
            this.flowChart33.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart33.CASE2Color = System.Drawing.Color.Red;
            this.flowChart33.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.CASE3 = null;
            this.flowChart33.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart33.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart33.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.DefaultColor = System.Drawing.Color.White;
            this.flowChart33.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart33.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart33.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart33.Location = new System.Drawing.Point(371, 538);
            this.flowChart33.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.flowChart33.menuOpening = false;
            this.flowChart33.Name = "flowChart33";
            this.flowChart33.NEXT = this.flowChart54;
            this.flowChart33.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart33.NEXTColor = System.Drawing.Color.Black;
            this.flowChart33.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart33.Size = new System.Drawing.Size(280, 31);
            this.flowChart33.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart33.SubFlowChart = null;
            this.flowChart33.TabIndex = 84;
            this.flowChart33.Text = "Robot return to safety pos";
            this.flowChart33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart33.TimeOut = 10000;
            this.flowChart33.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart33.tmrTimeOut = null;
            this.flowChart33.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart33_FlowRun);
            // 
            // npFlowChart24
            // 
            this.npFlowChart24.AlarmCode = "";
            this.npFlowChart24.ArrowSeparation = 20;
            this.npFlowChart24.ArrowsWidth = 1;
            this.npFlowChart24.BackColor = System.Drawing.Color.White;
            this.npFlowChart24.bClearTrace = false;
            this.npFlowChart24.bIsLastFlowChart = false;
            this.npFlowChart24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart24.bSkip = false;
            this.npFlowChart24.bStepByStepMode = false;
            this.npFlowChart24.CASE1 = null;
            this.npFlowChart24.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart24.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart24.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.CASE2 = null;
            this.npFlowChart24.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart24.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart24.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.CASE3 = null;
            this.npFlowChart24.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart24.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart24.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart24.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart24.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart24.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart24.Location = new System.Drawing.Point(59, 708);
            this.npFlowChart24.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart24.menuOpening = false;
            this.npFlowChart24.Name = "npFlowChart24";
            this.npFlowChart24.NEXT = this.npFlowChart23;
            this.npFlowChart24.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart24.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart24.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart24.Size = new System.Drawing.Size(233, 35);
            this.npFlowChart24.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart24.SubFlowChart = null;
            this.npFlowChart24.TabIndex = 92;
            this.npFlowChart24.Text = "Get NG buffer";
            this.npFlowChart24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart24.TimeOut = 10000;
            this.npFlowChart24.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart24.tmrTimeOut = null;
            this.npFlowChart24.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart24_FlowRun);
            // 
            // npFlowChart23
            // 
            this.npFlowChart23.AlarmCode = "";
            this.npFlowChart23.ArrowSeparation = 20;
            this.npFlowChart23.ArrowsWidth = 1;
            this.npFlowChart23.BackColor = System.Drawing.Color.White;
            this.npFlowChart23.bClearTrace = false;
            this.npFlowChart23.bIsLastFlowChart = false;
            this.npFlowChart23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart23.bSkip = false;
            this.npFlowChart23.bStepByStepMode = false;
            this.npFlowChart23.CASE1 = null;
            this.npFlowChart23.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart23.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart23.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.CASE2 = null;
            this.npFlowChart23.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart23.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart23.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.CASE3 = null;
            this.npFlowChart23.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart23.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart23.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart23.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart23.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart23.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart23.Location = new System.Drawing.Point(59, 650);
            this.npFlowChart23.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart23.menuOpening = false;
            this.npFlowChart23.Name = "npFlowChart23";
            this.npFlowChart23.NEXT = this.npFlowChart22;
            this.npFlowChart23.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart23.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart23.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart23.Size = new System.Drawing.Size(233, 35);
            this.npFlowChart23.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart23.SubFlowChart = null;
            this.npFlowChart23.TabIndex = 93;
            this.npFlowChart23.Text = "Judge=1?";
            this.npFlowChart23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart23.TimeOut = 10000;
            this.npFlowChart23.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart23.tmrTimeOut = null;
            this.npFlowChart23.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart23_FlowRun);
            // 
            // npFlowChart22
            // 
            this.npFlowChart22.AlarmCode = "";
            this.npFlowChart22.ArrowSeparation = 20;
            this.npFlowChart22.ArrowsWidth = 1;
            this.npFlowChart22.BackColor = System.Drawing.Color.White;
            this.npFlowChart22.bClearTrace = false;
            this.npFlowChart22.bIsLastFlowChart = false;
            this.npFlowChart22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart22.bSkip = false;
            this.npFlowChart22.bStepByStepMode = false;
            this.npFlowChart22.CASE1 = null;
            this.npFlowChart22.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart22.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart22.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.CASE2 = null;
            this.npFlowChart22.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart22.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart22.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.CASE3 = null;
            this.npFlowChart22.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart22.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart22.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart22.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart22.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart22.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart22.Location = new System.Drawing.Point(59, 592);
            this.npFlowChart22.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart22.menuOpening = false;
            this.npFlowChart22.Name = "npFlowChart22";
            this.npFlowChart22.NEXT = this.npFlowChart21;
            this.npFlowChart22.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart22.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart22.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart22.Size = new System.Drawing.Size(233, 35);
            this.npFlowChart22.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart22.SubFlowChart = null;
            this.npFlowChart22.TabIndex = 91;
            this.npFlowChart22.Text = "R1 Goto NG CDD";
            this.npFlowChart22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart22.TimeOut = 10000;
            this.npFlowChart22.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart22.tmrTimeOut = null;
            this.npFlowChart22.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart22_FlowRun);
            // 
            // npFlowChart21
            // 
            this.npFlowChart21.AlarmCode = "";
            this.npFlowChart21.ArrowSeparation = 20;
            this.npFlowChart21.ArrowsWidth = 1;
            this.npFlowChart21.BackColor = System.Drawing.Color.White;
            this.npFlowChart21.bClearTrace = false;
            this.npFlowChart21.bIsLastFlowChart = false;
            this.npFlowChart21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart21.bSkip = false;
            this.npFlowChart21.bStepByStepMode = false;
            this.npFlowChart21.CASE1 = null;
            this.npFlowChart21.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart21.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart21.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.CASE2 = null;
            this.npFlowChart21.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart21.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart21.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.CASE3 = null;
            this.npFlowChart21.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart21.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart21.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart21.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart21.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart21.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart21.Location = new System.Drawing.Point(59, 534);
            this.npFlowChart21.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart21.menuOpening = false;
            this.npFlowChart21.Name = "npFlowChart21";
            this.npFlowChart21.NEXT = this.npFlowChart20;
            this.npFlowChart21.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart21.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart21.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart21.Size = new System.Drawing.Size(233, 35);
            this.npFlowChart21.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart21.SubFlowChart = null;
            this.npFlowChart21.TabIndex = 94;
            this.npFlowChart21.Text = "Wait R1 on NG buffer";
            this.npFlowChart21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart21.TimeOut = 10000;
            this.npFlowChart21.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart21.tmrTimeOut = null;
            this.npFlowChart21.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart21_FlowRun);
            // 
            // npFlowChart20
            // 
            this.npFlowChart20.AlarmCode = "";
            this.npFlowChart20.ArrowSeparation = 20;
            this.npFlowChart20.ArrowsWidth = 1;
            this.npFlowChart20.BackColor = System.Drawing.Color.White;
            this.npFlowChart20.bClearTrace = false;
            this.npFlowChart20.bIsLastFlowChart = false;
            this.npFlowChart20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart20.bSkip = false;
            this.npFlowChart20.bStepByStepMode = false;
            this.npFlowChart20.CASE1 = this.npFlowChart24;
            this.npFlowChart20.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.npFlowChart20.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart20.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.CASE2 = null;
            this.npFlowChart20.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart20.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart20.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.CASE3 = null;
            this.npFlowChart20.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart20.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart20.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart20.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart20.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart20.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart20.Location = new System.Drawing.Point(59, 480);
            this.npFlowChart20.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.npFlowChart20.menuOpening = false;
            this.npFlowChart20.Name = "npFlowChart20";
            this.npFlowChart20.NEXT = this.npFlowChart25;
            this.npFlowChart20.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart20.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart20.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart20.Size = new System.Drawing.Size(233, 31);
            this.npFlowChart20.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart20.SubFlowChart = null;
            this.npFlowChart20.TabIndex = 97;
            this.npFlowChart20.Text = "CCD take picture";
            this.npFlowChart20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart20.TimeOut = 10000;
            this.npFlowChart20.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart20.tmrTimeOut = null;
            this.npFlowChart20.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart20_FlowRun);
            // 
            // npFlowChart25
            // 
            this.npFlowChart25.AlarmCode = "";
            this.npFlowChart25.ArrowSeparation = 20;
            this.npFlowChart25.ArrowsWidth = 1;
            this.npFlowChart25.BackColor = System.Drawing.Color.White;
            this.npFlowChart25.bClearTrace = false;
            this.npFlowChart25.bIsLastFlowChart = false;
            this.npFlowChart25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart25.bSkip = false;
            this.npFlowChart25.bStepByStepMode = false;
            this.npFlowChart25.CASE1 = null;
            this.npFlowChart25.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart25.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart25.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.CASE2 = null;
            this.npFlowChart25.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart25.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart25.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.CASE3 = null;
            this.npFlowChart25.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart25.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart25.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart25.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart25.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart25.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart25.Location = new System.Drawing.Point(59, 426);
            this.npFlowChart25.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.npFlowChart25.menuOpening = false;
            this.npFlowChart25.Name = "npFlowChart25";
            this.npFlowChart25.NEXT = this.npFlowChart26;
            this.npFlowChart25.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart25.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart25.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart25.Size = new System.Drawing.Size(233, 31);
            this.npFlowChart25.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart25.SubFlowChart = null;
            this.npFlowChart25.TabIndex = 96;
            this.npFlowChart25.Text = "R1 Goto NG buffer";
            this.npFlowChart25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart25.TimeOut = 10000;
            this.npFlowChart25.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart25.tmrTimeOut = null;
            this.npFlowChart25.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart25_FlowRun);
            // 
            // npFlowChart26
            // 
            this.npFlowChart26.AlarmCode = "";
            this.npFlowChart26.ArrowSeparation = 20;
            this.npFlowChart26.ArrowsWidth = 1;
            this.npFlowChart26.BackColor = System.Drawing.Color.White;
            this.npFlowChart26.bClearTrace = false;
            this.npFlowChart26.bIsLastFlowChart = false;
            this.npFlowChart26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart26.bSkip = false;
            this.npFlowChart26.bStepByStepMode = false;
            this.npFlowChart26.CASE1 = null;
            this.npFlowChart26.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart26.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart26.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.CASE2 = null;
            this.npFlowChart26.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart26.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart26.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.CASE3 = null;
            this.npFlowChart26.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart26.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart26.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart26.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart26.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart26.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart26.Location = new System.Drawing.Point(59, 368);
            this.npFlowChart26.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart26.menuOpening = false;
            this.npFlowChart26.Name = "npFlowChart26";
            this.npFlowChart26.NEXT = this.npFlowChart27;
            this.npFlowChart26.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart26.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart26.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart26.Size = new System.Drawing.Size(233, 35);
            this.npFlowChart26.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart26.SubFlowChart = null;
            this.npFlowChart26.TabIndex = 95;
            this.npFlowChart26.Text = "Wait R1 on NG buffer";
            this.npFlowChart26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart26.TimeOut = 10000;
            this.npFlowChart26.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart26.tmrTimeOut = null;
            this.npFlowChart26.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart26_FlowRun);
            // 
            // npFlowChart27
            // 
            this.npFlowChart27.AlarmCode = "";
            this.npFlowChart27.ArrowSeparation = 20;
            this.npFlowChart27.ArrowsWidth = 1;
            this.npFlowChart27.BackColor = System.Drawing.Color.White;
            this.npFlowChart27.bClearTrace = false;
            this.npFlowChart27.bIsLastFlowChart = false;
            this.npFlowChart27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart27.bSkip = false;
            this.npFlowChart27.bStepByStepMode = false;
            this.npFlowChart27.CASE1 = null;
            this.npFlowChart27.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart27.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart27.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.CASE2 = null;
            this.npFlowChart27.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart27.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart27.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.CASE3 = null;
            this.npFlowChart27.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart27.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart27.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart27.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart27.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart27.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart27.Location = new System.Drawing.Point(59, 310);
            this.npFlowChart27.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart27.menuOpening = false;
            this.npFlowChart27.Name = "npFlowChart27";
            this.npFlowChart27.NEXT = this.fc_ResetR1;
            this.npFlowChart27.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart27.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart27.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart27.Size = new System.Drawing.Size(233, 35);
            this.npFlowChart27.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart27.SubFlowChart = null;
            this.npFlowChart27.TabIndex = 90;
            this.npFlowChart27.Text = "Refesh NG buffer";
            this.npFlowChart27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart27.TimeOut = 10000;
            this.npFlowChart27.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart27.tmrTimeOut = null;
            this.npFlowChart27.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart27_FlowRun);
            // 
            // flowChart54
            // 
            this.flowChart54.AlarmCode = "";
            this.flowChart54.ArrowSeparation = 20;
            this.flowChart54.ArrowsWidth = 1;
            this.flowChart54.BackColor = System.Drawing.Color.White;
            this.flowChart54.bClearTrace = false;
            this.flowChart54.bIsLastFlowChart = false;
            this.flowChart54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart54.bSkip = false;
            this.flowChart54.bStepByStepMode = false;
            this.flowChart54.CASE1 = null;
            this.flowChart54.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart54.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart54.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.CASE2 = null;
            this.flowChart54.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart54.CASE2Color = System.Drawing.Color.Red;
            this.flowChart54.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.CASE3 = null;
            this.flowChart54.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart54.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart54.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.DefaultColor = System.Drawing.Color.White;
            this.flowChart54.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart54.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart54.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart54.Location = new System.Drawing.Point(371, 592);
            this.flowChart54.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart54.menuOpening = false;
            this.flowChart54.Name = "flowChart54";
            this.flowChart54.NEXT = this.flowChart55;
            this.flowChart54.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart54.NEXTColor = System.Drawing.Color.Black;
            this.flowChart54.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart54.Size = new System.Drawing.Size(280, 35);
            this.flowChart54.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart54.SubFlowChart = null;
            this.flowChart54.TabIndex = 77;
            this.flowChart54.Text = "R1 Set Speed";
            this.flowChart54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart54.TimeOut = 10000;
            this.flowChart54.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart54.tmrTimeOut = null;
            this.flowChart54.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart54_FlowRun);
            // 
            // flowChart55
            // 
            this.flowChart55.AlarmCode = "";
            this.flowChart55.ArrowSeparation = 20;
            this.flowChart55.ArrowsWidth = 1;
            this.flowChart55.BackColor = System.Drawing.Color.White;
            this.flowChart55.bClearTrace = false;
            this.flowChart55.bIsLastFlowChart = false;
            this.flowChart55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart55.bSkip = false;
            this.flowChart55.bStepByStepMode = false;
            this.flowChart55.CASE1 = null;
            this.flowChart55.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart55.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart55.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.CASE2 = null;
            this.flowChart55.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart55.CASE2Color = System.Drawing.Color.Red;
            this.flowChart55.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.CASE3 = null;
            this.flowChart55.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart55.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart55.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.DefaultColor = System.Drawing.Color.White;
            this.flowChart55.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart55.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart55.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart55.Location = new System.Drawing.Point(371, 650);
            this.flowChart55.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart55.menuOpening = false;
            this.flowChart55.Name = "flowChart55";
            this.flowChart55.NEXT = this.flowChart56;
            this.flowChart55.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart55.NEXTColor = System.Drawing.Color.Black;
            this.flowChart55.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart55.Size = new System.Drawing.Size(280, 35);
            this.flowChart55.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart55.SubFlowChart = null;
            this.flowChart55.TabIndex = 77;
            this.flowChart55.Text = "Wait R1 Set Speed";
            this.flowChart55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart55.TimeOut = 10000;
            this.flowChart55.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart55.tmrTimeOut = null;
            this.flowChart55.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart55_FlowRun);
            // 
            // flowChart56
            // 
            this.flowChart56.AlarmCode = "";
            this.flowChart56.ArrowSeparation = 20;
            this.flowChart56.ArrowsWidth = 1;
            this.flowChart56.BackColor = System.Drawing.Color.White;
            this.flowChart56.bClearTrace = false;
            this.flowChart56.bIsLastFlowChart = false;
            this.flowChart56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart56.bSkip = false;
            this.flowChart56.bStepByStepMode = false;
            this.flowChart56.CASE1 = null;
            this.flowChart56.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart56.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart56.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.CASE2 = null;
            this.flowChart56.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart56.CASE2Color = System.Drawing.Color.Red;
            this.flowChart56.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.CASE3 = null;
            this.flowChart56.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart56.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart56.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.DefaultColor = System.Drawing.Color.White;
            this.flowChart56.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart56.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart56.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart56.Location = new System.Drawing.Point(371, 708);
            this.flowChart56.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart56.menuOpening = false;
            this.flowChart56.Name = "flowChart56";
            this.flowChart56.NEXT = this.flowChart57;
            this.flowChart56.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart56.NEXTColor = System.Drawing.Color.Black;
            this.flowChart56.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart56.Size = new System.Drawing.Size(280, 35);
            this.flowChart56.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart56.SubFlowChart = null;
            this.flowChart56.TabIndex = 77;
            this.flowChart56.Text = "Set Vision enable";
            this.flowChart56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart56.TimeOut = 10000;
            this.flowChart56.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart56.tmrTimeOut = null;
            this.flowChart56.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart56_FlowRun);
            // 
            // flowChart57
            // 
            this.flowChart57.AlarmCode = "";
            this.flowChart57.ArrowSeparation = 20;
            this.flowChart57.ArrowsWidth = 1;
            this.flowChart57.BackColor = System.Drawing.Color.White;
            this.flowChart57.bClearTrace = false;
            this.flowChart57.bIsLastFlowChart = false;
            this.flowChart57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart57.bSkip = false;
            this.flowChart57.bStepByStepMode = false;
            this.flowChart57.CASE1 = null;
            this.flowChart57.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart57.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart57.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.CASE2 = null;
            this.flowChart57.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart57.CASE2Color = System.Drawing.Color.Red;
            this.flowChart57.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.CASE3 = null;
            this.flowChart57.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart57.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart57.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.DefaultColor = System.Drawing.Color.White;
            this.flowChart57.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart57.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart57.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart57.Location = new System.Drawing.Point(371, 766);
            this.flowChart57.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart57.menuOpening = false;
            this.flowChart57.Name = "flowChart57";
            this.flowChart57.NEXT = this.flowChart1;
            this.flowChart57.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart57.NEXTColor = System.Drawing.Color.Black;
            this.flowChart57.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart57.Size = new System.Drawing.Size(280, 35);
            this.flowChart57.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart57.SubFlowChart = null;
            this.flowChart57.TabIndex = 77;
            this.flowChart57.Text = "Wait Vision enable";
            this.flowChart57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart57.TimeOut = 10000;
            this.flowChart57.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart57.tmrTimeOut = null;
            this.flowChart57.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart57_FlowRun);
            // 
            // flowChart1
            // 
            this.flowChart1.AlarmCode = "";
            this.flowChart1.ArrowSeparation = 20;
            this.flowChart1.ArrowsWidth = 1;
            this.flowChart1.BackColor = System.Drawing.Color.White;
            this.flowChart1.bClearTrace = false;
            this.flowChart1.bIsLastFlowChart = false;
            this.flowChart1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart1.bSkip = false;
            this.flowChart1.bStepByStepMode = false;
            this.flowChart1.CASE1 = this.flowChart2;
            this.flowChart1.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart1.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart1.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.CASE2 = null;
            this.flowChart1.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart1.CASE2Color = System.Drawing.Color.Red;
            this.flowChart1.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.CASE3 = null;
            this.flowChart1.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart1.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart1.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.DefaultColor = System.Drawing.Color.White;
            this.flowChart1.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart1.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart1.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart1.Location = new System.Drawing.Point(371, 824);
            this.flowChart1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart1.menuOpening = false;
            this.flowChart1.Name = "flowChart1";
            this.flowChart1.NEXT = this.npFlowChart1;
            this.flowChart1.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart1.NEXTColor = System.Drawing.Color.Black;
            this.flowChart1.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart1.Size = new System.Drawing.Size(280, 35);
            this.flowChart1.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart1.SubFlowChart = null;
            this.flowChart1.TabIndex = 79;
            this.flowChart1.Text = "Is Feeder Alarm";
            this.flowChart1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart1.TimeOut = 10000;
            this.flowChart1.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart1.tmrTimeOut = null;
            this.flowChart1.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart1_FlowRun);
            // 
            // flowChart2
            // 
            this.flowChart2.AlarmCode = "";
            this.flowChart2.ArrowSeparation = 20;
            this.flowChart2.ArrowsWidth = 1;
            this.flowChart2.BackColor = System.Drawing.Color.White;
            this.flowChart2.bClearTrace = false;
            this.flowChart2.bIsLastFlowChart = false;
            this.flowChart2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart2.bSkip = false;
            this.flowChart2.bStepByStepMode = false;
            this.flowChart2.CASE1 = null;
            this.flowChart2.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart2.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart2.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.CASE2 = null;
            this.flowChart2.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart2.CASE2Color = System.Drawing.Color.Red;
            this.flowChart2.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.CASE3 = null;
            this.flowChart2.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart2.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart2.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.DefaultColor = System.Drawing.Color.White;
            this.flowChart2.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart2.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart2.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart2.Location = new System.Drawing.Point(743, 824);
            this.flowChart2.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart2.menuOpening = false;
            this.flowChart2.Name = "flowChart2";
            this.flowChart2.NEXT = this.flowChart1;
            this.flowChart2.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart2.NEXTColor = System.Drawing.Color.Black;
            this.flowChart2.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart2.Size = new System.Drawing.Size(197, 35);
            this.flowChart2.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart2.SubFlowChart = null;
            this.flowChart2.TabIndex = 80;
            this.flowChart2.Text = "Feeder Reset";
            this.flowChart2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart2.TimeOut = 10000;
            this.flowChart2.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart2.tmrTimeOut = null;
            this.flowChart2.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart2_FlowRun);
            // 
            // npFlowChart1
            // 
            this.npFlowChart1.AlarmCode = "";
            this.npFlowChart1.ArrowSeparation = 20;
            this.npFlowChart1.ArrowsWidth = 1;
            this.npFlowChart1.BackColor = System.Drawing.Color.White;
            this.npFlowChart1.bClearTrace = false;
            this.npFlowChart1.bIsLastFlowChart = false;
            this.npFlowChart1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart1.bSkip = false;
            this.npFlowChart1.bStepByStepMode = false;
            this.npFlowChart1.CASE1 = null;
            this.npFlowChart1.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart1.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart1.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.CASE2 = null;
            this.npFlowChart1.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart1.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart1.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.CASE3 = null;
            this.npFlowChart1.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart1.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart1.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart1.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart1.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart1.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart1.Location = new System.Drawing.Point(371, 884);
            this.npFlowChart1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart1.menuOpening = false;
            this.npFlowChart1.Name = "npFlowChart1";
            this.npFlowChart1.NEXT = null;
            this.npFlowChart1.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart1.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart1.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart1.Size = new System.Drawing.Size(280, 35);
            this.npFlowChart1.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart1.SubFlowChart = null;
            this.npFlowChart1.TabIndex = 85;
            this.npFlowChart1.Text = "Initial finish";
            this.npFlowChart1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart1.TimeOut = 10000;
            this.npFlowChart1.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart1.tmrTimeOut = null;
            this.npFlowChart1.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart1_FlowRun);
            // 
            // fc_InitialStart
            // 
            this.fc_InitialStart.AlarmCode = "";
            this.fc_InitialStart.ArrowSeparation = 20;
            this.fc_InitialStart.ArrowsWidth = 1;
            this.fc_InitialStart.BackColor = System.Drawing.Color.White;
            this.fc_InitialStart.bClearTrace = false;
            this.fc_InitialStart.bIsLastFlowChart = false;
            this.fc_InitialStart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fc_InitialStart.bSkip = false;
            this.fc_InitialStart.bStepByStepMode = false;
            this.fc_InitialStart.CASE1 = null;
            this.fc_InitialStart.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_InitialStart.CASE1Color = System.Drawing.Color.LimeGreen;
            this.fc_InitialStart.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.CASE2 = null;
            this.fc_InitialStart.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_InitialStart.CASE2Color = System.Drawing.Color.Red;
            this.fc_InitialStart.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.CASE3 = null;
            this.fc_InitialStart.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_InitialStart.CASE3Color = System.Drawing.Color.Blue;
            this.fc_InitialStart.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.DefaultColor = System.Drawing.Color.White;
            this.fc_InitialStart.eSkipPath = NPSDK.FCResultType.NEXT;
            this.fc_InitialStart.ExecutedColor = System.Drawing.Color.LightGray;
            this.fc_InitialStart.ExecutingColor = System.Drawing.Color.Lime;
            this.fc_InitialStart.Location = new System.Drawing.Point(371, 32);
            this.fc_InitialStart.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fc_InitialStart.menuOpening = false;
            this.fc_InitialStart.Name = "fc_InitialStart";
            this.fc_InitialStart.NEXT = this.npFlowChart31;
            this.fc_InitialStart.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.fc_InitialStart.NEXTColor = System.Drawing.Color.Black;
            this.fc_InitialStart.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.fc_InitialStart.Size = new System.Drawing.Size(280, 35);
            this.fc_InitialStart.SkipColor = System.Drawing.Color.Yellow;
            this.fc_InitialStart.SubFlowChart = null;
            this.fc_InitialStart.TabIndex = 8;
            this.fc_InitialStart.Text = "Initial start";
            this.fc_InitialStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.fc_InitialStart.TimeOut = 10000;
            this.fc_InitialStart.TimeoutColor = System.Drawing.Color.Red;
            this.fc_InitialStart.tmrTimeOut = null;
            this.fc_InitialStart.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.fc_InitialStart_FlowRun);
            // 
            // npFlowChart31
            // 
            this.npFlowChart31.AlarmCode = "";
            this.npFlowChart31.ArrowSeparation = 20;
            this.npFlowChart31.ArrowsWidth = 1;
            this.npFlowChart31.BackColor = System.Drawing.Color.White;
            this.npFlowChart31.bClearTrace = false;
            this.npFlowChart31.bIsLastFlowChart = false;
            this.npFlowChart31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart31.bSkip = false;
            this.npFlowChart31.bStepByStepMode = false;
            this.npFlowChart31.CASE1 = null;
            this.npFlowChart31.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart31.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart31.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.CASE2 = null;
            this.npFlowChart31.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart31.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart31.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.CASE3 = null;
            this.npFlowChart31.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart31.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart31.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart31.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart31.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart31.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart31.Location = new System.Drawing.Point(371, 81);
            this.npFlowChart31.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart31.menuOpening = false;
            this.npFlowChart31.Name = "npFlowChart31";
            this.npFlowChart31.NEXT = this.npFlowChart32;
            this.npFlowChart31.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart31.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart31.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart31.Size = new System.Drawing.Size(280, 35);
            this.npFlowChart31.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart31.SubFlowChart = null;
            this.npFlowChart31.TabIndex = 98;
            this.npFlowChart31.Text = "delete files";
            this.npFlowChart31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart31.TimeOut = 10000;
            this.npFlowChart31.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart31.tmrTimeOut = null;
            this.npFlowChart31.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart31_FlowRun);
            // 
            // npFlowChart32
            // 
            this.npFlowChart32.AlarmCode = "";
            this.npFlowChart32.ArrowSeparation = 20;
            this.npFlowChart32.ArrowsWidth = 1;
            this.npFlowChart32.BackColor = System.Drawing.Color.White;
            this.npFlowChart32.bClearTrace = false;
            this.npFlowChart32.bIsLastFlowChart = false;
            this.npFlowChart32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.npFlowChart32.bSkip = false;
            this.npFlowChart32.bStepByStepMode = false;
            this.npFlowChart32.CASE1 = null;
            this.npFlowChart32.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart32.CASE1Color = System.Drawing.Color.LimeGreen;
            this.npFlowChart32.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.CASE2 = null;
            this.npFlowChart32.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart32.CASE2Color = System.Drawing.Color.Red;
            this.npFlowChart32.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.CASE3 = null;
            this.npFlowChart32.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart32.CASE3Color = System.Drawing.Color.Blue;
            this.npFlowChart32.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.DefaultColor = System.Drawing.Color.White;
            this.npFlowChart32.eSkipPath = NPSDK.FCResultType.NEXT;
            this.npFlowChart32.ExecutedColor = System.Drawing.Color.LightGray;
            this.npFlowChart32.ExecutingColor = System.Drawing.Color.Lime;
            this.npFlowChart32.Location = new System.Drawing.Point(371, 134);
            this.npFlowChart32.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.npFlowChart32.menuOpening = false;
            this.npFlowChart32.Name = "npFlowChart32";
            this.npFlowChart32.NEXT = this.flowChart96;
            this.npFlowChart32.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.npFlowChart32.NEXTColor = System.Drawing.Color.Black;
            this.npFlowChart32.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.npFlowChart32.Size = new System.Drawing.Size(280, 35);
            this.npFlowChart32.SkipColor = System.Drawing.Color.Yellow;
            this.npFlowChart32.SubFlowChart = null;
            this.npFlowChart32.TabIndex = 99;
            this.npFlowChart32.Text = "wait delete";
            this.npFlowChart32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.npFlowChart32.TimeOut = 10000;
            this.npFlowChart32.TimeoutColor = System.Drawing.Color.Red;
            this.npFlowChart32.tmrTimeOut = null;
            this.npFlowChart32.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.npFlowChart32_FlowRun);
            // 
            // dataColumn99
            // 
            this.dataColumn99.ColumnName = "FeederPutIndex";
            this.dataColumn99.DataType = typeof(int);
            // 
            // dataColumn100
            // 
            this.dataColumn100.ColumnName = "VacIndex";
            this.dataColumn100.DataType = typeof(short);
            // 
            // cogRecDisp_H5_Recipe
            // 
            this.cogRecDisp_H5_Recipe.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogRecDisp_H5_Recipe.ColorMapLowerRoiLimit = 0D;
            this.cogRecDisp_H5_Recipe.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogRecDisp_H5_Recipe.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogRecDisp_H5_Recipe.ColorMapUpperRoiLimit = 1D;
            this.cogRecDisp_H5_Recipe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cogRecDisp_H5_Recipe.DoubleTapZoomCycleLength = 2;
            this.cogRecDisp_H5_Recipe.DoubleTapZoomSensitivity = 2.5D;
            this.cogRecDisp_H5_Recipe.Location = new System.Drawing.Point(3, 961);
            this.cogRecDisp_H5_Recipe.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogRecDisp_H5_Recipe.MouseWheelSensitivity = 1D;
            this.cogRecDisp_H5_Recipe.Name = "cogRecDisp_H5_Recipe";
            this.cogRecDisp_H5_Recipe.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogRecDisp_H5_Recipe.OcxState")));
            this.cogRecDisp_H5_Recipe.Size = new System.Drawing.Size(979, 473);
            this.cogRecDisp_H5_Recipe.TabIndex = 152;
            // 
            // cogRecordDisplay_Discharge
            // 
            this.cogRecordDisplay_Discharge.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogRecordDisplay_Discharge.ColorMapLowerRoiLimit = 0D;
            this.cogRecordDisplay_Discharge.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogRecordDisplay_Discharge.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogRecordDisplay_Discharge.ColorMapUpperRoiLimit = 1D;
            this.cogRecordDisplay_Discharge.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cogRecordDisplay_Discharge.DoubleTapZoomCycleLength = 2;
            this.cogRecordDisplay_Discharge.DoubleTapZoomSensitivity = 2.5D;
            this.cogRecordDisplay_Discharge.Location = new System.Drawing.Point(2, 481);
            this.cogRecordDisplay_Discharge.Margin = new System.Windows.Forms.Padding(2);
            this.cogRecordDisplay_Discharge.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogRecordDisplay_Discharge.MouseWheelSensitivity = 1D;
            this.cogRecordDisplay_Discharge.Name = "cogRecordDisplay_Discharge";
            this.cogRecordDisplay_Discharge.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogRecordDisplay_Discharge.OcxState")));
            this.cogRecordDisplay_Discharge.Size = new System.Drawing.Size(981, 475);
            this.cogRecordDisplay_Discharge.TabIndex = 140;
            // 
            // cogRecordDisplay_Pickup
            // 
            this.cogRecordDisplay_Pickup.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogRecordDisplay_Pickup.ColorMapLowerRoiLimit = 0D;
            this.cogRecordDisplay_Pickup.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogRecordDisplay_Pickup.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogRecordDisplay_Pickup.ColorMapUpperRoiLimit = 1D;
            this.cogRecordDisplay_Pickup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cogRecordDisplay_Pickup.DoubleTapZoomCycleLength = 2;
            this.cogRecordDisplay_Pickup.DoubleTapZoomSensitivity = 2.5D;
            this.cogRecordDisplay_Pickup.Location = new System.Drawing.Point(2, 2);
            this.cogRecordDisplay_Pickup.Margin = new System.Windows.Forms.Padding(2);
            this.cogRecordDisplay_Pickup.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogRecordDisplay_Pickup.MouseWheelSensitivity = 1D;
            this.cogRecordDisplay_Pickup.Name = "cogRecordDisplay_Pickup";
            this.cogRecordDisplay_Pickup.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogRecordDisplay_Pickup.OcxState")));
            this.cogRecordDisplay_Pickup.Size = new System.Drawing.Size(981, 475);
            this.cogRecordDisplay_Pickup.TabIndex = 139;
            // 
            // dataColumn101
            // 
            this.dataColumn101.ColumnName = "FFUComPort";
            // 
            // dataColumn102
            // 
            this.dataColumn102.ColumnName = "FFUBortRate";
            // 
            // dataColumn103
            // 
            this.dataColumn103.ColumnName = "FFUDataBits";
            // 
            // dataColumn104
            // 
            this.dataColumn104.ColumnName = "FFUParity";
            // 
            // dataColumn105
            // 
            this.dataColumn105.ColumnName = "FFUStopBit";
            // 
            // dataColumn106
            // 
            this.dataColumn106.ColumnName = "PickTeachVisX3";
            this.dataColumn106.DataType = typeof(double);
            // 
            // dataColumn107
            // 
            this.dataColumn107.ColumnName = "PickTeachVisY3";
            this.dataColumn107.DataType = typeof(double);
            // 
            // dataColumn108
            // 
            this.dataColumn108.ColumnName = "PickTeachVisU3";
            this.dataColumn108.DataType = typeof(double);
            // 
            // dataColumn109
            // 
            this.dataColumn109.ColumnName = "PickTeachRobotX3";
            this.dataColumn109.DataType = typeof(double);
            // 
            // dataColumn110
            // 
            this.dataColumn110.ColumnName = "PickTeachRobotY3";
            this.dataColumn110.DataType = typeof(double);
            // 
            // dataColumn111
            // 
            this.dataColumn111.ColumnName = "PickTeachRobotU3";
            this.dataColumn111.DataType = typeof(double);
            // 
            // dataColumn112
            // 
            this.dataColumn112.ColumnName = "DischargeTeachVisX3";
            this.dataColumn112.DataType = typeof(double);
            // 
            // dataColumn113
            // 
            this.dataColumn113.ColumnName = "DischargeTeachVisY3";
            this.dataColumn113.DataType = typeof(double);
            // 
            // dataColumn114
            // 
            this.dataColumn114.ColumnName = "DischargeTeachVisU3";
            this.dataColumn114.DataType = typeof(double);
            // 
            // dataColumn115
            // 
            this.dataColumn115.ColumnName = "DischargeTeachRobotX3";
            this.dataColumn115.DataType = typeof(double);
            // 
            // dataColumn116
            // 
            this.dataColumn116.ColumnName = "DischargeTeachRobotY3";
            this.dataColumn116.DataType = typeof(double);
            // 
            // dataColumn117
            // 
            this.dataColumn117.ColumnName = "DischargeTeachRobotU3";
            this.dataColumn117.DataType = typeof(double);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tableLayoutPanel11);
            this.tabPage6.Location = new System.Drawing.Point(4, 31);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(664, 1402);
            this.tabPage6.TabIndex = 13;
            this.tabPage6.Text = "Robot communication list";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.dgv_EpsonErrInfo, 0, 1);
            this.tableLayoutPanel11.Controls.Add(this.dgv_EpsonPosition, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(658, 1396);
            this.tableLayoutPanel11.TabIndex = 1;
            // 
            // dgv_EpsonErrInfo
            // 
            this.dgv_EpsonErrInfo.ColumnArr = null;
            this.dgv_EpsonErrInfo.CurrentSelectedIndex = 0;
            this.dgv_EpsonErrInfo.DgvHeader = null;
            this.dgv_EpsonErrInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_EpsonErrInfo.Location = new System.Drawing.Point(8, 708);
            this.dgv_EpsonErrInfo.Margin = new System.Windows.Forms.Padding(8, 10, 8, 10);
            this.dgv_EpsonErrInfo.Name = "dgv_EpsonErrInfo";
            this.dgv_EpsonErrInfo.SelectRow = null;
            this.dgv_EpsonErrInfo.Size = new System.Drawing.Size(642, 678);
            this.dgv_EpsonErrInfo.TabIndex = 1;
            this.dgv_EpsonErrInfo.Load += new System.EventHandler(this.dgv_EpsonErrInfo_Load);
            // 
            // dgv_EpsonPosition
            // 
            this.dgv_EpsonPosition.ColumnArr = null;
            this.dgv_EpsonPosition.CurrentSelectedIndex = 0;
            this.dgv_EpsonPosition.DgvHeader = null;
            this.dgv_EpsonPosition.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_EpsonPosition.Location = new System.Drawing.Point(5, 7);
            this.dgv_EpsonPosition.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.dgv_EpsonPosition.Name = "dgv_EpsonPosition";
            this.dgv_EpsonPosition.SelectRow = null;
            this.dgv_EpsonPosition.Size = new System.Drawing.Size(648, 684);
            this.dgv_EpsonPosition.TabIndex = 0;
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.tableLayoutPanel5);
            this.tabPage17.Location = new System.Drawing.Point(4, 31);
            this.tabPage17.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage17.Size = new System.Drawing.Size(664, 1402);
            this.tabPage17.TabIndex = 12;
            this.tabPage17.Text = "R1_DischargeVision";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.32127F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.67873F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tabControl3, 1, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(660, 1398);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel10, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(438, 1392);
            this.tableLayoutPanel6.TabIndex = 16;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel8.Controls.Add(this.dataGridView1, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 1, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(432, 829);
            this.tableLayoutPanel8.TabIndex = 15;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.DataSource = this.RecipeData;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(2, 2);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 20;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(341, 825);
            this.dataGridView1.TabIndex = 16;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.button3, 0, 2);
            this.tableLayoutPanel9.Controls.Add(this.button13, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.button14, 0, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(348, 3);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 3;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(81, 823);
            this.tableLayoutPanel9.TabIndex = 15;
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Location = new System.Drawing.Point(2, 550);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(77, 271);
            this.button3.TabIndex = 3;
            this.button3.Text = "Light On/Off";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button13
            // 
            this.button13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button13.Location = new System.Drawing.Point(2, 2);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(77, 270);
            this.button13.TabIndex = 0;
            this.button13.Text = "Algorithm editing";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // button14
            // 
            this.button14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button14.Location = new System.Drawing.Point(2, 276);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(77, 270);
            this.button14.TabIndex = 1;
            this.button14.Text = "Calibration";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 4;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.58931F));
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotY3, 0, 6);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionX3, 0, 5);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotX3, 0, 6);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotU2, 0, 4);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotY2, 0, 4);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotX2, 0, 4);
            this.tableLayoutPanel10.Controls.Add(this.label50, 2, 0);
            this.tableLayoutPanel10.Controls.Add(this.label51, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionX1, 0, 1);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionY1, 1, 1);
            this.tableLayoutPanel10.Controls.Add(this.btnTeachDiscVisPos, 3, 1);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotX1, 0, 2);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotY1, 1, 2);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotU1, 2, 2);
            this.tableLayoutPanel10.Controls.Add(this.btnTeachDiscRobotPos, 3, 2);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionU1, 2, 1);
            this.tableLayoutPanel10.Controls.Add(this.label52, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.btnTeachDiscRobotPos2, 3, 4);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionX2, 0, 3);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionU2, 2, 3);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionY2, 1, 3);
            this.tableLayoutPanel10.Controls.Add(this.btnTeachDiscVisPos2, 3, 3);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionY3, 1, 5);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargePosVisionU3, 2, 5);
            this.tableLayoutPanel10.Controls.Add(this.txtDisChargeRobotU3, 2, 6);
            this.tableLayoutPanel10.Controls.Add(this.btnTeachDiscVisPos3, 3, 5);
            this.tableLayoutPanel10.Controls.Add(this.btnTeachDiscRobotPos3, 3, 6);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 838);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 7;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(432, 551);
            this.tableLayoutPanel10.TabIndex = 16;
            // 
            // txtDisChargeRobotY3
            // 
            this.txtDisChargeRobotY3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotY3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotY3", true));
            this.txtDisChargeRobotY3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotY3.Location = new System.Drawing.Point(97, 470);
            this.txtDisChargeRobotY3.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotY3.Name = "txtDisChargeRobotY3";
            this.txtDisChargeRobotY3.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotY3.TabIndex = 19;
            this.txtDisChargeRobotY3.Text = "NULL";
            this.txtDisChargeRobotY3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargePosVisionX3
            // 
            this.txtDisChargePosVisionX3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionX3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisX3", true));
            this.txtDisChargePosVisionX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionX3.Location = new System.Drawing.Point(2, 392);
            this.txtDisChargePosVisionX3.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionX3.Name = "txtDisChargePosVisionX3";
            this.txtDisChargePosVisionX3.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionX3.TabIndex = 18;
            this.txtDisChargePosVisionX3.Text = "NULL";
            this.txtDisChargePosVisionX3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargeRobotX3
            // 
            this.txtDisChargeRobotX3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotX3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotX3", true));
            this.txtDisChargeRobotX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotX3.Location = new System.Drawing.Point(2, 470);
            this.txtDisChargeRobotX3.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotX3.Name = "txtDisChargeRobotX3";
            this.txtDisChargeRobotX3.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotX3.TabIndex = 16;
            this.txtDisChargeRobotX3.Text = "NULL";
            this.txtDisChargeRobotX3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargeRobotU2
            // 
            this.txtDisChargeRobotU2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotU2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotU2", true));
            this.txtDisChargeRobotU2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotU2.Location = new System.Drawing.Point(192, 314);
            this.txtDisChargeRobotU2.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotU2.Name = "txtDisChargeRobotU2";
            this.txtDisChargeRobotU2.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotU2.TabIndex = 14;
            this.txtDisChargeRobotU2.Text = "NUll";
            this.txtDisChargeRobotU2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargeRobotY2
            // 
            this.txtDisChargeRobotY2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotY2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotY2", true));
            this.txtDisChargeRobotY2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotY2.Location = new System.Drawing.Point(97, 314);
            this.txtDisChargeRobotY2.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotY2.Name = "txtDisChargeRobotY2";
            this.txtDisChargeRobotY2.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotY2.TabIndex = 13;
            this.txtDisChargeRobotY2.Text = "NULL";
            this.txtDisChargeRobotY2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargeRobotX2
            // 
            this.txtDisChargeRobotX2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotX2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotX2", true));
            this.txtDisChargeRobotX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotX2.Location = new System.Drawing.Point(2, 314);
            this.txtDisChargeRobotX2.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotX2.Name = "txtDisChargeRobotX2";
            this.txtDisChargeRobotX2.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotX2.TabIndex = 12;
            this.txtDisChargeRobotX2.Text = "NULL";
            this.txtDisChargeRobotX2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(226, 27);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(23, 24);
            this.label50.TabIndex = 11;
            this.label50.Text = "U";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label50.UseMnemonic = false;
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(131, 27);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(22, 24);
            this.label51.TabIndex = 10;
            this.label51.Text = "Y";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label51.UseMnemonic = false;
            // 
            // txtDisChargePosVisionX1
            // 
            this.txtDisChargePosVisionX1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionX1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisX", true));
            this.txtDisChargePosVisionX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionX1.Location = new System.Drawing.Point(2, 80);
            this.txtDisChargePosVisionX1.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionX1.Name = "txtDisChargePosVisionX1";
            this.txtDisChargePosVisionX1.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionX1.TabIndex = 4;
            this.txtDisChargePosVisionX1.Text = "NULL";
            this.txtDisChargePosVisionX1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargePosVisionY1
            // 
            this.txtDisChargePosVisionY1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionY1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisY", true));
            this.txtDisChargePosVisionY1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionY1.Location = new System.Drawing.Point(97, 80);
            this.txtDisChargePosVisionY1.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionY1.Name = "txtDisChargePosVisionY1";
            this.txtDisChargePosVisionY1.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionY1.TabIndex = 6;
            this.txtDisChargePosVisionY1.Text = "NULL";
            this.txtDisChargePosVisionY1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachDiscVisPos
            // 
            this.btnTeachDiscVisPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachDiscVisPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachDiscVisPos.Location = new System.Drawing.Point(287, 80);
            this.btnTeachDiscVisPos.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachDiscVisPos.Name = "btnTeachDiscVisPos";
            this.btnTeachDiscVisPos.Size = new System.Drawing.Size(143, 74);
            this.btnTeachDiscVisPos.TabIndex = 1;
            this.btnTeachDiscVisPos.Text = "Teaching visual position (grapper1)";
            this.btnTeachDiscVisPos.UseVisualStyleBackColor = true;
            this.btnTeachDiscVisPos.Click += new System.EventHandler(this.button15_Click);
            // 
            // txtDisChargeRobotX1
            // 
            this.txtDisChargeRobotX1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotX1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotX", true));
            this.txtDisChargeRobotX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotX1.Location = new System.Drawing.Point(2, 158);
            this.txtDisChargeRobotX1.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotX1.Name = "txtDisChargeRobotX1";
            this.txtDisChargeRobotX1.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotX1.TabIndex = 4;
            this.txtDisChargeRobotX1.Text = "NULL";
            this.txtDisChargeRobotX1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargeRobotY1
            // 
            this.txtDisChargeRobotY1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotY1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotY", true));
            this.txtDisChargeRobotY1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotY1.Location = new System.Drawing.Point(97, 158);
            this.txtDisChargeRobotY1.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotY1.Name = "txtDisChargeRobotY1";
            this.txtDisChargeRobotY1.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotY1.TabIndex = 6;
            this.txtDisChargeRobotY1.Text = "NULL";
            this.txtDisChargeRobotY1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargeRobotU1
            // 
            this.txtDisChargeRobotU1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotU1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotU", true));
            this.txtDisChargeRobotU1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotU1.Location = new System.Drawing.Point(192, 158);
            this.txtDisChargeRobotU1.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotU1.Name = "txtDisChargeRobotU1";
            this.txtDisChargeRobotU1.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotU1.TabIndex = 8;
            this.txtDisChargeRobotU1.Text = "NUll";
            this.txtDisChargeRobotU1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachDiscRobotPos
            // 
            this.btnTeachDiscRobotPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachDiscRobotPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachDiscRobotPos.Location = new System.Drawing.Point(287, 158);
            this.btnTeachDiscRobotPos.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachDiscRobotPos.Name = "btnTeachDiscRobotPos";
            this.btnTeachDiscRobotPos.Size = new System.Drawing.Size(143, 74);
            this.btnTeachDiscRobotPos.TabIndex = 1;
            this.btnTeachDiscRobotPos.Text = "Teaching robot position G1";
            this.btnTeachDiscRobotPos.UseVisualStyleBackColor = true;
            this.btnTeachDiscRobotPos.Visible = false;
            this.btnTeachDiscRobotPos.Click += new System.EventHandler(this.button16_Click);
            // 
            // txtDisChargePosVisionU1
            // 
            this.txtDisChargePosVisionU1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionU1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisU", true));
            this.txtDisChargePosVisionU1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionU1.Location = new System.Drawing.Point(192, 80);
            this.txtDisChargePosVisionU1.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionU1.Name = "txtDisChargePosVisionU1";
            this.txtDisChargePosVisionU1.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionU1.TabIndex = 8;
            this.txtDisChargePosVisionU1.Text = "NUll";
            this.txtDisChargePosVisionU1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(35, 27);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(24, 24);
            this.label52.TabIndex = 9;
            this.label52.Text = "X";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label52.UseMnemonic = false;
            // 
            // btnTeachDiscRobotPos2
            // 
            this.btnTeachDiscRobotPos2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachDiscRobotPos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachDiscRobotPos2.Location = new System.Drawing.Point(287, 314);
            this.btnTeachDiscRobotPos2.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachDiscRobotPos2.Name = "btnTeachDiscRobotPos2";
            this.btnTeachDiscRobotPos2.Size = new System.Drawing.Size(143, 74);
            this.btnTeachDiscRobotPos2.TabIndex = 15;
            this.btnTeachDiscRobotPos2.Text = "Teaching robot position G2";
            this.btnTeachDiscRobotPos2.UseVisualStyleBackColor = true;
            this.btnTeachDiscRobotPos2.Visible = false;
            this.btnTeachDiscRobotPos2.Click += new System.EventHandler(this.button17_Click);
            // 
            // txtDisChargePosVisionX2
            // 
            this.txtDisChargePosVisionX2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionX2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisX2", true));
            this.txtDisChargePosVisionX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionX2.Location = new System.Drawing.Point(2, 236);
            this.txtDisChargePosVisionX2.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionX2.Name = "txtDisChargePosVisionX2";
            this.txtDisChargePosVisionX2.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionX2.TabIndex = 4;
            this.txtDisChargePosVisionX2.Text = "NULL";
            this.txtDisChargePosVisionX2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargePosVisionU2
            // 
            this.txtDisChargePosVisionU2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionU2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisU2", true));
            this.txtDisChargePosVisionU2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionU2.Location = new System.Drawing.Point(192, 236);
            this.txtDisChargePosVisionU2.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionU2.Name = "txtDisChargePosVisionU2";
            this.txtDisChargePosVisionU2.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionU2.TabIndex = 4;
            this.txtDisChargePosVisionU2.Text = "NULL";
            this.txtDisChargePosVisionU2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargePosVisionY2
            // 
            this.txtDisChargePosVisionY2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionY2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisY2", true));
            this.txtDisChargePosVisionY2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionY2.Location = new System.Drawing.Point(97, 236);
            this.txtDisChargePosVisionY2.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionY2.Name = "txtDisChargePosVisionY2";
            this.txtDisChargePosVisionY2.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionY2.TabIndex = 4;
            this.txtDisChargePosVisionY2.Text = "NULL";
            this.txtDisChargePosVisionY2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachDiscVisPos2
            // 
            this.btnTeachDiscVisPos2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachDiscVisPos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachDiscVisPos2.Location = new System.Drawing.Point(287, 236);
            this.btnTeachDiscVisPos2.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachDiscVisPos2.Name = "btnTeachDiscVisPos2";
            this.btnTeachDiscVisPos2.Size = new System.Drawing.Size(143, 74);
            this.btnTeachDiscVisPos2.TabIndex = 1;
            this.btnTeachDiscVisPos2.Text = "Teaching visual position (grapper2)";
            this.btnTeachDiscVisPos2.UseVisualStyleBackColor = true;
            this.btnTeachDiscVisPos2.Click += new System.EventHandler(this.button18_Click);
            // 
            // txtDisChargePosVisionY3
            // 
            this.txtDisChargePosVisionY3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionY3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisY3", true));
            this.txtDisChargePosVisionY3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionY3.Location = new System.Drawing.Point(97, 392);
            this.txtDisChargePosVisionY3.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionY3.Name = "txtDisChargePosVisionY3";
            this.txtDisChargePosVisionY3.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionY3.TabIndex = 17;
            this.txtDisChargePosVisionY3.Text = "NULL";
            this.txtDisChargePosVisionY3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargePosVisionU3
            // 
            this.txtDisChargePosVisionU3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargePosVisionU3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachVisU3", true));
            this.txtDisChargePosVisionU3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargePosVisionU3.Location = new System.Drawing.Point(192, 392);
            this.txtDisChargePosVisionU3.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargePosVisionU3.Name = "txtDisChargePosVisionU3";
            this.txtDisChargePosVisionU3.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargePosVisionU3.TabIndex = 17;
            this.txtDisChargePosVisionU3.Text = "NULL";
            this.txtDisChargePosVisionU3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDisChargeRobotU3
            // 
            this.txtDisChargeRobotU3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtDisChargeRobotU3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.DischargeTeachRobotU3", true));
            this.txtDisChargeRobotU3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDisChargeRobotU3.Location = new System.Drawing.Point(192, 470);
            this.txtDisChargeRobotU3.Margin = new System.Windows.Forms.Padding(2);
            this.txtDisChargeRobotU3.Name = "txtDisChargeRobotU3";
            this.txtDisChargeRobotU3.Size = new System.Drawing.Size(91, 28);
            this.txtDisChargeRobotU3.TabIndex = 17;
            this.txtDisChargeRobotU3.Text = "NULL";
            this.txtDisChargeRobotU3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachDiscVisPos3
            // 
            this.btnTeachDiscVisPos3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachDiscVisPos3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachDiscVisPos3.Location = new System.Drawing.Point(287, 392);
            this.btnTeachDiscVisPos3.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachDiscVisPos3.Name = "btnTeachDiscVisPos3";
            this.btnTeachDiscVisPos3.Size = new System.Drawing.Size(143, 74);
            this.btnTeachDiscVisPos3.TabIndex = 15;
            this.btnTeachDiscVisPos3.Text = "Teaching visual position (grapper3)";
            this.btnTeachDiscVisPos3.UseVisualStyleBackColor = true;
            this.btnTeachDiscVisPos3.Click += new System.EventHandler(this.btnTeachDiscVisPos3_Click);
            // 
            // btnTeachDiscRobotPos3
            // 
            this.btnTeachDiscRobotPos3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachDiscRobotPos3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachDiscRobotPos3.Location = new System.Drawing.Point(287, 470);
            this.btnTeachDiscRobotPos3.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachDiscRobotPos3.Name = "btnTeachDiscRobotPos3";
            this.btnTeachDiscRobotPos3.Size = new System.Drawing.Size(143, 79);
            this.btnTeachDiscRobotPos3.TabIndex = 15;
            this.btnTeachDiscRobotPos3.Text = "Teaching robot position G3";
            this.btnTeachDiscRobotPos3.UseVisualStyleBackColor = true;
            this.btnTeachDiscRobotPos3.Visible = false;
            this.btnTeachDiscRobotPos3.Click += new System.EventHandler(this.btnTeachDiscRobotPos3_Click);
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage19);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(447, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(210, 1392);
            this.tabControl3.TabIndex = 17;
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.groupBox2);
            this.tabPage19.Controls.Add(this.flowChart108);
            this.tabPage19.Controls.Add(this.flowChart109);
            this.tabPage19.Controls.Add(this.flowChart112);
            this.tabPage19.Controls.Add(this.flowChart111);
            this.tabPage19.Controls.Add(this.flowChart110);
            this.tabPage19.Controls.Add(this.flowChart113);
            this.tabPage19.Controls.Add(this.flowChart114);
            this.tabPage19.Controls.Add(this.flowChart115);
            this.tabPage19.Location = new System.Drawing.Point(4, 31);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(202, 1357);
            this.tabPage19.TabIndex = 1;
            this.tabPage19.Text = "Auto calibration";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ResetPick);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Controls.Add(this.textBox10);
            this.groupBox2.Controls.Add(this.textBox11);
            this.groupBox2.Controls.Add(this.textBox12);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.button26);
            this.groupBox2.Controls.Add(this.button29);
            this.groupBox2.Location = new System.Drawing.Point(131, 1000);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(130, 254);
            this.groupBox2.TabIndex = 63;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Fiducial2";
            this.groupBox2.Visible = false;
            // 
            // ResetPick
            // 
            this.ResetPick.Location = new System.Drawing.Point(6, 85);
            this.ResetPick.Name = "ResetPick";
            this.ResetPick.Size = new System.Drawing.Size(178, 33);
            this.ResetPick.TabIndex = 22;
            this.ResetPick.Text = "Reset Pick";
            this.ResetPick.UseVisualStyleBackColor = true;
            this.ResetPick.Visible = false;
            this.ResetPick.Click += new System.EventHandler(this.ResetPick_Click);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(108, 228);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(89, 26);
            this.textBox2.TabIndex = 97;
            this.textBox2.Text = "Null";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(-4, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 24);
            this.label3.TabIndex = 96;
            this.label3.Text = "Fiducial2 A";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBox7);
            this.groupBox7.Controls.Add(this.label5);
            this.groupBox7.Controls.Add(this.button21);
            this.groupBox7.Controls.Add(this.textBox8);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Controls.Add(this.textBox9);
            this.groupBox7.Location = new System.Drawing.Point(208, 28);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Size = new System.Drawing.Size(166, 198);
            this.groupBox7.TabIndex = 95;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Fiducial2";
            // 
            // textBox7
            // 
            this.textBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.H1_Fid2RefA", true));
            this.textBox7.Location = new System.Drawing.Point(63, 114);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(102, 28);
            this.textBox7.TabIndex = 90;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 24);
            this.label5.TabIndex = 89;
            this.label5.Text = "A";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(62, 150);
            this.button21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(99, 33);
            this.button21.TabIndex = 88;
            this.button21.Text = "Replace";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // textBox8
            // 
            this.textBox8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.H1_Fid2RefY", true));
            this.textBox8.Location = new System.Drawing.Point(63, 72);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(102, 28);
            this.textBox8.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 24);
            this.label6.TabIndex = 1;
            this.label6.Text = "Y";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(34, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 24);
            this.label12.TabIndex = 0;
            this.label12.Text = "X";
            // 
            // textBox9
            // 
            this.textBox9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.H1_Fid2RefX", true));
            this.textBox9.Location = new System.Drawing.Point(63, 35);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(102, 28);
            this.textBox9.TabIndex = 3;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(108, 192);
            this.textBox10.Margin = new System.Windows.Forms.Padding(4);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(89, 26);
            this.textBox10.TabIndex = 93;
            this.textBox10.Text = "Null";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(108, 163);
            this.textBox11.Margin = new System.Windows.Forms.Padding(4);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(89, 26);
            this.textBox11.TabIndex = 94;
            this.textBox11.Text = "Null";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(108, 127);
            this.textBox12.Margin = new System.Windows.Forms.Padding(4);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(89, 26);
            this.textBox12.TabIndex = 92;
            this.textBox12.Text = "Null";
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(-3, 198);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 24);
            this.label25.TabIndex = 91;
            this.label25.Text = "Fiducial2 Y";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(-2, 163);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(105, 24);
            this.label26.TabIndex = 90;
            this.label26.Text = "Fiducial2 X";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(8, 130);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(62, 24);
            this.label27.TabIndex = 89;
            this.label27.Text = "Result";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(19, 75);
            this.button26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(166, 42);
            this.button26.TabIndex = 88;
            this.button26.Text = "Trigger";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(19, 28);
            this.button29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(166, 42);
            this.button29.TabIndex = 87;
            this.button29.Text = "Setup";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // flowChart108
            // 
            this.flowChart108.AlarmCode = "";
            this.flowChart108.ArrowSeparation = 20;
            this.flowChart108.ArrowsWidth = 1;
            this.flowChart108.BackColor = System.Drawing.Color.White;
            this.flowChart108.bClearTrace = false;
            this.flowChart108.bIsLastFlowChart = false;
            this.flowChart108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart108.bSkip = false;
            this.flowChart108.bStepByStepMode = false;
            this.flowChart108.CASE1 = null;
            this.flowChart108.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart108.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart108.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.CASE2 = null;
            this.flowChart108.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart108.CASE2Color = System.Drawing.Color.Red;
            this.flowChart108.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.CASE3 = null;
            this.flowChart108.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart108.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart108.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.DefaultColor = System.Drawing.Color.White;
            this.flowChart108.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart108.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart108.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart108.Location = new System.Drawing.Point(212, 134);
            this.flowChart108.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart108.menuOpening = false;
            this.flowChart108.Name = "flowChart108";
            this.flowChart108.NEXT = null;
            this.flowChart108.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart108.NEXTColor = System.Drawing.Color.Black;
            this.flowChart108.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart108.Size = new System.Drawing.Size(86, 35);
            this.flowChart108.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart108.SubFlowChart = null;
            this.flowChart108.TabIndex = 55;
            this.flowChart108.Text = "Calibrate";
            this.flowChart108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart108.TimeOut = 10000;
            this.flowChart108.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart108.tmrTimeOut = null;
            this.flowChart108.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart108_FlowRun);
            // 
            // flowChart109
            // 
            this.flowChart109.AlarmCode = "";
            this.flowChart109.ArrowSeparation = 20;
            this.flowChart109.ArrowsWidth = 1;
            this.flowChart109.BackColor = System.Drawing.Color.White;
            this.flowChart109.bClearTrace = false;
            this.flowChart109.bIsLastFlowChart = false;
            this.flowChart109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart109.bSkip = false;
            this.flowChart109.bStepByStepMode = false;
            this.flowChart109.CASE1 = this.flowChart108;
            this.flowChart109.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart109.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart109.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.CASE2 = null;
            this.flowChart109.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart109.CASE2Color = System.Drawing.Color.Red;
            this.flowChart109.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.CASE3 = null;
            this.flowChart109.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart109.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart109.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.DefaultColor = System.Drawing.Color.White;
            this.flowChart109.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart109.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart109.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart109.Location = new System.Drawing.Point(222, 197);
            this.flowChart109.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart109.menuOpening = false;
            this.flowChart109.Name = "flowChart109";
            this.flowChart109.NEXT = this.flowChart110;
            this.flowChart109.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart109.NEXTColor = System.Drawing.Color.Black;
            this.flowChart109.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart109.Size = new System.Drawing.Size(66, 122);
            this.flowChart109.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart109.SubFlowChart = null;
            this.flowChart109.TabIndex = 54;
            this.flowChart109.Text = "Judge Loop Times";
            this.flowChart109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart109.TimeOut = 10000;
            this.flowChart109.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart109.tmrTimeOut = null;
            this.flowChart109.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart109_FlowRun);
            // 
            // flowChart110
            // 
            this.flowChart110.AlarmCode = "";
            this.flowChart110.ArrowSeparation = 20;
            this.flowChart110.ArrowsWidth = 1;
            this.flowChart110.BackColor = System.Drawing.Color.White;
            this.flowChart110.bClearTrace = false;
            this.flowChart110.bIsLastFlowChart = false;
            this.flowChart110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart110.bSkip = false;
            this.flowChart110.bStepByStepMode = false;
            this.flowChart110.CASE1 = null;
            this.flowChart110.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart110.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart110.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.CASE2 = null;
            this.flowChart110.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart110.CASE2Color = System.Drawing.Color.Red;
            this.flowChart110.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.CASE3 = null;
            this.flowChart110.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart110.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart110.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.DefaultColor = System.Drawing.Color.White;
            this.flowChart110.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart110.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart110.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart110.Location = new System.Drawing.Point(11, 184);
            this.flowChart110.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart110.menuOpening = false;
            this.flowChart110.Name = "flowChart110";
            this.flowChart110.NEXT = this.flowChart111;
            this.flowChart110.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart110.NEXTColor = System.Drawing.Color.Black;
            this.flowChart110.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart110.Size = new System.Drawing.Size(178, 35);
            this.flowChart110.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart110.SubFlowChart = null;
            this.flowChart110.TabIndex = 48;
            this.flowChart110.Text = "R1 to picture pos1";
            this.flowChart110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart110.TimeOut = 10000;
            this.flowChart110.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart110.tmrTimeOut = null;
            this.flowChart110.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart110_FlowRun);
            // 
            // flowChart111
            // 
            this.flowChart111.AlarmCode = "";
            this.flowChart111.ArrowSeparation = 20;
            this.flowChart111.ArrowsWidth = 1;
            this.flowChart111.BackColor = System.Drawing.Color.White;
            this.flowChart111.bClearTrace = false;
            this.flowChart111.bIsLastFlowChart = false;
            this.flowChart111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart111.bSkip = false;
            this.flowChart111.bStepByStepMode = false;
            this.flowChart111.CASE1 = null;
            this.flowChart111.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart111.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart111.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.CASE2 = null;
            this.flowChart111.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart111.CASE2Color = System.Drawing.Color.Red;
            this.flowChart111.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.CASE3 = null;
            this.flowChart111.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart111.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart111.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.DefaultColor = System.Drawing.Color.White;
            this.flowChart111.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart111.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart111.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart111.Location = new System.Drawing.Point(11, 241);
            this.flowChart111.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart111.menuOpening = false;
            this.flowChart111.Name = "flowChart111";
            this.flowChart111.NEXT = this.flowChart112;
            this.flowChart111.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart111.NEXTColor = System.Drawing.Color.Black;
            this.flowChart111.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart111.Size = new System.Drawing.Size(178, 35);
            this.flowChart111.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart111.SubFlowChart = null;
            this.flowChart111.TabIndex = 49;
            this.flowChart111.Text = "Wait R1  arrive pos";
            this.flowChart111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart111.TimeOut = 10000;
            this.flowChart111.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart111.tmrTimeOut = null;
            this.flowChart111.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart111_FlowRun);
            // 
            // flowChart112
            // 
            this.flowChart112.AlarmCode = "";
            this.flowChart112.ArrowSeparation = 20;
            this.flowChart112.ArrowsWidth = 1;
            this.flowChart112.BackColor = System.Drawing.Color.White;
            this.flowChart112.bClearTrace = false;
            this.flowChart112.bIsLastFlowChart = false;
            this.flowChart112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart112.bSkip = false;
            this.flowChart112.bStepByStepMode = false;
            this.flowChart112.CASE1 = null;
            this.flowChart112.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart112.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart112.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.CASE2 = null;
            this.flowChart112.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart112.CASE2Color = System.Drawing.Color.Red;
            this.flowChart112.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.CASE3 = null;
            this.flowChart112.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart112.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart112.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.DefaultColor = System.Drawing.Color.White;
            this.flowChart112.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart112.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart112.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart112.Location = new System.Drawing.Point(11, 288);
            this.flowChart112.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart112.menuOpening = false;
            this.flowChart112.Name = "flowChart112";
            this.flowChart112.NEXT = this.flowChart109;
            this.flowChart112.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart112.NEXTColor = System.Drawing.Color.Black;
            this.flowChart112.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart112.Size = new System.Drawing.Size(178, 35);
            this.flowChart112.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart112.SubFlowChart = null;
            this.flowChart112.TabIndex = 50;
            this.flowChart112.Text = "R1 Goto picture";
            this.flowChart112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart112.TimeOut = 10000;
            this.flowChart112.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart112.tmrTimeOut = null;
            this.flowChart112.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart112_FlowRun);
            // 
            // flowChart113
            // 
            this.flowChart113.AlarmCode = "";
            this.flowChart113.ArrowSeparation = 20;
            this.flowChart113.ArrowsWidth = 1;
            this.flowChart113.BackColor = System.Drawing.Color.White;
            this.flowChart113.bClearTrace = false;
            this.flowChart113.bIsLastFlowChart = false;
            this.flowChart113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart113.bSkip = false;
            this.flowChart113.bStepByStepMode = false;
            this.flowChart113.CASE1 = null;
            this.flowChart113.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart113.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart113.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.CASE2 = null;
            this.flowChart113.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart113.CASE2Color = System.Drawing.Color.Red;
            this.flowChart113.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.CASE3 = null;
            this.flowChart113.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart113.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart113.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.DefaultColor = System.Drawing.Color.White;
            this.flowChart113.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart113.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart113.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart113.Location = new System.Drawing.Point(11, 134);
            this.flowChart113.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart113.menuOpening = false;
            this.flowChart113.Name = "flowChart113";
            this.flowChart113.NEXT = this.flowChart110;
            this.flowChart113.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart113.NEXTColor = System.Drawing.Color.Black;
            this.flowChart113.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart113.Size = new System.Drawing.Size(178, 35);
            this.flowChart113.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart113.SubFlowChart = null;
            this.flowChart113.TabIndex = 47;
            this.flowChart113.Text = "Start Robot work";
            this.flowChart113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart113.TimeOut = 10000;
            this.flowChart113.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart113.tmrTimeOut = null;
            this.flowChart113.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart113_FlowRun);
            // 
            // flowChart114
            // 
            this.flowChart114.AlarmCode = "";
            this.flowChart114.ArrowSeparation = 20;
            this.flowChart114.ArrowsWidth = 1;
            this.flowChart114.BackColor = System.Drawing.Color.White;
            this.flowChart114.bClearTrace = false;
            this.flowChart114.bIsLastFlowChart = false;
            this.flowChart114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart114.bSkip = false;
            this.flowChart114.bStepByStepMode = false;
            this.flowChart114.CASE1 = null;
            this.flowChart114.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart114.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart114.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.CASE2 = null;
            this.flowChart114.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart114.CASE2Color = System.Drawing.Color.Red;
            this.flowChart114.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.CASE3 = null;
            this.flowChart114.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart114.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart114.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.DefaultColor = System.Drawing.Color.White;
            this.flowChart114.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart114.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart114.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart114.Location = new System.Drawing.Point(11, 87);
            this.flowChart114.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart114.menuOpening = false;
            this.flowChart114.Name = "flowChart114";
            this.flowChart114.NEXT = this.flowChart113;
            this.flowChart114.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart114.NEXTColor = System.Drawing.Color.Black;
            this.flowChart114.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart114.Size = new System.Drawing.Size(178, 35);
            this.flowChart114.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart114.SubFlowChart = null;
            this.flowChart114.TabIndex = 46;
            this.flowChart114.Text = "Auto calibration";
            this.flowChart114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart114.TimeOut = 10000;
            this.flowChart114.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart114.tmrTimeOut = null;
            this.flowChart114.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart114_FlowRun);
            // 
            // flowChart115
            // 
            this.flowChart115.AlarmCode = "";
            this.flowChart115.ArrowSeparation = 20;
            this.flowChart115.ArrowsWidth = 1;
            this.flowChart115.BackColor = System.Drawing.Color.White;
            this.flowChart115.bClearTrace = false;
            this.flowChart115.bIsLastFlowChart = false;
            this.flowChart115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart115.bSkip = false;
            this.flowChart115.bStepByStepMode = false;
            this.flowChart115.CASE1 = null;
            this.flowChart115.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart115.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart115.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.CASE2 = null;
            this.flowChart115.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart115.CASE2Color = System.Drawing.Color.Red;
            this.flowChart115.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.CASE3 = null;
            this.flowChart115.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart115.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart115.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.DefaultColor = System.Drawing.Color.White;
            this.flowChart115.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart115.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart115.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart115.Location = new System.Drawing.Point(11, 39);
            this.flowChart115.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart115.menuOpening = false;
            this.flowChart115.Name = "flowChart115";
            this.flowChart115.NEXT = this.flowChart114;
            this.flowChart115.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart115.NEXTColor = System.Drawing.Color.Black;
            this.flowChart115.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart115.Size = new System.Drawing.Size(178, 35);
            this.flowChart115.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart115.SubFlowChart = null;
            this.flowChart115.TabIndex = 45;
            this.flowChart115.Text = "Start process";
            this.flowChart115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart115.TimeOut = 10000;
            this.flowChart115.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart115.tmrTimeOut = null;
            this.flowChart115.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart115_FlowRun);
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.tableLayoutPanel15);
            this.tabPage12.Location = new System.Drawing.Point(4, 31);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(664, 1402);
            this.tabPage12.TabIndex = 11;
            this.tabPage12.Text = "R1_Pick1Vision";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.32127F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.67873F));
            this.tableLayoutPanel15.Controls.Add(this.tableLayoutPanel16, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.tabControl6, 1, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 1;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(664, 1402);
            this.tableLayoutPanel15.TabIndex = 1;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel18, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.tableLayoutPanel17, 0, 1);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(441, 1396);
            this.tableLayoutPanel16.TabIndex = 16;
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 2;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.Controls.Add(this.dgv_H2_PickPos, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.tableLayoutPanel19, 1, 0);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 1;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(435, 831);
            this.tableLayoutPanel18.TabIndex = 15;
            // 
            // dgv_H2_PickPos
            // 
            this.dgv_H2_PickPos.AllowUserToAddRows = false;
            this.dgv_H2_PickPos.AutoGenerateColumns = false;
            this.dgv_H2_PickPos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgv_H2_PickPos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_H2_PickPos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.calibIndexDataGridViewTextBoxColumn,
            this.calibPixelXDataGridViewTextBoxColumn,
            this.calibPixelYDataGridViewTextBoxColumn,
            this.calibRobotXDataGridViewTextBoxColumn,
            this.calibRobotYDataGridViewTextBoxColumn});
            this.dgv_H2_PickPos.DataMember = "R1_PickVisCalib";
            this.dgv_H2_PickPos.DataSource = this.RecipeData;
            this.dgv_H2_PickPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_H2_PickPos.Location = new System.Drawing.Point(2, 2);
            this.dgv_H2_PickPos.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_H2_PickPos.Name = "dgv_H2_PickPos";
            this.dgv_H2_PickPos.RowHeadersWidth = 20;
            this.dgv_H2_PickPos.RowTemplate.Height = 27;
            this.dgv_H2_PickPos.Size = new System.Drawing.Size(344, 827);
            this.dgv_H2_PickPos.TabIndex = 16;
            // 
            // calibIndexDataGridViewTextBoxColumn
            // 
            this.calibIndexDataGridViewTextBoxColumn.DataPropertyName = "Calib_Index";
            this.calibIndexDataGridViewTextBoxColumn.HeaderText = "Calib_Index";
            this.calibIndexDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.calibIndexDataGridViewTextBoxColumn.Name = "calibIndexDataGridViewTextBoxColumn";
            this.calibIndexDataGridViewTextBoxColumn.Width = 134;
            // 
            // calibPixelXDataGridViewTextBoxColumn
            // 
            this.calibPixelXDataGridViewTextBoxColumn.DataPropertyName = "Calib_PixelX";
            this.calibPixelXDataGridViewTextBoxColumn.HeaderText = "Calib_PixelX";
            this.calibPixelXDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.calibPixelXDataGridViewTextBoxColumn.Name = "calibPixelXDataGridViewTextBoxColumn";
            this.calibPixelXDataGridViewTextBoxColumn.Width = 142;
            // 
            // calibPixelYDataGridViewTextBoxColumn
            // 
            this.calibPixelYDataGridViewTextBoxColumn.DataPropertyName = "Calib_PixelY";
            this.calibPixelYDataGridViewTextBoxColumn.HeaderText = "Calib_PixelY";
            this.calibPixelYDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.calibPixelYDataGridViewTextBoxColumn.Name = "calibPixelYDataGridViewTextBoxColumn";
            this.calibPixelYDataGridViewTextBoxColumn.Width = 140;
            // 
            // calibRobotXDataGridViewTextBoxColumn
            // 
            this.calibRobotXDataGridViewTextBoxColumn.DataPropertyName = "Calib_RobotX";
            this.calibRobotXDataGridViewTextBoxColumn.HeaderText = "Calib_RobotX";
            this.calibRobotXDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.calibRobotXDataGridViewTextBoxColumn.Name = "calibRobotXDataGridViewTextBoxColumn";
            this.calibRobotXDataGridViewTextBoxColumn.Width = 151;
            // 
            // calibRobotYDataGridViewTextBoxColumn
            // 
            this.calibRobotYDataGridViewTextBoxColumn.DataPropertyName = "Calib_RobotY";
            this.calibRobotYDataGridViewTextBoxColumn.HeaderText = "Calib_RobotY";
            this.calibRobotYDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.calibRobotYDataGridViewTextBoxColumn.Name = "calibRobotYDataGridViewTextBoxColumn";
            this.calibRobotYDataGridViewTextBoxColumn.Width = 149;
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.button1, 0, 2);
            this.tableLayoutPanel19.Controls.Add(this.btnPickPos1AlogrithmEditing, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.btnPickPosStartCalib, 0, 1);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(351, 3);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 3;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(81, 825);
            this.tableLayoutPanel19.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(2, 552);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(77, 271);
            this.button1.TabIndex = 2;
            this.button1.Text = "Light On/Off";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnPickPos1AlogrithmEditing
            // 
            this.btnPickPos1AlogrithmEditing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPickPos1AlogrithmEditing.Location = new System.Drawing.Point(2, 2);
            this.btnPickPos1AlogrithmEditing.Margin = new System.Windows.Forms.Padding(2);
            this.btnPickPos1AlogrithmEditing.Name = "btnPickPos1AlogrithmEditing";
            this.btnPickPos1AlogrithmEditing.Size = new System.Drawing.Size(77, 271);
            this.btnPickPos1AlogrithmEditing.TabIndex = 0;
            this.btnPickPos1AlogrithmEditing.Text = "Algorithm editing";
            this.btnPickPos1AlogrithmEditing.UseVisualStyleBackColor = true;
            this.btnPickPos1AlogrithmEditing.Click += new System.EventHandler(this.btnPickPos1AlogrithmEditing_Click);
            // 
            // btnPickPosStartCalib
            // 
            this.btnPickPosStartCalib.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPickPosStartCalib.Location = new System.Drawing.Point(2, 277);
            this.btnPickPosStartCalib.Margin = new System.Windows.Forms.Padding(2);
            this.btnPickPosStartCalib.Name = "btnPickPosStartCalib";
            this.btnPickPosStartCalib.Size = new System.Drawing.Size(77, 271);
            this.btnPickPosStartCalib.TabIndex = 1;
            this.btnPickPosStartCalib.Text = "Calibration";
            this.btnPickPosStartCalib.UseVisualStyleBackColor = true;
            this.btnPickPosStartCalib.Click += new System.EventHandler(this.btnPickPosStartCalib_Click);
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 4;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.58931F));
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotU3, 0, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotX3, 0, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionX3, 0, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotY3, 0, 6);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotX2, 0, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotY2, 0, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotU2, 0, 4);
            this.tableLayoutPanel17.Controls.Add(this.lb_PickVisU, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.lb_PickVisY, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionX1, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionY1, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.btnTeachPickVisPos, 3, 1);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotX1, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotY1, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosRobotU1, 2, 2);
            this.tableLayoutPanel17.Controls.Add(this.btnTeachPickRobotPos, 3, 2);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionU1, 2, 1);
            this.tableLayoutPanel17.Controls.Add(this.lb_PickVisX, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.btnTeachPickRobotPos2, 3, 4);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionX2, 0, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionU2, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionY2, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.btnTeachPickVisPos2, 3, 3);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionY3, 1, 5);
            this.tableLayoutPanel17.Controls.Add(this.txtPickPosVisionU3, 2, 5);
            this.tableLayoutPanel17.Controls.Add(this.btnTeachPickVisPos3, 3, 5);
            this.tableLayoutPanel17.Controls.Add(this.btnTeachPickRobotPos3, 3, 6);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 840);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 7;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(435, 553);
            this.tableLayoutPanel17.TabIndex = 16;
            // 
            // txtPickPosRobotU3
            // 
            this.txtPickPosRobotU3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotU3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachRobotU3", true));
            this.txtPickPosRobotU3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotU3.Location = new System.Drawing.Point(194, 470);
            this.txtPickPosRobotU3.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotU3.Name = "txtPickPosRobotU3";
            this.txtPickPosRobotU3.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotU3.TabIndex = 21;
            this.txtPickPosRobotU3.Text = "NULL";
            this.txtPickPosRobotU3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosRobotX3
            // 
            this.txtPickPosRobotX3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotX3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachRobotX3", true));
            this.txtPickPosRobotX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotX3.Location = new System.Drawing.Point(2, 470);
            this.txtPickPosRobotX3.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotX3.Name = "txtPickPosRobotX3";
            this.txtPickPosRobotX3.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotX3.TabIndex = 20;
            this.txtPickPosRobotX3.Text = "NULL";
            this.txtPickPosRobotX3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosVisionX3
            // 
            this.txtPickPosVisionX3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionX3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachVisX3", true));
            this.txtPickPosVisionX3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionX3.Location = new System.Drawing.Point(2, 392);
            this.txtPickPosVisionX3.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionX3.Name = "txtPickPosVisionX3";
            this.txtPickPosVisionX3.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionX3.TabIndex = 18;
            this.txtPickPosVisionX3.Text = "NULL";
            this.txtPickPosVisionX3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosRobotY3
            // 
            this.txtPickPosRobotY3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotY3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachRobotY3", true));
            this.txtPickPosRobotY3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotY3.Location = new System.Drawing.Point(98, 470);
            this.txtPickPosRobotY3.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotY3.Name = "txtPickPosRobotY3";
            this.txtPickPosRobotY3.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotY3.TabIndex = 16;
            this.txtPickPosRobotY3.Text = "NULL";
            this.txtPickPosRobotY3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosRobotX2
            // 
            this.txtPickPosRobotX2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotX2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachRobotX2", true));
            this.txtPickPosRobotX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotX2.Location = new System.Drawing.Point(2, 314);
            this.txtPickPosRobotX2.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotX2.Name = "txtPickPosRobotX2";
            this.txtPickPosRobotX2.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotX2.TabIndex = 14;
            this.txtPickPosRobotX2.Text = "NUll";
            this.txtPickPosRobotX2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosRobotY2
            // 
            this.txtPickPosRobotY2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotY2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachRobotY2", true));
            this.txtPickPosRobotY2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotY2.Location = new System.Drawing.Point(98, 314);
            this.txtPickPosRobotY2.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotY2.Name = "txtPickPosRobotY2";
            this.txtPickPosRobotY2.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotY2.TabIndex = 13;
            this.txtPickPosRobotY2.Text = "NULL";
            this.txtPickPosRobotY2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosRobotU2
            // 
            this.txtPickPosRobotU2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotU2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachRobotU2", true));
            this.txtPickPosRobotU2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotU2.Location = new System.Drawing.Point(194, 314);
            this.txtPickPosRobotU2.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotU2.Name = "txtPickPosRobotU2";
            this.txtPickPosRobotU2.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotU2.TabIndex = 12;
            this.txtPickPosRobotU2.Text = "NULL";
            this.txtPickPosRobotU2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lb_PickVisU
            // 
            this.lb_PickVisU.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_PickVisU.AutoSize = true;
            this.lb_PickVisU.Location = new System.Drawing.Point(228, 27);
            this.lb_PickVisU.Name = "lb_PickVisU";
            this.lb_PickVisU.Size = new System.Drawing.Size(23, 24);
            this.lb_PickVisU.TabIndex = 11;
            this.lb_PickVisU.Text = "U";
            this.lb_PickVisU.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_PickVisU.UseMnemonic = false;
            // 
            // lb_PickVisY
            // 
            this.lb_PickVisY.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_PickVisY.AutoSize = true;
            this.lb_PickVisY.Location = new System.Drawing.Point(133, 27);
            this.lb_PickVisY.Name = "lb_PickVisY";
            this.lb_PickVisY.Size = new System.Drawing.Size(22, 24);
            this.lb_PickVisY.TabIndex = 10;
            this.lb_PickVisY.Text = "Y";
            this.lb_PickVisY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_PickVisY.UseMnemonic = false;
            // 
            // txtPickPosVisionX1
            // 
            this.txtPickPosVisionX1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionX1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachVisX", true));
            this.txtPickPosVisionX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionX1.Location = new System.Drawing.Point(2, 80);
            this.txtPickPosVisionX1.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionX1.Name = "txtPickPosVisionX1";
            this.txtPickPosVisionX1.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionX1.TabIndex = 4;
            this.txtPickPosVisionX1.Text = "NULL";
            this.txtPickPosVisionX1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosVisionY1
            // 
            this.txtPickPosVisionY1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionY1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "Rset.PickTeachVisY", true));
            this.txtPickPosVisionY1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionY1.Location = new System.Drawing.Point(98, 80);
            this.txtPickPosVisionY1.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionY1.Name = "txtPickPosVisionY1";
            this.txtPickPosVisionY1.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionY1.TabIndex = 6;
            this.txtPickPosVisionY1.Text = "NULL";
            this.txtPickPosVisionY1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachPickVisPos
            // 
            this.btnTeachPickVisPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachPickVisPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachPickVisPos.Location = new System.Drawing.Point(290, 80);
            this.btnTeachPickVisPos.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachPickVisPos.Name = "btnTeachPickVisPos";
            this.btnTeachPickVisPos.Size = new System.Drawing.Size(143, 74);
            this.btnTeachPickVisPos.TabIndex = 1;
            this.btnTeachPickVisPos.Text = "Teaching visual position (grapper1)";
            this.btnTeachPickVisPos.UseVisualStyleBackColor = true;
            this.btnTeachPickVisPos.Click += new System.EventHandler(this.btnTeachPickVisPos_Click);
            // 
            // txtPickPosRobotX1
            // 
            this.txtPickPosRobotX1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotX1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "Rset.PickTeachRobotX", true));
            this.txtPickPosRobotX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotX1.Location = new System.Drawing.Point(2, 158);
            this.txtPickPosRobotX1.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotX1.Name = "txtPickPosRobotX1";
            this.txtPickPosRobotX1.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotX1.TabIndex = 4;
            this.txtPickPosRobotX1.Text = "NULL";
            this.txtPickPosRobotX1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosRobotY1
            // 
            this.txtPickPosRobotY1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotY1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "Rset.PickTeachRobotY", true));
            this.txtPickPosRobotY1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotY1.Location = new System.Drawing.Point(98, 158);
            this.txtPickPosRobotY1.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotY1.Name = "txtPickPosRobotY1";
            this.txtPickPosRobotY1.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotY1.TabIndex = 6;
            this.txtPickPosRobotY1.Text = "NULL";
            this.txtPickPosRobotY1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosRobotU1
            // 
            this.txtPickPosRobotU1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosRobotU1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "Rset.PickTeachRobotU", true));
            this.txtPickPosRobotU1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosRobotU1.Location = new System.Drawing.Point(194, 158);
            this.txtPickPosRobotU1.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosRobotU1.Name = "txtPickPosRobotU1";
            this.txtPickPosRobotU1.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosRobotU1.TabIndex = 8;
            this.txtPickPosRobotU1.Text = "NUll";
            this.txtPickPosRobotU1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachPickRobotPos
            // 
            this.btnTeachPickRobotPos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachPickRobotPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachPickRobotPos.Location = new System.Drawing.Point(290, 158);
            this.btnTeachPickRobotPos.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachPickRobotPos.Name = "btnTeachPickRobotPos";
            this.btnTeachPickRobotPos.Size = new System.Drawing.Size(143, 74);
            this.btnTeachPickRobotPos.TabIndex = 1;
            this.btnTeachPickRobotPos.Text = "Teaching robot position G1";
            this.btnTeachPickRobotPos.UseVisualStyleBackColor = true;
            this.btnTeachPickRobotPos.Visible = false;
            this.btnTeachPickRobotPos.Click += new System.EventHandler(this.btnTeachPickRobotPos_Click);
            // 
            // txtPickPosVisionU1
            // 
            this.txtPickPosVisionU1.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionU1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "Rset.PickTeachVisU", true));
            this.txtPickPosVisionU1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionU1.Location = new System.Drawing.Point(194, 80);
            this.txtPickPosVisionU1.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionU1.Name = "txtPickPosVisionU1";
            this.txtPickPosVisionU1.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionU1.TabIndex = 8;
            this.txtPickPosVisionU1.Text = "NUll";
            this.txtPickPosVisionU1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lb_PickVisX
            // 
            this.lb_PickVisX.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_PickVisX.AutoSize = true;
            this.lb_PickVisX.Location = new System.Drawing.Point(36, 27);
            this.lb_PickVisX.Name = "lb_PickVisX";
            this.lb_PickVisX.Size = new System.Drawing.Size(24, 24);
            this.lb_PickVisX.TabIndex = 9;
            this.lb_PickVisX.Text = "X";
            this.lb_PickVisX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lb_PickVisX.UseMnemonic = false;
            // 
            // btnTeachPickRobotPos2
            // 
            this.btnTeachPickRobotPos2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachPickRobotPos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachPickRobotPos2.Location = new System.Drawing.Point(290, 314);
            this.btnTeachPickRobotPos2.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachPickRobotPos2.Name = "btnTeachPickRobotPos2";
            this.btnTeachPickRobotPos2.Size = new System.Drawing.Size(143, 74);
            this.btnTeachPickRobotPos2.TabIndex = 15;
            this.btnTeachPickRobotPos2.Text = "Teaching robot position G2";
            this.btnTeachPickRobotPos2.UseVisualStyleBackColor = true;
            this.btnTeachPickRobotPos2.Visible = false;
            this.btnTeachPickRobotPos2.Click += new System.EventHandler(this.btnTeachPickRobotPos2_Click);
            // 
            // txtPickPosVisionX2
            // 
            this.txtPickPosVisionX2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionX2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachVisX2", true));
            this.txtPickPosVisionX2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionX2.Location = new System.Drawing.Point(2, 236);
            this.txtPickPosVisionX2.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionX2.Name = "txtPickPosVisionX2";
            this.txtPickPosVisionX2.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionX2.TabIndex = 4;
            this.txtPickPosVisionX2.Text = "NULL";
            this.txtPickPosVisionX2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosVisionU2
            // 
            this.txtPickPosVisionU2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionU2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachVisU2", true));
            this.txtPickPosVisionU2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionU2.Location = new System.Drawing.Point(194, 236);
            this.txtPickPosVisionU2.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionU2.Name = "txtPickPosVisionU2";
            this.txtPickPosVisionU2.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionU2.TabIndex = 4;
            this.txtPickPosVisionU2.Text = "NULL";
            this.txtPickPosVisionU2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosVisionY2
            // 
            this.txtPickPosVisionY2.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionY2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachVisY2", true));
            this.txtPickPosVisionY2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionY2.Location = new System.Drawing.Point(98, 236);
            this.txtPickPosVisionY2.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionY2.Name = "txtPickPosVisionY2";
            this.txtPickPosVisionY2.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionY2.TabIndex = 4;
            this.txtPickPosVisionY2.Text = "NULL";
            this.txtPickPosVisionY2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachPickVisPos2
            // 
            this.btnTeachPickVisPos2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachPickVisPos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachPickVisPos2.Location = new System.Drawing.Point(290, 236);
            this.btnTeachPickVisPos2.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachPickVisPos2.Name = "btnTeachPickVisPos2";
            this.btnTeachPickVisPos2.Size = new System.Drawing.Size(143, 74);
            this.btnTeachPickVisPos2.TabIndex = 1;
            this.btnTeachPickVisPos2.Text = "Teaching visual position (grapper2)";
            this.btnTeachPickVisPos2.UseVisualStyleBackColor = true;
            this.btnTeachPickVisPos2.Click += new System.EventHandler(this.btnTeachPickVisPos2_Click);
            // 
            // txtPickPosVisionY3
            // 
            this.txtPickPosVisionY3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionY3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachVisY3", true));
            this.txtPickPosVisionY3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionY3.Location = new System.Drawing.Point(98, 392);
            this.txtPickPosVisionY3.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionY3.Name = "txtPickPosVisionY3";
            this.txtPickPosVisionY3.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionY3.TabIndex = 17;
            this.txtPickPosVisionY3.Text = "NULL";
            this.txtPickPosVisionY3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPickPosVisionU3
            // 
            this.txtPickPosVisionU3.BackColor = System.Drawing.SystemColors.Menu;
            this.txtPickPosVisionU3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PickTeachVisU3", true));
            this.txtPickPosVisionU3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPickPosVisionU3.Location = new System.Drawing.Point(194, 392);
            this.txtPickPosVisionU3.Margin = new System.Windows.Forms.Padding(2);
            this.txtPickPosVisionU3.Name = "txtPickPosVisionU3";
            this.txtPickPosVisionU3.Size = new System.Drawing.Size(92, 28);
            this.txtPickPosVisionU3.TabIndex = 19;
            this.txtPickPosVisionU3.Text = "NULL";
            this.txtPickPosVisionU3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnTeachPickVisPos3
            // 
            this.btnTeachPickVisPos3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachPickVisPos3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachPickVisPos3.Location = new System.Drawing.Point(290, 392);
            this.btnTeachPickVisPos3.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachPickVisPos3.Name = "btnTeachPickVisPos3";
            this.btnTeachPickVisPos3.Size = new System.Drawing.Size(143, 74);
            this.btnTeachPickVisPos3.TabIndex = 15;
            this.btnTeachPickVisPos3.Text = "Teaching visual position (grapper3)";
            this.btnTeachPickVisPos3.UseVisualStyleBackColor = true;
            this.btnTeachPickVisPos3.Click += new System.EventHandler(this.btnTeachPickVisPos3_Click);
            // 
            // btnTeachPickRobotPos3
            // 
            this.btnTeachPickRobotPos3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTeachPickRobotPos3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTeachPickRobotPos3.Location = new System.Drawing.Point(290, 470);
            this.btnTeachPickRobotPos3.Margin = new System.Windows.Forms.Padding(2);
            this.btnTeachPickRobotPos3.Name = "btnTeachPickRobotPos3";
            this.btnTeachPickRobotPos3.Size = new System.Drawing.Size(143, 81);
            this.btnTeachPickRobotPos3.TabIndex = 15;
            this.btnTeachPickRobotPos3.Text = "Teaching robot position G3";
            this.btnTeachPickRobotPos3.UseVisualStyleBackColor = true;
            this.btnTeachPickRobotPos3.Visible = false;
            this.btnTeachPickRobotPos3.Click += new System.EventHandler(this.btnTeachPickRobotPos3_Click);
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage16);
            this.tabControl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl6.Location = new System.Drawing.Point(450, 3);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(211, 1396);
            this.tabControl6.TabIndex = 17;
            // 
            // tabPage16
            // 
            this.tabPage16.AutoScroll = true;
            this.tabPage16.Controls.Add(this.flowChart92);
            this.tabPage16.Controls.Add(this.flowChart93);
            this.tabPage16.Controls.Add(this.flowChart97);
            this.tabPage16.Controls.Add(this.flowChart95);
            this.tabPage16.Controls.Add(this.flowChart94);
            this.tabPage16.Controls.Add(this.flowChart98);
            this.tabPage16.Controls.Add(this.flowChart99);
            this.tabPage16.Controls.Add(this.flowChart100);
            this.tabPage16.Location = new System.Drawing.Point(4, 31);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(203, 1361);
            this.tabPage16.TabIndex = 1;
            this.tabPage16.Text = "Auto calibration";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // flowChart92
            // 
            this.flowChart92.AlarmCode = "";
            this.flowChart92.ArrowSeparation = 20;
            this.flowChart92.ArrowsWidth = 1;
            this.flowChart92.BackColor = System.Drawing.Color.White;
            this.flowChart92.bClearTrace = false;
            this.flowChart92.bIsLastFlowChart = false;
            this.flowChart92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart92.bSkip = false;
            this.flowChart92.bStepByStepMode = false;
            this.flowChart92.CASE1 = null;
            this.flowChart92.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart92.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart92.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.CASE2 = null;
            this.flowChart92.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart92.CASE2Color = System.Drawing.Color.Red;
            this.flowChart92.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.CASE3 = null;
            this.flowChart92.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart92.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart92.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.DefaultColor = System.Drawing.Color.White;
            this.flowChart92.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart92.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart92.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart92.Location = new System.Drawing.Point(211, 139);
            this.flowChart92.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart92.menuOpening = false;
            this.flowChart92.Name = "flowChart92";
            this.flowChart92.NEXT = null;
            this.flowChart92.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart92.NEXTColor = System.Drawing.Color.Black;
            this.flowChart92.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart92.Size = new System.Drawing.Size(87, 35);
            this.flowChart92.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart92.SubFlowChart = null;
            this.flowChart92.TabIndex = 55;
            this.flowChart92.Text = "Calibrate";
            this.flowChart92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart92.TimeOut = 10000;
            this.flowChart92.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart92.tmrTimeOut = null;
            this.flowChart92.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart92_FlowRun);
            // 
            // flowChart93
            // 
            this.flowChart93.AlarmCode = "";
            this.flowChart93.ArrowSeparation = 20;
            this.flowChart93.ArrowsWidth = 1;
            this.flowChart93.BackColor = System.Drawing.Color.White;
            this.flowChart93.bClearTrace = false;
            this.flowChart93.bIsLastFlowChart = false;
            this.flowChart93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart93.bSkip = false;
            this.flowChart93.bStepByStepMode = false;
            this.flowChart93.CASE1 = this.flowChart92;
            this.flowChart93.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart93.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart93.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.CASE2 = null;
            this.flowChart93.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart93.CASE2Color = System.Drawing.Color.Red;
            this.flowChart93.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.CASE3 = null;
            this.flowChart93.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart93.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart93.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.DefaultColor = System.Drawing.Color.White;
            this.flowChart93.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart93.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart93.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart93.Location = new System.Drawing.Point(221, 198);
            this.flowChart93.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart93.menuOpening = false;
            this.flowChart93.Name = "flowChart93";
            this.flowChart93.NEXT = this.flowChart94;
            this.flowChart93.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart93.NEXTColor = System.Drawing.Color.Black;
            this.flowChart93.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart93.Size = new System.Drawing.Size(71, 122);
            this.flowChart93.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart93.SubFlowChart = null;
            this.flowChart93.TabIndex = 54;
            this.flowChart93.Text = "Judge Loop Times";
            this.flowChart93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart93.TimeOut = 10000;
            this.flowChart93.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart93.tmrTimeOut = null;
            this.flowChart93.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart93_FlowRun);
            // 
            // flowChart94
            // 
            this.flowChart94.AlarmCode = "";
            this.flowChart94.ArrowSeparation = 20;
            this.flowChart94.ArrowsWidth = 1;
            this.flowChart94.BackColor = System.Drawing.Color.White;
            this.flowChart94.bClearTrace = false;
            this.flowChart94.bIsLastFlowChart = false;
            this.flowChart94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart94.bSkip = false;
            this.flowChart94.bStepByStepMode = false;
            this.flowChart94.CASE1 = null;
            this.flowChart94.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart94.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart94.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.CASE2 = null;
            this.flowChart94.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart94.CASE2Color = System.Drawing.Color.Red;
            this.flowChart94.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.CASE3 = null;
            this.flowChart94.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart94.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart94.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.DefaultColor = System.Drawing.Color.White;
            this.flowChart94.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart94.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart94.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart94.Location = new System.Drawing.Point(11, 186);
            this.flowChart94.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart94.menuOpening = false;
            this.flowChart94.Name = "flowChart94";
            this.flowChart94.NEXT = this.flowChart95;
            this.flowChart94.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart94.NEXTColor = System.Drawing.Color.Black;
            this.flowChart94.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart94.Size = new System.Drawing.Size(178, 35);
            this.flowChart94.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart94.SubFlowChart = null;
            this.flowChart94.TabIndex = 48;
            this.flowChart94.Text = "R1 to picture pos1";
            this.flowChart94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart94.TimeOut = 10000;
            this.flowChart94.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart94.tmrTimeOut = null;
            this.flowChart94.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart94_FlowRun);
            // 
            // flowChart95
            // 
            this.flowChart95.AlarmCode = "";
            this.flowChart95.ArrowSeparation = 20;
            this.flowChart95.ArrowsWidth = 1;
            this.flowChart95.BackColor = System.Drawing.Color.White;
            this.flowChart95.bClearTrace = false;
            this.flowChart95.bIsLastFlowChart = false;
            this.flowChart95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart95.bSkip = false;
            this.flowChart95.bStepByStepMode = false;
            this.flowChart95.CASE1 = null;
            this.flowChart95.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart95.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart95.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.CASE2 = null;
            this.flowChart95.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart95.CASE2Color = System.Drawing.Color.Red;
            this.flowChart95.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.CASE3 = null;
            this.flowChart95.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart95.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart95.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.DefaultColor = System.Drawing.Color.White;
            this.flowChart95.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart95.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart95.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart95.Location = new System.Drawing.Point(11, 242);
            this.flowChart95.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart95.menuOpening = false;
            this.flowChart95.Name = "flowChart95";
            this.flowChart95.NEXT = this.flowChart97;
            this.flowChart95.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart95.NEXTColor = System.Drawing.Color.Black;
            this.flowChart95.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart95.Size = new System.Drawing.Size(178, 35);
            this.flowChart95.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart95.SubFlowChart = null;
            this.flowChart95.TabIndex = 49;
            this.flowChart95.Text = "Wait R1  arrive pos";
            this.flowChart95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart95.TimeOut = 10000;
            this.flowChart95.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart95.tmrTimeOut = null;
            this.flowChart95.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart95_FlowRun);
            // 
            // flowChart97
            // 
            this.flowChart97.AlarmCode = "";
            this.flowChart97.ArrowSeparation = 20;
            this.flowChart97.ArrowsWidth = 1;
            this.flowChart97.BackColor = System.Drawing.Color.White;
            this.flowChart97.bClearTrace = false;
            this.flowChart97.bIsLastFlowChart = false;
            this.flowChart97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart97.bSkip = false;
            this.flowChart97.bStepByStepMode = false;
            this.flowChart97.CASE1 = null;
            this.flowChart97.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart97.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart97.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.CASE2 = null;
            this.flowChart97.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart97.CASE2Color = System.Drawing.Color.Red;
            this.flowChart97.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.CASE3 = null;
            this.flowChart97.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart97.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart97.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.DefaultColor = System.Drawing.Color.White;
            this.flowChart97.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart97.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart97.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart97.Location = new System.Drawing.Point(11, 289);
            this.flowChart97.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart97.menuOpening = false;
            this.flowChart97.Name = "flowChart97";
            this.flowChart97.NEXT = this.flowChart93;
            this.flowChart97.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart97.NEXTColor = System.Drawing.Color.Black;
            this.flowChart97.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart97.Size = new System.Drawing.Size(178, 35);
            this.flowChart97.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart97.SubFlowChart = null;
            this.flowChart97.TabIndex = 50;
            this.flowChart97.Text = "R1 Goto picture";
            this.flowChart97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart97.TimeOut = 10000;
            this.flowChart97.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart97.tmrTimeOut = null;
            this.flowChart97.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart97_FlowRun);
            // 
            // flowChart98
            // 
            this.flowChart98.AlarmCode = "";
            this.flowChart98.ArrowSeparation = 20;
            this.flowChart98.ArrowsWidth = 1;
            this.flowChart98.BackColor = System.Drawing.Color.White;
            this.flowChart98.bClearTrace = false;
            this.flowChart98.bIsLastFlowChart = false;
            this.flowChart98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart98.bSkip = false;
            this.flowChart98.bStepByStepMode = false;
            this.flowChart98.CASE1 = null;
            this.flowChart98.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart98.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart98.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.CASE2 = null;
            this.flowChart98.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart98.CASE2Color = System.Drawing.Color.Red;
            this.flowChart98.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.CASE3 = null;
            this.flowChart98.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart98.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart98.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.DefaultColor = System.Drawing.Color.White;
            this.flowChart98.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart98.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart98.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart98.Location = new System.Drawing.Point(11, 139);
            this.flowChart98.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart98.menuOpening = false;
            this.flowChart98.Name = "flowChart98";
            this.flowChart98.NEXT = this.flowChart94;
            this.flowChart98.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart98.NEXTColor = System.Drawing.Color.Black;
            this.flowChart98.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart98.Size = new System.Drawing.Size(178, 35);
            this.flowChart98.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart98.SubFlowChart = null;
            this.flowChart98.TabIndex = 47;
            this.flowChart98.Text = "Start Robot work";
            this.flowChart98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart98.TimeOut = 10000;
            this.flowChart98.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart98.tmrTimeOut = null;
            this.flowChart98.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart98_FlowRun);
            // 
            // flowChart99
            // 
            this.flowChart99.AlarmCode = "";
            this.flowChart99.ArrowSeparation = 20;
            this.flowChart99.ArrowsWidth = 1;
            this.flowChart99.BackColor = System.Drawing.Color.White;
            this.flowChart99.bClearTrace = false;
            this.flowChart99.bIsLastFlowChart = false;
            this.flowChart99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart99.bSkip = false;
            this.flowChart99.bStepByStepMode = false;
            this.flowChart99.CASE1 = null;
            this.flowChart99.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart99.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart99.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.CASE2 = null;
            this.flowChart99.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart99.CASE2Color = System.Drawing.Color.Red;
            this.flowChart99.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.CASE3 = null;
            this.flowChart99.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart99.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart99.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.DefaultColor = System.Drawing.Color.White;
            this.flowChart99.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart99.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart99.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart99.Location = new System.Drawing.Point(11, 87);
            this.flowChart99.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart99.menuOpening = false;
            this.flowChart99.Name = "flowChart99";
            this.flowChart99.NEXT = this.flowChart98;
            this.flowChart99.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart99.NEXTColor = System.Drawing.Color.Black;
            this.flowChart99.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart99.Size = new System.Drawing.Size(178, 35);
            this.flowChart99.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart99.SubFlowChart = null;
            this.flowChart99.TabIndex = 46;
            this.flowChart99.Text = "Auto calibration";
            this.flowChart99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart99.TimeOut = 10000;
            this.flowChart99.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart99.tmrTimeOut = null;
            this.flowChart99.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart99_FlowRun);
            // 
            // flowChart100
            // 
            this.flowChart100.AlarmCode = "";
            this.flowChart100.ArrowSeparation = 20;
            this.flowChart100.ArrowsWidth = 1;
            this.flowChart100.BackColor = System.Drawing.Color.White;
            this.flowChart100.bClearTrace = false;
            this.flowChart100.bIsLastFlowChart = false;
            this.flowChart100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart100.bSkip = false;
            this.flowChart100.bStepByStepMode = false;
            this.flowChart100.CASE1 = null;
            this.flowChart100.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart100.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart100.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.CASE2 = null;
            this.flowChart100.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart100.CASE2Color = System.Drawing.Color.Red;
            this.flowChart100.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.CASE3 = null;
            this.flowChart100.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart100.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart100.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.DefaultColor = System.Drawing.Color.White;
            this.flowChart100.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart100.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart100.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart100.Location = new System.Drawing.Point(11, 39);
            this.flowChart100.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart100.menuOpening = false;
            this.flowChart100.Name = "flowChart100";
            this.flowChart100.NEXT = this.flowChart99;
            this.flowChart100.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart100.NEXTColor = System.Drawing.Color.Black;
            this.flowChart100.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart100.Size = new System.Drawing.Size(178, 35);
            this.flowChart100.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart100.SubFlowChart = null;
            this.flowChart100.TabIndex = 45;
            this.flowChart100.Text = "Start process";
            this.flowChart100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart100.TimeOut = 10000;
            this.flowChart100.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart100.tmrTimeOut = null;
            this.flowChart100.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart100_FlowRun);
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.tableLayoutPanel12);
            this.tabPage11.Location = new System.Drawing.Point(4, 31);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage11.Size = new System.Drawing.Size(664, 1402);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "CCD";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.35514F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.64486F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(660, 1398);
            this.tableLayoutPanel12.TabIndex = 64;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel3, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.cogRecDisp1, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 2);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.0285F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.302022F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(654, 923);
            this.tableLayoutPanel3.TabIndex = 60;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 755);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(648, 166);
            this.panel3.TabIndex = 58;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel4.Controls.Add(this.button6, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.button4, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.button7, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.button8, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.button9, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.button10, 3, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(648, 166);
            this.tableLayoutPanel4.TabIndex = 59;
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.Location = new System.Drawing.Point(431, 2);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(101, 162);
            this.button6.TabIndex = 25;
            this.button6.Text = "Go To DischargeVision";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.Location = new System.Drawing.Point(538, 2);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(107, 162);
            this.button4.TabIndex = 61;
            this.button4.Text = "Go To NGVision";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.Location = new System.Drawing.Point(3, 2);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(101, 162);
            this.button7.TabIndex = 20;
            this.button7.Text = "Live";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.Location = new System.Drawing.Point(110, 2);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(101, 162);
            this.button8.TabIndex = 21;
            this.button8.Text = "Light On";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.Location = new System.Drawing.Point(217, 2);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(101, 162);
            this.button9.TabIndex = 22;
            this.button9.Text = "Light Off";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.Location = new System.Drawing.Point(324, 2);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(101, 162);
            this.button10.TabIndex = 24;
            this.button10.Text = "Go To PickVision";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // cogRecDisp1
            // 
            this.cogRecDisp1.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogRecDisp1.ColorMapLowerRoiLimit = 0D;
            this.cogRecDisp1.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogRecDisp1.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogRecDisp1.ColorMapUpperRoiLimit = 1D;
            this.cogRecDisp1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cogRecDisp1.DoubleTapZoomCycleLength = 2;
            this.cogRecDisp1.DoubleTapZoomSensitivity = 2.5D;
            this.cogRecDisp1.Location = new System.Drawing.Point(3, 3);
            this.cogRecDisp1.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogRecDisp1.MouseWheelSensitivity = 1D;
            this.cogRecDisp1.Name = "cogRecDisp1";
            this.cogRecDisp1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogRecDisp1.OcxState")));
            this.cogRecDisp1.Size = new System.Drawing.Size(648, 747);
            this.cogRecDisp1.TabIndex = 59;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.textBox15);
            this.groupBox9.Controls.Add(this.label28);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.textBox31);
            this.groupBox9.Controls.Add(this.textBox32);
            this.groupBox9.Controls.Add(this.textBox33);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.button31);
            this.groupBox9.Controls.Add(this.button32);
            this.groupBox9.Location = new System.Drawing.Point(15, 1054);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Size = new System.Drawing.Size(403, 262);
            this.groupBox9.TabIndex = 62;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Fiducial1";
            this.groupBox9.Visible = false;
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(108, 228);
            this.textBox15.Margin = new System.Windows.Forms.Padding(4);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(92, 26);
            this.textBox15.TabIndex = 97;
            this.textBox15.Text = "Null";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(0, 228);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(94, 24);
            this.label28.TabIndex = 96;
            this.label28.Text = "Fiducial A";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox28);
            this.groupBox10.Controls.Add(this.label29);
            this.groupBox10.Controls.Add(this.button30);
            this.groupBox10.Controls.Add(this.textBox29);
            this.groupBox10.Controls.Add(this.label31);
            this.groupBox10.Controls.Add(this.label32);
            this.groupBox10.Controls.Add(this.textBox30);
            this.groupBox10.Location = new System.Drawing.Point(208, 23);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Size = new System.Drawing.Size(176, 198);
            this.groupBox10.TabIndex = 95;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Fiducial1";
            // 
            // textBox28
            // 
            this.textBox28.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.H1_Fid1RefA", true));
            this.textBox28.Location = new System.Drawing.Point(62, 106);
            this.textBox28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(108, 28);
            this.textBox28.TabIndex = 90;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(32, 111);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(23, 24);
            this.label29.TabIndex = 89;
            this.label29.Text = "A";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(62, 147);
            this.button30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(99, 33);
            this.button30.TabIndex = 88;
            this.button30.Text = "Replace";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // textBox29
            // 
            this.textBox29.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.H1_Fid1RefY", true));
            this.textBox29.Location = new System.Drawing.Point(62, 72);
            this.textBox29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(108, 28);
            this.textBox29.TabIndex = 4;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(31, 72);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(22, 24);
            this.label31.TabIndex = 1;
            this.label31.Text = "Y";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(31, 36);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(24, 24);
            this.label32.TabIndex = 0;
            this.label32.Text = "X";
            // 
            // textBox30
            // 
            this.textBox30.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.H1_Fid1RefX", true));
            this.textBox30.Location = new System.Drawing.Point(62, 35);
            this.textBox30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(108, 28);
            this.textBox30.TabIndex = 3;
            // 
            // textBox31
            // 
            this.textBox31.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(108, 192);
            this.textBox31.Margin = new System.Windows.Forms.Padding(4);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(92, 26);
            this.textBox31.TabIndex = 93;
            this.textBox31.Text = "Null";
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox32
            // 
            this.textBox32.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(108, 163);
            this.textBox32.Margin = new System.Windows.Forms.Padding(4);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(92, 26);
            this.textBox32.TabIndex = 94;
            this.textBox32.Text = "Null";
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(108, 127);
            this.textBox33.Margin = new System.Windows.Forms.Padding(4);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(92, 26);
            this.textBox33.TabIndex = 92;
            this.textBox33.Text = "Null";
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(2, 198);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(93, 24);
            this.label33.TabIndex = 91;
            this.label33.Text = "Fiducial Y";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(2, 163);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(95, 24);
            this.label34.TabIndex = 90;
            this.label34.Text = "Fiducial X";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(19, 130);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(62, 24);
            this.label35.TabIndex = 89;
            this.label35.Text = "Result";
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(19, 75);
            this.button31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(166, 42);
            this.button31.TabIndex = 88;
            this.button31.Text = "Trigger";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(19, 28);
            this.button32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(166, 42);
            this.button32.TabIndex = 87;
            this.button32.Text = "Setup";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.AutoScroll = true;
            this.tabPage9.Controls.Add(this.label59);
            this.tabPage9.Controls.Add(this.textBox46);
            this.tabPage9.Controls.Add(this.textBox75);
            this.tabPage9.Controls.Add(this.textBox74);
            this.tabPage9.Controls.Add(this.textBox73);
            this.tabPage9.Controls.Add(this.textBox72);
            this.tabPage9.Controls.Add(this.textBox25);
            this.tabPage9.Controls.Add(this.textBox23);
            this.tabPage9.Controls.Add(this.MName);
            this.tabPage9.Controls.Add(this.textBox22);
            this.tabPage9.Controls.Add(this.textBox21);
            this.tabPage9.Controls.Add(this.textBox20);
            this.tabPage9.Controls.Add(this.textBox19);
            this.tabPage9.Controls.Add(this.textBox18);
            this.tabPage9.Controls.Add(this.textBox17);
            this.tabPage9.Controls.Add(this.textBox16);
            this.tabPage9.Controls.Add(this.label92);
            this.tabPage9.Controls.Add(this.label91);
            this.tabPage9.Controls.Add(this.label90);
            this.tabPage9.Controls.Add(this.checkBox2);
            this.tabPage9.Controls.Add(this.checkBox1);
            this.tabPage9.Controls.Add(this.label89);
            this.tabPage9.Controls.Add(this.label65);
            this.tabPage9.Controls.Add(this.label64);
            this.tabPage9.Controls.Add(this.label54);
            this.tabPage9.Controls.Add(this.label55);
            this.tabPage9.Controls.Add(this.label56);
            this.tabPage9.Controls.Add(this.label57);
            this.tabPage9.Controls.Add(this.label58);
            this.tabPage9.Controls.Add(this.label61);
            this.tabPage9.Controls.Add(this.label62);
            this.tabPage9.Controls.Add(this.button48);
            this.tabPage9.Controls.Add(this.button47);
            this.tabPage9.Controls.Add(this.button46);
            this.tabPage9.Location = new System.Drawing.Point(4, 31);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(664, 1402);
            this.tabPage9.TabIndex = 6;
            this.tabPage9.Text = "MES";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(118, 543);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(80, 24);
            this.label59.TabIndex = 151;
            this.label59.Text = "TISPath:";
            // 
            // textBox46
            // 
            this.textBox46.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.TISPath", true));
            this.textBox46.Location = new System.Drawing.Point(242, 543);
            this.textBox46.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(307, 28);
            this.textBox46.TabIndex = 150;
            this.textBox46.Text = "PAutoScrew";
            // 
            // textBox75
            // 
            this.textBox75.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.SettingData, "PSet.JabilSavePath", true));
            this.textBox75.Location = new System.Drawing.Point(244, 738);
            this.textBox75.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(307, 28);
            this.textBox75.TabIndex = 145;
            this.textBox75.Text = "PAutoScrew";
            // 
            // textBox74
            // 
            this.textBox74.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.SettingData, "PSet.DataSavePath", true));
            this.textBox74.Location = new System.Drawing.Point(244, 696);
            this.textBox74.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(307, 28);
            this.textBox74.TabIndex = 143;
            this.textBox74.Text = "PAutoScrew";
            // 
            // textBox73
            // 
            this.textBox73.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.SettingData, "PSet.TarslinkPath", true));
            this.textBox73.Location = new System.Drawing.Point(244, 652);
            this.textBox73.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(307, 28);
            this.textBox73.TabIndex = 141;
            this.textBox73.Text = "PAutoScrew";
            // 
            // textBox72
            // 
            this.textBox72.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.TN", true));
            this.textBox72.Location = new System.Drawing.Point(242, 491);
            this.textBox72.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(307, 28);
            this.textBox72.TabIndex = 130;
            this.textBox72.Text = "PAutoScrew";
            // 
            // textBox25
            // 
            this.textBox25.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.cm", true));
            this.textBox25.Location = new System.Drawing.Point(242, 439);
            this.textBox25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(307, 28);
            this.textBox25.TabIndex = 123;
            this.textBox25.Text = "bmw";
            // 
            // textBox23
            // 
            this.textBox23.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PS", true));
            this.textBox23.Location = new System.Drawing.Point(242, 397);
            this.textBox23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(307, 28);
            this.textBox23.TabIndex = 121;
            this.textBox23.Text = "PAutoScrew";
            // 
            // MName
            // 
            this.MName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.MN", true));
            this.MName.Location = new System.Drawing.Point(242, 345);
            this.MName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MName.Name = "MName";
            this.MName.Size = new System.Drawing.Size(307, 28);
            this.MName.TabIndex = 119;
            this.MName.Text = "P11";
            // 
            // textBox22
            // 
            this.textBox22.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PN", true));
            this.textBox22.Location = new System.Drawing.Point(242, 295);
            this.textBox22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(307, 28);
            this.textBox22.TabIndex = 118;
            this.textBox22.Text = "P11";
            // 
            // textBox21
            // 
            this.textBox21.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.LineN", true));
            this.textBox21.Location = new System.Drawing.Point(242, 244);
            this.textBox21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(307, 28);
            this.textBox21.TabIndex = 117;
            this.textBox21.Text = "L018A";
            // 
            // textBox20
            // 
            this.textBox20.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.ON", true));
            this.textBox20.Location = new System.Drawing.Point(242, 199);
            this.textBox20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(307, 28);
            this.textBox20.TabIndex = 116;
            this.textBox20.Text = "ONISSAN";
            // 
            // textBox19
            // 
            this.textBox19.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.NN", true));
            this.textBox19.Location = new System.Drawing.Point(242, 153);
            this.textBox19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(307, 28);
            this.textBox19.TabIndex = 115;
            this.textBox19.Text = "nXA0253680E";
            // 
            // textBox18
            // 
            this.textBox18.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.StationN", true));
            this.textBox18.Location = new System.Drawing.Point(242, 111);
            this.textBox18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(307, 28);
            this.textBox18.TabIndex = 114;
            this.textBox18.Text = "PAutoScrew";
            // 
            // textBox17
            // 
            this.textBox17.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.PCN", true));
            this.textBox17.Location = new System.Drawing.Point(242, 62);
            this.textBox17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(307, 28);
            this.textBox17.TabIndex = 113;
            this.textBox17.Text = "Ncnhuanissan003";
            // 
            // textBox16
            // 
            this.textBox16.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.CurrentN", true));
            this.textBox16.Location = new System.Drawing.Point(242, 20);
            this.textBox16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(307, 28);
            this.textBox16.TabIndex = 112;
            this.textBox16.Text = "CRenault Nissan";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(122, 738);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(132, 24);
            this.label92.TabIndex = 146;
            this.label92.Text = "JabilSavePath:";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(122, 696);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(131, 24);
            this.label91.TabIndex = 144;
            this.label91.Text = "DataSavePath:";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(122, 652);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(80, 24);
            this.label90.TabIndex = 142;
            this.label90.Text = "Tarslink:";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.RecipeData, "RSet.JabilSaveEnable", true));
            this.checkBox2.Location = new System.Drawing.Point(396, 614);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(169, 28);
            this.checkBox2.TabIndex = 133;
            this.checkBox2.Text = "JabilSaveEnable";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.RecipeData, "RSet.TISEnable", true));
            this.checkBox1.Location = new System.Drawing.Point(106, 614);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(117, 28);
            this.checkBox1.TabIndex = 132;
            this.checkBox1.Text = "TISEnable";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(118, 491);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(119, 24);
            this.label89.TabIndex = 131;
            this.label89.Text = "TesterName:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(142, 397);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(80, 24);
            this.label65.TabIndex = 122;
            this.label65.Text = "PScrew:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(141, 348);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(87, 24);
            this.label64.TabIndex = 120;
            this.label64.Text = "M Name:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(142, 296);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(83, 24);
            this.label54.TabIndex = 111;
            this.label54.Text = "P Name:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(120, 254);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(107, 24);
            this.label55.TabIndex = 110;
            this.label55.Text = "Line Name:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(141, 205);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(86, 24);
            this.label56.TabIndex = 109;
            this.label56.Text = "O Name:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(142, 159);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(85, 24);
            this.label57.TabIndex = 108;
            this.label57.Text = "N Name:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(100, 111);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(127, 24);
            this.label58.TabIndex = 107;
            this.label58.Text = "Station Name:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(132, 62);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(96, 24);
            this.label61.TabIndex = 106;
            this.label61.Text = "PC Name:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(96, 20);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(133, 24);
            this.label62.TabIndex = 105;
            this.label62.Text = "Current Name:";
            // 
            // button48
            // 
            this.button48.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button48.BackgroundImage")));
            this.button48.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button48.Location = new System.Drawing.Point(586, 730);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(75, 42);
            this.button48.TabIndex = 149;
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button47
            // 
            this.button47.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button47.BackgroundImage")));
            this.button47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button47.Location = new System.Drawing.Point(586, 683);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(75, 42);
            this.button47.TabIndex = 148;
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button46
            // 
            this.button46.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button46.BackgroundImage")));
            this.button46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button46.Location = new System.Drawing.Point(586, 641);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(75, 42);
            this.button46.TabIndex = 147;
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tbMassage);
            this.tabPage2.Controls.Add(this.tbNO);
            this.tabPage2.Controls.Add(this.tbName);
            this.tabPage2.Controls.Add(this.btndisConScan1);
            this.tabPage2.Controls.Add(this.btnConScan1);
            this.tabPage2.Controls.Add(this.btnStarScan1);
            this.tabPage2.Controls.Add(this.label40);
            this.tabPage2.Controls.Add(this.label41);
            this.tabPage2.Location = new System.Drawing.Point(4, 31);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(664, 1402);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "Scanner";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tbMassage
            // 
            this.tbMassage.Location = new System.Drawing.Point(149, 158);
            this.tbMassage.Multiline = true;
            this.tbMassage.Name = "tbMassage";
            this.tbMassage.Size = new System.Drawing.Size(505, 131);
            this.tbMassage.TabIndex = 29;
            // 
            // tbNO
            // 
            this.tbNO.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.ScannerPort", true));
            this.tbNO.Location = new System.Drawing.Point(149, 85);
            this.tbNO.Name = "tbNO";
            this.tbNO.Size = new System.Drawing.Size(206, 28);
            this.tbNO.TabIndex = 24;
            this.tbNO.Text = "9004";
            // 
            // tbName
            // 
            this.tbName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.ScannerIP", true));
            this.tbName.Location = new System.Drawing.Point(149, 23);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(206, 28);
            this.tbName.TabIndex = 23;
            this.tbName.Text = "172.168.10.20";
            // 
            // btndisConScan1
            // 
            this.btndisConScan1.Location = new System.Drawing.Point(558, 23);
            this.btndisConScan1.Name = "btndisConScan1";
            this.btndisConScan1.Size = new System.Drawing.Size(130, 54);
            this.btndisConScan1.TabIndex = 38;
            this.btndisConScan1.Text = "Disconnect ";
            this.btndisConScan1.UseVisualStyleBackColor = true;
            this.btndisConScan1.Click += new System.EventHandler(this.btndisConScan1_Click);
            // 
            // btnConScan1
            // 
            this.btnConScan1.Location = new System.Drawing.Point(414, 23);
            this.btnConScan1.Name = "btnConScan1";
            this.btnConScan1.Size = new System.Drawing.Size(130, 54);
            this.btnConScan1.TabIndex = 37;
            this.btnConScan1.Text = "Connect";
            this.btnConScan1.UseVisualStyleBackColor = true;
            this.btnConScan1.Click += new System.EventHandler(this.btnConScan1_Click);
            // 
            // btnStarScan1
            // 
            this.btnStarScan1.Location = new System.Drawing.Point(414, 88);
            this.btnStarScan1.Name = "btnStarScan1";
            this.btnStarScan1.Size = new System.Drawing.Size(130, 54);
            this.btnStarScan1.TabIndex = 36;
            this.btnStarScan1.Text = "Start";
            this.btnStarScan1.UseVisualStyleBackColor = true;
            this.btnStarScan1.Click += new System.EventHandler(this.btnStarScan1_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(74, 85);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(48, 24);
            this.label40.TabIndex = 26;
            this.label40.Text = "Port:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(94, 28);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(31, 24);
            this.label41.TabIndex = 25;
            this.label41.Text = "IP:";
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.textBox52);
            this.tabPage18.Controls.Add(this.groupBox24);
            this.tabPage18.Controls.Add(this.label7);
            this.tabPage18.Controls.Add(this.groupBox4);
            this.tabPage18.Controls.Add(this.textBox51);
            this.tabPage18.Controls.Add(this.groupBox16);
            this.tabPage18.Controls.Add(this.textBox50);
            this.tabPage18.Controls.Add(this.label14);
            this.tabPage18.Controls.Add(this.textBox49);
            this.tabPage18.Controls.Add(this.label73);
            this.tabPage18.Controls.Add(this.label66);
            this.tabPage18.Controls.Add(this.label72);
            this.tabPage18.Controls.Add(this.textBox48);
            this.tabPage18.Controls.Add(this.label71);
            this.tabPage18.Controls.Add(this.txtReadData);
            this.tabPage18.Controls.Add(this.label17);
            this.tabPage18.Controls.Add(this.btnWriteR);
            this.tabPage18.Controls.Add(this.label11);
            this.tabPage18.Controls.Add(this.label10);
            this.tabPage18.Controls.Add(this.button5);
            this.tabPage18.Controls.Add(this.btnReadR);
            this.tabPage18.Controls.Add(this.label9);
            this.tabPage18.Controls.Add(this.label16);
            this.tabPage18.Controls.Add(this.btnWritePR);
            this.tabPage18.Controls.Add(this.txtReadPRX);
            this.tabPage18.Controls.Add(this.numWritePR3);
            this.tabPage18.Controls.Add(this.txtReadPRY);
            this.tabPage18.Controls.Add(this.label24);
            this.tabPage18.Controls.Add(this.label15);
            this.tabPage18.Controls.Add(this.numWritePR2);
            this.tabPage18.Controls.Add(this.txtReadPRZ);
            this.tabPage18.Controls.Add(this.numWritePR1);
            this.tabPage18.Location = new System.Drawing.Point(4, 31);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(664, 1402);
            this.tabPage18.TabIndex = 1;
            this.tabPage18.Text = "Robot";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(646, 1140);
            this.textBox52.Margin = new System.Windows.Forms.Padding(2);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(91, 28);
            this.textBox52.TabIndex = 15;
            this.textBox52.Visible = false;
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.button77);
            this.groupBox24.Controls.Add(this.tableLayoutPanel13);
            this.groupBox24.Location = new System.Drawing.Point(3, 547);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(411, 406);
            this.groupBox24.TabIndex = 130;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "NG buffer";
            // 
            // button77
            // 
            this.button77.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button77.Location = new System.Drawing.Point(265, 41);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(127, 46);
            this.button77.TabIndex = 25;
            this.button77.Text = "NG Rset";
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.myCheckBox3, 0, 2);
            this.tableLayoutPanel13.Controls.Add(this.myCheckBox1, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.myCheckBox2, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.myCheckBox4, 0, 3);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(6, 29);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 5;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(237, 325);
            this.tableLayoutPanel13.TabIndex = 0;
            // 
            // myCheckBox3
            // 
            this.myCheckBox3.Checked = false;
            this.myCheckBox3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.RecipeData, "RSet.NGbuffer3", true));
            this.myCheckBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.myCheckBox3.Location = new System.Drawing.Point(2, 142);
            this.myCheckBox3.Margin = new System.Windows.Forms.Padding(2);
            this.myCheckBox3.MaximumSize = new System.Drawing.Size(0, 55);
            this.myCheckBox3.MinimumSize = new System.Drawing.Size(55, 55);
            this.myCheckBox3.Name = "myCheckBox3";
            this.myCheckBox3.Size = new System.Drawing.Size(233, 55);
            this.myCheckBox3.TabIndex = 21;
            this.myCheckBox3.Text = "NG buffer3";
            // 
            // myCheckBox1
            // 
            this.myCheckBox1.Checked = false;
            this.myCheckBox1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.RecipeData, "RSet.NGbuffer1", true));
            this.myCheckBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.myCheckBox1.Location = new System.Drawing.Point(2, 2);
            this.myCheckBox1.Margin = new System.Windows.Forms.Padding(2);
            this.myCheckBox1.MaximumSize = new System.Drawing.Size(0, 55);
            this.myCheckBox1.MinimumSize = new System.Drawing.Size(55, 55);
            this.myCheckBox1.Name = "myCheckBox1";
            this.myCheckBox1.Size = new System.Drawing.Size(233, 55);
            this.myCheckBox1.TabIndex = 19;
            this.myCheckBox1.Text = "NG buffer1";
            // 
            // myCheckBox2
            // 
            this.myCheckBox2.Checked = false;
            this.myCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.RecipeData, "RSet.NGbuffer2", true));
            this.myCheckBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.myCheckBox2.Location = new System.Drawing.Point(2, 72);
            this.myCheckBox2.Margin = new System.Windows.Forms.Padding(2);
            this.myCheckBox2.MaximumSize = new System.Drawing.Size(0, 55);
            this.myCheckBox2.MinimumSize = new System.Drawing.Size(55, 55);
            this.myCheckBox2.Name = "myCheckBox2";
            this.myCheckBox2.Size = new System.Drawing.Size(233, 55);
            this.myCheckBox2.TabIndex = 20;
            this.myCheckBox2.Text = "NG buffer2";
            // 
            // myCheckBox4
            // 
            this.myCheckBox4.Checked = false;
            this.myCheckBox4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.RecipeData, "RSet.NGbuffer3", true));
            this.myCheckBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.myCheckBox4.Location = new System.Drawing.Point(2, 212);
            this.myCheckBox4.Margin = new System.Windows.Forms.Padding(2);
            this.myCheckBox4.MaximumSize = new System.Drawing.Size(0, 55);
            this.myCheckBox4.MinimumSize = new System.Drawing.Size(55, 55);
            this.myCheckBox4.Name = "myCheckBox4";
            this.myCheckBox4.Size = new System.Drawing.Size(233, 55);
            this.myCheckBox4.TabIndex = 22;
            this.myCheckBox4.Text = "NG buffer4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(518, 1146);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 24);
            this.label7.TabIndex = 14;
            this.label7.Text = "Command";
            this.label7.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.numericUpDown1);
            this.groupBox4.Controls.Add(this.ResetDischarge);
            this.groupBox4.Location = new System.Drawing.Point(3, 420);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(744, 85);
            this.groupBox4.TabIndex = 129;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Index ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "DischargingPosIndex:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.VacIndex", true));
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(217, 33);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            48,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(88, 35);
            this.numericUpDown1.TabIndex = 23;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // ResetDischarge
            // 
            this.ResetDischarge.Location = new System.Drawing.Point(341, 27);
            this.ResetDischarge.Name = "ResetDischarge";
            this.ResetDischarge.Size = new System.Drawing.Size(113, 46);
            this.ResetDischarge.TabIndex = 25;
            this.ResetDischarge.Text = "Reset";
            this.ResetDischarge.UseVisualStyleBackColor = true;
            this.ResetDischarge.Click += new System.EventHandler(this.ResetDischarge_Click_2);
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(248, 1143);
            this.textBox51.Margin = new System.Windows.Forms.Padding(2);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(91, 28);
            this.textBox51.TabIndex = 13;
            this.textBox51.Visible = false;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.groupBox11);
            this.groupBox16.Controls.Add(this.groupBox8);
            this.groupBox16.Controls.Add(this.textBox47);
            this.groupBox16.Controls.Add(this.label60);
            this.groupBox16.Controls.Add(this.label13);
            this.groupBox16.Controls.Add(this.btnConnectResult);
            this.groupBox16.Controls.Add(this.textBox1);
            this.groupBox16.Controls.Add(this.btnEnableRbt);
            this.groupBox16.Controls.Add(this.Btn_ConnectRobot);
            this.groupBox16.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox16.Location = new System.Drawing.Point(3, 3);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox16.Size = new System.Drawing.Size(658, 376);
            this.groupBox16.TabIndex = 9;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Robot Setting And Test Function";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button25);
            this.groupBox11.Controls.Add(this.num_maxFY);
            this.groupBox11.Controls.Add(this.num_maxFX);
            this.groupBox11.Controls.Add(this.num_minFY);
            this.groupBox11.Controls.Add(this.num_minFX);
            this.groupBox11.Controls.Add(this.label47);
            this.groupBox11.Controls.Add(this.label48);
            this.groupBox11.Controls.Add(this.label49);
            this.groupBox11.Controls.Add(this.label53);
            this.groupBox11.Location = new System.Drawing.Point(473, 102);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(433, 255);
            this.groupBox11.TabIndex = 10;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "FeederPos";
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(156, 183);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(204, 46);
            this.button25.TabIndex = 28;
            this.button25.Text = "Seting";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // num_maxFY
            // 
            this.num_maxFY.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.FeederMaxValueY", true));
            this.num_maxFY.DecimalPlaces = 3;
            this.num_maxFY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_maxFY.Location = new System.Drawing.Point(280, 127);
            this.num_maxFY.Margin = new System.Windows.Forms.Padding(2);
            this.num_maxFY.Maximum = new decimal(new int[] {
            680,
            0,
            0,
            0});
            this.num_maxFY.Name = "num_maxFY";
            this.num_maxFY.Size = new System.Drawing.Size(123, 35);
            this.num_maxFY.TabIndex = 27;
            this.num_maxFY.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // num_maxFX
            // 
            this.num_maxFX.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.FeederMaxValueX", true));
            this.num_maxFX.DecimalPlaces = 3;
            this.num_maxFX.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_maxFX.Location = new System.Drawing.Point(140, 127);
            this.num_maxFX.Margin = new System.Windows.Forms.Padding(2);
            this.num_maxFX.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.num_maxFX.Name = "num_maxFX";
            this.num_maxFX.Size = new System.Drawing.Size(123, 35);
            this.num_maxFX.TabIndex = 26;
            // 
            // num_minFY
            // 
            this.num_minFY.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.FeederMinValueY", true));
            this.num_minFY.DecimalPlaces = 3;
            this.num_minFY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_minFY.Location = new System.Drawing.Point(280, 72);
            this.num_minFY.Margin = new System.Windows.Forms.Padding(2);
            this.num_minFY.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.num_minFY.Minimum = new decimal(new int[] {
            450,
            0,
            0,
            -2147483648});
            this.num_minFY.Name = "num_minFY";
            this.num_minFY.Size = new System.Drawing.Size(123, 35);
            this.num_minFY.TabIndex = 25;
            // 
            // num_minFX
            // 
            this.num_minFX.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.FeederMinValueX", true));
            this.num_minFX.DecimalPlaces = 3;
            this.num_minFX.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_minFX.Location = new System.Drawing.Point(140, 72);
            this.num_minFX.Margin = new System.Windows.Forms.Padding(2);
            this.num_minFX.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.num_minFX.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.num_minFX.Name = "num_minFX";
            this.num_minFX.Size = new System.Drawing.Size(123, 35);
            this.num_minFX.TabIndex = 24;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(297, 33);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(63, 24);
            this.label47.TabIndex = 17;
            this.label47.Text = "Y Axis";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(152, 33);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(65, 24);
            this.label48.TabIndex = 16;
            this.label48.Text = "X Axis";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(13, 79);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(90, 24);
            this.label49.TabIndex = 10;
            this.label49.Text = "MinValue";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(8, 134);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(95, 24);
            this.label53.TabIndex = 11;
            this.label53.Text = "MaxValue";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.button11);
            this.groupBox8.Controls.Add(this.num_maxPY);
            this.groupBox8.Controls.Add(this.num_maxPX);
            this.groupBox8.Controls.Add(this.num_minPY);
            this.groupBox8.Controls.Add(this.num_minPX);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.label19);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Location = new System.Drawing.Point(27, 102);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(433, 255);
            this.groupBox8.TabIndex = 9;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "PalletPos";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(156, 183);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(204, 46);
            this.button11.TabIndex = 28;
            this.button11.Text = "Seting";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // num_maxPY
            // 
            this.num_maxPY.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.PalletMaxValueY", true));
            this.num_maxPY.DecimalPlaces = 3;
            this.num_maxPY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_maxPY.Location = new System.Drawing.Point(265, 127);
            this.num_maxPY.Margin = new System.Windows.Forms.Padding(2);
            this.num_maxPY.Maximum = new decimal(new int[] {
            680,
            0,
            0,
            0});
            this.num_maxPY.Name = "num_maxPY";
            this.num_maxPY.Size = new System.Drawing.Size(119, 35);
            this.num_maxPY.TabIndex = 27;
            this.num_maxPY.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_maxPY.ValueChanged += new System.EventHandler(this.num_maxFY_ValueChanged);
            // 
            // num_maxPX
            // 
            this.num_maxPX.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.PalletMaxValueX", true));
            this.num_maxPX.DecimalPlaces = 3;
            this.num_maxPX.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_maxPX.Location = new System.Drawing.Point(125, 127);
            this.num_maxPX.Margin = new System.Windows.Forms.Padding(2);
            this.num_maxPX.Maximum = new decimal(new int[] {
            660,
            0,
            0,
            0});
            this.num_maxPX.Name = "num_maxPX";
            this.num_maxPX.Size = new System.Drawing.Size(119, 35);
            this.num_maxPX.TabIndex = 26;
            // 
            // num_minPY
            // 
            this.num_minPY.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.PalletMinValueY", true));
            this.num_minPY.DecimalPlaces = 3;
            this.num_minPY.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_minPY.Location = new System.Drawing.Point(265, 72);
            this.num_minPY.Margin = new System.Windows.Forms.Padding(2);
            this.num_minPY.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.num_minPY.Minimum = new decimal(new int[] {
            450,
            0,
            0,
            -2147483648});
            this.num_minPY.Name = "num_minPY";
            this.num_minPY.Size = new System.Drawing.Size(119, 35);
            this.num_minPY.TabIndex = 25;
            // 
            // num_minPX
            // 
            this.num_minPX.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.PalletMinValueX", true));
            this.num_minPX.DecimalPlaces = 3;
            this.num_minPX.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_minPX.Location = new System.Drawing.Point(125, 72);
            this.num_minPX.Margin = new System.Windows.Forms.Padding(2);
            this.num_minPX.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.num_minPX.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.num_minPX.Name = "num_minPX";
            this.num_minPX.Size = new System.Drawing.Size(119, 35);
            this.num_minPX.TabIndex = 24;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(297, 33);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(63, 24);
            this.label46.TabIndex = 17;
            this.label46.Text = "Y Axis";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(152, 33);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(65, 24);
            this.label45.TabIndex = 16;
            this.label45.Text = "X Axis";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 79);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 24);
            this.label19.TabIndex = 10;
            this.label19.Text = "MinValue";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(8, 134);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(95, 24);
            this.label44.TabIndex = 11;
            this.label44.Text = "MaxValue";
            // 
            // textBox47
            // 
            this.textBox47.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.RobotPort", true));
            this.textBox47.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox47.Location = new System.Drawing.Point(142, 69);
            this.textBox47.Margin = new System.Windows.Forms.Padding(2);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(180, 28);
            this.textBox47.TabIndex = 8;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(24, 69);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(93, 24);
            this.label60.TabIndex = 7;
            this.label60.Text = "RobotPort";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(24, 33);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 24);
            this.label13.TabIndex = 0;
            this.label13.Text = "RobotIP";
            // 
            // btnConnectResult
            // 
            this.btnConnectResult.Enabled = false;
            this.btnConnectResult.Location = new System.Drawing.Point(376, 62);
            this.btnConnectResult.Margin = new System.Windows.Forms.Padding(2);
            this.btnConnectResult.Name = "btnConnectResult";
            this.btnConnectResult.Size = new System.Drawing.Size(222, 33);
            this.btnConnectResult.TabIndex = 6;
            this.btnConnectResult.Text = "ConncetStatus";
            this.btnConnectResult.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.RobotPoint1", true));
            this.textBox1.Location = new System.Drawing.Point(142, 33);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(180, 28);
            this.textBox1.TabIndex = 1;
            // 
            // btnEnableRbt
            // 
            this.btnEnableRbt.Location = new System.Drawing.Point(602, 23);
            this.btnEnableRbt.Margin = new System.Windows.Forms.Padding(2);
            this.btnEnableRbt.Name = "btnEnableRbt";
            this.btnEnableRbt.Size = new System.Drawing.Size(222, 33);
            this.btnEnableRbt.TabIndex = 2;
            this.btnEnableRbt.Text = "EnableRobot";
            this.btnEnableRbt.UseVisualStyleBackColor = true;
            this.btnEnableRbt.Click += new System.EventHandler(this.btnEnableRbt_Click);
            // 
            // Btn_ConnectRobot
            // 
            this.Btn_ConnectRobot.Location = new System.Drawing.Point(376, 23);
            this.Btn_ConnectRobot.Margin = new System.Windows.Forms.Padding(2);
            this.Btn_ConnectRobot.Name = "Btn_ConnectRobot";
            this.Btn_ConnectRobot.Size = new System.Drawing.Size(222, 33);
            this.Btn_ConnectRobot.TabIndex = 2;
            this.Btn_ConnectRobot.Text = "ConnectRobot";
            this.Btn_ConnectRobot.UseVisualStyleBackColor = true;
            this.Btn_ConnectRobot.Click += new System.EventHandler(this.Btn_ConnectRobot_Click);
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(643, 1099);
            this.textBox50.Margin = new System.Windows.Forms.Padding(2);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(91, 28);
            this.textBox50.TabIndex = 12;
            this.textBox50.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(118, 1073);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 24);
            this.label14.TabIndex = 0;
            this.label14.Text = "Command";
            this.label14.Visible = false;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(643, 1065);
            this.textBox49.Margin = new System.Windows.Forms.Padding(2);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(91, 28);
            this.textBox49.TabIndex = 11;
            this.textBox49.Visible = false;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(518, 1242);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(72, 24);
            this.label73.TabIndex = 0;
            this.label73.Text = "UValue";
            this.label73.Visible = false;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(524, 1073);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(98, 24);
            this.label66.TabIndex = 10;
            this.label66.Text = "Command";
            this.label66.Visible = false;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(518, 1205);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(71, 24);
            this.label72.TabIndex = 0;
            this.label72.Text = "YValue";
            this.label72.Visible = false;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(250, 1068);
            this.textBox48.Margin = new System.Windows.Forms.Padding(2);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(91, 28);
            this.textBox48.TabIndex = 9;
            this.textBox48.Visible = false;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(518, 1177);
            this.label71.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(73, 24);
            this.label71.TabIndex = 0;
            this.label71.Text = "XValue";
            this.label71.Visible = false;
            // 
            // txtReadData
            // 
            this.txtReadData.Location = new System.Drawing.Point(250, 1101);
            this.txtReadData.Margin = new System.Windows.Forms.Padding(2);
            this.txtReadData.Name = "txtReadData";
            this.txtReadData.Size = new System.Drawing.Size(91, 28);
            this.txtReadData.TabIndex = 4;
            this.txtReadData.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(124, 1146);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 24);
            this.label17.TabIndex = 0;
            this.label17.Text = "Command";
            this.label17.Visible = false;
            // 
            // btnWriteR
            // 
            this.btnWriteR.Location = new System.Drawing.Point(756, 1068);
            this.btnWriteR.Margin = new System.Windows.Forms.Padding(2);
            this.btnWriteR.Name = "btnWriteR";
            this.btnWriteR.Size = new System.Drawing.Size(153, 33);
            this.btnWriteR.TabIndex = 2;
            this.btnWriteR.Text = "WriteRobotR";
            this.btnWriteR.UseVisualStyleBackColor = true;
            this.btnWriteR.Visible = false;
            this.btnWriteR.Click += new System.EventHandler(this.btnWriteR_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(124, 1177);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "XValue";
            this.label11.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(124, 1205);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 24);
            this.label10.TabIndex = 0;
            this.label10.Text = "YValue";
            this.label10.Visible = false;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(756, 1146);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(152, 33);
            this.button5.TabIndex = 2;
            this.button5.Text = "ReadRobotXYU";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnReadR
            // 
            this.btnReadR.Location = new System.Drawing.Point(360, 1073);
            this.btnReadR.Margin = new System.Windows.Forms.Padding(2);
            this.btnReadR.Name = "btnReadR";
            this.btnReadR.Size = new System.Drawing.Size(153, 33);
            this.btnReadR.TabIndex = 2;
            this.btnReadR.Text = "ReadRobotR";
            this.btnReadR.UseVisualStyleBackColor = true;
            this.btnReadR.Visible = false;
            this.btnReadR.Click += new System.EventHandler(this.btnReadR_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(124, 1242);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "UValue";
            this.label9.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(524, 1104);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 24);
            this.label16.TabIndex = 0;
            this.label16.Text = "Value";
            this.label16.Visible = false;
            // 
            // btnWritePR
            // 
            this.btnWritePR.Location = new System.Drawing.Point(362, 1146);
            this.btnWritePR.Margin = new System.Windows.Forms.Padding(2);
            this.btnWritePR.Name = "btnWritePR";
            this.btnWritePR.Size = new System.Drawing.Size(152, 33);
            this.btnWritePR.TabIndex = 2;
            this.btnWritePR.Text = "WriteRobotXYU";
            this.btnWritePR.UseVisualStyleBackColor = true;
            this.btnWritePR.Visible = false;
            this.btnWritePR.Click += new System.EventHandler(this.btnWritePR_Click);
            // 
            // txtReadPRX
            // 
            this.txtReadPRX.Location = new System.Drawing.Point(646, 1177);
            this.txtReadPRX.Margin = new System.Windows.Forms.Padding(2);
            this.txtReadPRX.Name = "txtReadPRX";
            this.txtReadPRX.Size = new System.Drawing.Size(91, 28);
            this.txtReadPRX.TabIndex = 4;
            this.txtReadPRX.Visible = false;
            // 
            // numWritePR3
            // 
            this.numWritePR3.DecimalPlaces = 3;
            this.numWritePR3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numWritePR3.Location = new System.Drawing.Point(248, 1242);
            this.numWritePR3.Margin = new System.Windows.Forms.Padding(2);
            this.numWritePR3.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numWritePR3.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numWritePR3.Name = "numWritePR3";
            this.numWritePR3.Size = new System.Drawing.Size(88, 28);
            this.numWritePR3.TabIndex = 3;
            this.numWritePR3.Visible = false;
            // 
            // txtReadPRY
            // 
            this.txtReadPRY.Location = new System.Drawing.Point(646, 1204);
            this.txtReadPRY.Margin = new System.Windows.Forms.Padding(2);
            this.txtReadPRY.Name = "txtReadPRY";
            this.txtReadPRY.Size = new System.Drawing.Size(91, 28);
            this.txtReadPRY.TabIndex = 4;
            this.txtReadPRY.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(126, 1106);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 24);
            this.label24.TabIndex = 0;
            this.label24.Text = "Value";
            this.label24.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(518, 1068);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 24);
            this.label15.TabIndex = 0;
            this.label15.Visible = false;
            // 
            // numWritePR2
            // 
            this.numWritePR2.DecimalPlaces = 3;
            this.numWritePR2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numWritePR2.Location = new System.Drawing.Point(248, 1205);
            this.numWritePR2.Margin = new System.Windows.Forms.Padding(2);
            this.numWritePR2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numWritePR2.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numWritePR2.Name = "numWritePR2";
            this.numWritePR2.Size = new System.Drawing.Size(88, 28);
            this.numWritePR2.TabIndex = 3;
            this.numWritePR2.Visible = false;
            // 
            // txtReadPRZ
            // 
            this.txtReadPRZ.Location = new System.Drawing.Point(646, 1234);
            this.txtReadPRZ.Margin = new System.Windows.Forms.Padding(2);
            this.txtReadPRZ.Name = "txtReadPRZ";
            this.txtReadPRZ.Size = new System.Drawing.Size(91, 28);
            this.txtReadPRZ.TabIndex = 4;
            this.txtReadPRZ.Visible = false;
            // 
            // numWritePR1
            // 
            this.numWritePR1.DecimalPlaces = 3;
            this.numWritePR1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numWritePR1.Location = new System.Drawing.Point(248, 1177);
            this.numWritePR1.Margin = new System.Windows.Forms.Padding(2);
            this.numWritePR1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numWritePR1.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.numWritePR1.Name = "numWritePR1";
            this.numWritePR1.Size = new System.Drawing.Size(88, 28);
            this.numWritePR1.TabIndex = 3;
            this.numWritePR1.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(378, 1141);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(138, 33);
            this.button2.TabIndex = 15;
            this.button2.Text = "Set pick vacant";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txt_PickPos
            // 
            this.txt_PickPos.Location = new System.Drawing.Point(270, 1143);
            this.txt_PickPos.Margin = new System.Windows.Forms.Padding(2);
            this.txt_PickPos.Name = "txt_PickPos";
            this.txt_PickPos.Size = new System.Drawing.Size(88, 28);
            this.txt_PickPos.TabIndex = 14;
            this.txt_PickPos.Text = "1";
            this.txt_PickPos.Visible = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(69, 1145);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(181, 24);
            this.label36.TabIndex = 13;
            this.label36.Text = "Current fetch vacant:";
            this.label36.Visible = false;
            // 
            // tabControl7
            // 
            this.tabControl7.Controls.Add(this.tabPage18);
            this.tabControl7.Controls.Add(this.tabPage11);
            this.tabControl7.Controls.Add(this.tabPage2);
            this.tabControl7.Controls.Add(this.tabPage9);
            this.tabControl7.Controls.Add(this.tabPage12);
            this.tabControl7.Controls.Add(this.tabPage17);
            this.tabControl7.Controls.Add(this.tabPage1);
            this.tabControl7.Controls.Add(this.tabPage6);
            this.tabControl7.Controls.Add(this.tabPage4);
            this.tabControl7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl7.Location = new System.Drawing.Point(0, 0);
            this.tabControl7.Name = "tabControl7";
            this.tabControl7.SelectedIndex = 0;
            this.tabControl7.Size = new System.Drawing.Size(672, 1437);
            this.tabControl7.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel7);
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(664, 1402);
            this.tabPage1.TabIndex = 14;
            this.tabPage1.Text = "R1_Discharge2Vision";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.32127F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.67873F));
            this.tableLayoutPanel7.Controls.Add(this.tableLayoutPanel27, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.tabControl5, 1, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(664, 1402);
            this.tableLayoutPanel7.TabIndex = 3;
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 1;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Controls.Add(this.tableLayoutPanel28, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.tableLayoutPanel30, 0, 1);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 2;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(441, 1396);
            this.tableLayoutPanel27.TabIndex = 16;
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 2;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel28.Controls.Add(this.dataGridView2, 0, 0);
            this.tableLayoutPanel28.Controls.Add(this.tableLayoutPanel29, 1, 0);
            this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 1;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(435, 831);
            this.tableLayoutPanel28.TabIndex = 15;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.DataSource = this.RecipeData;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(2, 2);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 20;
            this.dataGridView2.RowTemplate.Height = 27;
            this.dataGridView2.Size = new System.Drawing.Size(344, 827);
            this.dataGridView2.TabIndex = 16;
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 1;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel29.Controls.Add(this.button12, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.button15, 0, 1);
            this.tableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(351, 3);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 2;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(81, 825);
            this.tableLayoutPanel29.TabIndex = 15;
            // 
            // button12
            // 
            this.button12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button12.Location = new System.Drawing.Point(2, 2);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(77, 408);
            this.button12.TabIndex = 0;
            this.button12.Text = "Algorithm editing";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button15
            // 
            this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button15.Location = new System.Drawing.Point(2, 414);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(77, 409);
            this.button15.TabIndex = 1;
            this.button15.Text = "Calibration";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click_1);
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.ColumnCount = 4;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.1369F));
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.58931F));
            this.tableLayoutPanel30.Controls.Add(this.textBox34, 0, 6);
            this.tableLayoutPanel30.Controls.Add(this.textBox35, 0, 5);
            this.tableLayoutPanel30.Controls.Add(this.textBox36, 0, 6);
            this.tableLayoutPanel30.Controls.Add(this.textBox37, 0, 4);
            this.tableLayoutPanel30.Controls.Add(this.textBox38, 0, 4);
            this.tableLayoutPanel30.Controls.Add(this.textBox39, 0, 4);
            this.tableLayoutPanel30.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel30.Controls.Add(this.label8, 1, 0);
            this.tableLayoutPanel30.Controls.Add(this.textBox40, 0, 1);
            this.tableLayoutPanel30.Controls.Add(this.textBox41, 1, 1);
            this.tableLayoutPanel30.Controls.Add(this.button16, 3, 1);
            this.tableLayoutPanel30.Controls.Add(this.textBox42, 0, 2);
            this.tableLayoutPanel30.Controls.Add(this.textBox43, 1, 2);
            this.tableLayoutPanel30.Controls.Add(this.textBox44, 2, 2);
            this.tableLayoutPanel30.Controls.Add(this.button17, 3, 2);
            this.tableLayoutPanel30.Controls.Add(this.textBox45, 2, 1);
            this.tableLayoutPanel30.Controls.Add(this.label37, 0, 0);
            this.tableLayoutPanel30.Controls.Add(this.button18, 3, 4);
            this.tableLayoutPanel30.Controls.Add(this.textBox55, 0, 3);
            this.tableLayoutPanel30.Controls.Add(this.textBox56, 2, 3);
            this.tableLayoutPanel30.Controls.Add(this.textBox57, 1, 3);
            this.tableLayoutPanel30.Controls.Add(this.button19, 3, 3);
            this.tableLayoutPanel30.Controls.Add(this.textBox58, 1, 5);
            this.tableLayoutPanel30.Controls.Add(this.textBox59, 2, 5);
            this.tableLayoutPanel30.Controls.Add(this.textBox60, 2, 6);
            this.tableLayoutPanel30.Controls.Add(this.button20, 3, 5);
            this.tableLayoutPanel30.Controls.Add(this.button22, 3, 6);
            this.tableLayoutPanel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 840);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 7;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(435, 553);
            this.tableLayoutPanel30.TabIndex = 16;
            // 
            // textBox34
            // 
            this.textBox34.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox34.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotY3", true));
            this.textBox34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox34.Location = new System.Drawing.Point(98, 470);
            this.textBox34.Margin = new System.Windows.Forms.Padding(2);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(92, 28);
            this.textBox34.TabIndex = 19;
            this.textBox34.Text = "NULL";
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            this.textBox35.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox35.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisX3", true));
            this.textBox35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox35.Location = new System.Drawing.Point(2, 392);
            this.textBox35.Margin = new System.Windows.Forms.Padding(2);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(92, 28);
            this.textBox35.TabIndex = 18;
            this.textBox35.Text = "NULL";
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox36
            // 
            this.textBox36.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox36.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotX3", true));
            this.textBox36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox36.Location = new System.Drawing.Point(2, 470);
            this.textBox36.Margin = new System.Windows.Forms.Padding(2);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(92, 28);
            this.textBox36.TabIndex = 16;
            this.textBox36.Text = "NULL";
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox37.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotU2", true));
            this.textBox37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox37.Location = new System.Drawing.Point(194, 314);
            this.textBox37.Margin = new System.Windows.Forms.Padding(2);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(92, 28);
            this.textBox37.TabIndex = 14;
            this.textBox37.Text = "NUll";
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox38
            // 
            this.textBox38.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox38.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotY2", true));
            this.textBox38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox38.Location = new System.Drawing.Point(98, 314);
            this.textBox38.Margin = new System.Windows.Forms.Padding(2);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(92, 28);
            this.textBox38.TabIndex = 13;
            this.textBox38.Text = "NULL";
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox39.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotX2", true));
            this.textBox39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox39.Location = new System.Drawing.Point(2, 314);
            this.textBox39.Margin = new System.Windows.Forms.Padding(2);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(92, 28);
            this.textBox39.TabIndex = 12;
            this.textBox39.Text = "NULL";
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(228, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 24);
            this.label2.TabIndex = 11;
            this.label2.Text = "U";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.UseMnemonic = false;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(133, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 24);
            this.label8.TabIndex = 10;
            this.label8.Text = "Y";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.UseMnemonic = false;
            // 
            // textBox40
            // 
            this.textBox40.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox40.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisX", true));
            this.textBox40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox40.Location = new System.Drawing.Point(2, 80);
            this.textBox40.Margin = new System.Windows.Forms.Padding(2);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(92, 28);
            this.textBox40.TabIndex = 4;
            this.textBox40.Text = "NULL";
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox41
            // 
            this.textBox41.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox41.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisY", true));
            this.textBox41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox41.Location = new System.Drawing.Point(98, 80);
            this.textBox41.Margin = new System.Windows.Forms.Padding(2);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(92, 28);
            this.textBox41.TabIndex = 6;
            this.textBox41.Text = "NULL";
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button16
            // 
            this.button16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(290, 80);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(143, 74);
            this.button16.TabIndex = 1;
            this.button16.Text = "Teaching visual position (grapper1)";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click_1);
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox42.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotX", true));
            this.textBox42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox42.Location = new System.Drawing.Point(2, 158);
            this.textBox42.Margin = new System.Windows.Forms.Padding(2);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(92, 28);
            this.textBox42.TabIndex = 4;
            this.textBox42.Text = "NULL";
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox43
            // 
            this.textBox43.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox43.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotY", true));
            this.textBox43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox43.Location = new System.Drawing.Point(98, 158);
            this.textBox43.Margin = new System.Windows.Forms.Padding(2);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(92, 28);
            this.textBox43.TabIndex = 6;
            this.textBox43.Text = "NULL";
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox44.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotU", true));
            this.textBox44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox44.Location = new System.Drawing.Point(194, 158);
            this.textBox44.Margin = new System.Windows.Forms.Padding(2);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(92, 28);
            this.textBox44.TabIndex = 8;
            this.textBox44.Text = "NUll";
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button17
            // 
            this.button17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(290, 158);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(143, 74);
            this.button17.TabIndex = 1;
            this.button17.Text = "Teaching robot position G1";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click_1);
            // 
            // textBox45
            // 
            this.textBox45.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox45.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisU", true));
            this.textBox45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox45.Location = new System.Drawing.Point(194, 80);
            this.textBox45.Margin = new System.Windows.Forms.Padding(2);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(92, 28);
            this.textBox45.TabIndex = 8;
            this.textBox45.Text = "NUll";
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(36, 27);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(24, 24);
            this.label37.TabIndex = 9;
            this.label37.Text = "X";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label37.UseMnemonic = false;
            // 
            // button18
            // 
            this.button18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(290, 314);
            this.button18.Margin = new System.Windows.Forms.Padding(2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(143, 74);
            this.button18.TabIndex = 15;
            this.button18.Text = "Teaching robot position G2";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click_1);
            // 
            // textBox55
            // 
            this.textBox55.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox55.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisX2", true));
            this.textBox55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox55.Location = new System.Drawing.Point(2, 236);
            this.textBox55.Margin = new System.Windows.Forms.Padding(2);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(92, 28);
            this.textBox55.TabIndex = 4;
            this.textBox55.Text = "NULL";
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox56
            // 
            this.textBox56.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox56.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisU2", true));
            this.textBox56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox56.Location = new System.Drawing.Point(194, 236);
            this.textBox56.Margin = new System.Windows.Forms.Padding(2);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(92, 28);
            this.textBox56.TabIndex = 4;
            this.textBox56.Text = "NULL";
            this.textBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox57
            // 
            this.textBox57.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox57.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisY2", true));
            this.textBox57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox57.Location = new System.Drawing.Point(98, 236);
            this.textBox57.Margin = new System.Windows.Forms.Padding(2);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(92, 28);
            this.textBox57.TabIndex = 4;
            this.textBox57.Text = "NULL";
            this.textBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button19
            // 
            this.button19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(290, 236);
            this.button19.Margin = new System.Windows.Forms.Padding(2);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(143, 74);
            this.button19.TabIndex = 1;
            this.button19.Text = "Teaching visual position (grapper2)";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // textBox58
            // 
            this.textBox58.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox58.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisY3", true));
            this.textBox58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox58.Location = new System.Drawing.Point(98, 392);
            this.textBox58.Margin = new System.Windows.Forms.Padding(2);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(92, 28);
            this.textBox58.TabIndex = 17;
            this.textBox58.Text = "NULL";
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox59
            // 
            this.textBox59.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox59.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachVisU3", true));
            this.textBox59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox59.Location = new System.Drawing.Point(194, 392);
            this.textBox59.Margin = new System.Windows.Forms.Padding(2);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(92, 28);
            this.textBox59.TabIndex = 17;
            this.textBox59.Text = "NULL";
            this.textBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox60
            // 
            this.textBox60.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox60.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.Discharge2TeachRobotU3", true));
            this.textBox60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox60.Location = new System.Drawing.Point(194, 470);
            this.textBox60.Margin = new System.Windows.Forms.Padding(2);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(92, 28);
            this.textBox60.TabIndex = 17;
            this.textBox60.Text = "NULL";
            this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button20
            // 
            this.button20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(290, 392);
            this.button20.Margin = new System.Windows.Forms.Padding(2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(143, 74);
            this.button20.TabIndex = 15;
            this.button20.Text = "Teaching visual position (grapper3)";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button22
            // 
            this.button22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(290, 470);
            this.button22.Margin = new System.Windows.Forms.Padding(2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(143, 81);
            this.button22.TabIndex = 15;
            this.button22.Text = "Teaching robot position G3";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage3);
            this.tabControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl5.Location = new System.Drawing.Point(450, 3);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(211, 1396);
            this.tabControl5.TabIndex = 17;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.flowChart4);
            this.tabPage3.Controls.Add(this.flowChart5);
            this.tabPage3.Controls.Add(this.flowChart46);
            this.tabPage3.Controls.Add(this.flowChart30);
            this.tabPage3.Controls.Add(this.flowChart6);
            this.tabPage3.Controls.Add(this.flowChart47);
            this.tabPage3.Controls.Add(this.flowChart48);
            this.tabPage3.Controls.Add(this.flowChart49);
            this.tabPage3.Location = new System.Drawing.Point(4, 31);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(203, 1361);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "Auto calibration";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // flowChart4
            // 
            this.flowChart4.AlarmCode = "";
            this.flowChart4.ArrowSeparation = 20;
            this.flowChart4.ArrowsWidth = 1;
            this.flowChart4.BackColor = System.Drawing.Color.White;
            this.flowChart4.bClearTrace = false;
            this.flowChart4.bIsLastFlowChart = false;
            this.flowChart4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart4.bSkip = false;
            this.flowChart4.bStepByStepMode = false;
            this.flowChart4.CASE1 = null;
            this.flowChart4.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart4.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart4.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.CASE2 = null;
            this.flowChart4.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart4.CASE2Color = System.Drawing.Color.Red;
            this.flowChart4.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.CASE3 = null;
            this.flowChart4.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart4.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart4.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.DefaultColor = System.Drawing.Color.White;
            this.flowChart4.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart4.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart4.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart4.Location = new System.Drawing.Point(212, 134);
            this.flowChart4.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart4.menuOpening = false;
            this.flowChart4.Name = "flowChart4";
            this.flowChart4.NEXT = null;
            this.flowChart4.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart4.NEXTColor = System.Drawing.Color.Black;
            this.flowChart4.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart4.Size = new System.Drawing.Size(86, 35);
            this.flowChart4.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart4.SubFlowChart = null;
            this.flowChart4.TabIndex = 55;
            this.flowChart4.Text = "Calibrate";
            this.flowChart4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart4.TimeOut = 10000;
            this.flowChart4.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart4.tmrTimeOut = null;
            this.flowChart4.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart4_FlowRun_1);
            // 
            // flowChart5
            // 
            this.flowChart5.AlarmCode = "";
            this.flowChart5.ArrowSeparation = 20;
            this.flowChart5.ArrowsWidth = 1;
            this.flowChart5.BackColor = System.Drawing.Color.White;
            this.flowChart5.bClearTrace = false;
            this.flowChart5.bIsLastFlowChart = false;
            this.flowChart5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart5.bSkip = false;
            this.flowChart5.bStepByStepMode = false;
            this.flowChart5.CASE1 = this.flowChart4;
            this.flowChart5.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart5.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart5.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.CASE2 = null;
            this.flowChart5.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart5.CASE2Color = System.Drawing.Color.Red;
            this.flowChart5.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.CASE3 = null;
            this.flowChart5.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart5.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart5.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.DefaultColor = System.Drawing.Color.White;
            this.flowChart5.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart5.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart5.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart5.Location = new System.Drawing.Point(222, 197);
            this.flowChart5.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart5.menuOpening = false;
            this.flowChart5.Name = "flowChart5";
            this.flowChart5.NEXT = this.flowChart6;
            this.flowChart5.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart5.NEXTColor = System.Drawing.Color.Black;
            this.flowChart5.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart5.Size = new System.Drawing.Size(66, 122);
            this.flowChart5.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart5.SubFlowChart = null;
            this.flowChart5.TabIndex = 54;
            this.flowChart5.Text = "Judge Loop Times";
            this.flowChart5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart5.TimeOut = 10000;
            this.flowChart5.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart5.tmrTimeOut = null;
            this.flowChart5.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart5_FlowRun_1);
            // 
            // flowChart6
            // 
            this.flowChart6.AlarmCode = "";
            this.flowChart6.ArrowSeparation = 20;
            this.flowChart6.ArrowsWidth = 1;
            this.flowChart6.BackColor = System.Drawing.Color.White;
            this.flowChart6.bClearTrace = false;
            this.flowChart6.bIsLastFlowChart = false;
            this.flowChart6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart6.bSkip = false;
            this.flowChart6.bStepByStepMode = false;
            this.flowChart6.CASE1 = null;
            this.flowChart6.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart6.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart6.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.CASE2 = null;
            this.flowChart6.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart6.CASE2Color = System.Drawing.Color.Red;
            this.flowChart6.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.CASE3 = null;
            this.flowChart6.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart6.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart6.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.DefaultColor = System.Drawing.Color.White;
            this.flowChart6.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart6.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart6.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart6.Location = new System.Drawing.Point(11, 184);
            this.flowChart6.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart6.menuOpening = false;
            this.flowChart6.Name = "flowChart6";
            this.flowChart6.NEXT = this.flowChart30;
            this.flowChart6.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart6.NEXTColor = System.Drawing.Color.Black;
            this.flowChart6.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart6.Size = new System.Drawing.Size(178, 35);
            this.flowChart6.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart6.SubFlowChart = null;
            this.flowChart6.TabIndex = 48;
            this.flowChart6.Text = "R1 to picture pos1";
            this.flowChart6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart6.TimeOut = 10000;
            this.flowChart6.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart6.tmrTimeOut = null;
            this.flowChart6.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart6_FlowRun_1);
            // 
            // flowChart30
            // 
            this.flowChart30.AlarmCode = "";
            this.flowChart30.ArrowSeparation = 20;
            this.flowChart30.ArrowsWidth = 1;
            this.flowChart30.BackColor = System.Drawing.Color.White;
            this.flowChart30.bClearTrace = false;
            this.flowChart30.bIsLastFlowChart = false;
            this.flowChart30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart30.bSkip = false;
            this.flowChart30.bStepByStepMode = false;
            this.flowChart30.CASE1 = null;
            this.flowChart30.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart30.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart30.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.CASE2 = null;
            this.flowChart30.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart30.CASE2Color = System.Drawing.Color.Red;
            this.flowChart30.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.CASE3 = null;
            this.flowChart30.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart30.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart30.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.DefaultColor = System.Drawing.Color.White;
            this.flowChart30.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart30.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart30.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart30.Location = new System.Drawing.Point(11, 241);
            this.flowChart30.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart30.menuOpening = false;
            this.flowChart30.Name = "flowChart30";
            this.flowChart30.NEXT = this.flowChart46;
            this.flowChart30.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart30.NEXTColor = System.Drawing.Color.Black;
            this.flowChart30.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart30.Size = new System.Drawing.Size(178, 35);
            this.flowChart30.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart30.SubFlowChart = null;
            this.flowChart30.TabIndex = 49;
            this.flowChart30.Text = "Wait R1  arrive pos";
            this.flowChart30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart30.TimeOut = 10000;
            this.flowChart30.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart30.tmrTimeOut = null;
            this.flowChart30.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart30_FlowRun_1);
            // 
            // flowChart46
            // 
            this.flowChart46.AlarmCode = "";
            this.flowChart46.ArrowSeparation = 20;
            this.flowChart46.ArrowsWidth = 1;
            this.flowChart46.BackColor = System.Drawing.Color.White;
            this.flowChart46.bClearTrace = false;
            this.flowChart46.bIsLastFlowChart = false;
            this.flowChart46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart46.bSkip = false;
            this.flowChart46.bStepByStepMode = false;
            this.flowChart46.CASE1 = null;
            this.flowChart46.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart46.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart46.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.CASE2 = null;
            this.flowChart46.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart46.CASE2Color = System.Drawing.Color.Red;
            this.flowChart46.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.CASE3 = null;
            this.flowChart46.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart46.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart46.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.DefaultColor = System.Drawing.Color.White;
            this.flowChart46.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart46.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart46.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart46.Location = new System.Drawing.Point(11, 288);
            this.flowChart46.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart46.menuOpening = false;
            this.flowChart46.Name = "flowChart46";
            this.flowChart46.NEXT = this.flowChart5;
            this.flowChart46.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart46.NEXTColor = System.Drawing.Color.Black;
            this.flowChart46.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart46.Size = new System.Drawing.Size(178, 35);
            this.flowChart46.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart46.SubFlowChart = null;
            this.flowChart46.TabIndex = 50;
            this.flowChart46.Text = "R1 Goto picture";
            this.flowChart46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart46.TimeOut = 10000;
            this.flowChart46.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart46.tmrTimeOut = null;
            this.flowChart46.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart46_FlowRun);
            // 
            // flowChart47
            // 
            this.flowChart47.AlarmCode = "";
            this.flowChart47.ArrowSeparation = 20;
            this.flowChart47.ArrowsWidth = 1;
            this.flowChart47.BackColor = System.Drawing.Color.White;
            this.flowChart47.bClearTrace = false;
            this.flowChart47.bIsLastFlowChart = false;
            this.flowChart47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart47.bSkip = false;
            this.flowChart47.bStepByStepMode = false;
            this.flowChart47.CASE1 = null;
            this.flowChart47.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart47.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart47.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.CASE2 = null;
            this.flowChart47.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart47.CASE2Color = System.Drawing.Color.Red;
            this.flowChart47.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.CASE3 = null;
            this.flowChart47.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart47.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart47.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.DefaultColor = System.Drawing.Color.White;
            this.flowChart47.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart47.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart47.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart47.Location = new System.Drawing.Point(11, 134);
            this.flowChart47.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart47.menuOpening = false;
            this.flowChart47.Name = "flowChart47";
            this.flowChart47.NEXT = this.flowChart6;
            this.flowChart47.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart47.NEXTColor = System.Drawing.Color.Black;
            this.flowChart47.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart47.Size = new System.Drawing.Size(178, 35);
            this.flowChart47.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart47.SubFlowChart = null;
            this.flowChart47.TabIndex = 47;
            this.flowChart47.Text = "Start Robot work";
            this.flowChart47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart47.TimeOut = 10000;
            this.flowChart47.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart47.tmrTimeOut = null;
            this.flowChart47.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart47_FlowRun);
            // 
            // flowChart48
            // 
            this.flowChart48.AlarmCode = "";
            this.flowChart48.ArrowSeparation = 20;
            this.flowChart48.ArrowsWidth = 1;
            this.flowChart48.BackColor = System.Drawing.Color.White;
            this.flowChart48.bClearTrace = false;
            this.flowChart48.bIsLastFlowChart = false;
            this.flowChart48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart48.bSkip = false;
            this.flowChart48.bStepByStepMode = false;
            this.flowChart48.CASE1 = null;
            this.flowChart48.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart48.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart48.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.CASE2 = null;
            this.flowChart48.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart48.CASE2Color = System.Drawing.Color.Red;
            this.flowChart48.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.CASE3 = null;
            this.flowChart48.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart48.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart48.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.DefaultColor = System.Drawing.Color.White;
            this.flowChart48.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart48.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart48.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart48.Location = new System.Drawing.Point(11, 87);
            this.flowChart48.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart48.menuOpening = false;
            this.flowChart48.Name = "flowChart48";
            this.flowChart48.NEXT = this.flowChart47;
            this.flowChart48.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart48.NEXTColor = System.Drawing.Color.Black;
            this.flowChart48.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart48.Size = new System.Drawing.Size(178, 35);
            this.flowChart48.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart48.SubFlowChart = null;
            this.flowChart48.TabIndex = 46;
            this.flowChart48.Text = "Auto calibration";
            this.flowChart48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart48.TimeOut = 10000;
            this.flowChart48.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart48.tmrTimeOut = null;
            this.flowChart48.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart48_FlowRun);
            // 
            // flowChart49
            // 
            this.flowChart49.AlarmCode = "";
            this.flowChart49.ArrowSeparation = 20;
            this.flowChart49.ArrowsWidth = 1;
            this.flowChart49.BackColor = System.Drawing.Color.White;
            this.flowChart49.bClearTrace = false;
            this.flowChart49.bIsLastFlowChart = false;
            this.flowChart49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowChart49.bSkip = false;
            this.flowChart49.bStepByStepMode = false;
            this.flowChart49.CASE1 = null;
            this.flowChart49.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart49.CASE1Color = System.Drawing.Color.LimeGreen;
            this.flowChart49.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.CASE2 = null;
            this.flowChart49.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart49.CASE2Color = System.Drawing.Color.Red;
            this.flowChart49.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.CASE3 = null;
            this.flowChart49.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart49.CASE3Color = System.Drawing.Color.Blue;
            this.flowChart49.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.DefaultColor = System.Drawing.Color.White;
            this.flowChart49.eSkipPath = NPSDK.FCResultType.NEXT;
            this.flowChart49.ExecutedColor = System.Drawing.Color.LightGray;
            this.flowChart49.ExecutingColor = System.Drawing.Color.Lime;
            this.flowChart49.Location = new System.Drawing.Point(11, 39);
            this.flowChart49.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.flowChart49.menuOpening = false;
            this.flowChart49.Name = "flowChart49";
            this.flowChart49.NEXT = this.flowChart48;
            this.flowChart49.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.flowChart49.NEXTColor = System.Drawing.Color.Black;
            this.flowChart49.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.flowChart49.Size = new System.Drawing.Size(178, 35);
            this.flowChart49.SkipColor = System.Drawing.Color.Yellow;
            this.flowChart49.SubFlowChart = null;
            this.flowChart49.TabIndex = 45;
            this.flowChart49.Text = "Start process";
            this.flowChart49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.flowChart49.TimeOut = 10000;
            this.flowChart49.TimeoutColor = System.Drawing.Color.Red;
            this.flowChart49.tmrTimeOut = null;
            this.flowChart49.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.flowChart49_FlowRun);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.textBox4);
            this.tabPage4.Controls.Add(this.label81);
            this.tabPage4.Controls.Add(this.label80);
            this.tabPage4.Controls.Add(this.numericUpDown2);
            this.tabPage4.Controls.Add(this.textBox3);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Controls.Add(this.panel4);
            this.tabPage4.Location = new System.Drawing.Point(4, 31);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(664, 1402);
            this.tabPage4.TabIndex = 15;
            this.tabPage4.Text = "Other parameters";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.RecipeData, "RSet.TrayCount", true));
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(246, 713);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(112, 35);
            this.textBox4.TabIndex = 131;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(36, 716);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(206, 29);
            this.label81.TabIndex = 130;
            this.label81.Text = "Current tray count:";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(54, 621);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(107, 24);
            this.label80.TabIndex = 129;
            this.label80.Text = "Scan Timer";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.RecipeData, "RSet.scantimer", true));
            this.numericUpDown2.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(175, 621);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(99, 28);
            this.numericUpDown2.TabIndex = 128;
            this.numericUpDown2.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.SettingData, "PSet.MaxDisplay", true));
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(246, 497);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(112, 35);
            this.textBox3.TabIndex = 126;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(36, 501);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(142, 29);
            this.label18.TabIndex = 125;
            this.label18.Text = "Max Display";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button23);
            this.groupBox3.Controls.Add(this.button24);
            this.groupBox3.Controls.Add(this.txtTaskValue);
            this.groupBox3.Location = new System.Drawing.Point(6, 361);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(744, 87);
            this.groupBox3.TabIndex = 127;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Today Task";
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(404, 38);
            this.button23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(279, 30);
            this.button23.TabIndex = 2;
            this.button23.Text = "Reset Finished Task Value";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(132, 37);
            this.button24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(195, 30);
            this.button24.TabIndex = 1;
            this.button24.Text = "Today Task Value";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // txtTaskValue
            // 
            this.txtTaskValue.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.SettingData, "PSet.TodayTaskValue", true));
            this.txtTaskValue.Location = new System.Drawing.Point(19, 38);
            this.txtTaskValue.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTaskValue.Name = "txtTaskValue";
            this.txtTaskValue.Size = new System.Drawing.Size(100, 28);
            this.txtTaskValue.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.DownCCDExpTime);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.ScanExpTime);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.LiveExpTime);
            this.panel4.Controls.Add(this.DisChargeExpTime);
            this.panel4.Controls.Add(this.PickExpTime);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Location = new System.Drawing.Point(6, 7);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(470, 350);
            this.panel4.TabIndex = 4;
            this.panel4.Tag = "";
            // 
            // DownCCDExpTime
            // 
            this.DownCCDExpTime.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.SettingData, "MSet.DownCCDExpTime", true));
            this.DownCCDExpTime.DecimalPlaces = 1;
            this.DownCCDExpTime.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.DownCCDExpTime.Location = new System.Drawing.Point(290, 231);
            this.DownCCDExpTime.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.DownCCDExpTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.DownCCDExpTime.Name = "DownCCDExpTime";
            this.DownCCDExpTime.Size = new System.Drawing.Size(158, 28);
            this.DownCCDExpTime.TabIndex = 10;
            this.DownCCDExpTime.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(26, 273);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(129, 24);
            this.label20.TabIndex = 9;
            this.label20.Text = "Live exposure";
            // 
            // ScanExpTime
            // 
            this.ScanExpTime.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.SettingData, "MSet.ScanExpTime", true));
            this.ScanExpTime.DecimalPlaces = 1;
            this.ScanExpTime.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.ScanExpTime.Location = new System.Drawing.Point(293, 59);
            this.ScanExpTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ScanExpTime.Name = "ScanExpTime";
            this.ScanExpTime.Size = new System.Drawing.Size(158, 28);
            this.ScanExpTime.TabIndex = 8;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(29, 62);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(138, 24);
            this.label21.TabIndex = 7;
            this.label21.Text = "Scan exposure";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 24);
            this.label22.TabIndex = 6;
            this.label22.Text = "Exposure";
            // 
            // LiveExpTime
            // 
            this.LiveExpTime.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.SettingData, "MSet.LiveExpTime", true));
            this.LiveExpTime.DecimalPlaces = 1;
            this.LiveExpTime.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.LiveExpTime.Location = new System.Drawing.Point(290, 273);
            this.LiveExpTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LiveExpTime.Name = "LiveExpTime";
            this.LiveExpTime.Size = new System.Drawing.Size(158, 28);
            this.LiveExpTime.TabIndex = 5;
            // 
            // DisChargeExpTime
            // 
            this.DisChargeExpTime.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.SettingData, "MSet.DischargeExpTime", true));
            this.DisChargeExpTime.DecimalPlaces = 1;
            this.DisChargeExpTime.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.DisChargeExpTime.Location = new System.Drawing.Point(293, 142);
            this.DisChargeExpTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.DisChargeExpTime.Name = "DisChargeExpTime";
            this.DisChargeExpTime.Size = new System.Drawing.Size(158, 28);
            this.DisChargeExpTime.TabIndex = 4;
            // 
            // PickExpTime
            // 
            this.PickExpTime.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.SettingData, "MSet.PickExpTime", true));
            this.PickExpTime.DecimalPlaces = 1;
            this.PickExpTime.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.PickExpTime.Location = new System.Drawing.Point(293, 100);
            this.PickExpTime.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.PickExpTime.Name = "PickExpTime";
            this.PickExpTime.Size = new System.Drawing.Size(158, 28);
            this.PickExpTime.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(29, 103);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(130, 24);
            this.label30.TabIndex = 0;
            this.label30.Text = "Pick exposure";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(26, 232);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(199, 24);
            this.label38.TabIndex = 2;
            this.label38.Text = "NGTaryCCD exposure";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(29, 144);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(180, 24);
            this.label39.TabIndex = 1;
            this.label39.Text = "Discharge exposure";
            // 
            // chk_SaveImg
            // 
            this.chk_SaveImg.Checked = false;
            this.chk_SaveImg.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.SettingData, "PSet.ImgSave", true));
            this.chk_SaveImg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_SaveImg.Location = new System.Drawing.Point(10, 11);
            this.chk_SaveImg.Margin = new System.Windows.Forms.Padding(10, 11, 10, 11);
            this.chk_SaveImg.MaximumSize = new System.Drawing.Size(0, 54);
            this.chk_SaveImg.MinimumSize = new System.Drawing.Size(55, 54);
            this.chk_SaveImg.Name = "chk_SaveImg";
            this.chk_SaveImg.Size = new System.Drawing.Size(517, 54);
            this.chk_SaveImg.TabIndex = 0;
            this.chk_SaveImg.Text = " Save Bitmap";
            // 
            // txtSavePath
            // 
            this.txtSavePath.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.SettingData, "PSet.SaveImagePath", true));
            this.txtSavePath.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSavePath.Location = new System.Drawing.Point(3, 172);
            this.txtSavePath.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSavePath.Name = "txtSavePath";
            this.txtSavePath.Size = new System.Drawing.Size(531, 28);
            this.txtSavePath.TabIndex = 1;
            // 
            // chk_SaveJpgImg
            // 
            this.chk_SaveJpgImg.Checked = false;
            this.chk_SaveJpgImg.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.SettingData, "PSet.JPGImgSave", true));
            this.chk_SaveJpgImg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chk_SaveJpgImg.Location = new System.Drawing.Point(10, 96);
            this.chk_SaveJpgImg.Margin = new System.Windows.Forms.Padding(10, 11, 10, 11);
            this.chk_SaveJpgImg.MaximumSize = new System.Drawing.Size(0, 54);
            this.chk_SaveJpgImg.MinimumSize = new System.Drawing.Size(55, 54);
            this.chk_SaveJpgImg.Name = "chk_SaveJpgImg";
            this.chk_SaveJpgImg.Size = new System.Drawing.Size(517, 54);
            this.chk_SaveJpgImg.TabIndex = 0;
            this.chk_SaveJpgImg.Text = " Save JPEG";
            // 
            // btnPathSelect
            // 
            this.btnPathSelect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPathSelect.BackgroundImage")));
            this.btnPathSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPathSelect.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnPathSelect.Location = new System.Drawing.Point(540, 172);
            this.btnPathSelect.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPathSelect.Name = "btnPathSelect";
            this.btnPathSelect.Size = new System.Drawing.Size(95, 83);
            this.btnPathSelect.TabIndex = 139;
            this.btnPathSelect.UseVisualStyleBackColor = true;
            this.btnPathSelect.Click += new System.EventHandler(this.BtnPathSelect_Click);
            // 
            // dataColumn118
            // 
            this.dataColumn118.ColumnName = "ImgSave";
            this.dataColumn118.DataType = typeof(bool);
            // 
            // dataColumn119
            // 
            this.dataColumn119.ColumnName = "SaveImagePath";
            // 
            // dataColumn120
            // 
            this.dataColumn120.ColumnName = "JPGImgSave";
            this.dataColumn120.DataType = typeof(bool);
            // 
            // dataTable6
            // 
            this.dataTable6.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn121,
            this.dataColumn122,
            this.dataColumn123,
            this.dataColumn124,
            this.dataColumn125});
            this.dataTable6.TableName = "R1_Discharge2VisCalib";
            // 
            // dataColumn121
            // 
            this.dataColumn121.ColumnName = "Calib_Index";
            this.dataColumn121.DataType = typeof(int);
            // 
            // dataColumn122
            // 
            this.dataColumn122.ColumnName = "Calib_PixelX";
            this.dataColumn122.DataType = typeof(double);
            // 
            // dataColumn123
            // 
            this.dataColumn123.ColumnName = "Calib_PixelY";
            this.dataColumn123.DataType = typeof(double);
            // 
            // dataColumn124
            // 
            this.dataColumn124.ColumnName = "Calib_RobotX";
            this.dataColumn124.DataType = typeof(double);
            // 
            // dataColumn125
            // 
            this.dataColumn125.ColumnName = "Calib_RobotY";
            this.dataColumn125.DataType = typeof(double);
            // 
            // dataColumn126
            // 
            this.dataColumn126.ColumnName = "Discharge2TeachVisX";
            this.dataColumn126.DataType = typeof(double);
            // 
            // dataColumn127
            // 
            this.dataColumn127.ColumnName = "Discharge2TeachVisY";
            this.dataColumn127.DataType = typeof(double);
            // 
            // dataColumn128
            // 
            this.dataColumn128.ColumnName = "Discharge2TeachVisU";
            this.dataColumn128.DataType = typeof(double);
            // 
            // dataColumn129
            // 
            this.dataColumn129.ColumnName = "Discharge2TeachRobotX";
            this.dataColumn129.DataType = typeof(double);
            // 
            // dataColumn130
            // 
            this.dataColumn130.ColumnName = "Discharge2TeachRobotY";
            this.dataColumn130.DataType = typeof(double);
            // 
            // dataColumn131
            // 
            this.dataColumn131.ColumnName = "Discharge2TeachRobotU";
            this.dataColumn131.DataType = typeof(double);
            // 
            // dataColumn132
            // 
            this.dataColumn132.ColumnName = "Discharge2TeachVisX2";
            this.dataColumn132.DataType = typeof(double);
            // 
            // dataColumn133
            // 
            this.dataColumn133.ColumnName = "Discharge2TeachVisY2";
            this.dataColumn133.DataType = typeof(double);
            // 
            // dataColumn134
            // 
            this.dataColumn134.ColumnName = "Discharge2TeachVisU2";
            this.dataColumn134.DataType = typeof(double);
            // 
            // dataColumn135
            // 
            this.dataColumn135.ColumnName = "Discharge2TeachRobotX2";
            this.dataColumn135.DataType = typeof(double);
            // 
            // dataColumn136
            // 
            this.dataColumn136.ColumnName = "Discharge2TeachRobotY2";
            this.dataColumn136.DataType = typeof(double);
            // 
            // dataColumn137
            // 
            this.dataColumn137.ColumnName = "Discharge2TeachRobotU2";
            this.dataColumn137.DataType = typeof(double);
            // 
            // dataColumn138
            // 
            this.dataColumn138.ColumnName = "Discharge2TeachVisX3";
            this.dataColumn138.DataType = typeof(double);
            // 
            // dataColumn139
            // 
            this.dataColumn139.ColumnName = "Discharge2TeachVisY3";
            this.dataColumn139.DataType = typeof(double);
            // 
            // dataColumn140
            // 
            this.dataColumn140.ColumnName = "Discharge2TeachVisU3";
            this.dataColumn140.DataType = typeof(double);
            // 
            // dataColumn141
            // 
            this.dataColumn141.ColumnName = "Discharge2TeachRobotX3";
            this.dataColumn141.DataType = typeof(double);
            // 
            // dataColumn142
            // 
            this.dataColumn142.ColumnName = "Discharge2TeachRobotY3";
            this.dataColumn142.DataType = typeof(double);
            // 
            // dataColumn143
            // 
            this.dataColumn143.ColumnName = "Discharge2TeachRobotU3";
            this.dataColumn143.DataType = typeof(double);
            // 
            // dataColumn144
            // 
            this.dataColumn144.ColumnName = "Enable_Mes";
            this.dataColumn144.DataType = typeof(bool);
            // 
            // dataColumn145
            // 
            this.dataColumn145.ColumnName = "Mes_IP";
            // 
            // dataColumn146
            // 
            this.dataColumn146.ColumnName = "Mes_Port";
            // 
            // dataColumn147
            // 
            this.dataColumn147.Caption = "Pick";
            this.dataColumn147.ColumnName = "Column1";
            // 
            // dataColumn148
            // 
            this.dataColumn148.Caption = "ScanExpTime";
            this.dataColumn148.ColumnName = "ScanExpTime";
            this.dataColumn148.DataType = typeof(double);
            // 
            // dataColumn149
            // 
            this.dataColumn149.Caption = "PickExpTime";
            this.dataColumn149.ColumnName = "PickExpTime";
            this.dataColumn149.DataType = typeof(double);
            // 
            // dataColumn150
            // 
            this.dataColumn150.Caption = "DisChargeExpTime";
            this.dataColumn150.ColumnName = "DisChargeExpTime";
            this.dataColumn150.DataType = typeof(double);
            // 
            // dataColumn151
            // 
            this.dataColumn151.Caption = "DownCCDExpTime";
            this.dataColumn151.ColumnName = "DownCCDExpTime";
            this.dataColumn151.DataType = typeof(double);
            // 
            // dataColumn152
            // 
            this.dataColumn152.Caption = "LiveExpTime";
            this.dataColumn152.ColumnName = "LiveExpTime";
            this.dataColumn152.DataType = typeof(double);
            // 
            // label42
            // 
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(692, 72);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(21, 25);
            this.label42.TabIndex = 33;
            this.label42.Text = "%";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbR2SpeedRatio
            // 
            this.lbR2SpeedRatio.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lbR2SpeedRatio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbR2SpeedRatio.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbR2SpeedRatio.Location = new System.Drawing.Point(637, 72);
            this.lbR2SpeedRatio.Name = "lbR2SpeedRatio";
            this.lbR2SpeedRatio.Size = new System.Drawing.Size(49, 25);
            this.lbR2SpeedRatio.TabIndex = 32;
            this.lbR2SpeedRatio.Text = "0";
            this.lbR2SpeedRatio.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trackBar2
            // 
            this.trackBar2.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.SettingData, "PSet.R1MachineSpeedRatio", true));
            this.trackBar2.Location = new System.Drawing.Point(289, 61);
            this.trackBar2.Margin = new System.Windows.Forms.Padding(2);
            this.trackBar2.Maximum = 100;
            this.trackBar2.Minimum = 1;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(333, 45);
            this.trackBar2.TabIndex = 31;
            this.trackBar2.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar2.Value = 1;
            this.trackBar2.ValueChanged += new System.EventHandler(this.trackBar2_ValueChanged);
            this.trackBar2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trackBar2_MouseUp);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(26, 72);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(247, 24);
            this.label43.TabIndex = 30;
            this.label43.Text = "R1Machine Speed Ratio :";
            // 
            // dataColumn153
            // 
            this.dataColumn153.Caption = "R1MachineSpeedRatio";
            this.dataColumn153.ColumnName = "R1MachineSpeedRatio";
            this.dataColumn153.DataType = typeof(int);
            // 
            // dataColumn154
            // 
            this.dataColumn154.Caption = "MaxDisplay";
            this.dataColumn154.ColumnName = "MaxDisplay";
            this.dataColumn154.DataType = typeof(int);
            // 
            // dataColumn155
            // 
            this.dataColumn155.Caption = "TodayTaskValue";
            this.dataColumn155.ColumnName = "TodayTaskValue";
            this.dataColumn155.DataType = typeof(int);
            // 
            // dataColumn156
            // 
            this.dataColumn156.Caption = "NGbuffer1";
            this.dataColumn156.ColumnName = "NGbuffer1";
            this.dataColumn156.DataType = typeof(bool);
            // 
            // dataColumn157
            // 
            this.dataColumn157.Caption = "NGbuffer2";
            this.dataColumn157.ColumnName = "NGbuffer2";
            this.dataColumn157.DataType = typeof(bool);
            // 
            // dataColumn158
            // 
            this.dataColumn158.Caption = "NGbuffer3";
            this.dataColumn158.ColumnName = "NGbuffer3";
            this.dataColumn158.DataType = typeof(bool);
            // 
            // dataColumn159
            // 
            this.dataColumn159.ColumnName = "NGbuffer4";
            this.dataColumn159.DataType = typeof(bool);
            // 
            // dataColumn160
            // 
            this.dataColumn160.ColumnName = "dateTime";
            // 
            // dataColumn161
            // 
            this.dataColumn161.ColumnName = "PalletMinValueX";
            this.dataColumn161.DataType = typeof(double);
            // 
            // dataColumn162
            // 
            this.dataColumn162.ColumnName = "PalletMinValueY";
            this.dataColumn162.DataType = typeof(double);
            // 
            // dataColumn163
            // 
            this.dataColumn163.ColumnName = "PalletMaxValueX";
            this.dataColumn163.DataType = typeof(double);
            // 
            // dataColumn164
            // 
            this.dataColumn164.ColumnName = "PalletMaxValueY";
            this.dataColumn164.DataType = typeof(double);
            // 
            // dataColumn165
            // 
            this.dataColumn165.ColumnName = "FeederMaxValueY";
            this.dataColumn165.DataType = typeof(double);
            // 
            // dataColumn166
            // 
            this.dataColumn166.ColumnName = "FeederMaxValueX";
            this.dataColumn166.DataType = typeof(double);
            // 
            // dataColumn167
            // 
            this.dataColumn167.ColumnName = "FeederMinValueY";
            this.dataColumn167.DataType = typeof(double);
            // 
            // dataColumn168
            // 
            this.dataColumn168.ColumnName = "FeederMinValueX";
            this.dataColumn168.DataType = typeof(double);
            // 
            // dataColumn169
            // 
            this.dataColumn169.ColumnName = "scantimer";
            this.dataColumn169.DataType = typeof(short);
            // 
            // tabControl8
            // 
            this.tabControl8.Controls.Add(this.tabPage5);
            this.tabControl8.Controls.Add(this.tabPage7);
            this.tabControl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl8.Location = new System.Drawing.Point(0, 0);
            this.tabControl8.Name = "tabControl8";
            this.tabControl8.SelectedIndex = 0;
            this.tabControl8.Size = new System.Drawing.Size(788, 1437);
            this.tabControl8.TabIndex = 100;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.RGP_0001);
            this.tabPage5.Controls.Add(this.fc_InitialStart);
            this.tabPage5.Controls.Add(this.npFlowChart32);
            this.tabPage5.Controls.Add(this.flowChart96);
            this.tabPage5.Controls.Add(this.npFlowChart31);
            this.tabPage5.Controls.Add(this.fc_ConnectScanner);
            this.tabPage5.Controls.Add(this.npFlowChart20);
            this.tabPage5.Controls.Add(this.fc_CloseVisLight);
            this.tabPage5.Controls.Add(this.npFlowChart25);
            this.tabPage5.Controls.Add(this.fc_StartR1);
            this.tabPage5.Controls.Add(this.npFlowChart22);
            this.tabPage5.Controls.Add(this.fc_WaitR1Reset);
            this.tabPage5.Controls.Add(this.npFlowChart24);
            this.tabPage5.Controls.Add(this.flowChart54);
            this.tabPage5.Controls.Add(this.npFlowChart23);
            this.tabPage5.Controls.Add(this.flowChart56);
            this.tabPage5.Controls.Add(this.npFlowChart21);
            this.tabPage5.Controls.Add(this.flowChart57);
            this.tabPage5.Controls.Add(this.npFlowChart26);
            this.tabPage5.Controls.Add(this.flowChart55);
            this.tabPage5.Controls.Add(this.npFlowChart27);
            this.tabPage5.Controls.Add(this.fc_ResetR1);
            this.tabPage5.Controls.Add(this.npFlowChart6);
            this.tabPage5.Controls.Add(this.flowChart1);
            this.tabPage5.Controls.Add(this.npFlowChart5);
            this.tabPage5.Controls.Add(this.flowChart2);
            this.tabPage5.Controls.Add(this.npFlowChart4);
            this.tabPage5.Controls.Add(this.flowChart31);
            this.tabPage5.Controls.Add(this.npFlowChart3);
            this.tabPage5.Controls.Add(this.flowChart33);
            this.tabPage5.Controls.Add(this.npFlowChart1);
            this.tabPage5.Location = new System.Drawing.Point(4, 31);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(780, 1402);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Initial";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // RGP_0001
            // 
            this.RGP_0001.AlarmCode = "";
            this.RGP_0001.ArrowSeparation = 120;
            this.RGP_0001.ArrowsWidth = 1;
            this.RGP_0001.BackColor = System.Drawing.Color.White;
            this.RGP_0001.bClearTrace = false;
            this.RGP_0001.bIsLastFlowChart = false;
            this.RGP_0001.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RGP_0001.bSkip = false;
            this.RGP_0001.bStepByStepMode = false;
            this.RGP_0001.CASE1 = null;
            this.RGP_0001.Case1ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.RGP_0001.CASE1Color = System.Drawing.Color.LimeGreen;
            this.RGP_0001.CASE1EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.RGP_0001.Case1StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.RGP_0001.CASE2 = null;
            this.RGP_0001.Case2ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.RGP_0001.CASE2Color = System.Drawing.Color.Red;
            this.RGP_0001.CASE2EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.RGP_0001.Case2StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.RGP_0001.CASE3 = null;
            this.RGP_0001.Case3ArrowType = NPSDK.NPFlowChart.ArrowTypes.Line;
            this.RGP_0001.CASE3Color = System.Drawing.Color.Blue;
            this.RGP_0001.CASE3EndPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.RGP_0001.Case3StartPoint = NPSDK.NPFlowChart.FlowchartSides.Right;
            this.RGP_0001.DefaultColor = System.Drawing.Color.White;
            this.RGP_0001.eSkipPath = NPSDK.FCResultType.IDLE;
            this.RGP_0001.ExecutedColor = System.Drawing.Color.LightGray;
            this.RGP_0001.ExecutingColor = System.Drawing.Color.Lime;
            this.RGP_0001.Location = new System.Drawing.Point(110, 65);
            this.RGP_0001.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.RGP_0001.menuOpening = false;
            this.RGP_0001.Name = "RGP_0001";
            this.RGP_0001.NEXT = this.fc_CloseVisLight;
            this.RGP_0001.NextArrowType = NPSDK.NPFlowChart.ArrowTypes.Square;
            this.RGP_0001.NEXTColor = System.Drawing.Color.Black;
            this.RGP_0001.NEXTEndPoint = NPSDK.NPFlowChart.FlowchartSides.Left;
            this.RGP_0001.NEXTStartPoint = NPSDK.NPFlowChart.FlowchartSides.Bottom;
            this.RGP_0001.Size = new System.Drawing.Size(141, 83);
            this.RGP_0001.SkipColor = System.Drawing.Color.Yellow;
            this.RGP_0001.SubFlowChart = null;
            this.RGP_0001.TabIndex = 100;
            this.RGP_0001.Text = "Reset Gantry Process Starts";
            this.RGP_0001.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RGP_0001.TimeOut = 10000;
            this.RGP_0001.TimeoutColor = System.Drawing.Color.Red;
            this.RGP_0001.tmrTimeOut = null;
            this.RGP_0001.FlowRun += new NPSDK.NPFlowChart.FlowRunEvent(this.RGP_0001_FlowRun);
            // 
            // tabPage7
            // 
            this.tabPage7.Location = new System.Drawing.Point(4, 31);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(780, 1402);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Reset Gantry Process";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 1;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Controls.Add(this.cogRecDisp_H5_Recipe, 0, 2);
            this.tableLayoutPanel14.Controls.Add(this.cogRecordDisplay_Pickup, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.cogRecordDisplay_Discharge, 0, 1);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 3;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(985, 1437);
            this.tableLayoutPanel14.TabIndex = 152;
            // 
            // tableLayoutPanel108
            // 
            this.tableLayoutPanel108.ColumnCount = 2;
            this.tableLayoutPanel108.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel108.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel108.Controls.Add(this.btnPathSelect, 1, 2);
            this.tableLayoutPanel108.Controls.Add(this.chk_SaveImg, 0, 0);
            this.tableLayoutPanel108.Controls.Add(this.txtSavePath, 0, 2);
            this.tableLayoutPanel108.Controls.Add(this.chk_SaveJpgImg, 0, 1);
            this.tableLayoutPanel108.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel108.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel108.Name = "tableLayoutPanel108";
            this.tableLayoutPanel108.RowCount = 3;
            this.tableLayoutPanel108.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel108.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel108.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel108.Size = new System.Drawing.Size(672, 257);
            this.tableLayoutPanel108.TabIndex = 140;
            // 
            // dataColumn170
            // 
            this.dataColumn170.ColumnName = "TrayCount";
            this.dataColumn170.DataType = typeof(short);
            // 
            // GantryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(813, 914);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "GantryForm";
            this.Text = "Gantry";
            this.Load += new System.EventHandler(this.GantryForm_Load);
            this.plMaintenance.ResumeLayout(false);
            this.plProductionSetting.ResumeLayout(false);
            this.plRecipeEditor.ResumeLayout(false);
            this.plRecipeEditor.PerformLayout();
            this.plFlowInitial.ResumeLayout(false);
            this.plFlowAuto.ResumeLayout(false);
            this.plMachineStatus.ResumeLayout(false);
            this.plMachineStatus.PerformLayout();
            this.plMotionSetup.ResumeLayout(false);
            this.plMotionSetup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SettingData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RecipeData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable3)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTable4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable5)).EndInit();
            this.tb_Robot1AlarmInfo.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tabPage21.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel26.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel23.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.tableLayoutPanel24.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogRecDisp_H5_Recipe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogRecordDisplay_Discharge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogRecordDisplay_Pickup)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage19.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_H2_PickPos)).EndInit();
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.tabControl6.ResumeLayout(false);
            this.tabPage16.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogRecDisp1)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxFY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxFX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minFY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minFX)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxPY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_maxPX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minPY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_minPX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWritePR3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWritePR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWritePR1)).EndInit();
            this.tabControl7.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel30.PerformLayout();
            this.tabControl5.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DownCCDExpTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ScanExpTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LiveExpTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DisChargeExpTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PickExpTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            this.tabControl8.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel108.ResumeLayout(false);
            this.tableLayoutPanel108.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        #region MyRegion

        #endregion
        private System.Windows.Forms.Timer tmRefresh;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataTable dataTable2;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataColumn dataColumn37;
        private System.Data.DataColumn dataColumn38;
        private System.Data.DataColumn dataColumn39;
        private System.Windows.Forms.Button button28;
        public System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Button button27;
        public System.Windows.Forms.TextBox CTtime2;
        private System.Windows.Forms.Label label78;
        public System.Windows.Forms.TextBox CTtime1;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label63;
        public System.Windows.Forms.TextBox txtBarcodeResult2;
        private Cognex.VisionPro.CogRecordDisplay cogRecordDisplay1;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txtBarcodeResult;
        private System.Data.DataTable dataTable3;
        private System.Data.DataColumn dataColumn40;
        private System.Data.DataColumn dataColumn41;
        private System.Data.DataColumn dataColumn42;
        private System.Data.DataColumn dataColumn43;

        #region MyRegion
        private NPSDK.NPInput IB_FeederInPlace;
        private NPSDK.NPInput IB_FeederEmergencyStop;
        private NPSDK.NPInput IB_FeederReady;
        private NPSDK.NPInput IB_FeederLack;
        private NPSDK.NPOutput OB_FeederAlmReset;
        private NPSDK.NPOutput OB_FeederSafetySignal;
        private NPSDK.NPOutput OB_FeederEmgStop;
        private NPSDK.NPOutput OB_FeederStart;
        private NPSDK.NPOutput OB_FeederCompleted;

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Data.DataColumn dataColumn44;
        private System.Data.DataColumn dataColumn45;
        private System.Data.DataColumn dataColumn46;
        private System.Data.DataColumn dataColumn47;
        private System.Data.DataTable dataTable4;
        private System.Data.DataColumn dataColumn48;
        private System.Data.DataColumn dataColumn49;
        private System.Data.DataColumn dataColumn50;
        private System.Data.DataColumn dataColumn51;
        private System.Data.DataColumn dataColumn52;
        private System.Data.DataColumn dataColumn53;
        private System.Data.DataColumn dataColumn54;
        private System.Data.DataColumn dataColumn55;
        private System.Data.DataColumn dataColumn56;
        private System.Data.DataColumn dataColumn57;
        private System.Data.DataColumn dataColumn58;
        private System.Data.DataColumn dataColumn59;
        private System.Data.DataColumn dataColumn60;
        private System.Data.DataColumn dataColumn61;
        private System.Data.DataColumn dataColumn62;
        private System.Data.DataColumn dataColumn63;
        private System.Data.DataColumn dataColumn64;
        private System.Data.DataColumn dataColumn65;
        private System.Data.DataColumn dataColumn66;
        private System.Data.DataColumn dataColumn67;
        private System.Data.DataColumn dataColumn68;
        private System.Data.DataColumn dataColumn69;
        private System.Data.DataColumn dataColumn70;
        private System.Data.DataColumn dataColumn71;
        private System.Data.DataColumn dataColumn72;
        private System.Data.DataColumn dataColumn73;
        private System.Data.DataTable dataTable5;
        private System.Data.DataColumn dataColumn74;
        private System.Data.DataColumn dataColumn75;
        private System.Data.DataColumn dataColumn76;
        private System.Data.DataColumn dataColumn77;
        private System.Data.DataColumn dataColumn78;
        private System.Data.DataColumn dataColumn79;
        private System.Data.DataColumn dataColumn80;
        private System.Data.DataColumn dataColumn81;
        private System.Data.DataColumn dataColumn82;
        private System.Data.DataColumn dataColumn83;
        private System.Data.DataColumn dataColumn84;
        private System.Data.DataColumn dataColumn85;
        private System.Data.DataColumn dataColumn86;
        private System.Data.DataColumn dataColumn87;
        private System.Data.DataColumn dataColumn88;
        private System.Data.DataColumn dataColumn89;
        private System.Data.DataColumn dataColumn90;
        private System.Data.DataColumn dataColumn91;
        private System.Data.DataColumn dataColumn92;
        private System.Data.DataColumn dataColumn93;
        private System.Data.DataColumn dataColumn94;
        private System.Data.DataColumn dataColumn95;
        private System.Data.DataColumn dataColumn96;
        private Cognex.VisionPro.CogRecordDisplay cogRecordDisplay3;
        private Cognex.VisionPro.CogRecordDisplay cogRecordDisplay2;
        private System.Data.DataColumn dataColumn97;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tb_Robot1AlarmInfo;
        private NPSDK.NPFlowChart fcNgMes;   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0
        private NPSDK.NPFlowChart flowChart101;
        public NPSDK.NPFlowChart fc_ReflashR1AlramInfo;
        private NPSDK.NPFlowChart flowChart102;
        private System.Data.DataColumn dataColumn98;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.GroupBox groupBox15;
        public NPSDK.NPFlowChart flowChart7;
        public NPSDK.NPFlowChart flowChart9;
        public NPSDK.NPFlowChart flowChart11;
        public NPSDK.NPFlowChart flowChart12;
        public NPSDK.NPFlowChart flowChart13;
        private NPSDK.NPFlowChart flowChart96;
        private NPSDK.NPFlowChart fc_InitialStart;
        private NPSDK.NPFlowChart fc_ResetR1;
        private NPSDK.NPFlowChart fc_StartR1;
        private NPSDK.NPFlowChart fc_WaitR1Reset;
        private NPSDK.NPFlowChart fc_CloseVisLight;
        private NPSDK.NPFlowChart fc_ConnectScanner;
        private NPSDK.NPFlowChart flowChart1;
        private NPSDK.NPFlowChart flowChart2;
        private System.Windows.Forms.TabPage tabPage23;
        private NPSDK.NPFlowChart flowChart44;
        private NPSDK.NPFlowChart flowChart14;
        private NPSDK.NPFlowChart flowChart39;
        private NPSDK.NPFlowChart flowChart38;
        private NPSDK.NPFlowChart flowChart28;
        private NPSDK.NPFlowChart flowChart41;
        private NPSDK.NPFlowChart flowChart16;
        private NPSDK.NPFlowChart flowChart15;
        private NPSDK.NPFlowChart flowChart17;
        private NPSDK.NPFlowChart flowChart19;
        private NPSDK.NPFlowChart flowChart18;
        private NPSDK.NPFlowChart flowChart21;
        private NPSDK.NPFlowChart flowChart24;
        private NPSDK.NPFlowChart flowChart23;
        private NPSDK.NPFlowChart flowChart22;
        private NPSDK.NPFlowChart flowChart20;
        private NPSDK.NPFlowChart flowChart25;
        private NPSDK.NPFlowChart flowChart26;
        private NPSDK.NPFlowChart flowChart29;
        private NPSDK.NPFlowChart flowChart27;
        private NPSDK.NPFlowChart flowChart32;
        private System.Data.DataColumn dataColumn99;
        private NPSDK.NPFlowChart flowChart8;
        private NPSDK.NPFlowChart flowChart10;
        private NPSDK.NPFlowChart flowChart34;
        private NPSDK.NPFlowChart flowChart35;
        private NPSDK.NPFlowChart flowChart36;
        private NPSDK.NPFlowChart flowChart42;
        private NPSDK.NPFlowChart flowChart45;
        private NPSDK.NPFlowChart flowChart43;
        private System.Data.DataColumn dataColumn100;
        private NPSDK.NPFlowChart flowChart33;
        private NPSDK.NPFlowChart flowChart31;
        private NPSDK.NPFlowChart flowChart37;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.CheckBox chk_Output_1;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Button bt_WriteIO;
        private System.Windows.Forms.CheckBox chk_Output_2;
        private System.Windows.Forms.CheckBox chk_Output_3;
        private System.Windows.Forms.CheckBox chk_Output_4;
        private System.Windows.Forms.CheckBox chk_Output_5;
        private System.Windows.Forms.CheckBox chk_Output_6;
        private System.Windows.Forms.CheckBox chk_Output_7;
        private System.Windows.Forms.CheckBox chk_Output_8;
        private System.Windows.Forms.CheckBox chk_Output_9;
        private System.Windows.Forms.CheckBox chk_Output_10;
        private System.Windows.Forms.CheckBox chk_Output_11;
        private System.Windows.Forms.CheckBox chk_Output_12;
        private System.Windows.Forms.CheckBox chk_Output_13;
        private System.Windows.Forms.CheckBox chk_Output_14;
        private System.Windows.Forms.CheckBox chk_Output_15;
        private System.Windows.Forms.CheckBox chk_Output_16;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.GroupBox groupBox5;
        private NPSDK.NPInput IB_RobotPause;
        public NPSDK.NPOutput OB_RobotPause;
        public NPSDK.NPInput IB_RobotError;
        public NPSDK.NPInput IB_RobotEStop;
        public NPSDK.NPOutput OB_RobotStart;
        private NPSDK.NPInput IB_RobotBusy;
        private NPSDK.NPInput IB_RobotReady;
        public NPSDK.NPOutput OB_RobotLight;
        public NPSDK.NPOutput OB_RobotReset;
        private NPSDK.NPOutput OB_RobotStop;
        public NPSDK.NPOutput OB_RobotContinue;
        private NPSDK.NPOutput OB_RobotProg3;
        private NPSDK.NPOutput OB_RobotProg2;
        private NPSDK.NPOutput OB_RobotProg1;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Button bt_Input_1;
        private System.Windows.Forms.Button bt_Input_2;
        private System.Windows.Forms.Button bt_Input_3;
        private System.Windows.Forms.Button bt_Input_4;
        private System.Windows.Forms.Button bt_Input_5;
        private System.Windows.Forms.Button bt_Input_6;
        private System.Windows.Forms.Button bt_Input_7;
        private System.Windows.Forms.Button bt_Input_8;
        private System.Windows.Forms.Button bt_Input_9;
        private System.Windows.Forms.Button bt_Input_10;
        private System.Windows.Forms.Button bt_Input_11;
        private System.Windows.Forms.Button bt_Input_12;
        private System.Windows.Forms.Button bt_Input_13;
        private System.Windows.Forms.Button bt_Input_14;
        private System.Windows.Forms.Button bt_Input_15;
        private System.Windows.Forms.Button bt_Input_16;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Button bt_ReadIO;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label103;
        private NPSDK.NPFlowChart fc_RobotStart;
        private NPSDK.NPFlowChart flowChart40;
        public Cognex.VisionPro.CogRecordDisplay cogRecordDisplay_Pickup;
        public Cognex.VisionPro.CogRecordDisplay cogRecordDisplay_Discharge;
        private System.Data.DataColumn dataColumn101;
        private System.Data.DataColumn dataColumn102;
        private System.Data.DataColumn dataColumn103;
        private System.Data.DataColumn dataColumn104;
        private System.Data.DataColumn dataColumn105;
        private System.Data.DataColumn dataColumn106;
        private System.Data.DataColumn dataColumn107;
        private System.Data.DataColumn dataColumn108;
        private System.Data.DataColumn dataColumn109;
        private System.Data.DataColumn dataColumn110;
        private System.Data.DataColumn dataColumn111;
        private System.Data.DataColumn dataColumn112;
        private System.Data.DataColumn dataColumn113;
        private System.Data.DataColumn dataColumn114;
        private System.Data.DataColumn dataColumn115;
        private System.Data.DataColumn dataColumn116;
        private System.Data.DataColumn dataColumn117;
        private NPSDK.NPFlowChart flowChart52;
        private NPSDK.NPFlowChart flowChart53;
        private NPSDK.NPFlowChart flowChart54;
        private NPSDK.NPFlowChart flowChart55;
        private NPSDK.NPFlowChart flowChart56;
        private NPSDK.NPFlowChart flowChart57;
        private NPSDK.NPFlowChart flowChart58;
        private NPSDK.NPFlowChart flowChart60;
        private NPSDK.NPFlowChart flowChart62;
        private NPSDK.NPFlowChart flowChart65;
        private NPSDK.NPFlowChart flowChart67;
        private NPSDK.NPFlowChart flowChart3;
        private System.Windows.Forms.TabControl tabControl7;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.TextBox txt_PickPos;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Button btnWriteR;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnConnectResult;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnWritePR;
        private System.Windows.Forms.NumericUpDown numWritePR3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown numWritePR2;
        private System.Windows.Forms.NumericUpDown numWritePR1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtReadPRZ;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtReadPRY;
        private System.Windows.Forms.Button btnEnableRbt;
        private System.Windows.Forms.Button Btn_ConnectRobot;
        private System.Windows.Forms.TextBox txtReadPRX;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnReadR;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtReadData;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox tbMassage;
        private System.Windows.Forms.TextBox tbNO;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Button btndisConScan1;
        private System.Windows.Forms.Button btnConScan1;
        private System.Windows.Forms.Button btnStarScan1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox MName;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.DataGridView dgv_H2_PickPos;
        private System.Windows.Forms.DataGridViewTextBoxColumn calibIndexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn calibPixelXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn calibPixelYDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn calibRobotXDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn calibRobotYDataGridViewTextBoxColumn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Button btnPickPos1AlogrithmEditing;
        private System.Windows.Forms.Button btnPickPosStartCalib;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.TextBox txtPickPosRobotU3;
        private System.Windows.Forms.TextBox txtPickPosRobotX3;
        private System.Windows.Forms.TextBox txtPickPosVisionX3;
        private System.Windows.Forms.TextBox txtPickPosRobotY3;
        private System.Windows.Forms.TextBox txtPickPosRobotX2;
        private System.Windows.Forms.TextBox txtPickPosRobotY2;
        private System.Windows.Forms.TextBox txtPickPosRobotU2;
        private System.Windows.Forms.Label lb_PickVisU;
        private System.Windows.Forms.Label lb_PickVisY;
        private System.Windows.Forms.TextBox txtPickPosVisionX1;
        private System.Windows.Forms.TextBox txtPickPosVisionY1;
        private System.Windows.Forms.Button btnTeachPickVisPos;
        private System.Windows.Forms.TextBox txtPickPosRobotX1;
        private System.Windows.Forms.TextBox txtPickPosRobotY1;
        private System.Windows.Forms.TextBox txtPickPosRobotU1;
        private System.Windows.Forms.Button btnTeachPickRobotPos;
        private System.Windows.Forms.TextBox txtPickPosVisionU1;
        private System.Windows.Forms.Label lb_PickVisX;
        private System.Windows.Forms.Button btnTeachPickRobotPos2;
        private System.Windows.Forms.TextBox txtPickPosVisionX2;
        private System.Windows.Forms.TextBox txtPickPosVisionU2;
        private System.Windows.Forms.TextBox txtPickPosVisionY2;
        private System.Windows.Forms.Button btnTeachPickVisPos2;
        private System.Windows.Forms.TextBox txtPickPosVisionY3;
        private System.Windows.Forms.TextBox txtPickPosVisionU3;
        private System.Windows.Forms.Button btnTeachPickVisPos3;
        private System.Windows.Forms.Button btnTeachPickRobotPos3;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage16;
        private NPSDK.NPFlowChart flowChart92;
        private NPSDK.NPFlowChart flowChart93;
        private NPSDK.NPFlowChart flowChart94;
        private NPSDK.NPFlowChart flowChart95;
        private NPSDK.NPFlowChart flowChart97;
        private NPSDK.NPFlowChart flowChart98;
        private NPSDK.NPFlowChart flowChart99;
        private NPSDK.NPFlowChart flowChart100;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TextBox txtDisChargeRobotY3;
        private System.Windows.Forms.TextBox txtDisChargePosVisionX3;
        private System.Windows.Forms.TextBox txtDisChargeRobotX3;
        private System.Windows.Forms.TextBox txtDisChargeRobotU2;
        private System.Windows.Forms.TextBox txtDisChargeRobotY2;
        private System.Windows.Forms.TextBox txtDisChargeRobotX2;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtDisChargePosVisionX1;
        private System.Windows.Forms.TextBox txtDisChargePosVisionY1;
        private System.Windows.Forms.Button btnTeachDiscVisPos;
        private System.Windows.Forms.TextBox txtDisChargeRobotX1;
        private System.Windows.Forms.TextBox txtDisChargeRobotY1;
        private System.Windows.Forms.TextBox txtDisChargeRobotU1;
        private System.Windows.Forms.Button btnTeachDiscRobotPos;
        private System.Windows.Forms.TextBox txtDisChargePosVisionU1;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button btnTeachDiscRobotPos2;
        private System.Windows.Forms.TextBox txtDisChargePosVisionX2;
        private System.Windows.Forms.TextBox txtDisChargePosVisionU2;
        private System.Windows.Forms.TextBox txtDisChargePosVisionY2;
        private System.Windows.Forms.Button btnTeachDiscVisPos2;
        private System.Windows.Forms.TextBox txtDisChargePosVisionY3;
        private System.Windows.Forms.TextBox txtDisChargePosVisionU3;
        private System.Windows.Forms.TextBox txtDisChargeRobotU3;
        private System.Windows.Forms.Button btnTeachDiscVisPos3;
        private System.Windows.Forms.Button btnTeachDiscRobotPos3;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage19;
        private NPSDK.NPFlowChart flowChart108;
        private NPSDK.NPFlowChart flowChart109;
        private NPSDK.NPFlowChart flowChart110;
        private NPSDK.NPFlowChart flowChart111;
        private NPSDK.NPFlowChart flowChart112;
        private NPSDK.NPFlowChart flowChart113;
        private NPSDK.NPFlowChart flowChart114;
        private NPSDK.NPFlowChart flowChart115;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private VUControl.VUDatagridView dgv_EpsonErrInfo;
        public VUControl.VUDatagridView dgv_EpsonPosition;
        public NPSDK.NPInput IB_RobotLimit;
        private tstCkBox.MyCheckBox chk_SaveImg;
        private System.Windows.Forms.TextBox txtSavePath;
        private tstCkBox.MyCheckBox chk_SaveJpgImg;
        private System.Windows.Forms.Button btnPathSelect;
        private System.Data.DataColumn dataColumn118;
        private System.Data.DataColumn dataColumn119;
        private System.Data.DataColumn dataColumn120;
        private NPSDK.NPFlowChart flowChart76;
        private NPSDK.NPFlowChart flowChart77;
        private NPSDK.NPFlowChart flowChart73;
        private NPSDK.NPFlowChart flowChart74;
        private NPSDK.NPFlowChart flowChart79;
        private NPSDK.NPFlowChart flowChart78;
        private NPSDK.NPFlowChart flowChart75;
        private NPSDK.NPFlowChart flowChart72;
        private NPSDK.NPFlowChart flowChart69;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Data.DataTable dataTable6;
        private System.Data.DataColumn dataColumn121;
        private System.Data.DataColumn dataColumn122;
        private System.Data.DataColumn dataColumn123;
        private System.Data.DataColumn dataColumn124;
        private System.Data.DataColumn dataColumn125;
        private System.Data.DataColumn dataColumn126;
        private System.Data.DataColumn dataColumn127;
        private System.Data.DataColumn dataColumn128;
        private System.Data.DataColumn dataColumn129;
        private System.Data.DataColumn dataColumn130;
        private System.Data.DataColumn dataColumn131;
        private System.Data.DataColumn dataColumn132;
        private System.Data.DataColumn dataColumn133;
        private System.Data.DataColumn dataColumn134;
        private System.Data.DataColumn dataColumn135;
        private System.Data.DataColumn dataColumn136;
        private System.Data.DataColumn dataColumn137;
        private System.Data.DataColumn dataColumn138;
        private System.Data.DataColumn dataColumn139;
        private System.Data.DataColumn dataColumn140;
        private System.Data.DataColumn dataColumn141;
        private System.Data.DataColumn dataColumn142;
        private System.Data.DataColumn dataColumn143;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage3;
        private NPSDK.NPFlowChart flowChart4;
        private NPSDK.NPFlowChart flowChart5;
        private NPSDK.NPFlowChart flowChart6;
        private NPSDK.NPFlowChart flowChart30;
        private NPSDK.NPFlowChart flowChart46;
        private NPSDK.NPFlowChart flowChart47;
        private NPSDK.NPFlowChart flowChart48;
        private NPSDK.NPFlowChart flowChart49;
        private NPSDK.NPFlowChart flowChart50;
        private NPSDK.NPFlowChart flowChart51;
        private NPSDK.NPFlowChart flowChart61;
        private NPSDK.NPFlowChart flowChart70;
        private NPSDK.NPFlowChart flowChart68;
        private NPSDK.NPFlowChart flowChart64;
        private NPSDK.NPFlowChart flowChart63;
        private NPSDK.NPFlowChart flowChart71;
        private NPSDK.NPFlowChart flowChart80;
        private NPSDK.NPFlowChart flowChart81;
        private NPSDK.NPFlowChart flowChart82;
        private NPSDK.NPFlowChart flowChart66;
        private NPSDK.NPFlowChart flowChart83;
        public NPSDK.NPInput IB_FeederAlarm;
        private System.Data.DataColumn dataColumn144;
        private System.Data.DataColumn dataColumn145;
        private System.Data.DataColumn dataColumn146;
        private NPSDK.NPFlowChart npFlowChart1;
        private NPSDK.NPFlowChart npFlowChart2;
        private System.Windows.Forms.Button ResetPick;
        private System.Data.DataColumn dataColumn147;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.NumericUpDown DownCCDExpTime;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown ScanExpTime;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown LiveExpTime;
        private System.Windows.Forms.NumericUpDown DisChargeExpTime;
        private System.Windows.Forms.NumericUpDown PickExpTime;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Data.DataColumn dataColumn148;
        private System.Data.DataColumn dataColumn149;
        private System.Data.DataColumn dataColumn150;
        private System.Data.DataColumn dataColumn151;
        private System.Data.DataColumn dataColumn152;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lbR2SpeedRatio;
        public System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.Label label43;
        private System.Data.DataColumn dataColumn153;
        private System.Data.DataColumn dataColumn154;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox txtTaskValue;
        private System.Data.DataColumn dataColumn155;
        private NPSDK.NPFlowChart npFlowChart6;
        private NPSDK.NPFlowChart npFlowChart5;
        private NPSDK.NPFlowChart npFlowChart4;
        private NPSDK.NPFlowChart npFlowChart3;
        private NPSDK.NPFlowChart npFlowChart7;
        private NPSDK.NPFlowChart npFlowChart11;
        private NPSDK.NPFlowChart npFlowChart12;
        private NPSDK.NPFlowChart npFlowChart13;
        private NPSDK.NPFlowChart npFlowChart10;
        private NPSDK.NPFlowChart npFlowChart9;
        private NPSDK.NPFlowChart npFlowChart8;
        private NPSDK.NPFlowChart npFlowChart19;
        private NPSDK.NPFlowChart npFlowChart14;
        private NPSDK.NPFlowChart npFlowChart15;
        private NPSDK.NPFlowChart npFlowChart16;
        private NPSDK.NPFlowChart npFlowChart17;
        private NPSDK.NPFlowChart npFlowChart18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private Cognex.VisionPro.CogRecordDisplay cogRecDisp1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button ResetDischarge;
        private NPSDK.NPFlowChart npFlowChart20;
        private NPSDK.NPFlowChart npFlowChart21;
        private NPSDK.NPFlowChart npFlowChart22;
        private NPSDK.NPFlowChart npFlowChart23;
        private NPSDK.NPFlowChart npFlowChart24;
        private NPSDK.NPFlowChart npFlowChart25;
        private NPSDK.NPFlowChart npFlowChart26;
        private NPSDK.NPFlowChart npFlowChart27;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private tstCkBox.MyCheckBox myCheckBox3;
        private tstCkBox.MyCheckBox myCheckBox1;
        private tstCkBox.MyCheckBox myCheckBox2;
        private System.Data.DataColumn dataColumn156;
        private System.Data.DataColumn dataColumn157;
        private System.Data.DataColumn dataColumn158;
        private Cognex.VisionPro.CogRecordDisplay cogRecDisp_H5_Recipe;
        private System.Windows.Forms.Button button4;
        private tstCkBox.MyCheckBox myCheckBox4;
        private System.Data.DataColumn dataColumn159;
        private NPSDK.NPFlowChart npFlowChart29;
        private NPSDK.NPFlowChart npFlowChart28;
        private System.Data.DataColumn dataColumn160;
        private NPSDK.NPFlowChart npFlowChart30;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown num_maxPY;
        private System.Windows.Forms.NumericUpDown num_maxPX;
        private System.Windows.Forms.NumericUpDown num_minPY;
        private System.Windows.Forms.NumericUpDown num_minPX;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button button11;
        private System.Data.DataColumn dataColumn161;
        private System.Data.DataColumn dataColumn162;
        private System.Data.DataColumn dataColumn163;
        private System.Data.DataColumn dataColumn164;
        private System.Data.DataColumn dataColumn165;
        private System.Data.DataColumn dataColumn166;
        private System.Data.DataColumn dataColumn167;
        private System.Data.DataColumn dataColumn168;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.NumericUpDown num_maxFY;
        private System.Windows.Forms.NumericUpDown num_maxFX;
        private System.Windows.Forms.NumericUpDown num_minFY;
        private System.Windows.Forms.NumericUpDown num_minFX;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Data.DataColumn dataColumn169;
        private NPSDK.NPFlowChart npFlowChart32;
        private NPSDK.NPFlowChart npFlowChart31;
        private System.Windows.Forms.TabControl tabControl8;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel108;
        private NPSDK.NPFlowChart RGP_0001;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label81;
        private System.Data.DataColumn dataColumn170;
    }
}
