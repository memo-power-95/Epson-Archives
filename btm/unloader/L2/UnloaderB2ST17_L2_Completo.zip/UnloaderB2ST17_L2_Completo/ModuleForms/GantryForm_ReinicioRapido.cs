﻿using Alpha.Classes;
using System;
using System.Windows.Forms;
using static Alpha.FunctionForms.LogForm;

namespace Alpha._0.ModuleForms
{
    //MOD@@ Guillermo Carrillo - Unloader B2ST17 REINICIO RAPIDO (igual que la Unloader B1ST17 de linea 1)
    //
    //  El mismo reinicio rapido de las maquinas de Top y de la B2ST02 v1.3.0. El boton de Aaron (btnStopCurrent ->
    //  fnAbortCurrentProcess -> RESETPROCESS) se quito de la pantalla; en su lugar va REINICIO RAPIDO
    //  (MainForm.btn_RestartProcess_Click). El reinicio de Aaron queda SOLO para el STOP que pide el MES (no se toco).
    //
    //  Por que es mas seguro: NO brinca ningun paso que mueva la maquina. Es la inicializacion normal del proveedor
    //  (FlowCtrl.InitialReset, la misma de Inicializar) con todas sus validaciones y en su orden.
    //  El robot se para y se resetea (Stop + Reset), arranca su programa y va a la posicion segura (comando 013 GobackSafety), igual que en Inicializar.
    //  Solo se brincan pasos que no mueven nada y tardan:
    //    npFlowChart31                delete files / FilesMonitor
    //    flowChart96                  (si el MES ya estaba en linea) Initial MES (reconexion SECS/GEM + 1.5 s)
    //    npFlowChart3                 (si el MES ya estaba en linea) OFFLINE
    //    npFlowChart4                 (si el MES ya estaba en linea) IDLE REASON
    //    npFlowChart5                 (si el MES ya estaba en linea) MODULE LIST
    //    npFlowChart6                 (si el MES ya estaba en linea) OP CALL
    //    fc_ConnectScanner            Connect Scanner (se sigue esperando a las puertas)
    //    fc_CloseVisLight             fotos de prueba (la luz si se apaga)
    //  El conveyor se inicializa igual que en Inicializar (no se toco).
    //  Banderas: bRestartQuickActive y bRestartQuickSkipMes se apagan al terminar la inicializacion, con Stop, con
    //  Inicializar o si se cancela la ventana "execute initialize?" de fnInitial.
    public partial class GantryForm
    {
        private volatile bool bRestartQuickActive = false;
        private volatile bool bRestartQuickSkipMes = false;

        public bool ReinicioRapidoEnCurso { get { return bRestartQuickActive; } }

        //  Desde el boton (hilo de la ventana). true = quedo armado y se puede inicializar; false = no se toca nada.
        public bool PrepararReinicioRapido()
        {
            if (bRestartQuickActive)
            {
                using (Form dueno = new Form { TopMost = true })
                    MessageBox.Show(dueno, "El reinicio rapido ya esta en proceso.", "Reinicio rapido");
                return false;
            }
            bool mesEnLinea = MesYaEnLineaRemota();
            using (Form dueno = new Form { TopMost = true })
            {
                string texto = "REINICIO RAPIDO\r\n\r\n"
                    + "El robot se para y se resetea (Stop + Reset), arranca su programa y va a la posicion segura (comando 013 GobackSafety), igual que en Inicializar.\r\n\r\n"
                    + "Se brinca solo lo que no mueve nada: archivos, escaner, fotos de prueba"
                    + (mesEnLinea ? " y la reconexion del MES (ya esta en linea)" : "") + ".\r\n\r\n"
                    + "ANTES de continuar revise que la garra del robot este ARRIBA y sin pieza, y que el area del robot este despejada. Continuar?";
                if (MessageBox.Show(dueno, texto, "Reinicio rapido", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    return false;
            }
            bRestartQuickSkipMes = mesEnLinea;
            bRestartQuickActive = true;
            MiddleLayer.LogF.AddLog(LogType.Production, "Reinicio rapido: inicia"
                + (mesEnLinea ? ", MES ya en Online_Remote (no se reconecta)" : ", MES no estaba en linea (se inicializa completo)"), true);
            return true;
        }

        //  Stop, Inicializar, o una inicializacion que no se pudo arrancar.
        public void CancelarReinicioRapido()
        {
            if (bRestartQuickActive)
                MiddleLayer.LogF.AddLog(LogType.Production, "Reinicio rapido: cancelado, se apagan las banderas", true);
            bRestartQuickActive = false;
            bRestartQuickSkipMes = false;
        }

        //  Ultimo paso de la inicializacion de la Gantry.
        private void TerminarReinicioRapidoGantry()
        {
            if (bRestartQuickActive)
                MiddleLayer.LogF.AddLog(LogType.Production, "Reinicio rapido: inicializacion terminada", true);
            bRestartQuickActive = false;
            bRestartQuickSkipMes = false;
        }

        //  Las mismas validaciones que la Top Cover 1.0.6.9. Ante cualquier duda: false (se reconecta el MES completo).
        private bool MesYaEnLineaRemota()
        {
            if (!SysPara.EnableMes) return false;
            try
            {
                var mes = MESLib.CommParas.MesManager;
                if (mes == null || !mes.MesInitE || mes._connector == null) return false;
                return (MESLib.ControlState)Convert.ToInt32(mes._connector.SV.CurrentControlState.content)
                    == MESLib.ControlState.Online_Remote;
            }
            catch
            {
                return false;
            }
        }
    }
}
