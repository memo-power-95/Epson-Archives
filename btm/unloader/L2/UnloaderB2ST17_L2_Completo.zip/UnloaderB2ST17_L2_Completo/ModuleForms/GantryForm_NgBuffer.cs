using Alpha._0.Classes;
using NPSDK;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using static Alpha.FunctionForms.LogForm;

namespace Alpha._0.ModuleForms
{
    //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: la pieza que rechazo el MES va al NG buffer
    //
    //  Paso nuevo del flujo "MES NG -> NG buffer" (fcNgMes), entre flowChart50 ("wait and judge feeder inplace") y
    //  flowChart26 ("Robot to discharge picture pos"). Si ningun gripper trae una pieza rechazada, sigue de inmediato:
    //  todo queda como el proveedor.
    //  Si trae alguna, antes de dejar el grupo en la charola la deja en el NG buffer con los MISMOS pasos que el
    //  proveedor usa al Inicializar (npFlowChart24 a npFlowChart27) y la Unloader de linea 2 en produccion:
    //    1. lugar libre del NG buffer segun las marcas de la receta (NGbuffer1 a NGbuffer4);
    //    2. 017: el robot va a la camara del NG buffer;
    //    3. foto (H1_NGCCDCheck): si el lugar tiene pieza, se marca lleno y se busca otro;
    //    4. 016: el robot deja la pieza de ESE gripper en ese lugar;
    //    5. se marca el lugar como lleno en la receta.
    //  Despues la descarga sigue igual que siempre: el robot deja el grupo en la charola de un solo movimiento y en el
    //  lugar de la pieza rechazada queda un hueco (como cuando una pieza no pasa la foto).
    //  Si los 4 lugares estan llenos: aviso 0006 del proveedor ("NG is full") y el paso espera a que se vacie el NG
    //  buffer y se apriete "NG Rset" en la Gantry (no hay ventanas dentro del flujo).
    public partial class GantryForm
    {
        int estadoNgMes = 0;
        int gripperNgMes = -1;
        string lugarNgMes = "";
        bool avisoNgLlenoDado = false;
        readonly JTimer relojNgMes = new JTimer();

        private void OlvidarNgBuffer()
        {
            estadoNgMes = 0;
            gripperNgMes = -1;
            lugarNgMes = "";
            avisoNgLlenoDado = false;
        }

        private FCResultType fcNgMes_FlowRun(object sender, EventArgs e)
        {
            try
            {
                switch (estadoNgMes)
                {
                    case 0:   // siguiente gripper con una pieza rechazada
                        gripperNgMes = -1;
                        for (int g = 0; g < 3; g++)
                        {
                            if (gripperRechazado[g] && SysPara.iProductCountOnGrapper[g] == 1) { gripperNgMes = g; break; }
                        }
                        if (gripperNgMes < 0)
                        {
                            //  ninguna (o ya se dejaron todas): el grupo siguiente empieza limpio
                            //  MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo: en ese modo el MES ya contesto por TODO el pallet; los rechazos
                            //  de los grupos que faltan se conservan hasta el siguiente pallet (flowChart21).
                            if (!mpcActivo) for (int i = 0; i < rechazadaPorMes.Length; i++) rechazadaPorMes[i] = false;
                            for (int g = 0; g < 3; g++) gripperRechazado[g] = false;
                            return FCResultType.NEXT;
                        }
                        estadoNgMes = 1;
                        return FCResultType.IDLE;

                    case 1:   // lugar libre del NG buffer
                        lugarNgMes = LugarLibreDelNgBuffer();
                        if (lugarNgMes == null)
                        {
                            if (!avisoNgLlenoDado)
                            {
                                avisoNgLlenoDado = true;
                                MiddleLayer.LogF.AddLog(LogType.Production, "Pieza rechazada por el MES: el NG buffer esta lleno; vacielo y apriete NG Rset", true);
                                SysPara.NPShowAlarm("0006");
                            }
                            return FCResultType.IDLE;
                        }
                        avisoNgLlenoDado = false;
                        estadoNgMes = 2;
                        return FCResultType.IDLE;

                    case 2:   // 017: a la camara del NG buffer (como npFlowChart22)
                        if (Robot.WriteToEpson("017", lugarNgMes, "FF", 20000))
                        {
                            MiddleLayer.LogF.AddLog(LogType.Production, "Pieza rechazada por el MES: robot a la camara del NG buffer " + lugarNgMes, SysPara.bEnableGeneralSaveLog);
                            relojNgMes.Restart();
                            estadoNgMes = 3;
                        }
                        return FCResultType.IDLE;

                    case 3:   // esperar al robot (como npFlowChart21)
                        {
                            int ret = Robot.ReadFromEpson();
                            if (ret == 1)
                            {
                                OB_RobotLight.On();
                                estadoNgMes = 4;
                            }
                            else if (ret != 0 && relojNgMes.On(SysPara.TimeOutSec))
                            {
                                SDKKernal.ShowAlarm("1639");
                                relojNgMes.Restart();
                            }
                            return FCResultType.IDLE;
                        }

                    case 4:   // foto: el lugar tiene que estar vacio (como npFlowChart20)
                        {
                            bool vacio = LugarDelNgBufferVacio();
                            OB_RobotLight.Off();
                            if (!vacio)
                            {
                                MiddleLayer.LogF.AddLog(LogType.Production, "Pieza rechazada por el MES: el lugar " + lugarNgMes + " del NG buffer no esta vacio, se busca otro", true);
                                MarcarLugarDelNgBuffer(lugarNgMes);
                                estadoNgMes = 1;
                                return FCResultType.IDLE;
                            }
                            estadoNgMes = 5;
                            return FCResultType.IDLE;
                        }

                    case 5:   // 016: dejar la pieza de ese gripper (como npFlowChart25)
                        {
                            string gripper = (gripperNgMes + 1).ToString("00");
                            if (Robot.WriteToEpson("016", lugarNgMes, gripper, 30000))
                            {
                                MiddleLayer.LogF.AddLog(LogType.Production, "Command：016 Pos：" + lugarNgMes + " AppIndex：" + gripper, SysPara.bEnableGeneralSaveLog);
                                relojNgMes.Restart();
                                estadoNgMes = 6;
                            }
                            return FCResultType.IDLE;
                        }

                    case 6:   // esperar al robot (como npFlowChart26)
                        {
                            int ret = Robot.ReadFromEpson();
                            if (ret == 1)
                            {
                                estadoNgMes = 7;
                            }
                            else if (ret != 0 && relojNgMes.On(SysPara.TimeOutSec))
                            {
                                SDKKernal.ShowAlarm("1153");
                                relojNgMes.Restart();
                            }
                            return FCResultType.IDLE;
                        }

                    case 7:   // marcar el lugar lleno (como npFlowChart27); ese gripper ya va vacio
                        MarcarLugarDelNgBuffer(lugarNgMes);
                        gripperRechazado[gripperNgMes] = false;
                        MiddleLayer.LogF.AddLog(LogType.Production, "Pieza rechazada por el MES: gripper " + (gripperNgMes + 1)
                            + " dejada en el NG buffer, lugar " + lugarNgMes, true);
                        estadoNgMes = 0;
                        return FCResultType.IDLE;
                }
            }
            catch (Exception ex)
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Pieza rechazada por el MES: error en el paso del NG buffer: " + ex.Message, true);
            }
            return FCResultType.IDLE;
        }

        //  Igual que npFlowChart24: el primer lugar que la receta no tiene marcado como lleno. null = todos llenos.
        private string LugarLibreDelNgBuffer()
        {
            if (!GetRecipeValue("RSet", "NGbuffer1")) return "001";
            if (!GetRecipeValue("RSet", "NGbuffer2")) return "002";
            if (!GetRecipeValue("RSet", "NGbuffer3")) return "003";
            if (!GetRecipeValue("RSet", "NGbuffer4")) return "004";
            return null;
        }

        //  Igual que npFlowChart27.
        private void MarcarLugarDelNgBuffer(string lugar)
        {
            string columna = lugar == "002" ? "NGbuffer2" : lugar == "003" ? "NGbuffer3" : lugar == "004" ? "NGbuffer4" : "NGbuffer1";
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0][columna] = true;
            dt.AcceptChanges();
            this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        //  Igual que npFlowChart20. Si la foto falla, cuenta como NO vacio (se busca otro lugar), como el proveedor.
        private bool LugarDelNgBufferVacio()
        {
            try
            {
                double exposure = GetSettingValue("MSet", "DownCCDExpTime");
                if (!H1_NGCCDCheck.TakePicture(exposure)) return false;
                RefreshDifferentThreadUI(cogRecDisp_H5_Recipe, () =>
                {
                    cogRecDisp_H5_Recipe.Image = H1_NGCCDCheck.InputImage;
                    cogRecDisp_H5_Recipe.Fit();
                });
                H1_NGCCDCheck.RunTB();
                return Convert.ToBoolean(H1_NGCCDCheck.TB.Outputs["IsHaveProduct"].Value) == false;
            }
            catch
            {
                CCDAlogrithmStatus = false;
                SDKKernal.ShowAlarm("1205");
                return false;
            }
        }

        //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0 velocidad 3: las imagenes del grupo (npFlowChart30) se guardan
        //  en otro hilo con el mismo nombre, formato y carpeta; la original se libera al terminar (antes quedaba en
        //  memoria). En el paso solo se arman los nombres y los registros, como el proveedor.
        private FCResultType GuardarImagenesDelGrupoAparte()
        {
            try
            {
                string saveImgPath = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\";
                string eqpid = MiddleLayer.MesF2.GetSettingValue("PSet", "EQPID");
                List<KeyValuePair<Image, string>> trabajos = new List<KeyValuePair<Image, string>>();
                for (int i = 0; i < productImage1.Count; i++)
                {
                    string pcbCode = PCBCode[PickedPocketIDs[i]];
                    if (pcbCode == "" || pcbCode == null)
                        pcbCode = "NA";
                    string ImageName = string.Format(@"{0}_{1}_NA_NA_{2}_{3}.jpg",
                           pcbCode,
                           SysPara.sPalletCodes[PickedPocketIDs[i]],
                           productImage1[i].Timer,
                           eqpid);
                    trabajos.Add(new KeyValuePair<Image, string>(productImage1[i].Image, saveImgPath + ImageName));
                    ImageCode code = new ImageCode();
                    code.PalletCode = SysPara.sPalletCodes[PickedPocketIDs[i]];
                    code.PCBCode = pcbCode;
                    ImgCode.Add(code);
                }
                PCBCode = new string[12];
                productImage1.Clear();
                PickedPocketIDs.Clear();
                Task.Run(() =>
                {
                    foreach (KeyValuePair<Image, string> t in trabajos)
                    {
                        try
                        {
                            if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                            using (Bitmap objImg = new Bitmap(t.Key))
                            {
                                objImg.Save(t.Value, System.Drawing.Imaging.ImageFormat.Jpeg);
                            }
                        }
                        catch (Exception ex)
                        {
                            MiddleLayer.LogF.AddLog(LogType.Production, "No se pudo guardar la imagen " + t.Value + ": " + ex.Message, true);
                        }
                        finally
                        {
                            try { if (t.Key != null) t.Key.Dispose(); } catch { }
                        }
                    }
                });
            }
            catch (Exception)
            {
                productImage1.Clear(); PickedPocketIDs.Clear();
                PCBCode = new string[12];
            }
            return FCResultType.NEXT;
        }
    }
}
