using Alpha._0.Classes;
using Alpha._0.Vision;
using Alpha.FunctionForms;
using AcuraLibrary.Forms;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using Cognex.VisionPro.ImageFile;
using Cognex.VisionPro3D;
using NPSDK;
using LogSv;
using Microsoft.Win32;
using NPClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Alpha.FunctionForms.LogForm;
using static NPSDK.MotorBaseInterface;
using log4net;
using logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TcpipHelper;
using System.Dynamic;
using System.Diagnostics;
using System.Linq;
//using Alpha.MES;


namespace Alpha._0.ModuleForms
{

    public partial class GantryForm : ModuleBaseForm
    {
        List<int> PickedPocketIDs = new List<int>();

        public ProcessDataForm processData = MiddleLayer.ProcessF.fnGetDataForm("Alpha");

        public bool CCDAlogrithmStatus = false;

        #region 伺服模块属性变量 servo propertied
        bool isServoModuleIdel;
        int isMovingCmd = 0;
        bool bpushCmd = false;
        bool isServoModuleHome;
        List<NPMotor> motors = new List<NPMotor>();
        double[] targetPos = { 0, 0, 0 };
        public int servoWorkType;

        double[] heightRes = { 0, 0, 0, 0 };
        bool pressHeightRes = false;

        public int pressAndHeightCmd = 0;
        public int pressAndHeightResult = 0;
        #endregion

        //public int inPlaceAtScanner2=0;

        public int iScannerCmd = 0; //0,1,2
        public int iCameraCmd = 0;//0,1,2

        public string[] scanningString = { "", "" };
        public bool scanMaterialRes, scanPalletRes;

        public int Pickup_Odd_Even_Order = 1;
        public int Discharge_Order = 1;



        private int RouteIndex = 0;
        private int CycleIndex = 0;
        private bool BreakLinearServoOn = false;

        public bool RobotInitial = false;
        public string BarcodeString = "";

        public bool isTakePictureFinish = false;
        private int CalibPictureCount = 0;
        public bool bAutoCalibFlow = false;
        public bool bReadIOFlow = false;
        public List<Tuple<Cog3DVect3, CogImage8Grey>> visCalibData = new List<Tuple<Cog3DVect3, CogImage8Grey>>();

        public H1_PickupPos H1_PickupPos = new H1_PickupPos();
        public H1_DischargePos H1_DischargePos = new H1_DischargePos();
        public H1_NGCCDCheck H1_NGCCDCheck = new H1_NGCCDCheck();
        //public H1_Discharge2Pos H1_Discharge2Pos = new H1_Discharge2Pos();
        //public H1_DownCCDPickup H1_DownCCDPickup = new H1_DownCCDPickup();
        public bool pinResult = true;

        public string[] DataTotal = new string[24];
        public bool TPFP = true;

        public int sindex = 0;

        public int CurrentDisplayCount { set; get; }
        JTimer FeedinTimer = new JTimer();

        public double heightMax;
        public double heightMin;
        public double pressMax, pressMin;
        public bool isPutDown = false;
        public bool canDischarge = false;
        public bool isServoHome = false;
        public int ComIndex = 9;

        public double downCCDOrderL = 1;
        public double downCCDOrderR = 1;
        public bool isServoAlm = false;
        public bool isLastProduct = false;
        public bool isPressNG = false;
        public bool isHeightNG = false;
        public bool isPCBNULL = false;
        public JTimer readPressTimer = new JTimer();
        public JTimer PressTimer = new JTimer();
        public JTimer ReadIOTimer = new JTimer();
        public JTimer WriteIOTimer = new JTimer();
        public JTimer InitTM = new JTimer();
        public JTimer FeederTM = new JTimer();
        public bool isNGDiskHaveM = false;

        public double[] ReadRobotR = new double[101];
        public double[,] ReadRobotPR = new double[101, 6];
        BackgroundWorker bgwEpsonCommunicate;
        public Epson Robot = new Epson();
        public string updownsignal;
        public string feedersignal;
        public bool specialevents;
        public bool specialevents2;
        public bool cleargrapperfinish;
        public JTimer specialtimer = new JTimer();
        //public Servo servo; 
        string[] PCBCode = new string[12];


        string ngPos = "000";
        string gripper = "00";
        Reintento reintento = new Reintento();

        string[] dgvHeader = new string[] { "Num", "Name", "CmdCode", "PosIndex", "GrapIndex", "X_Pos", "Y_Pos", "Z_Pos", "Annotaion" };
        string[] dgvHeaderErr = new string[] { "Num", "Name", "CmdCode", "Alarm Content" };

        public ProcessDataForm processDataform = MiddleLayer.ProcessF.fnGetDataForm("Alpha");
        public struct SaveImage
        {
            public Image Image;
            public string Timer;
            public bool result;
        }
        public struct ImageCode
        {
            public string PCBCode;
            public string PalletCode;
        }
        List<ImageCode> ImgCode = new List<ImageCode>();
        List<SaveImage> productImage1 = new List<SaveImage>();
        List<SaveImage> FeederImage1 = new List<SaveImage>();
        /// <summary>
        /// ReadIO
        /// </summary>
        private string[] _readIO = new string[16];
        public string[] ReadIO
        {
            get
            {
                return _readIO;
            }
            set
            {
                _readIO = value;
                RefreshDifferentThreadUI(bt_Input_1, () => { bt_Input_1.BackgroundImage = _readIO[0].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_2, () => { bt_Input_2.BackgroundImage = _readIO[1].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_3, () => { bt_Input_3.BackgroundImage = _readIO[2].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_4, () => { bt_Input_4.BackgroundImage = _readIO[3].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_5, () => { bt_Input_5.BackgroundImage = _readIO[4].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_6, () => { bt_Input_6.BackgroundImage = _readIO[5].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_7, () => { bt_Input_7.BackgroundImage = _readIO[6].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_8, () => { bt_Input_8.BackgroundImage = _readIO[7].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_9, () => { bt_Input_9.BackgroundImage = _readIO[8].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_10, () => { bt_Input_10.BackgroundImage = _readIO[9].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_11, () => { bt_Input_11.BackgroundImage = _readIO[10].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_12, () => { bt_Input_12.BackgroundImage = _readIO[11].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_13, () => { bt_Input_13.BackgroundImage = _readIO[12].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_14, () => { bt_Input_14.BackgroundImage = _readIO[13].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_15, () => { bt_Input_15.BackgroundImage = _readIO[14].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
                RefreshDifferentThreadUI(bt_Input_16, () => { bt_Input_16.BackgroundImage = _readIO[15].ToString() == "1" ? Properties.Resources.Green : Properties.Resources.Red; });
            }
        }

        /// <summary>
        /// WriteIO
        /// </summary>
        private string[] _writeIO = new string[16] { "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0" };
        public string[] WriteIO
        {
            get
            {
                return _writeIO;
            }
            set
            {
                _writeIO = value;
                RefreshDifferentThreadUI(chk_Output_1, () => { chk_Output_1.Checked = _writeIO[0] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_2, () => { chk_Output_2.Checked = _writeIO[1] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_3, () => { chk_Output_3.Checked = _writeIO[2] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_4, () => { chk_Output_4.Checked = _writeIO[3] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_5, () => { chk_Output_5.Checked = _writeIO[4] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_6, () => { chk_Output_6.Checked = _writeIO[5] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_7, () => { chk_Output_7.Checked = _writeIO[6] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_8, () => { chk_Output_8.Checked = _writeIO[7] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_9, () => { chk_Output_9.Checked = _writeIO[8] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_10, () => { chk_Output_10.Checked = _writeIO[9] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_11, () => { chk_Output_11.Checked = _writeIO[10] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_12, () => { chk_Output_12.Checked = _writeIO[11] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_13, () => { chk_Output_13.Checked = _writeIO[12] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_14, () => { chk_Output_14.Checked = _writeIO[13] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_15, () => { chk_Output_15.Checked = _writeIO[14] == "1" ? true : false; });
                RefreshDifferentThreadUI(chk_Output_16, () => { chk_Output_16.Checked = _writeIO[15] == "1" ? true : false; });
            }
        }


        Reintento TipsFrm;
        private void DisposeFrm(Reintento tipsFrm)
        {
            if (tipsFrm != null)
            {
                tipsFrm.Close();
                tipsFrm.Dispose();
            }
        }

        #region【Save all tables position(保存各表的坐标)】
        public void SaveAxisPosPara()
        {
            string positionPath = Path.Combine(Application.StartupPath + @"\EpsonPosition.xml");
            dgv_EpsonPosition.SaveXmlFileFromPath(positionPath);

            positionPath = Path.Combine(Application.StartupPath + @"\EpsonErrInfo.xml");
            dgv_EpsonErrInfo.SaveXmlFileFromPath(positionPath);
        }
        #endregion
        public GantryForm()
        {
            //string testFormat = string.Format("{0:000.000}", 1.2);
            Control.CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();

            SetInputOutputIP(this.plMaintenance);


            GetComList();

            //添加实时显示控件
            H1_PickupPos.RecordDisplayList.Add(cogRecordDisplay_Pickup);
            H1_DischargePos.RecordDisplayList.Add(cogRecordDisplay_Discharge);
            //H1_DownCCDPickup.RecordDisplayList.Add(cogRecordDisplay3);

            //补充主页面显示挂载 
            //H1_PickupPos.RecordDisplayList.Add(MiddleLayer.MachineMainF.cogRecDisp1);
            //H1_DischargePos.RecordDisplayList.Add(MiddleLayer.MachineMainF.cogRecDisp2); 

            dgv_EpsonPosition.DgvHeader = dgvHeader;
            dgv_EpsonPosition.RaiseSelectedEvent += VUDatagridView1_RaiseSelectedEvent;
            dgv_EpsonPosition.LoadXmlFileFromPath(Application.StartupPath + @"\EpsonPosition.xml");

            dgv_EpsonErrInfo.DgvHeader = dgvHeaderErr;
            dgv_EpsonErrInfo.RaiseSelectedEvent += dgv_ErrInfo_RaiseSelectedEvent;
            dgv_EpsonErrInfo.LoadXmlFileFromPath(Application.StartupPath + @"\EpsonErrInfo.xml");

            InitBackGround();

            SysPara.CableDetectTh = new Thread(new ThreadStart(tm_CableDetection_Tick));
            SysPara.CableDetectTh.IsBackground = true;
            SysPara.CableDetectTh.Start();
            tabControl7.Controls.Remove(tabPage1);
            tabControl7.Controls.Remove(tabPage9);
            LoadTrayRecordsFromFile();
        }

        public void SetInputOutputIP(Control _ctrl)
        {
            if (_ctrl is NPSDK.NPInput)
            {
                ((NPSDK.NPInput)_ctrl).IP = "172.168.100.100.1.1";
            }
            if (_ctrl is NPSDK.NPOutput)
            {
                ((NPSDK.NPOutput)_ctrl).IP = "172.168.100.100.1.1";
            }
            foreach (var item in _ctrl.Controls)
            {
                SetInputOutputIP((Control)item);
            }
        }

        public void GetComList()
        {
            RegistryKey keyCom = Registry.LocalMachine.OpenSubKey("Hardware\\DeviceMap\\SerialComm");
            if (keyCom != null)
            {
                string[] sSubKeys = keyCom.GetValueNames();

                foreach (string sName in sSubKeys)
                {
                    string sValue = (string)keyCom.GetValue(sName);
                }
                //cmbComPort.SelectedIndex = 6;
            }
        }

        //private void InitBackGround()
        //{
        //    if (bgwEpsonCommunicate == null) { bgwEpsonCommunicate = new BackgroundWorker(); }

        //    bgwEpsonCommunicate.WorkerSupportsCancellation = true;
        //    bgwEpsonCommunicate.WorkerReportsProgress = true;
        //    bgwEpsonCommunicate.DoWork += new DoWorkEventHandler(bgwEpsonCommunicate_DoWork);
        //    bgwEpsonCommunicate.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bgwEpsonCommunicate_RunWorkerCompleted);
        //}

        private void InitBackGround()
        {
            if (bgwEpsonCommunicate == null)
            {
                bgwEpsonCommunicate = new BackgroundWorker();
                bgwEpsonCommunicate.WorkerSupportsCancellation = true;
                bgwEpsonCommunicate.WorkerReportsProgress = false;
                // IMPORTANT:
                // Prevent duplicate registration
                bgwEpsonCommunicate.DoWork -= bgwEpsonCommunicate_DoWork;
                bgwEpsonCommunicate.DoWork += bgwEpsonCommunicate_DoWork;
                bgwEpsonCommunicate.RunWorkerCompleted -= bgwEpsonCommunicate_RunWorkerCompleted;
                bgwEpsonCommunicate.RunWorkerCompleted += bgwEpsonCommunicate_RunWorkerCompleted;
            }
        }

        //private void bgwEpsonCommunicate_DoWork(object sender, DoWorkEventArgs e)
        //{
        //    do
        //    {
        //        Robot.Recive();
        //        Thread.Sleep(10);
        //    } while (Robot.ConnectStatus);
        //}
        private void bgwEpsonCommunicate_DoWork(object sender,DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;

            try
            {
                while (Robot.ConnectStatus)
                {
                    // Cancel Support
                    if (worker.CancellationPending)
                    {
                        e.Cancel = true;
                        return;
                    }
                    try
                    {
                        Robot.Recive();
                    }
                    catch (Exception ex)
                    {
                        Log.log.Write($"Robot Recive Error : {ex}",Color.Red);
                        break;
                    }
                    // IMPORTANT:
                    // Prevent high CPU
                    Thread.Sleep(50);
                }
            }
            catch (Exception ex)
            {
                Log.log.Write($"Robot Thread Error : {ex}", Color.Red);
            }
        }

        //private void bgwEpsonCommunicate_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        //{
        //    Log.log.Write("Robot Disconnected", Color.Black);
        //}
        private void bgwEpsonCommunicate_RunWorkerCompleted(object sender,RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                Log.log.Write("Robot Communication Stopped",Color.Black);
            }
            else if (e.Error != null)
            {
                Log.log.Write($"Robot Thread Error : {e.Error}",Color.Red);
            }
            else
            {
                Log.log.Write("Robot Disconnected",Color.Black);
            }
        }

        private void Btn_ConnectRobot_Click(object sender, EventArgs e)
        {
            if (ConnectEpsonRobot())
            {
                btnConnectResult.Text = "ConnectSuccess";
                btnConnectResult.BackColor = Color.Green;

                MiddleLayer.LogF.AddLog(LogType.Production, "Robot connect success", SysPara.bEnableGeneralSaveLog);

            }
            else
            {
                btnConnectResult.Text = "ConnectFail";
                btnConnectResult.BackColor = Color.Red;
                MiddleLayer.LogF.AddLog(LogType.Production, "Robot connect failed", SysPara.bEnableGeneralSaveLog);

            }
        }

        private void btnReadR_Click(object sender, EventArgs e)
        {
            if (Robot.ReadFromEpson() == 1)
            {
                txtReadData.Text = Robot.ReadRobotStr;
                btnReadR.BackColor = Color.Green;
            }
            else
            {
                btnReadR.BackColor = Color.Red;
            }
        }


        //public static bool DelayMs(int delayMilliseconds)
        //{
        //    DateTime now = DateTime.Now;
        //    Double s;
        //    do
        //    {
        //        TimeSpan spand = DateTime.Now - now;
        //        s = spand.Seconds * 1000;
        //        Application.DoEvents();
        //        Thread.Sleep(1);
        //    }
        //    while (s < delayMilliseconds);
        //    return true;
        //}

        public static void DelayMs(int delayMilliseconds)
        {
            DateTime start = DateTime.Now;

            while ((DateTime.Now - start).TotalMilliseconds < delayMilliseconds)
            {
                Application.DoEvents();
                Thread.Sleep(1);
            }
        }
        private void btnWritePR_Click(object sender, EventArgs e)
        {
            if (Robot.WriteToEpson(textBox49.Text, "FFF", "FF", 59000, numWritePR1.Value.ToString(), numWritePR2.Value.ToString(), numericUpDown1.Value.ToString()))
            {
                btnWritePR.BackColor = Color.Green;
            }
            else
            {
                btnWritePR.BackColor = Color.Red;
            }
        }



        private bool ConnectBarcode1()
        {
            if (KeyenceBarcode1.ConnectStatus())
            {
                return true;
            }
            else
            {
                KeyenceBarcode1.Disconnect();
                string IP = GetRecipeValue("RSet", "ScannerIP");//PSet.BardodeIP
                string Port = GetRecipeValue("RSet", "ScannerPort");//PSet.BardodeIP
                int iPort = Convert.ToInt32(Port);//PSet.BarcodePort
                KeyenceBarcode1.Connect(IP, iPort);
                return true;
            }
        }

        private bool ConnectBarcode2()
        {
            if (KeyenceBarcode2.ConnectStatus())
            {
                return true;
            }
            else
            {
                KeyenceBarcode2.Disconnect();
                string IP = GetRecipeValue("RSet", "ScannerIP");//PSet.BardodeIP
                string Port = GetRecipeValue("RSet", "ScannerPort");//PSet.BardodeIP
                int iPort = Convert.ToInt32(Port);//PSet.BarcodePort
                KeyenceBarcode2.Connect(IP, iPort);
                return true;
            }
        }


        /// <summary>
        ///  
        /// </summary>
        /// <returns></returns>
        /// 
        TCPCLient KeyenceBarcode1 = new TCPCLient();
        TCPCLient KeyenceBarcode2 = new TCPCLient();

        private string GetBarcode1()
        {
            if (KeyenceBarcode1.ConnectStatus())
            {
                KeyenceBarcode1.Sent("LON" + "\r\n");
                Thread.Sleep(500);
                string str = (KeyenceBarcode1.Receive().Replace("\r", "")).Replace("\n", "");
                KeyenceBarcode1.Sent("LOFF" + "\r\n");
                KeyenceBarcode1.Sent("LON" + "\r\n");
                Thread.Sleep(500);
                string BarcodeString1 = (KeyenceBarcode1.Receive().Replace("\r", "")).Replace("\n", "");
                KeyenceBarcode1.Sent("LOFF" + "\r\n");
                if (BarcodeString1.Contains("ERROR"))
                {
                    BarcodeString1 = BarcodeString1.Replace("ERROR", "");
                }
                return BarcodeString1;
            }
            else
            {
                return string.Empty;
            }
        }

        private string GetBarcode2()
        {
            if (KeyenceBarcode2.ConnectStatus())
            {
                KeyenceBarcode2.Sent("LON" + "\r\n");
                Thread.Sleep(500);
                string BarcodeString2 = (KeyenceBarcode2.Receive().Replace("\r", "")).Replace("\n", "");

                if (BarcodeString2.Contains("ERROR"))
                {
                    BarcodeString2 = BarcodeString2.Replace("ERROR", "");
                }
                return BarcodeString2;
            }
            else
            {
                return string.Empty;
            }
        }

        public bool TrigerBarcode()
        {
            RefreshDifferentThreadUI(tbMassage, () =>
            {
                tbMassage.Text = "";
            });
            if (KeyenceBarcode1.ConnectStatus())
            {
                try
                {
                    int length = KeyenceBarcode1.tcpClient.Client.Available;
                    if (length > 0)
                    {
                        byte[] recived = new byte[length];
                        KeyenceBarcode1.tcpClient.Client.Receive(recived);
                    }
                }
                catch (Exception) { }
                KeyenceBarcode1.Sent("LON" + "\r\n");

                int timer = Convert.ToInt16(GetRecipeValue("RSet", "scantimer"));
                Thread.Sleep(timer);
                RefreshDifferentThreadUI(tbMassage, () =>
                {
                    SysPara.QRCode1 = KeyenceBarcode1.Receive().Trim();
                    tbMassage.Text = SysPara.QRCode1;
                });
                if (SysPara.QRCode1.Contains("ERROR"))
                {
                    return false;
                }
                return true;
            }
            else { return false; }
        }


        #region append0208
        public override void InitialReset()
        {
            RobotInitial = false;
            fc_InitialStart.TaskReset();
        }



        private void btnConScan1_Click(object sender, EventArgs e)
        {
            ConnectBarcode1();
            if (KeyenceBarcode1.ConnectStatus())
            {
                btnConScan1.BackColor = Color.Green;
            }

            //ConnectBarcode2();
            //if (KeyenceBarcode2.ConnectStatus())
            //{
            //    btnConScan2.BackColor = Color.Green;
            //}
        }




        private void btnStarScan1_Click(object sender, EventArgs e)
        {
            //TrigerBarcode1();
            TrigerBarcode();

        }

        private void btndisConScan1_Click(object sender, EventArgs e)
        {
            KeyenceBarcode1.Disconnect();
            btnConScan1.BackColor = Color.Red;
        }



        private TCPCLient KeyenceLaser = new TCPCLient();





        public override void Initial()
        {
            fc_InitialStart.TaskRun();
        }
        public override void RestartProcessReset()
        {
            
            RGP_0001.TaskReset();
        }
        public override void RestartProcess()
        {
            
            RGP_0001.TaskRun();
        }
        public override void RunReset()
        {
            flowChart69.TaskReset();
            //fc_FDStart.TaskReset();
            fc_RobotStart.TaskReset();
            fc_ReflashR1AlramInfo.TaskReset();

        }

        public override void Run()
        {
            flowChart69.TaskRun();
            //fc_FDStart.TaskRun();
            fc_RobotStart.TaskRun();
            fc_ReflashR1AlramInfo.TaskRun();
        }


        public void RobotStart(int num)
        {
            if (num == 1)
            {
                OB_RobotContinue.On();
                Thread.Sleep(500);
                OB_RobotContinue.Off();

                OB_RobotProg1.Off();
                OB_RobotReset.Off();
                //OB_Robot1CycleStop.On();
                Thread.Sleep(500);
                //OB_Robot1CycleStop.Off();
                OB_RobotStart.Off();

                OB_RobotPause.On();
                OB_RobotStop.On();

                OB_RobotReset.On();
                Thread.Sleep(500);
                OB_RobotStart.On();
                OB_RobotReset.Off();
                Thread.Sleep(500);
                OB_RobotStart.Off();
                OB_RobotProg1.On();
                Thread.Sleep(500);
                OB_RobotProg1.Off();
            }

        }

        #endregion


        #region 伺服相关函数 servo Functions

        public override void ServoOn()
        {
            if (motors == null)
            {
                return;
            }
            for (int i = 0; i < motors.Count; i++)
            {
                motors[i].ServoOn();
            }
            isServoModuleIdel = true;
        }


        public override void ServoOff()
        {
            for (int i = 0; i < motors.Count; i++)
            {
                motors[i].ServoOff();
            }
            isServoModuleIdel = false;
        }



        public void StopAllMortos()
        {
            for (int i = 0; i < motors.Count; i++)
            {
                motors[i].Stop();
            }

        }



        #region reion1

        private void btnEnableRbt_Click(object sender, EventArgs e)
        {
            RobotStart(1);
        }

        private void btnWriteR_Click(object sender, EventArgs e)
        {

            if (Robot.WriteToEpson(textBox49.Text, "FFF", "FF", 59000))
            {
                btnWriteR.BackColor = Color.Green;
            }
            else
            {
                btnWriteR.BackColor = Color.Red;
            }
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            H1_PickupPos.RunLive(cogRecDisp1);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button8_Click(object sender, EventArgs e)
        {
            OB_RobotLight.On();
        }
        /// <summary>
        ///  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button9_Click(object sender, EventArgs e)
        {
            OB_RobotLight.Off();
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button10_Click(object sender, EventArgs e)
        {
            H1_PickupPos.EditTB();
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            //H1_DischargePos.RunLive(cogRecDisp2);
            //H1_DownCCDPickup.RunLiveCCDIndex = 1;     
            //H1_DownCCDPickup.RunLive(cogRecDisp2);

            //H2_PickupPos.RunLiveCCDIndex = 1;
            //H2_PickupPos.RunLive(cogRecDisp2);
        }




        /// <summary>
        ///  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {
            H1_DischargePos.EditTB();
            //H1_DownCCDPickup.EditTB()/*;*/
        }

        private void btnPickPos1AlogrithmEditing_Click(object sender, EventArgs e)
        {
            H1_PickupPos.EditTB();
        }

        private void btnPickPosStartCalib_Click(object sender, EventArgs e)
        {
            this.flowChart100.TaskReset();
            bAutoCalibFlow = false;
            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                while (!bAutoCalibFlow)
                {
                    flowChart100.TaskRun();
                }
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTeachPickVisPos_Click(object sender, EventArgs e)
        {
            H1_PickupPos.RunTB();
            DataTable dt = RecipeData.Tables["Rset"];
            if (H1_PickupPos.IsAccept)
            {
                dt.Rows[0]["PickTeachVisX"] = H1_PickupPos.GetOutput("X").ToString();
                dt.Rows[0]["PickTeachVisY"] = H1_PickupPos.GetOutput("Y").ToString();
                dt.Rows[0]["PickTeachVisU"] = H1_PickupPos.GetOutput("Angle").ToString();
                dt.AcceptChanges();
            }
            else
            {
                dt.Rows[0]["PickTeachVisX"] = Convert.ToString(999.999);
                dt.Rows[0]["PickTeachVisY"] = Convert.ToString(999.999);
                dt.Rows[0]["PickTeachVisU"] = Convert.ToString(999.999);
                dt.AcceptChanges();
            }
        }


        private void btnTeachPickRobotPos_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            //if (RobotZebra.ReadPR(20, ref ReadRobotPR)) //PR20
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "005", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["PickTeachRobotX"] = x.ToString();
            dt.Rows[0]["PickTeachRobotY"] = y.ToString();
            dt.Rows[0]["PickTeachRobotU"] = u.ToString();
            dt.AcceptChanges();
        }

        private void btnTeachPickVisPos2_Click(object sender, EventArgs e)
        {



            H1_PickupPos.RunTB();
            //H1_DownCCDPickup.RunTB();
            //while (!H2_PickupPos.RunTBOk())
            //{ Thread.Sleep(2); }
            DataTable dt = RecipeData.Tables["Rset"];
            if (H1_PickupPos.IsAccept)
            {
                dt.Rows[0]["PickTeachVisX2"] = H1_PickupPos.GetOutput("X").ToString();
                dt.Rows[0]["PickTeachVisY2"] = H1_PickupPos.GetOutput("Y").ToString();
                dt.Rows[0]["PickTeachVisU2"] = H1_PickupPos.GetOutput("Angle").ToString();
                dt.AcceptChanges();
            }
            else
            {
                dt.Rows[0]["PickTeachVisX2"] = Convert.ToString(999.999);
                dt.Rows[0]["PickTeachVisY2"] = Convert.ToString(999.999);
                dt.Rows[0]["PickTeachVisU2"] = Convert.ToString(999.999);
                dt.AcceptChanges();
            }
        }

        private void btnTeachPickRobotPos2_Click(object sender, EventArgs e)
        {


            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            //if (RobotZebra.ReadPR(20, ref ReadRobotPR)) //PR20
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "005", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["PickTeachRobotX2"] = x.ToString();
            dt.Rows[0]["PickTeachRobotY2"] = y.ToString();
            dt.Rows[0]["PickTeachRobotU2"] = u.ToString();
            dt.AcceptChanges();

        }
        private void ResetRobot()
        {
            if (ConnectEpsonRobot())
            {
                OB_RobotPause.Off();
                OB_RobotStart.Off();
                OB_RobotProg1.Off();
                OB_RobotProg2.Off();
                OB_RobotProg3.Off();
                OB_RobotStop.Off();
                OB_RobotContinue.Off();
                OB_RobotReset.Off();

                OB_RobotStop.On();
                DelayMs(500);
                OB_RobotStop.Off();
                OB_RobotReset.On();
                DelayMs(500);
                OB_RobotReset.Off();
            }
        }
        private void startRobot()
        {
            if (IB_RobotReady.On())
            {
                OB_RobotStart.On();
                DelayMs(1000);
                OB_RobotStart.Off();
            }
        }
        private FCResultType flowChart100_FlowRun(object sender, EventArgs e)
        {
            ResetRobot();
            DelayMs(100);
            startRobot();
            return FCResultType.NEXT;
        }

        private FCResultType flowChart99_FlowRun(object sender, EventArgs e)
        {
            CalibPictureCount = 0;
            visCalibData.Clear();
            if (Robot.WriteToEpson("014", "005", "FF", 3000, "FFFFFFF", "FFFFFFF", "FFFFFFF"))
            {
                RobotPose = Robot.ReadRobotXYU;
                DelayMs(100);
                RunTM.Restart();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart98_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec)) { return FCResultType.IDLE; }
            else { return FCResultType.IDLE; }
        }
        double[] RobotPose = new double[3];
        public bool SendAutoCalibration(int index, int CameraIndex)
        {
            if (CameraIndex == 1)
            {
                RobotPose[0] = Convert.ToDouble(txtPickPosRobotX1.Text);
                RobotPose[1] = Convert.ToDouble(txtPickPosRobotY1.Text);
                RobotPose[2] = Convert.ToDouble(txtPickPosRobotU1.Text);
            }
            else if (CameraIndex == 2)
            {
                RobotPose[0] = Convert.ToDouble(txtDisChargeRobotX1.Text);
                RobotPose[1] = Convert.ToDouble(txtDisChargeRobotY1.Text);
                RobotPose[2] = Convert.ToDouble(txtDisChargeRobotU1.Text);
            }
            else if (CameraIndex == 3)
            {
                RobotPose[0] = Convert.ToDouble(textBox42.Text);
                RobotPose[1] = Convert.ToDouble(textBox43.Text);
                RobotPose[2] = Convert.ToDouble(textBox44.Text);
            }
            switch (index)
            {
                case 1:
                    RobotPose[0] = RobotPose[0] - 5; RobotPose[1] = RobotPose[1] - 5; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "-05.000", "-05.000", "000.000");
                case 2:
                    RobotPose[0] = RobotPose[0] - 0; RobotPose[1] = RobotPose[1] - 5; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "000.000", "-05.000", "000.000");
                case 3:
                    RobotPose[0] = RobotPose[0] + 5; RobotPose[1] = RobotPose[1] - 5; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "005.000", "-05.000", "000.000");
                case 4:
                    RobotPose[0] = RobotPose[0] + 5; RobotPose[1] = RobotPose[1] - 0; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "005.000", "000.000", "000.000");
                case 5:
                    RobotPose[0] = RobotPose[0] + 0; RobotPose[1] = RobotPose[1] - 0; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "000.000", "000.000", "000.000");
                case 6:
                    RobotPose[0] = RobotPose[0] - 5; RobotPose[1] = RobotPose[1] - 0; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "-05.000", "000.000", "000.000");
                case 7:
                    RobotPose[0] = RobotPose[0] - 5; RobotPose[1] = RobotPose[1] + 5; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "-05.000", "005.000", "000.000");
                case 8:
                    RobotPose[0] = RobotPose[0] - 0; RobotPose[1] = RobotPose[1] + 5; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "000.000", "005.000", "000.000");
                case 9:
                    RobotPose[0] = RobotPose[0] + 5; RobotPose[1] = RobotPose[1] + 5; RobotPose[2] = RobotPose[2] - 0;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "005.000", "005.000", "000.000");
                case 10:
                    RobotPose[0] = RobotPose[0] - 5; RobotPose[1] = RobotPose[1] - 5; RobotPose[2] = RobotPose[2] + 3;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "-05.000", "-05.000", "003.000");
                case 11:
                    RobotPose[0] = RobotPose[0] - 5; RobotPose[1] = RobotPose[1] - 5; RobotPose[2] = RobotPose[2] - 3;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "-05.000", "-05.000", "-03.000");
                case 12:
                    RobotPose[0] = RobotPose[0] + 0; RobotPose[1] = RobotPose[1] + 0; RobotPose[2] = RobotPose[2] + 3;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "000.000", "000.000", "003.000");
                case 13:
                    RobotPose[0] = RobotPose[0] + 0; RobotPose[1] = RobotPose[1] + 0; RobotPose[2] = RobotPose[2] + 6;
                    return Robot.WriteToEpson("014", (100 + index).ToString("FFF"), "FF", 30000, "000.000", "000.000", "006.000");
                default:
                    return true;
            }
        }


        private FCResultType flowChart94_FlowRun(object sender, EventArgs e)
        {
            if (SendAutoCalibration(CalibPictureCount + 1, 1))
            {
                DelayMs(100);
                RunTM.Restart();
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart95_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {

                SysPara.NPShowAlarm("1153");
                return FCResultType.IDLE;
            }        //R timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart97_FlowRun(object sender, EventArgs e)
        {

            OB_RobotLight.On();
            DelayMs(200);
            CogImage8Grey img = null;
            Cog3DVect3 xyu = new Cog3DVect3();
            if (H1_PickupPos.TakePicture())
            {
                img = H1_PickupPos.InputImage;
                if (Robot.ConnectStatus)
                {
                    if (Robot.WriteToEpson("015", "000", "FF", 20000, "FFFFFFF", "FFFFFFF", "FFFFFFF"))//Robot.ReadFromEpson()==1)
                    {
                        double[] Pos = new double[3];
                        Pos = RobotPose;
                        xyu = new Cog3DVect3(Pos[0], Pos[1], Pos[2]);
                    }
                    else { return FCResultType.IDLE; }
                }
                else { return FCResultType.IDLE; }

                Tuple<Cog3DVect3, CogImage8Grey> xyu_Image = new Tuple<Cog3DVect3, CogImage8Grey>(xyu, img);
                visCalibData.Add(xyu_Image);
                CalibPictureCount++;
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart93_FlowRun(object sender, EventArgs e)
        {
            if (CalibPictureCount >= 11)
            {
                return FCResultType.CASE1;
            }
            else
                return FCResultType.NEXT;
        }

        private FCResultType flowChart92_FlowRun(object sender, EventArgs e)
        {
            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                if (!H1_PickupPos.TB.Inputs.Contains("CalibDatas"))
                {
                    H1_PickupPos.TB.Inputs.Add(new Cognex.VisionPro.ToolBlock.CogToolBlockTerminal("CalibDatas", new List<Tuple<Cog3DVect3, CogImage8Grey>>()));
                }
                H1_PickupPos.visCalibData = visCalibData;
                H1_PickupPos.TB.Inputs["ISCalib"].Value = true;
                H1_PickupPos.TB.Inputs["GrabPosIndex"].Value = 0;
                H1_PickupPos.RunTB();
                H1_PickupPos.TB.Inputs["ISCalib"].Value = false;
                OB_RobotLight.Off();
                DataTable dt = RecipeData.Tables["R1_PickVisCalib"];
                List<Tuple<Cog3DVect2, Cog3DVect2>> visRobotData = new List<Tuple<Cog3DVect2, Cog3DVect2>>();
                visRobotData = H1_PickupPos.GetOutput("VisRobotData") as List<Tuple<Cog3DVect2, Cog3DVect2>>;
                if (H1_PickupPos.IsAccept)
                {
                    dt.Clear();

                    for (int i = 0; i < visRobotData.Count; i++)
                    {
                        DataRow row = dt.NewRow();
                        row["Calib_Index"] = (i + 1).ToString();
                        row["Calib_PixelX"] = visRobotData[i].Item1.X.ToString("f3");
                        row["Calib_PixelY"] = visRobotData[i].Item1.Y.ToString("f3");
                        row["Calib_RobotX"] = visRobotData[i].Item2.X.ToString("f3");
                        row["Calib_RobotY"] = visRobotData[i].Item2.Y.ToString("f3");
                        dt.Rows.Add(row);
                    }
                    dt.AcceptChanges();
                }
                else
                {
                    dt.Rows[0]["Calib_Index"] = "0";
                    dt.Rows[0]["Calib_PixelX"] = "999";
                    dt.Rows[0]["Calib_PixelY"] = "999";
                    dt.Rows[0]["Calib_RobotX"] = "999";
                    dt.Rows[0]["Calib_RobotY"] = "999";
                    dt.AcceptChanges();
                }
            });
            //WriteToRobotR(30, 0);
            bAutoCalibFlow = true;
            return FCResultType.IDLE;
        }
        #endregion
        #region R1 refresh alarms
        private FCResultType fc_ReflashR1AlramInfo_FlowRun(object sender, EventArgs e)
        {
            //bool errorStop = false;
            //for (int i = 0; i < JSDK.Alarm.AlarmList.Count; i++)
            //{
            //    if (JSDK.Alarm.AlarmList[i].DoStop)
            //    {
            //        errorStop = true;
            //        break;
            //    }
            //}
            //if (errorStop)
            //{
            //    MiddleLayer.GantryF.OB_RobotPause.Off();
            //    MiddleLayer.ConveyorF.OB_UpCvyMtFwd.Off();
            //    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} click pause");
            //    if (SysPara.SystemRun)
            //        LogManagement.Instance.SaveLog(LogManagement.LogType.MachineStatus, "Idle");
            //    MiddleLayer.StopRun();
            //}

            return FCResultType.NEXT;
        }

        private FCResultType flowChart102_FlowRun(object sender, EventArgs e)
        {
            //if (MiddleLayer.GantryF.ReflashRobotR())
            //{
            //    if (MiddleLayer.GantryF.ReadRobotR[2] == -1)
            //    {
            //        SysPara.NPShowAlarm("2101");
            //    }
            //    else if (MiddleLayer.GantryF.ReadRobotR[2] == -2)
            //    {
            //        SysPara.NPShowAlarm("2102");
            //    }
            //    else if (MiddleLayer.GantryF.ReadRobotR[2] == -3)
            //    {
            //        SysPara.NPShowAlarm("2103");
            //    }
            //    else if (MiddleLayer.GantryF.ReadRobotR[2] == -4)
            //    {
            //        SysPara.NPShowAlarm("2104");
            //    }
            //    else if (MiddleLayer.GantryF.ReadRobotR[2] == -5)
            //    {
            //        SysPara.NPShowAlarm("2105");
            //    }
            //    else if (MiddleLayer.GantryF.ReadRobotR[2] == -6)
            //    {
            //        SysPara.NPShowAlarm("2106");
            //    }
            //    if (MiddleLayer.GantryF.ReadRobotR[4] == -1)
            //    {
            //        SysPara.NPShowAlarm("2401");
            //    }
            //    if (MiddleLayer.GantryF.ReadRobotR[5] == -1)
            //    {
            //        SysPara.NPShowAlarm("2501");
            //    }
            //    if (MiddleLayer.GantryF.ReadRobotR[6] == -1)
            //    {
            //        SysPara.NPShowAlarm("2601");
            //    }
            //    return FCResultType.NEXT;
            //}
            //else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart101_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        private void btnAutoCom1_Pressure_Click(object sender, EventArgs e)
        {
            tmRefresh.Start();
        }

        private void btnStopAuto_Click(object sender, EventArgs e)
        {
            tmRefresh.Stop();
        }



        void savePressLimToDataSet()
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["PressMax"] = pressMax;
            dt.Rows[0]["PressMin"] = pressMin;
            dt.AcceptChanges();
            MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        void saveHeightLimToDataSet()
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["HeightHLim"] = heightMax;
            dt.Rows[0]["HeightLLim"] = heightMin;
            dt.AcceptChanges();
            MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        void saveVacIndexToDataSet()
        {
            DataTable dt = RecipeData.Tables["RSet"];
            //dt.Rows[0]["VacIndex"] = SysPara.iVacIndex;
            dt.Rows[0]["VacIndex"] = (SysPara.iVacIndex - 1) * 3 + SysPara.grapperIndex;
            dt.AcceptChanges();
            MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        void saveTrayCountToDataSet(int count)
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["TrayCount"] = count;
            dt.AcceptChanges();
            MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        void savePickNumToDataSet()
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["PickPosIndex"] = Pickup_Odd_Even_Order;
            dt.AcceptChanges();
            MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }
        private void button2_Click(object sender, EventArgs e)
        {

            if (int.TryParse(txt_PickPos.Text, out Pickup_Odd_Even_Order))
            {
                savePickNumToDataSet();
                txt_PickPos.ForeColor = Color.Black;
            }
            else
            {
                txt_PickPos.Text = CycleIndex.ToString();
                txt_PickPos.ForeColor = Color.Red;
            }

        }

        private void tmRefresh_Tick(object sender, EventArgs e)
        {
            //string strPressure = PressReadCOM.ReadContent_COM1();
            //double _Pressure = double.Parse(strPressure);
            tmRefresh.Enabled = false;
            if (MiddleLayer.ProcessF.GetSettingValue("PSet", "dcEnableCheckProcess"))
            {
                SysPara.NPShowAlarm("0008");
            }
            else
            {
                SDKKernal.ClearAlarm("0008");
            }
            if (MiddleLayer.ProcessF.GetSettingValue("PSet", "IsDryCycleMode"))
            {
                SysPara.NPShowAlarm("0011");
            }
            else
            {
                SDKKernal.ClearAlarm("0011");
            }

            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
            {
                SysPara.NPShowAlarm("0013");
            }
            else
            {
                SDKKernal.ClearAlarm("0013");
            }

            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
            {
                SysPara.NPShowAlarm("0014");
            }
            else
            {
                SDKKernal.ClearAlarm("0014");
            }
            string dateTimeStr = DateTime.Now.ToString("yyyyMMdd");
            if (GetSettingValue("PSet", "dateTime") != dateTimeStr)
            {
                DataTable dt = SettingData.Tables["PSet"];
                dt.Rows[0]["dateTime"] = dateTimeStr;
                dt.AcceptChanges();
                MiddleLayer.SystemF.WriteSettingData();
                string path = @"D:\WorkLog\PickupImageVac_BMP";
                string path1 = @"D:\WorkLog\PickupImageVac_JPG";
                string path2 = @"D:\DataSave\backup";
                SaveFile.DeleteFile(path1, 3);
                SaveFile.DeleteFile(path2, 3);
                SaveFile.DeleteFile(path, 3);

                string path3 = @"D:\DateLog";
                string path4 = @"D:\WorkLog\PutdownImageVac_BMP";
                string path5 = @"D:\WorkLog\PutdownImageVac_JPG";
                SaveFile.DeleteFile(path3, 3);
                SaveFile.DeleteFile(path4, 3);
                SaveFile.DeleteFile(path5, 3);
                string path6 = @"D:\EVMS\TP\LOG";
                SaveFile.DeleteFile1(path6, 21);
            }
            if (SaveFile.DriveFreeSpace(20))
                SDKKernal.ShowAlarm("0020");
            tmRefresh.Enabled = true;


        }
        #endregion

        private void button27_Click(object sender, EventArgs e)
        {

        }


        private void button5_Click(object sender, EventArgs e)
        {
            string[] pos1 = GetDataByAnnotation(dgv_EpsonPosition, "GetPosition");
            if (pos1 != null)
            {
                if (Robot.WriteToEpson(pos1[2], pos1[3], pos1[4], 30000))
                {
                    int ret = Robot.ReadFromEpson();
                    if (ret == 12)
                    {
                        txtReadPRX.Text = Robot.ReadRobotXYU[0].ToString();
                        txtReadPRY.Text = Robot.ReadRobotXYU[1].ToString();
                        txtReadPRZ.Text = Robot.ReadRobotXYU[2].ToString();
                    }
                }
                else
                {
                    txtReadPRX.Text = "-999.999";
                    txtReadPRY.Text = "-999.999";
                    txtReadPRZ.Text = "-999.999";
                }
            }
        }


        #endregion



        private void button13_Click_1(object sender, EventArgs e)
        {
            H1_DischargePos.EditTB();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.flowChart115.TaskReset();
            bAutoCalibFlow = false;
            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                while (!bAutoCalibFlow)
                {
                    flowChart115.TaskRun();
                }
            });
        }
        private void button15_Click(object sender, EventArgs e)
        {
            H1_DischargePos.RunTB();
            DataTable dt = RecipeData.Tables["Rset"];
            if (H1_DischargePos.IsAccept)
            {
                dt.Rows[0]["DischargeTeachVisX"] = H1_DischargePos.GetOutput("X").ToString();
                dt.Rows[0]["DischargeTeachVisY"] = H1_DischargePos.GetOutput("Y").ToString();
                dt.Rows[0]["DischargeTeachVisU"] = H1_DischargePos.GetOutput("Angle").ToString();
                dt.AcceptChanges();
            }
            else
            {
                dt.Rows[0]["DischargeTeachVisX"] = Convert.ToString(999.999);
                dt.Rows[0]["DischargeTeachVisY"] = Convert.ToString(999.999);
                dt.Rows[0]["DischargeTeachVisU"] = Convert.ToString(999.999);
                dt.AcceptChanges();
            }
        }
        private void button16_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "011", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["DischargeTeachRobotX"] = x;
            dt.Rows[0]["DischargeTeachRobotY"] = y;
            dt.Rows[0]["DischargeTeachRobotU"] = u;
            dt.AcceptChanges();
        }
        private void button17_Click(object sender, EventArgs e)
        {

            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "011", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["DischargeTeachRobotX2"] = x;
            dt.Rows[0]["DischargeTeachRobotY2"] = y;
            dt.Rows[0]["DischargeTeachRobotU2"] = u;
            dt.AcceptChanges();

        }
        private void button18_Click(object sender, EventArgs e)
        {

            H1_DischargePos.RunTB();
            DataTable dt = RecipeData.Tables["Rset"];
            if (H1_DischargePos.IsAccept)
            {
                dt.Rows[0]["DischargeTeachVisX2"] = H1_DischargePos.GetOutput("X").ToString();
                dt.Rows[0]["DischargeTeachVisY2"] = H1_DischargePos.GetOutput("Y").ToString();
                dt.Rows[0]["DischargeTeachVisU2"] = H1_DischargePos.GetOutput("Angle").ToString();
                dt.AcceptChanges();
            }
            else
            {
                dt.Rows[0]["DischargeTeachVisX2"] = Convert.ToString(999.999);
                dt.Rows[0]["DischargeTeachVisY2"] = Convert.ToString(999.999);
                dt.Rows[0]["DischargeTeachVisU2"] = Convert.ToString(999.999);
                dt.AcceptChanges();
            }
        }

        private FCResultType flowChart115_FlowRun(object sender, EventArgs e)
        {
            ResetRobot();
            DelayMs(100);
            startRobot();
            return FCResultType.NEXT;
        }

        private FCResultType flowChart114_FlowRun(object sender, EventArgs e)
        {
            CalibPictureCount = 0;
            visCalibData.Clear();
            if (Robot.WriteToEpson("014", "011", "FF", 30000, "FFFFFFF", "FFFFFFF", "FFFFFFF"))
            {
                RobotPose = Robot.ReadRobotXYU;
                DelayMs(100);
                RunTM.Restart();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart113_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec)) { return FCResultType.IDLE; }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart110_FlowRun(object sender, EventArgs e)
        {
            if (SendAutoCalibration(CalibPictureCount + 1, 2))
            {
                DelayMs(100);
                RunTM.Restart();
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart111_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {

                SysPara.NPShowAlarm("1153");
                return FCResultType.IDLE;
            }        //R timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart112_FlowRun(object sender, EventArgs e)
        {

            OB_RobotLight.On();
            // DelayMs(2000);
            CogImage8Grey img = null;
            Cog3DVect3 xyu = new Cog3DVect3();
            //DelayMs(3000);
            if (H1_DischargePos.TakePicture())
            {
                img = H1_DischargePos.InputImage;
                if (Robot.ConnectStatus)
                {
                    if (Robot.WriteToEpson("015", "000", "FF", 20000, "FFFFFFF", "FFFFFFF", "FFFFFFF"))//Robot.ReadFromEpson()==1)
                    {
                        double[] Pos = new double[3];
                        Pos = RobotPose;
                        xyu = new Cog3DVect3(Pos[0], Pos[1], Pos[2]);
                    }
                    else { return FCResultType.IDLE; }
                }
                else { return FCResultType.IDLE; }

                Tuple<Cog3DVect3, CogImage8Grey> xyu_Image = new Tuple<Cog3DVect3, CogImage8Grey>(xyu, img);
                visCalibData.Add(xyu_Image);
                CalibPictureCount++;
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart109_FlowRun(object sender, EventArgs e)
        {
            if (CalibPictureCount >= 11)
            {
                return FCResultType.CASE1;
            }
            else
                return FCResultType.NEXT;
        }

        private FCResultType flowChart108_FlowRun(object sender, EventArgs e)
        {

            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                if (!H1_DischargePos.TB.Inputs.Contains("CalibDatas"))
                {
                    H1_DischargePos.TB.Inputs.Add(new Cognex.VisionPro.ToolBlock.CogToolBlockTerminal("CalibDatas", new List<Tuple<Cog3DVect3, CogImage8Grey>>()));
                }
                H1_DischargePos.visCalibData = visCalibData;
                H1_DischargePos.TB.Inputs["ISCalib"].Value = true;
                H1_DischargePos.TB.Inputs["GrabPosIndex"].Value = 0;
                H1_DischargePos.RunTB();
                H1_DischargePos.TB.Inputs["ISCalib"].Value = false;
                OB_RobotLight.Off();
                DataTable dt = RecipeData.Tables["R1_DischargeVisCalib"];
                List<Tuple<Cog3DVect2, Cog3DVect2>> visRobotData = new List<Tuple<Cog3DVect2, Cog3DVect2>>();
                visRobotData = H1_DischargePos.GetOutput("VisRobotData") as List<Tuple<Cog3DVect2, Cog3DVect2>>;
                if (H1_DischargePos.IsAccept)
                {
                    dt.Clear();

                    for (int i = 0; i < visRobotData.Count; i++)
                    {
                        DataRow row = dt.NewRow();
                        row["Calib_Index"] = (i + 1).ToString();
                        row["Calib_PixelX"] = visRobotData[i].Item1.X.ToString("f3");
                        row["Calib_PixelY"] = visRobotData[i].Item1.Y.ToString("f3");
                        row["Calib_RobotX"] = visRobotData[i].Item2.X.ToString("f3");
                        row["Calib_RobotY"] = visRobotData[i].Item2.Y.ToString("f3");
                        dt.Rows.Add(row);
                    }
                    dt.AcceptChanges();
                }
                else
                {
                    dt.Rows[0]["Calib_Index"] = "0";
                    dt.Rows[0]["Calib_PixelX"] = "999";
                    dt.Rows[0]["Calib_PixelY"] = "999";
                    dt.Rows[0]["Calib_RobotX"] = "999";
                    dt.Rows[0]["Calib_RobotY"] = "999";
                    dt.AcceptChanges();
                }
            });
            //WriteToRobotR(30, 0);
            bAutoCalibFlow = true;
            return FCResultType.IDLE;
        }

        private void button46_Click(object sender, EventArgs e)
        {

            FolderBrowserDialog fbDialog = new FolderBrowserDialog();
            if (fbDialog.ShowDialog() == DialogResult.OK)
            {
                textBox73.Text = fbDialog.SelectedPath;
            }
        }

        private void button47_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbDialog = new FolderBrowserDialog();
            if (fbDialog.ShowDialog() == DialogResult.OK)
            {
                textBox74.Text = fbDialog.SelectedPath;
            }
        }

        private void button48_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbDialog = new FolderBrowserDialog();
            if (fbDialog.ShowDialog() == DialogResult.OK)
            {
                textBox75.Text = fbDialog.SelectedPath;
            }
        }

        #region 机器人测试流程 robot debug flow

        bool bTestFlowControl = false;


        private FCResultType flowChart4_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                return FCResultType.IDLE;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart5_FlowRun(object sender, EventArgs e)
        {
            string[] pos1 = GetDataByAnnotation(dgv_EpsonPosition, "GetPosition");
            if (pos1 != null)
            {
                if (Robot.WriteToEpson(pos1[2], pos1[3], pos1[4], 30000))
                { return FCResultType.NEXT; }
                else { return FCResultType.IDLE; }
            }
            else
            { return FCResultType.IDLE; }

        }

        private FCResultType flowChart6_FlowRun(object sender, EventArgs e)
        {
            if (Robot.ReadFromEpson() == 12)
            {
                double[] a = Robot.ReadRobotXYU;
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }
        #endregion
        public void RefreshDifferentThreadUI(Control control, Action action)
        {
            if (control.InvokeRequired)
            {
                Action refreshUI = new Action(action);
                control.Invoke(refreshUI);
            }
            else
            {
                action.Invoke();
            }
        }

        public void ShowText(CogRecordDisplay recordDisplay, string text, CogColorConstants labelColor, CogColorConstants backgroundColor, double posX, double posY)
        {
            //if (recordDisplay.InteractiveGraphics.Count != 0)
            //recordDisplay.InteractiveGraphics.Clear();
            CogGraphicLabel lab = new CogGraphicLabel();
            lab.Font = new Font("Ariual", 15);
            lab.SelectedLineStyle = CogGraphicLineStyleConstants.Solid;
            lab.SelectedSpaceName = "@";
            lab.Color = labelColor;
            lab.SetXYText(posX, posY, text);
            lab.BackgroundColor = backgroundColor;
            recordDisplay.InteractiveGraphics.Add(lab, null, false);
        }


        #region 机器人点位表 robot position sheet
        private void VUDatagridView1_RaiseSelectedEvent(bool bComplete)
        {
            int index = dgv_EpsonPosition.myDgv.CurrentRow.Index;

            string[] selectedRowArr = dgv_EpsonPosition.GetDataArrayByIndex(index);

            DataGridViewRow dataGirdRow = dgv_EpsonPosition.GetDataGridRow(index);

            //tbx_X.Text = selectedRowArr[2];
            //tbx_Y.Text = selectedRowArr[3];
            //tbx_Z.Text = selectedRowArr[4];
        }

        private void dgv_ErrInfo_RaiseSelectedEvent(bool bComplete)
        {
            int index = dgv_EpsonErrInfo.myDgv.CurrentRow.Index;

            string[] selectedRowArr = dgv_EpsonErrInfo.GetDataArrayByIndex(index);

            DataGridViewRow dataGirdRow = dgv_EpsonErrInfo.GetDataGridRow(index);

            //tbx_X.Text = selectedRowArr[2];
            //tbx_Y.Text = selectedRowArr[3];
            //tbx_Z.Text = selectedRowArr[4];
        }

        public string[] GetDataByAnnotation(VUControl.VUDatagridView dgv, string annotation)
        {
            string[] GetDataInfo = dgv.GetDataArrayByFlagName(1, annotation);
            return GetDataInfo;
        }


        public bool ConnectEpsonRobot()
        {
            if (Robot.ConnectToEpson(MiddleLayer.GantryF.GetRecipeValue("RSet", "RobotPoint1"), MiddleLayer.GantryF.GetRecipeValue("RSet", "RobotPort")))
            {
                if (!bgwEpsonCommunicate.IsBusy)
                    bgwEpsonCommunicate.RunWorkerAsync();
                return true;
            }
            else
            {

                SysPara.NPShowAlarm("1635");
                return false;
            }
        }


        #endregion

        #region 获取机械手上IO  Get robot IO


        private FCResultType flowChart9_FlowRun(object sender, EventArgs e)
        {
            string[] pos1 = GetDataByAnnotation(dgv_EpsonPosition, "ReadRobotDI");
            if (ReadIOTimer.On(20000))
            {
                ReadIOTimer.Restart();
                Log.log.Write("ReadRobotDI Command send timeout", Color.Red);
                return FCResultType.NEXT;
            }
            if (Robot.WriteToEpson(pos1[2], pos1[3], pos1[4], 30000))
            {
                ReadIOTimer.Restart();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart11_FlowRun(object sender, EventArgs e)
        {
            ReadIOTimer.Restart();
            return FCResultType.NEXT;
        }


        public bool GetRobotDO()
        {
            string[] pos1 = GetDataByAnnotation(dgv_EpsonPosition, "WriteRobotDO");
            string[] s1 = new string[7];
            string[] s2 = new string[7];
            string[] s3 = new string[7];
            for (int i = 0; i < 21; i++)
            {
                if (i < 7) { s1[i] = WriteIO[i]; }
                else if (i >= 7 && i < 14) { s2[i - 7] = WriteIO[i]; }
                else if (i >= 14 && i < 16) { s3[i - 14] = WriteIO[i]; }
                else { s3[i - 14] = "F"; }
            }
            bool ret = Robot.WriteToEpson(pos1[2], pos1[3], "FF", 30000, string.Join("", s1), string.Join("", s2), string.Join("", s3));
            return ret;
        }



        private void bt_WriteIO_Click(object sender, EventArgs e)
        {
            WriteIOTimer.Restart();
            bool ret;
            bt_WriteIO.Enabled = false;
            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                while (true)
                {
                    ret = GetRobotDO();
                    if (ret || WriteIOTimer.On(20000)) { bt_WriteIO.Enabled = true; break; }
                }
            });

        }

        private void tabControl4_Selected(object sender, TabControlEventArgs e)
        {
            if (tabControl4.SelectedIndex == 1)
            {
                if (Robot.ConnectStatus)
                {
                    bt_ReadIO_Click(null, null);
                }
            }
        }

        private FCResultType flowChart13_FlowRun(object sender, EventArgs e)
        {
            string[] pos1 = GetDataByAnnotation(dgv_EpsonPosition, "ReadRobotDO");
            if (ReadIOTimer.On(20000))
            {
                ReadIOTimer.Restart();
                Log.log.Write("ReadRobotSpeed Command send timeout", Color.Red);
                return FCResultType.NEXT;
            }
            if (Robot.WriteToEpson(pos1[2], pos1[3], pos1[4], 30000))
            {
                ReadIOTimer.Restart();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart12_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ReadIOTimer.On(20000))
            {
                bReadIOFlow = true;
                bt_ReadIO.Enabled = true;
                Log.log.Write("ReadRobotSpeed recieve data timeout", Color.Red);
                return FCResultType.IDLE;
            }
            if (ret == 102)
            {
                WriteIO = Robot.Output;
                bReadIOFlow = true;
                bt_ReadIO.Enabled = true;
                return FCResultType.IDLE;
            }

            else { return FCResultType.IDLE; }
        }
        private void chk_Output_1_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_1.Checked)
            {
                chk_Output_1.BackgroundImage = Properties.Resources.Green;
                WriteIO[0] = "1";
            }
            else
            {
                chk_Output_1.BackgroundImage = Properties.Resources.Red;
                WriteIO[0] = "0";
            }
        }

        private void chk_Output_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_2.Checked)
            {
                chk_Output_2.BackgroundImage = Properties.Resources.Green;
                WriteIO[1] = "1";
            }
            else
            {
                chk_Output_2.BackgroundImage = Properties.Resources.Red;
                WriteIO[1] = "0";
            }
        }
        private void chk_Output_3_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_3.Checked)
            {
                chk_Output_3.BackgroundImage = Properties.Resources.Green;
                WriteIO[2] = "1";
            }
            else
            {
                chk_Output_3.BackgroundImage = Properties.Resources.Red;
                WriteIO[2] = "0";
            }
        }

        private void chk_Output_4_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_4.Checked)
            {
                chk_Output_4.BackgroundImage = Properties.Resources.Green;
                WriteIO[3] = "1";
            }
            else
            {
                chk_Output_4.BackgroundImage = Properties.Resources.Red;
                WriteIO[3] = "0";
            }
        }

        private void chk_Output_5_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_5.Checked)
            {
                chk_Output_5.BackgroundImage = Properties.Resources.Green;
                WriteIO[4] = "1";
            }
            else
            {
                chk_Output_5.BackgroundImage = Properties.Resources.Red;
                WriteIO[4] = "0";
            }
        }

        private void chk_Output_6_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_6.Checked)
            {
                chk_Output_6.BackgroundImage = Properties.Resources.Green;
                WriteIO[5] = "1";
            }
            else
            {
                chk_Output_6.BackgroundImage = Properties.Resources.Red;
                WriteIO[5] = "0";
            }
        }

        private void chk_Output_7_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_7.Checked)
            {
                chk_Output_7.BackgroundImage = Properties.Resources.Green;
                WriteIO[6] = "1";
            }
            else
            {
                chk_Output_7.BackgroundImage = Properties.Resources.Red;
                WriteIO[6] = "0";
            }
        }

        private void chk_Output_8_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_8.Checked)
            {
                chk_Output_8.BackgroundImage = Properties.Resources.Green;
                WriteIO[7] = "1";
            }
            else
            {
                chk_Output_8.BackgroundImage = Properties.Resources.Red;
                WriteIO[7] = "0";
            }
        }

        private void chk_Output_9_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_9.Checked)
            {
                chk_Output_9.BackgroundImage = Properties.Resources.Green;
                WriteIO[8] = "1";
            }
            else
            {
                chk_Output_9.BackgroundImage = Properties.Resources.Red;
                WriteIO[8] = "0";
            }
        }

        private void chk_Output_10_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_10.Checked)
            {
                chk_Output_10.BackgroundImage = Properties.Resources.Green;
                WriteIO[9] = "1";
            }
            else
            {
                chk_Output_10.BackgroundImage = Properties.Resources.Red;
                WriteIO[9] = "0";
            }
        }

        private void chk_Output_11_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_11.Checked)
            {
                chk_Output_11.BackgroundImage = Properties.Resources.Green;
                WriteIO[10] = "1";
            }
            else
            {
                chk_Output_11.BackgroundImage = Properties.Resources.Red;
                WriteIO[10] = "0";
            }
        }

        private void chk_Output_12_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_12.Checked)
            {
                chk_Output_12.BackgroundImage = Properties.Resources.Green;
                WriteIO[11] = "1";
            }
            else
            {
                chk_Output_12.BackgroundImage = Properties.Resources.Red;
                WriteIO[11] = "0";
            }
        }

        private void chk_Output_13_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_13.Checked)
            {
                chk_Output_13.BackgroundImage = Properties.Resources.Green;
                WriteIO[12] = "1";
            }
            else
            {
                chk_Output_13.BackgroundImage = Properties.Resources.Red;
                WriteIO[12] = "0";
            }
        }

        private void chk_Output_14_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_14.Checked)
            {
                chk_Output_14.BackgroundImage = Properties.Resources.Green;
                WriteIO[13] = "1";
            }
            else
            {
                chk_Output_14.BackgroundImage = Properties.Resources.Red;
                WriteIO[13] = "0";
            }
        }

        private void chk_Output_15_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_15.Checked)
            {
                chk_Output_15.BackgroundImage = Properties.Resources.Green;
                WriteIO[14] = "1";
            }
            else
            {
                chk_Output_15.BackgroundImage = Properties.Resources.Red;
                WriteIO[14] = "0";
            }
        }

        private void chk_Output_16_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Output_16.Checked)
            {
                chk_Output_16.BackgroundImage = Properties.Resources.Green;
                WriteIO[15] = "1";
            }
            else
            {
                chk_Output_16.BackgroundImage = Properties.Resources.Red;
                WriteIO[15] = "0";
            }
        }

        #region GantryInitial


        private FCResultType fc_InitialStart_FlowRun(object sender, EventArgs e)
        {
            OlvidarRechazosDelMes();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: ninguna decision del MES ni pieza rechazada pendiente
            global::Alpha.Classes.VelocidadUnloaderB1.Leer();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: opciones de velocidad (Velocidad.txt)
            SysPara.JAGStarytEvent.Reset();
            isServoAlm = false;
            SysPara.RIniRet = false;
            SysPara.cycleRunMode = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsDryCycleMode");
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.DryRunMode = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsDryCycleMode");

            SysPara.myCBNGBypass = MiddleLayer.ProcessF.GetSettingValue("PSet", "dcEnableCheckProcess");
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.ByPassMode = MiddleLayer.ProcessF.GetSettingValue("PSet", "dcEnableCheckProcess");

            productImage1.Clear();
            SysPara.myCBDisableInOutDoor = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsEnabledInOutDoor");
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.DisbleInOutDoor = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsEnabledInOutDoor");
            FeederImage1.Clear();
            ImgCode.Clear();
            return FCResultType.NEXT;
        }

        private FCResultType fc_ConnectScanner_FlowRun(object sender, EventArgs e)
        {
            //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: no se reconecta el escaner, pero se sigue esperando
            //  a que el conveyor termine las puertas (bLRDoorIniFinish), igual que siempre.
            if (bRestartQuickActive)
            {
                if (!SysPara.bLRDoorIniFinish) return FCResultType.IDLE;
                SysPara.bLRDoorIniFinish = false;
                return FCResultType.NEXT;
            }
            if (SysPara.bLRDoorIniFinish)
            {
                SysPara.bLRDoorIniFinish = false;
                bool status1 = ConnectBarcode1();
                if (status1)
                {
                    return FCResultType.NEXT;
                }
                else
                {
                    if (!status1)
                    {

                        SysPara.NPShowAlarm("1305");
                    }
                    return FCResultType.IDLE;
                }
            }
            else
            {
                return FCResultType.IDLE;
            }

        }

        private FCResultType fc_CloseVisLight_FlowRun(object sender, EventArgs e)
        {
            OB_RobotLight.Off();
            if (bRestartQuickActive) return FCResultType.NEXT;   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: luz apagada, sin fotos de prueba (la luz si se apaga)
            if (H1_PickupPos.TakePicture() && H1_DischargePos.TakePicture()/*&&H1_Discharge2Pos.TakePicture()*/)
            {
                return FCResultType.NEXT;
            }
            else
            {

                SysPara.NPShowAlarm("1200");
                return FCResultType.IDLE;
            }
        }

        private FCResultType fc_ResetR1_FlowRun(object sender, EventArgs e)
        {
            if (ConnectEpsonRobot())
            {
                OB_RobotPause.Off();
                OB_RobotStart.Off();
                OB_RobotProg1.Off();
                OB_RobotProg2.Off();
                OB_RobotProg3.Off();
                OB_RobotStop.Off();
                OB_RobotContinue.Off();
                OB_RobotReset.Off();

                OB_RobotStop.On();
                DelayMs(500);
                OB_RobotStop.Off();
                OB_RobotReset.On();
                DelayMs(500);
                OB_RobotReset.Off();

                MiddleLayer.LogF.AddLog(LogType.Production, "Initial reset robot", SysPara.bEnableGeneralSaveLog);

                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }



        private FCResultType fc_StartR1_FlowRun(object sender, EventArgs e)
        {
            if (IB_RobotReady.On())
            {
                startRobot();
                MiddleLayer.LogF.AddLog(LogType.Production, "Initial start robot", SysPara.bEnableGeneralSaveLog);

                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType fc_WaitR1Reset_FlowRun(object sender, EventArgs e)
        {

            if (IB_RobotBusy.On()) { return FCResultType.NEXT; }
            else { return FCResultType.IDLE; }

        }


        private FCResultType flowChart1_FlowRun(object sender, EventArgs e)
        {
            if (IB_FeederEmergencyStop.On())
            {

                SysPara.NPShowAlarm("1100");
                return FCResultType.IDLE;
            }
            else
            {
                if (IB_FeederAlarm.On())
                {
                    InitTM.Restart();
                    return FCResultType.CASE1;
                }
                else
                { OB_FeederSafetySignal.On(); specialevents = false; cleargrapperfinish = false; return FCResultType.NEXT; }
            }

        }

        private FCResultType flowChart2_FlowRun(object sender, EventArgs e)
        {
            OB_FeederAlmReset.On();
            if (InitTM.On(5000))
            {
                OB_FeederAlmReset.Off();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart96_FlowRun(object sender, EventArgs e)
        {
            if (bRestartQuickSkipMes) return FCResultType.NEXT;   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: MES ya en linea, se brinca (Initial MES (reconexion SECS/GEM + 1.5 s))

            SysPara.EnableMes = MiddleLayer.MesF2.GetSettingValue("PSet", "Enable_Mes");
            MESLib.CommParas.EnableMes = SysPara.EnableMes;
            if (!MESLib.CommParas.MesManager.MesInitE)
            {
                MESLib.CommParas.MesManager.MesInit();
                MESLib.CommParas.MesManager.MesInitE = true;

                string EQPName = MiddleLayer.MesF2.GetSettingValue("PSet", "EQPName");
                MESLib.CommParas.MesManager._connector.MDLN = EQPName;
                //MESLib.CommParas.MesManager._connector.MDLN = "Bottom Unloader #01";
            }

            MESLib.CommParas.IP = MiddleLayer.MesF2.GetSettingValue("PSet", "Mes_IP");
            MESLib.CommParas.Port = MiddleLayer.MesF2.GetSettingValue("PSet", "Mes_Port");
            if (SysPara.EnableMes)
            {
                // secgem
                MESLib.CommFuns.StartSecsGem(out string error);
                if (error != string.Empty)
                {
                    SysPara.NPShowAlarm("70105"); // secgem open fail
                    MESLib.CommParas.MesCenter.PauseRunning();
                    return FCResultType.IDLE;
                }
                System.Threading.Thread.Sleep(1500);
                if (!MESLib.CommParas.MesManager.MesConnect(MESLib.CommParas.IP, MESLib.CommParas.Port))
                {
                    SysPara.NPShowAlarm("70109"); // secgem open fail
                    //System.Threading.Thread.Sleep(1000);
                    //MESLib.CommParas.MesManager.MesClose();
                    return FCResultType.IDLE;
                }

            }

            return FCResultType.NEXT;
        }
        #endregion

        #region GantryAuto
        //gantry start reset all variables
        private FCResultType fc_RobotStart_FlowRun(object sender, EventArgs e)
        {
            SysPara.IsTryRun = true;
            SysPara.bScanResult = false;
            SysPara.bPitureResult = false;
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.AssembCompeletStatus = false;
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.NotifyAssembly = false;

            SysPara.bPhotoFailed = false;

            PickedPocketIDs.Clear();
            for (int i = 0; i < 12; i++)
            {
                SysPara.iContinuousNGVac[i] = 0;
            }
            for (int i = 0; i < 3; i++)
            {
                SysPara.iProductCountOnGrapper[i] = 0;
                SysPara.pickUpProductIndex[i] = 0;
                SysPara.ThreeResultDatas[i] = new ResultData("ProductCode", "PalletCode", "OK");
            }
            SysPara.grapperIndex = 0;
            SysPara.pictureOKCount = 0;
            SysPara.bCanDischarge = true;
            return FCResultType.NEXT;
        }

        private FCResultType flowChart15_FlowRun(object sender, EventArgs e)
        {
            if (SysPara.IsTryRun)
            {
                //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0 velocidad 1: IsTryRun se prende en cada Start
                //  (fc_RobotStart) y nunca se apaga: aqui se esperaban 3 s fijos por pallet. La revision se sigue
                //  saltando igual; solo sin la espera. Con la opcion apagada queda como el proveedor.
                if (!global::Alpha.Classes.VelocidadUnloaderB1.SinEsperaDe3s)
                    DelayMs(3000);
                return FCResultType.NEXT;
            }

            if (IB_FeederReady.On())
            {
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart17_FlowRun(object sender, EventArgs e)
        {
            bool iDisableFeeder = MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder");
            SysPara.ST1_StartTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");   //lhj_0706
            OB_FeederSafetySignal.On();

            if (MiddleLayer.ConveyorF.UpConveyorAutoFlow.NotifyAssembly)//SysPara.bNotifyStartUnloadWork == true)
            {
                SysPara.iScanPosIndex = 1;
                MiddleLayer.ConveyorF.UpConveyorAutoFlow.NotifyAssembly = false;

                MiddleLayer.LogF.AddLog(LogType.Production, "Start unload", SysPara.bEnableGeneralSaveLog);

                return FCResultType.NEXT;
            }
            //if convey the last group product not fall 3,wait in convey,if time to 240 seconds,convey until not come next vehicles.jump a choice to check,yes=>continue waite,no=>first to drop product in robot grapper then wait
            if (specialevents)                              //如果一盘料最后夹爪不满3个料，等240秒流道还没有来料，弹窗 点是就继续等  点否就先去把当前夹爪上料抛掉再等
            {
                if (iDisableFeeder || (IB_FeederInPlace.On() && IB_FeederReady.On()))
                { processDataform.PickingClearEnable = true; }
                else { processDataform.PickingClearEnable = false; }
                processDataform.UnloadEnable = false;
                if (SysPara.bPickingClear)
                {
                    processDataform.PickingClearEnable = false;
                    SysPara.bPickingClear = false;
                    specialevents2 = true;
                    specialevents = false;
                    SysPara.grapperIndex = 0;
                    //SysPara.iVacIndex = GetRecipeValue("RSet", "VacIndex");
                    int iGroupNumb = GetRecipeValue("RSet", "VacIndex") / 3;
                    if (GetRecipeValue("RSet", "VacIndex") % 3 == 0)
                    {
                        SysPara.iVacIndex = iGroupNumb;
                    }
                    else
                    {
                        SysPara.iVacIndex = iGroupNumb + 1;
                    }
                    SysPara.iVacIndex++;
                    if (SysPara.iVacIndex > SysPara.iVacCount)
                    {
                        //if (iDisableFeeder)
                        //{

                        //    SysPara.NPShowAlarm("8019");
                        //}
                        //else if (!iDisableFeeder)
                        //{

                        //    SysPara.NPShowAlarm("80192");
                        //}

                        SysPara.iVacIndex = 0;
                        saveVacIndexToDataSet();
                    }
                    SysPara.bCanDischarge = true;
                    saveVacIndexToDataSet();

                    Discharge_Order = 1;//LFF-0221

                    DataTable dt = RecipeData.Tables["RSet"];
                    dt.Rows[0]["VacIndex"] = Discharge_Order;// Convert.ToInt16(numericUpDown1.Text);
                    dt.AcceptChanges();
                    MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));

                    Pickup_Odd_Even_Order = 1;
                    //  DataTable dt = RecipeData.Tables["RSet"];
                    dt.Rows[0]["PickPosIndex"] = Pickup_Odd_Even_Order;
                    dt.AcceptChanges();
                    MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));


                    return FCResultType.CASE2;
                }
            }
            else
            {
                processDataform.PickingClearEnable = false;
                if (iDisableFeeder || (IB_FeederInPlace.On() && OB_FeederSafetySignal.GetState()))
                {
                    processDataform.UnloadEnable = true;
                }
                else
                {
                    processDataform.UnloadEnable = false;
                }
                if (SysPara.bUnload)
                {

                    Discharge_Order = 1;//LFF-0221

                    DataTable dt = RecipeData.Tables["RSet"];
                    dt.Rows[0]["VacIndex"] = Discharge_Order;// Convert.ToInt16(numericUpDown1.Text);
                    dt.AcceptChanges();
                    MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));

                    SysPara.bUnload = false;
                    //                  processDataform.UnloadEnable = false;
                    SysPara.JAGStarytEvent.Set();
                }
            }
            return FCResultType.IDLE;
        }



        private FCResultType flowChart16_FlowRun(object sender, EventArgs e)
        {

            string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "FeedInPalletScan");
            if (Robot.WriteToEpson(pos[2], string.Format("{0:d3}", SysPara.iScanPosIndex), pos[4], 30000))
            {
                RunTM.Restart();
                MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + string.Format("{0:d3}", SysPara.ScanCount) + "AppIndex：" + pos[4], SysPara.bEnableGeneralSaveLog);

                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }


        private FCResultType flowChart8_FlowRun_1(object sender, EventArgs e)
        {
            MiddleLayer.SystemF.OB_LED.Off();
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Robot goto scanning position" + SysPara.ScanCount.ToString(), SysPara.bEnableGeneralSaveLog);

                return FCResultType.NEXT;
            }
            else if (ret == 0)
            {

                //Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {

                SysPara.NPShowAlarm("1639");
                MiddleLayer.LogF.AddLog(LogType.Production, GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], SysPara.bEnableGeneralSaveLog);

                return FCResultType.IDLE;
            }        //R timeout
            else
            {
                switch (ret)
                {
                    case -12:
                        break;
                    case -102:
                        break;
                    case -103:
                        break;
                    default:
                        break;
                }
                return FCResultType.IDLE;
            }
        }

        // 托盘记录文件路径
        private static readonly string TrayRecordFilePath = @"D:\TrayRecords\TraySerial.txt";

        // 缓存已处理的托盘序号
        private static readonly HashSet<string> _processedTraySerials = new HashSet<string>();
        //private static int _totalTrayCount = 0;
        private static readonly object _fileLock = new object();



        private static volatile int _totalTrayCount;

        public static int CurrentTrayCount => _totalTrayCount;

        /// <summary>
        /// 加载托盘记录
        /// </summary>
        private static void LoadTrayRecordsFromFile()
        {
            lock (_fileLock)
            {
                _processedTraySerials.Clear();

                try
                {
                    // 文件不存在
                    if (!File.Exists(TrayRecordFilePath))
                    {
                        string dir = Path.GetDirectoryName(TrayRecordFilePath);

                        if (!string.IsNullOrWhiteSpace(dir) &&
                            !Directory.Exists(dir))
                        {
                            Directory.CreateDirectory(dir);
                        }

                        _totalTrayCount = 0;
                        return;
                    }

                    var lines = File.ReadAllLines(TrayRecordFilePath);

                    foreach (var line in lines)
                    {
                        string serial = line.Trim();

                        if (!string.IsNullOrWhiteSpace(serial))
                        {
                            _processedTraySerials.Add(serial);
                        }
                    }

                    _totalTrayCount = _processedTraySerials.Count;
                }
                catch (Exception ex)
                {
                    _processedTraySerials.Clear();
                    _totalTrayCount = 0;

                    MiddleLayer.LogF.AddLog(
                        LogType.Alarmas,
                        $"Load tray records failed: {ex.Message}",
                        SysPara.bEnableGeneralSaveLog);
                }
            }
        }

        /// <summary>
        /// 添加新的托盘号
        /// </summary>
        private static bool TryAddNewTraySerial(string traySerial)
        {
            if (string.IsNullOrWhiteSpace(traySerial))
                return false;

            lock (_fileLock)
            {
                try
                {
                    // 已存在
                    if (_processedTraySerials.Contains(traySerial))
                        return false;

                    // 追加写入文件
                    File.AppendAllLines(
                        TrayRecordFilePath,
                        new[] { traySerial });

                    // 更新内存
                    _processedTraySerials.Add(traySerial);

                    _totalTrayCount = _processedTraySerials.Count;

                    return true;
                }
                catch (Exception ex)
                {
                    MiddleLayer.LogF.AddLog(
                        LogType.Alarmas,
                        $"Add tray serial failed: {ex.Message}",
                        SysPara.bEnableGeneralSaveLog);

                    return false;
                }
            }
        }

        /// <summary>
        /// 清空所有托盘记录
        /// </summary>
        private static bool ResetTrayRecords()
        {
            lock (_fileLock)
            {
                try
                {
                    _processedTraySerials.Clear();

                    _totalTrayCount = 0;

                    if (File.Exists(TrayRecordFilePath))
                    {
                        File.Delete(TrayRecordFilePath);
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    MiddleLayer.LogF.AddLog(
                        LogType.Alarmas,
                        $"Reset tray records failed: {ex.Message}",
                        SysPara.bEnableGeneralSaveLog);

                    return false;
                }
            }
        }

        /// <summary>
        /// 判断是否是首托盘
        /// </summary>
        private static bool IsFirstTraySerial(string traySerial)
        {
            lock (_fileLock)
            {
                if (_processedTraySerials.Count == 0)
                    return false;

                return traySerial == _processedTraySerials.First();
            }
        }

        /// <summary>
        /// 提取托盘编号
        /// </summary>
        private string ExtractTraySerial(string barcode)
        {
            if (string.IsNullOrWhiteSpace(barcode))
                return null;
            var parts = barcode.Split('-');
            return parts.Length >= 2? parts[0]+ "-" + parts[1]: null;
        }
        private int _lastTrayResetPeriod = -1;
        private FCResultType flowChart18_FlowRun(object sender, EventArgs e)
        {
            // Time Reset Check
            CheckTrayResetByTime();
            //Check RunMode
            if (SysPara.cycleRunMode)
            {
                return FCResultType.NEXT;
            }
            SysPara.bScanResult = TrigerBarcode();
            string[] code = SysPara.QRCode1.Split(new char[] { ',' });
            // 数量检查
            if (code.Length < 3)
            {
                SysPara.bScanResult = false;
            }
            else
            {
                // 重复检查
                for (int i = 0; i < code.Length; i++)
                {
                    for (int j = i + 1; j < code.Length; j++)
                    {
                        if (code[i] == code[j])
                        {
                            SysPara.bScanResult = false;
                            break;
                        }
                    }
                    if (!SysPara.bScanResult)
                        break;
                }
            }

            // 扫码失败
            if (!SysPara.bScanResult)
            {
                SDKKernal.ShowAlarm("1301");
                DisposeFrm(TipsFrm);
                TipsFrm = new Reintento();
                TipsFrm.fnSetTextMessageNShow("Confirm whether to scan the code again,yes or no",true,false,false);
                if (DialogResult.Yes == TipsFrm.dResult)
                {
                    return FCResultType.IDLE;
                }
            }
            DisposeFrm(TipsFrm);
            // 提取首码
            string firstCode = code.Length > 0 ? code[0] : null;
            string traySerial = ExtractTraySerial(firstCode);
            // 提取失败
            if (string.IsNullOrWhiteSpace(traySerial))
            {
                MiddleLayer.LogF.AddLog(LogType.Alarmas,$"Unable to extract tray serial from barcode: {firstCode}",SysPara.bEnableGeneralSaveLog);
                return FCResultType.IDLE;
            }
            // 尝试新增
            bool added = TryAddNewTraySerial(traySerial);
            if (added)
            {
                saveTrayCountToDataSet(CurrentTrayCount);
                MiddleLayer.LogF.AddLog(LogType.Production,$"New tray serial: {traySerial}, Current tray count: {CurrentTrayCount}",SysPara.bEnableGeneralSaveLog);
            }
            else
            {
                // 是否循环回到第一盘,如果回到第一盘，就清空队列，并删除文件，进入下一个托盘计数循环
                bool isFirstTray = IsFirstTraySerial(traySerial);
                if (isFirstTray)
                {
                    // 清空旧记录
                    ResetTrayRecords();
                    // 重新加入第一盘
                    TryAddNewTraySerial(traySerial);
                    saveTrayCountToDataSet(CurrentTrayCount);
                    MiddleLayer.LogF.AddLog(LogType.Production,$"Tray cycle restarted. New tray serial: {traySerial}, Current tray count: {CurrentTrayCount}",SysPara.bEnableGeneralSaveLog);
                }
                else
                {
                    MiddleLayer.LogF.AddLog(LogType.Production,$"Duplicate tray serial: {traySerial}, Current tray count: {CurrentTrayCount}",SysPara.bEnableGeneralSaveLog);
                }
            }
            // 保存二维码
            SaveFile.SaveData1(SysPara.QRCode1.Split(new char[] { ',' }));
            MiddleLayer.LogF.AddLog(LogType.Production,SysPara.QRCode1,SysPara.bEnableGeneralSaveLog);
            return FCResultType.NEXT;
        }

        private void CheckTrayResetByTime()
        {
            DateTime now = DateTime.Now;
            // Start from 07:00am
            if (now.Hour < 7)
            {
                return;
            }
            // 07~08 => 0
            // 09~10 => 1
            // 11~12 => 2
            int period = (now.Hour - 7) / 2;
            // Prevent repeated reset
            if (period != _lastTrayResetPeriod)
            {
                _lastTrayResetPeriod = period;
                // Clear tray records
                ResetTrayRecords();
                saveTrayCountToDataSet(CurrentTrayCount);
                MiddleLayer.LogF.AddLog(LogType.Production,$"Tray records reset by schedule. Period:{period}",SysPara.bEnableGeneralSaveLog);
            }
        }

        private FCResultType flowChart10_FlowRun_1(object sender, EventArgs e)
        {
            SysPara.iScanPosIndex = 5;
            if (SysPara.iScanPosIndex == 5)
            {
                SysPara.iScanPosIndex = 1;
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.CASE1;
            }
        }

        private FCResultType flowChart21_FlowRun(object sender, EventArgs e)
        {
            MiddleLayer.LogF.AddLog(LogType.Production, "Query MES Infomation", SysPara.bEnableGeneralSaveLog);

            SysPara.FailedIndexList.Clear();
            SysPara.AbortedIndexList.Clear();

            int errCount = 0;
            for (int i = 0; i < SysPara.iProductCount; i++)
            {
                SysPara.iPictureResults[i] = 0;
                string searchStr = SaveFile.SearchCode(1, SysPara.sProductCodes[i], 0);
                if (!searchStr.Contains("Err"))
                {
                    SysPara.bProductValid[i] = false;
                    errCount++;
                    SysPara.sProductCodes[i] = "ErrCode" + i.ToString();
                    SysPara.AbortedIndexList.Add(i + 1);  //coming failed is aborted

                }
                else
                {
                    SysPara.bProductValid[i] = true;
                    SysPara.sProductCodes[i] = string.Format("{0:000000}", i);
                }
            }
            #region 测试阶段手动设置有效性 
            //SysPara.bProductValid = new bool[] { true, true, true, false, true, false, true, false, true, true, true, false };
            SysPara.bProductValid = new bool[] { true, true, true, true, true, true, true, true, true, true, true, true };

            #endregion

            SysPara.gotoPictureIndex = 0;  //from 1 to 12
            SysPara.grapperIndex = SysPara.pictureOKCount + 1;
            ClearRobotPos();     //


            //SysPara.CFX.WorkStarted(SysPara.sProductCodes[0], 12); // start from the first product serial,indicates following 12
            SysPara.jagProcessData.Customer = "";
            SysPara.jagProcessData.MachineProcess = "Unload";
            SysPara.jagProcessData.RecipeName = "";
            SysPara.jagProcessData.PrimaryIdentifier = SysPara.sProductCodes[0];
            SysPara.jagProcessData.DateTimeUnitIn = DateTime.Parse(SysPara.ST1_StartTime);
            IniciarPalletMpc();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo: modo de este pallet y cableado


            return FCResultType.NEXT;
        }

        private void ClearRobotPos()
        {
            SysPara.robotPos.Clear();
            SysPara.robotPos.Add(new double[3] { 0, 0, 0 });
            SysPara.robotPos.Add(new double[3] { 0, 0, 0 });
            SysPara.robotPos.Add(new double[3] { 0, 0, 0 });
        }


        private FCResultType flowChart20_FlowRun(object sender, EventArgs e)
        {
            if (mpcActivo) return Mpc_Nodo20();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
            OB_RobotLight.On();
            SysPara.gotoPictureIndex++;
            if (SysPara.gotoPictureIndex > 12)
            {
                int errCount = 0;
                for (int i = 0; i < SysPara.iProductCount; i++)
                {
                    if (SysPara.bProductValid[i] == true && SysPara.iPictureResults[i] == 0)  //coming valid but picture failed
                    {
                        errCount++;
                    }
                }
                if (errCount == 0)
                {
                    MiddleLayer.ConveyorF.UpConveyorAutoFlow.AssembCompeletStatus = true;// SysPara.bUnloadCompleteStatus = true;
                }
                else
                {
                    SysPara.bPhotoFailed = true;
                }
                return FCResultType.CASE1;
            }
            if (!SysPara.cycleRunMode)
            {
                processData.fnShowSerial(SysPara.sProductCodes[SysPara.gotoPictureIndex - 1]);
            }
            if (SysPara.bProductValid[SysPara.gotoPictureIndex - 1] == false)
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Product" + SysPara.gotoPictureIndex.ToString() + " scan result is null", SysPara.bEnableGeneralSaveLog);
                return FCResultType.IDLE;
            }
            else
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Product" + SysPara.gotoPictureIndex.ToString() + " scan result is valid", SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
        }

        private FCResultType flowChart22_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            {
                return FCResultType.NEXT;
            }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {
                MiddleLayer.LogF.AddLog(LogType.Production, GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], SysPara.bEnableGeneralSaveLog);
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }


        private FCResultType flowChart23_FlowRun(object sender, EventArgs e)
        {
            SysPara.visionPos = new VisionPos();
            CogTransform2DLinear destRobot = new CogTransform2DLinear();
            CogTransform2DLinear destPart = new CogTransform2DLinear();
            CogTransform2DLinear curRobot = new CogTransform2DLinear();
            CogTransform2DLinear curPart = new CogTransform2DLinear();
            double offsetx, offsety, deltaA;
            try
            {
                if (SysPara.bDryCycle)
                {
                    OB_RobotLight.Off();
                    CCDAlogrithmStatus = true;
                    return FCResultType.NEXT;
                }
                double exposure = MiddleLayer.GantryF.GetSettingValue("MSet", "PickExpTime");
                if (SysPara.SnapPalletNGNum > 6)
                {
                    exposure = exposure * 1.2;
                }
                else if (SysPara.SnapPalletNGNum >= 8)
                {
                    exposure = exposure * 0.9;
                }

                if (H1_PickupPos.TakePicture(exposure))    //CCD take picture
                {
                    SaveImage image = new SaveImage();
                    if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
                    {
                        H1_PickupPos.RunTB();
                        RefreshDifferentThreadUI(cogRecordDisplay_Pickup, () =>
                        {
                            cogRecordDisplay_Pickup.Image = H1_PickupPos.InputImage;
                            cogRecordDisplay_Pickup.Record = H1_PickupPos.TB.CreateLastRunRecord().SubRecords[0];
                            cogRecordDisplay_Pickup.Fit();
                        });

                        image.Image = cogRecordDisplay_Pickup.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                        image.Timer = DateTime.Now.ToString("yyyyMMddHHmmss");

                        bool IsHaveProduct = (bool)H1_PickupPos.GetOutput("IsHaveProduct");
                        if ((H1_PickupPos.IsAccept) && IsHaveProduct)//yong zhe pan duan you mei you liao
                        {
                            SysPara.SnapPalletNGNum = 0;
                            destPart.TranslationX = (double)H1_PickupPos.GetOutput("X");
                            destPart.TranslationY = (double)H1_PickupPos.GetOutput("Y");
                            destPart.Rotation = (double)H1_PickupPos.GetOutput("Angle");

                            if ((bool)H1_PickupPos.GetOutput("bIsTilted"))
                            {
                                //SDKKernal.ShowAlarm("1212");
                                SysPara.NPShowAlarm("1212");
                                DisposeFrm(TipsFrm);
                                TipsFrm = new Reintento();
                                TipsFrm.fnSetTextMessageNShow("[CCD]The position of current product is not true!!![Yes]Check again,[No]Continue.", true, false, true);
                                if (TipsFrm.dResult == DialogResult.Yes)
                                {
                                    MiddleLayer.LogF.AddLog(LogType.Production, "Product" + SysPara.gotoPictureIndex.ToString() + " The position of current product is not true!!!OP Click [Yes] Bottom", SysPara.bEnableGeneralSaveLog);
                                    return FCResultType.IDLE;
                                }
                                else
                                {
                                    MiddleLayer.LogF.AddLog(LogType.Production, "Product" + SysPara.gotoPictureIndex.ToString() + " The position of current product is not true!!!OP Click [No] Bottom", SysPara.bEnableGeneralSaveLog);
                                }
                            }
                            switch (SysPara.grapperIndex)
                            {
                                case 1:
                                    curRobot.TranslationX = GetRecipeValue("RSet", "PickTeachRobotX");
                                    curRobot.TranslationY = GetRecipeValue("RSet", "PickTeachRobotY");
                                    double d = GetRecipeValue("RSet", "PickTeachRobotU");
                                    curRobot.Rotation = CogMisc.DegToRad(GetRecipeValue("RSet", "PickTeachRobotU"));

                                    curPart.TranslationX = GetRecipeValue("RSet", "PickTeachVisX");
                                    curPart.TranslationY = GetRecipeValue("RSet", "PickTeachVisY");
                                    curPart.Rotation = GetRecipeValue("RSet", "PickTeachVisU");
                                    break;
                                case 2:
                                    curRobot.TranslationX = GetRecipeValue("RSet", "PickTeachRobotX2");
                                    curRobot.TranslationY = GetRecipeValue("RSet", "PickTeachRobotY2");
                                    double d2 = GetRecipeValue("RSet", "PickTeachRobotU2");
                                    //RecipeData - RSet.PickTeachRobotU2
                                    curRobot.Rotation = CogMisc.DegToRad(GetRecipeValue("RSet", "PickTeachRobotU2"));

                                    curPart.TranslationX = GetRecipeValue("RSet", "PickTeachVisX2");
                                    curPart.TranslationY = GetRecipeValue("RSet", "PickTeachVisY2");
                                    curPart.Rotation = GetRecipeValue("RSet", "PickTeachVisU2");
                                    break;
                                case 3:
                                    curRobot.TranslationX = GetRecipeValue("RSet", "PickTeachRobotX3");
                                    curRobot.TranslationY = GetRecipeValue("RSet", "PickTeachRobotY3");
                                    curRobot.Rotation = CogMisc.DegToRad(GetRecipeValue("RSet", "PickTeachRobotU3"));

                                    curPart.TranslationX = GetRecipeValue("RSet", "PickTeachVisX3");
                                    curPart.TranslationY = GetRecipeValue("RSet", "PickTeachVisY3");
                                    curPart.Rotation = GetRecipeValue("RSet", "PickTeachVisU3");
                                    break;
                                default:
                                    break;
                            }
                            destRobot = destPart.Compose(curPart.Invert().Compose(curRobot));
                            offsetx = destRobot.TranslationX;
                            offsety = destRobot.TranslationY;
                            deltaA = CogMisc.RadToDeg(destRobot.Rotation);
                            SysPara.visionPos.x = offsetx;
                            SysPara.visionPos.y = offsety;
                            SysPara.visionPos.u = deltaA;
                            try
                            {
                                MiddleLayer.LogF.AddLog(LogType.Production, "PosX：" + offsetx.ToString() + "PosY：" + offsety.ToString(), SysPara.bEnableGeneralSaveLog);
                                double max_X = GetRecipeValue("RSet", "PalletMaxValueX");
                                double max_Y = GetRecipeValue("RSet", "PalletMaxValueY");
                                double min_X = GetRecipeValue("RSet", "PalletMinValueX");
                                double min_Y = GetRecipeValue("RSet", "PalletMinValueY");
                                bool bValue = max_X > offsetx && min_X < offsetx && max_Y > offsety && min_Y < offsety ? true : false;
                                if (!bValue)
                                {
                                    SDKKernal.ShowAlarm("1206");
                                    return FCResultType.IDLE;
                                }
                            }
                            catch (Exception)
                            {
                                SDKKernal.ShowAlarm("1206");
                                return FCResultType.IDLE;
                            }
                            //SysPara.visionPos.u = 0;
                            CCDAlogrithmStatus = true;
                            SysPara.robotPos[SysPara.grapperIndex - 1][0] = offsetx;
                            SysPara.robotPos[SysPara.grapperIndex - 1][1] = offsety;
                            SysPara.robotPos[SysPara.grapperIndex - 1][2] = deltaA;
                            productImage1.Add(image);
                            //OB_RobotLight.Off();
                            return FCResultType.NEXT;
                        }
                        else if ((H1_PickupPos.IsAccept) && (!IsHaveProduct))
                        {
                            try
                            {
                                string saveImgPath = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\";

                                string ImageName = string.Format(@"{0}_{1}_NA_NA_{2}_{3}.jpg",
                              "NA",
                               SysPara.sPalletCodes[SysPara.gotoPictureIndex - 1],
                            DateTime.Now.ToString("yyyyMMddHHmmss"),
                          MiddleLayer.MesF2.GetSettingValue("PSet", "EQPID")
                          );
                                Image img = cogRecordDisplay_Pickup.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                                using (Bitmap objImg = new Bitmap(img))
                                {
                                    if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                                    objImg.Save(saveImgPath + ImageName, System.Drawing.Imaging.ImageFormat.Jpeg);
                                }
                            }
                            catch (Exception)
                            {
                            }
                            SysPara.visionPos.x = 0;
                            SysPara.visionPos.y = 0;
                            SysPara.visionPos.u = 0;
                            CCDAlogrithmStatus = false;
                            SysPara.robotPos[SysPara.grapperIndex - 1][0] = 0;
                            SysPara.robotPos[SysPara.grapperIndex - 1][1] = 0;
                            SysPara.robotPos[SysPara.grapperIndex - 1][2] = 0;
                            return FCResultType.NEXT;
                        }
                        else
                        {
                            SysPara.visionPos.x = 0;
                            SysPara.visionPos.y = 0;
                            SysPara.visionPos.u = 0;
                            CCDAlogrithmStatus = false;
                            SysPara.robotPos[SysPara.grapperIndex - 1][0] = 0;
                            SysPara.robotPos[SysPara.grapperIndex - 1][1] = 0;
                            SysPara.robotPos[SysPara.grapperIndex - 1][2] = 0;
                            SDKKernal.ShowAlarm("1205");
                            DisposeFrm(TipsFrm);
                            TipsFrm = new Reintento();
                            if (SysPara.SnapPalletNGNum <= 6)
                            {
                                TipsFrm.fnSetTextMessageNShow("Confirm whether to snap the pallet hole 6 times again,yes or no", true, false, true);
                            }
                            else
                            {
                                TipsFrm.fnSetTextMessageNShow("Take this Camera out!!!", true, false, true);
                            }
                            if (TipsFrm.dResult == DialogResult.Yes)
                            {
                                SysPara.SnapPalletNGNum++;
                                return FCResultType.CASE1;
                            }
                            else
                            {
                                if (SysPara.SnapPalletNGNum > 6)
                                {
                                    return FCResultType.IDLE;
                                }
                                else
                                {
                                    return FCResultType.IDLE;
                                }
                            }
                        }
                    }
                    else
                    {
                        try
                        {
                            string saveImgPath = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\";
                            string ImageName = string.Format(@"{0}_{1}_NA_NA_{2}_{3}.jpg", "NA",SysPara.sPalletCodes[SysPara.gotoPictureIndex - 1],DateTime.Now.ToString("yyyyMMddHHmmss"),MiddleLayer.MesF2.GetSettingValue("PSet", "EQPID"));
                            Image img = cogRecordDisplay_Pickup.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                            using (Bitmap objImg = new Bitmap(img))
                            {
                                if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                                objImg.Save(saveImgPath + ImageName, System.Drawing.Imaging.ImageFormat.Jpeg);
                            }
                        }
                        catch (Exception)
                        {
                        }
                        SysPara.visionPos.x = 0;
                        SysPara.visionPos.y = 0;
                        SysPara.visionPos.u = 0;
                        //OB_RobotLight.Off();
                        SysPara.robotPos[SysPara.grapperIndex - 1][0] = 0;
                        SysPara.robotPos[SysPara.grapperIndex - 1][1] = 0;
                        SysPara.robotPos[SysPara.grapperIndex - 1][2] = 0;
                        CCDAlogrithmStatus = true;
                        return FCResultType.NEXT;
                    }
                }
                else
                {
                    //OB_RobotLight.Off();
                    CCDAlogrithmStatus = false;
                    //SysPara.NPShowAlarm("1103");        //CCD fail
                    return FCResultType.NEXT;
                }
            }
            catch (Exception ex)
            {
                //OB_RobotLight.Off();
                CCDAlogrithmStatus = false;
                SysPara.NPShowAlarm("1204");        //CCD fail
                return FCResultType.IDLE;
            }

        }

        private FCResultType flowChart34_FlowRun(object sender, EventArgs e)
        {
            SysPara.SnapPalletNGNum = 0;
            if (mpcActivo) return Mpc_Nodo34();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
            if (SysPara.cycleRunMode)  //tryrun mode,all valid,
            {
                SysPara.iPictureResults[SysPara.gotoPictureIndex - 1] = 1;       //101111010011
                SysPara.pickUpProductIndex[SysPara.pictureOKCount] = SysPara.gotoPictureIndex;//(1,3,4),(5,6,8),(11,12,8)
                SysPara.pictureOKCount++;
                if (SysPara.pictureOKCount == 3)
                {
                    OB_RobotLight.Off();
                    //SysPara.pictureOKCount = 0;
                    SysPara.grapperIndex = 0;
                    return FCResultType.NEXT;
                }
                else
                {
                    SysPara.grapperIndex = SysPara.pictureOKCount + 1;
                    return FCResultType.CASE1;
                }
                //      return FCResultType.NEXT;
            }
            if (CCDAlogrithmStatus)  // 1
            {
                SysPara.iPictureResults[SysPara.gotoPictureIndex - 1] = 1;
                SysPara.pickUpProductIndex[SysPara.pictureOKCount] = SysPara.gotoPictureIndex;
                SysPara.ThreeResultDatas[SysPara.pictureOKCount].ProductCode = SysPara.sProductCodes[(SysPara.gotoPictureIndex - 1)];
                SysPara.ThreeResultDatas[SysPara.pictureOKCount].PalletCode = SysPara.sPalletCodes[(SysPara.gotoPictureIndex - 1)];
                SysPara.pictureOKCount++;
            }
            else
            {
                SysPara.iPictureResults[SysPara.gotoPictureIndex - 1] = 0;
            }

            #region save
            if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
            {
                bool isSave = MiddleLayer.GantryF.GetSettingValue("PSet", "ImgSave");
                bool isJPGSave = MiddleLayer.GantryF.GetSettingValue("PSet", "JPGImgSave");
                string imgSaveName = "PickupImageVac" + SysPara.gotoPictureIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpg";
                if (isSave)
                {
                    string saveImgPath = CCDAlogrithmStatus ?
                       @"D:\WorkLog\\" + "PickupImageVac_BMP\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\"
                    : @"D:\WorkLog\\" + "PickupImageVac_BMP\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\";
                    using (CogImageFileBMP objImg = new CogImageFileBMP())
                    {
                        if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                        objImg.Open(saveImgPath + imgSaveName, CogImageFileModeConstants.Write);
                        objImg.Append(H1_PickupPos.InputImage);
                        objImg.Close();
                    }
                }
                if (isJPGSave)
                {
                    string saveImgPath1 = CCDAlogrithmStatus ?
                         @"D:\WorkLog\\" + "PickupImageVac_JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\"
                   : @"D:\WorkLog\\" + "PickupImageVac_JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\";
                    Image img = cogRecordDisplay_Pickup.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                    string imgSaveName1 = "PickupImageVac" + SysPara.gotoPictureIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpeg";
                    using (Bitmap objImg = new Bitmap(img))
                    {
                        if (!Directory.Exists(saveImgPath1)) { Directory.CreateDirectory(saveImgPath1); }
                        objImg.Save(saveImgPath1 + imgSaveName1, System.Drawing.Imaging.ImageFormat.Jpeg);
                    }
                }
            }
            #endregion save


            if (SysPara.pictureOKCount == 3)
            {
                OB_RobotLight.Off();
                SysPara.grapperIndex = SysPara.iProductCountOnGrapper[0] + SysPara.iProductCountOnGrapper[1] + SysPara.iProductCountOnGrapper[2];
                return FCResultType.NEXT;
            }
            else
            {
                SysPara.grapperIndex = SysPara.pictureOKCount + 1;
                if (SysPara.gotoPictureIndex < 12)
                {
                    return FCResultType.CASE1;
                }
                else
                {
                    OB_RobotLight.Off();
                    SysPara.grapperIndex = SysPara.iProductCountOnGrapper[0] + SysPara.iProductCountOnGrapper[1] + SysPara.iProductCountOnGrapper[2];
                    return FCResultType.NEXT;
                }
            }

        }

        private FCResultType flowChart24_FlowRun(object sender, EventArgs e)
        {
            int pickupNums = SysPara.iProductCountOnGrapper[0] + SysPara.iProductCountOnGrapper[1] + SysPara.iProductCountOnGrapper[2];
            if (pickupNums == 3)
            {
                SysPara.grapperIndex = 0;
                //SysPara.iVacIndex = GetRecipeValue("RSet", "VacIndex");   //1-10 
                int iGroupNumb = GetRecipeValue("RSet", "VacIndex") / 3;
                SysPara.iVacIndex = iGroupNumb;
                if (SysPara.bCanDischarge)
                {
                    SysPara.iVacIndex++;
                    if (SysPara.iVacIndex > SysPara.iVacCount)
                    {
                        if (!SysPara.cycleRunMode)
                        {
                            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
                            {
                                SysPara.bCanDischarge = false;
                            }
                            else if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
                            {
                                //SysPara.NPShowAlarm("80192");
                                SysPara.bCanDischarge = true;
                            }
                        }
                        SysPara.iVacIndex = 0;
                        saveVacIndexToDataSet();
                        if (SysPara.bCanDischarge)
                        {
                            return FCResultType.NEXT;
                        }
                        else
                        {
                            return FCResultType.IDLE;
                        }
                    }
                    else
                    {
                        SysPara.bCanDischarge = true;
                        saveVacIndexToDataSet();
                        return FCResultType.NEXT;
                    }
                }
                else
                {
                    return FCResultType.IDLE;
                }
            }
            else
            {
                if (pickupNums == SysPara.pictureOKCount && SysPara.pictureOKCount < 3)  //wait next pallet
                {
                    specialevents = true;
                    return FCResultType.CASE2;
                }
                else
                {
                    return FCResultType.CASE1;
                }
            }

        }
        private FCResultType flowChart25_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }


        private FCResultType flowChart36_FlowRun(object sender, EventArgs e)
        {
            SysPara.grapperIndex++;
            if (SysPara.grapperIndex > SysPara.pictureOKCount)
            {
                return FCResultType.CASE1;
            }

            int gotoPickupIndex = SysPara.pickUpProductIndex[SysPara.grapperIndex - 1];
            SysPara.ThreeResultDatas[SysPara.grapperIndex - 1].Time = DateTime.Now.ToString("hh::mm:ss");
            SysPara.jagProcessData.PrimaryIdentifier = SysPara.sProductCodes[gotoPickupIndex - 1];

            if (SysPara.iPictureResults[gotoPickupIndex - 1] == 1)
            {
                if (!SysPara.cycleRunMode)
                {
                    SysPara.jagProcessData.DateTimeUnitOut = DateTime.Now;
                    SysPara.ThreeResultDatas[SysPara.grapperIndex - 1].Result = "OK";
                    processData.fnUpdateResult(SysPara.ThreeResultDatas[SysPara.grapperIndex - 1], CurrentDisplayCount);
                    CurrentDisplayCount++;
                    int maxrows = Convert.ToInt32(MiddleLayer.GantryF.GetSettingValue("PSet", "MaxDisplay"));
                    if (maxrows <= 0)
                    {
                        maxrows = 12;
                    }
                    if (processData.fnRowsCount() > maxrows)
                    {
                        processData.fnRemoveLastResult();
                    }
                    processData.fnAddCountUnit(true, SysPara.sProductCodes[(gotoPickupIndex - 1)]);
                }
                PickedPocketIDs.Add(gotoPickupIndex - 1);
                return FCResultType.NEXT;
            }
            else
            {
                if (!SysPara.cycleRunMode)
                {
                    SysPara.jagProcessData.DateTimeUnitOut = DateTime.Now;
                    if (SysPara.bProductValid[gotoPickupIndex - 1])
                    {
          //              SysPara.CFX.UnitProcessed(SysPara.jagProcessData,
          //CFX.Structures.ProcessingResult.Failed);

                    }
                    else
                    {
         //               SysPara.CFX.UnitProcessed(SysPara.jagProcessData,
         //CFX.Structures.ProcessingResult.Aborted);
                    }

                    SysPara.ThreeResultDatas[SysPara.grapperIndex - 1].Result = "NG";
                    //processData.fnUpdateResult(SysPara.ThreeResultDatas[SysPara.grapperIndex - 1]);
                    processData.fnUpdateResult(SysPara.ThreeResultDatas[SysPara.grapperIndex - 1], CurrentDisplayCount);
                    CurrentDisplayCount++;
                    int maxrows = Convert.ToInt32(MiddleLayer.GantryF.GetSettingValue("PSet", "MaxDisplay"));
                    if (maxrows <= 0)
                    {
                        maxrows = 12;
                    }
                    if (processData.fnRowsCount() > maxrows)
                    {
                        processData.fnRemoveLastResult();
                    }
                    //processData.fnAddCountUnit(false, SysPara.sProductCodes[(gotoPickupIndex - 1)]);

                }
                if (SysPara.grapperIndex > SysPara.pictureOKCount)
                {
                    return FCResultType.CASE1;
                }
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart42_FlowRun(object sender, EventArgs e)
        {
            double pickTime = 0;
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            {
                stopwatch.Stop();
                pickTime = (double)stopwatch.ElapsedMilliseconds / 1000.00;
                if (string.Format("{0:d2}", SysPara.grapperIndex) == "01")
                {
                    MiddleLayer.ConveyorF.processData.textBox1.Text = pickTime.ToString("f3");
                }
                else if (string.Format("{0:d2}", SysPara.grapperIndex) == "02")
                {
                    MiddleLayer.ConveyorF.processData.textBox2.Text = pickTime.ToString("f3");
                }
                else if (string.Format("{0:d2}", SysPara.grapperIndex) == "03")
                {
                    MiddleLayer.ConveyorF.processData.textBox3.Text = pickTime.ToString("f3");
                }
                SysPara.iProductCountOnGrapper[SysPara.grapperIndex - 1] = 1;  // 1
                return FCResultType.NEXT;
            }
            else if (ret == 0)
            {
                SysPara.iProductCountOnGrapper[SysPara.grapperIndex - 1] = 0;  // 0
                MiddleLayer.LogF.AddLog(LogType.Production, GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], SysPara.bEnableGeneralSaveLog);
                //Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }        //R1 timeout
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart43_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        private FCResultType flowChart38_FlowRun(object sender, EventArgs e)
        {
            RunTM.Restart();
            if (SysPara.gotoPictureIndex == 12)
            {
                int errCount = 0;
                for (int i = 0; i < SysPara.iProductCount; i++)
                {
                    if (SysPara.bProductValid[i] == true && SysPara.iPictureResults[i] == 0)  //coming valid but picture failed
                    {
                        errCount++;
                    }
                }
                if (errCount == 0)
                {
                    //SysPara.bUnloadCompleteStatus = true;
                    MiddleLayer.ConveyorF.UpConveyorAutoFlow.AssembCompeletStatus = true;
                }
                else
                {
                    SysPara.grapperIndex++;   //1-3 
                    SysPara.bPhotoFailed = true;
                    return FCResultType.CASE1;
                }
            }
            SysPara.grapperIndex++;   //1-3 
            return FCResultType.NEXT;
        }

        private FCResultType flowChart26_FlowRun(object sender, EventArgs e)
        {
            OB_RobotLight.On();
            if (updownsignal == "up")
            {
                if (SysPara.iVacIndex == 0)
                {
                    SysPara.iVacIndex = 1;
                }
                int _vacPicturePosIndex = (SysPara.iVacIndex - 1) * 3 + SysPara.grapperIndex; // 1-10
                string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "UnloadPalletPicture");
                if (Robot.WriteToEpson(pos[2], string.Format("{0:d3}", _vacPicturePosIndex),string.Format("{0:d2}", SysPara.grapperIndex), 30000))
                {
                    RunTM.Restart();
                    MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + string.Format("{0:d3}", _vacPicturePosIndex) + "AppIndex：" + string.Format("{0:d2}", SysPara.grapperIndex), SysPara.bEnableGeneralSaveLog);
                    return FCResultType.NEXT;
                }
                else
                {
                    return FCResultType.IDLE;
                }
            }
            return FCResultType.IDLE;
        }


        private FCResultType flowChart27_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {
                MiddleLayer.LogF.AddLog(LogType.Production, GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], SysPara.bEnableGeneralSaveLog);

                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }
        //double[] robotPos = new double[3];

        private FCResultType flowChart29_FlowRun_1(object sender, EventArgs e)
        {
            if (updownsignal == "up")
            {
                SysPara.visionPos = new VisionPos();
                CogTransform2DLinear destRobot = new CogTransform2DLinear();
                CogTransform2DLinear destPart = new CogTransform2DLinear();
                CogTransform2DLinear curRobot = new CogTransform2DLinear();
                CogTransform2DLinear curPart = new CogTransform2DLinear();
                double offsetx, offsety, deltaA;
                //OB_RobotLight.On();
                try
                {
                    if (SysPara.bDryCycle)
                    {
                        OB_RobotLight.Off();
                        CCDAlogrithmStatus = true;
                        return FCResultType.NEXT;
                    }
                    double exposure = MiddleLayer.GantryF.GetSettingValue("MSet", "DisChargeExpTime");
                    if (H1_DischargePos.TakePicture(exposure))    //CCD take picture
                    {
                        bool isSave = MiddleLayer.GantryF.GetSettingValue("PSet", "ImgSave");
                        bool isJPGSave = MiddleLayer.GantryF.GetSettingValue("PSet", "JPGImgSave");
                        string imgSaveName = "PutdownImageVac" + SysPara.gotoPictureIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpg";
                        if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
                        {
                            if (isSave)
                            {
                                string saveImgPath = @"D:\WorkLog" + "\\" + "BMP\\" + DateTime.Now.ToString("yyyyMMdd") + "\\";
                                using (CogImageFileBMP objImg = new CogImageFileBMP())
                                {
                                    if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                                    objImg.Open(saveImgPath + imgSaveName, CogImageFileModeConstants.Write);
                                    objImg.Append(H1_DischargePos.InputImage);
                                    objImg.Close();
                                }
                            }
                            H1_DischargePos.RunTB();
                            RefreshDifferentThreadUI(cogRecordDisplay_Discharge, () =>
                            {
                                cogRecordDisplay_Discharge.Image = H1_DischargePos.InputImage;
                                cogRecordDisplay_Discharge.Record = H1_DischargePos.TB.CreateLastRunRecord().SubRecords[0];
                                cogRecordDisplay_Discharge.Fit();
                            });

                            //if (isJPGSave)
                            //{
                            //    string saveImgPath1 = "";
                            //    if (H1_DischargePos.IsAccept)
                            //    {
                            //        saveImgPath1 = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\" + "JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\";
                            //    }
                            //    else
                            //    {
                            //        saveImgPath1 = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\" + "JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\";
                            //    }

                            //    Image img = cogRecordDisplay_Discharge.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                            //    string imgSaveName1 = "PutdownImageVac" + _vacPicturePosIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpeg";
                            //    using (Bitmap objImg = new Bitmap(img))
                            //    {
                            //        if (!Directory.Exists(saveImgPath1)) { Directory.CreateDirectory(saveImgPath1); }
                            //        objImg.Save(saveImgPath1 + imgSaveName1, System.Drawing.Imaging.ImageFormat.Jpeg);
                            //    }
                            //}
                            SaveImage images = new SaveImage();
                            images.Image = cogRecordDisplay_Discharge.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                            images.Timer = DateTime.Now.ToString("yyyyMMddHHmmss");
                            images.result = H1_DischargePos.IsAccept;
                            FeederImage1.Add(images);

                            //try
                            //{
                            //    string saveImgPath = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\";
                            //    for (int i = 0; i < productImage1.Count; i++)
                            //    {
                            //        string ImageName = string.Format(@"{0}_{1}_NA_NA_{2}_{3}.bmp",
                            //               "NA",
                            //               "NA",
                            //         DateTime.Now.ToString("yyyyMMddHHmmss"),
                            //           MiddleLayer.MesF2.GetSettingValue("PSet", "EQPID")
                            //           );
                            //        using (Bitmap objImg = new Bitmap(cogRecordDisplay_Discharge.CreateContentBitmap(CogDisplayContentBitmapConstants.Display)))
                            //        {
                            //            if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                            //            objImg.Save(saveImgPath + ImageName, System.Drawing.Imaging.ImageFormat.Jpeg);
                            //        }

                            //    }
                            //}
                            //catch (Exception)
                            //{

                            //}

                            if (H1_DischargePos.IsAccept)
                            {
                                destPart.TranslationX = (double)H1_DischargePos.GetOutput("X");
                                destPart.TranslationY = (double)H1_DischargePos.GetOutput("Y");
                                destPart.Rotation = (double)H1_DischargePos.GetOutput("Angle");
                                double angle = 0;

                                switch (SysPara.grapperIndex)
                                {
                                    case 1:
                                        curRobot.TranslationX = GetRecipeValue("RSet", "DischargeTeachRobotX");
                                        curRobot.TranslationY = GetRecipeValue("RSet", "DischargeTeachRobotY");
                                        curRobot.Rotation = CogMisc.DegToRad(GetRecipeValue("RSet", "DischargeTeachRobotU"));

                                        curPart.TranslationX = GetRecipeValue("RSet", "DischargeTeachVisX");
                                        curPart.TranslationY = GetRecipeValue("RSet", "DischargeTeachVisY");
                                        curPart.Rotation = GetRecipeValue("RSet", "DischargeTeachVisU");
                                        angle = GetRecipeValue("RSet", "DischargeTeachRobotU");
                                        break;
                                    case 2:
                                        curRobot.TranslationX = GetRecipeValue("RSet", "DischargeTeachRobotX2");
                                        curRobot.TranslationY = GetRecipeValue("RSet", "DischargeTeachRobotY2");
                                        curRobot.Rotation = CogMisc.DegToRad(GetRecipeValue("RSet", "DischargeTeachRobotU2"));

                                        curPart.TranslationX = GetRecipeValue("RSet", "DischargeTeachVisX2");
                                        curPart.TranslationY = GetRecipeValue("RSet", "DischargeTeachVisY2");
                                        curPart.Rotation = GetRecipeValue("RSet", "DischargeTeachVisU2");
                                        angle = GetRecipeValue("RSet", "DischargeTeachRobotU2");
                                        break;
                                    case 3:
                                        curRobot.TranslationX = GetRecipeValue("RSet", "DischargeTeachRobotX3");
                                        curRobot.TranslationY = GetRecipeValue("RSet", "DischargeTeachRobotY3");
                                        curRobot.Rotation = CogMisc.DegToRad(GetRecipeValue("RSet", "DischargeTeachRobotU3"));

                                        curPart.TranslationX = GetRecipeValue("RSet", "DischargeTeachVisX3");
                                        curPart.TranslationY = GetRecipeValue("RSet", "DischargeTeachVisY3");
                                        curPart.Rotation = GetRecipeValue("RSet", "DischargeTeachVisU3");
                                        angle = GetRecipeValue("RSet", "DischargeTeachRobotU3");
                                        break;
                                    default:
                                        break;
                                }
                                destRobot = destPart.Compose(curPart.Invert().Compose(curRobot));
                                offsetx = destRobot.TranslationX;
                                offsety = destRobot.TranslationY;
                                deltaA = CogMisc.RadToDeg(destRobot.Rotation);
                                if (destPart.Rotation>=0)
                                {
                                    deltaA = angle;
                                }
                                CogMisc.RadToDeg(curRobot.Rotation);
                                if (deltaA > 0)
                                {
                                    deltaA -= 360;
                                }
                                SysPara.visionPos.x = offsetx;
                                SysPara.visionPos.y = offsety;
                                SysPara.visionPos.u = deltaA;
                                CCDAlogrithmStatus = true;
                                try
                                {
                                    MiddleLayer.LogF.AddLog(LogType.Production, "PosX：" + offsetx.ToString() + "PosY：" + offsety.ToString(), SysPara.bEnableGeneralSaveLog);
                                    double max_X = GetRecipeValue("RSet", "FeederMaxValueX");
                                    double max_Y = GetRecipeValue("RSet", "FeederMaxValueY");
                                    double min_X = GetRecipeValue("RSet", "FeederMinValueX");
                                    double min_Y = GetRecipeValue("RSet", "FeederMinValueY");
                                    bool bValue = max_X > offsetx && min_X < offsetx && max_Y > offsety && min_Y < offsety ? true : false;
                                    if (!bValue)
                                    {
                                        SDKKernal.ShowAlarm("1206");
                                        return FCResultType.IDLE;
                                    }
                                }
                                catch (Exception)
                                {
                                    SDKKernal.ShowAlarm("1206");
                                    return FCResultType.IDLE;
                                }
                                SysPara.robotPos[SysPara.grapperIndex - 1][0] = offsetx;
                                SysPara.robotPos[SysPara.grapperIndex - 1][1] = offsety;
                                SysPara.robotPos[SysPara.grapperIndex - 1][2] = deltaA;
                                return FCResultType.NEXT;
                            }
                            else
                            {
                                SysPara.visionPos.x = 0;
                                SysPara.visionPos.y = 0;
                                SysPara.visionPos.u = 0;
                                CCDAlogrithmStatus = false;
                                SysPara.robotPos[SysPara.grapperIndex - 1][0] = 0;
                                SysPara.robotPos[SysPara.grapperIndex - 1][1] = 0;
                                SysPara.robotPos[SysPara.grapperIndex - 1][2] = 0;
                                return FCResultType.NEXT;
                            }
                        }
                        else
                        {
                            SysPara.visionPos.x = 0;
                            SysPara.visionPos.y = 0;
                            SysPara.visionPos.u = 0;
                            SysPara.robotPos[SysPara.grapperIndex - 1][0] = 0;
                            SysPara.robotPos[SysPara.grapperIndex - 1][1] = 0;
                            SysPara.robotPos[SysPara.grapperIndex - 1][2] = 0;
                            CCDAlogrithmStatus = true;
                            return FCResultType.NEXT;
                        }
                    }
                    else
                    {
                        CCDAlogrithmStatus = false;
                        //SysPara.NPShowAlarm("1103");        //CCD fail
                        return FCResultType.NEXT;
                    }
                }
                catch (Exception ex)
                {
                    CCDAlogrithmStatus = false;
                    SysPara.NPShowAlarm("1204");        //CCD fail
                    return FCResultType.IDLE;
                }
            }
            return FCResultType.IDLE;
        }


        private FCResultType flowChart35_FlowRun(object sender, EventArgs e)
        {
            #region save2
            if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
            {
                bool isSave = MiddleLayer.GantryF.GetSettingValue("PSet", "ImgSave");
                bool isJPGSave = MiddleLayer.GantryF.GetSettingValue("PSet", "JPGImgSave");
                int _vacPicturePosIndex = (SysPara.iVacIndex - 1) * 3 + SysPara.grapperIndex; // 1-10
                saveVacIndexToDataSet();
                string imgSaveName = "PutdownImageVac" + _vacPicturePosIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpg";
                if (isSave)
                {
                    string saveImgPath = CCDAlogrithmStatus ?
                        MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\" + "PutdownImageVac_BMP\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\"
                    : MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\" + "PutdownImageVac_BMP\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\";
                    using (CogImageFileBMP objImg = new CogImageFileBMP())
                    {
                        if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                        objImg.Open(saveImgPath + imgSaveName, CogImageFileModeConstants.Write);
                        //if (updownsignal == "up")
                        //{
                        objImg.Append(H1_DischargePos.InputImage);
                        //}
                        //else
                        //{
                        //    objImg.Append(H1_Discharge2Pos.InputImage);
                        //}

                        objImg.Close();
                    }
                    if (isJPGSave)
                    {
                        string saveImgPath1 = CCDAlogrithmStatus ?
                            MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\" + "PutdownImageVac_JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\"
                        : MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\" + "PutdownImageVac_JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\";
                        Image img = cogRecordDisplay_Discharge.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                        string imgSaveName1 = "PutdownImageVac" + _vacPicturePosIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpeg";
                        using (Bitmap objImg = new Bitmap(img))
                        {
                            if (!Directory.Exists(saveImgPath1)) { Directory.CreateDirectory(saveImgPath1); }
                            objImg.Save(saveImgPath1 + imgSaveName1, System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                }
            }
            #endregion save2
            if (CCDAlogrithmStatus)
            {
                if (SysPara.grapperIndex == 3)
                {
                    OB_RobotLight.Off();
                    SysPara.grapperIndex = 0;
                    try
                    {
                        int num = 0;
                        string saveImgPath = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\";
                        for (int i = 0; i < FeederImage1.Count; i++)
                        {
                            string QRCode1 = "NA";
                            string QRCode2 = "NA";
                            if (FeederImage1[i].result)
                            {
                                QRCode1 = ImgCode[num].PCBCode;
                                QRCode2 = ImgCode[num].PalletCode;
                                num++;
                            }
                            string ImageName = string.Format(@"{0}_{1}_NA_NA_{2}_{3}.jpg",
                                   QRCode1,
                                   QRCode2,
                            FeederImage1[i].Timer,
                               MiddleLayer.MesF2.GetSettingValue("PSet", "EQPID")
                               );
                            using (Bitmap objImg = new Bitmap(FeederImage1[i].Image))
                            {
                                if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                                objImg.Save(saveImgPath + ImageName, System.Drawing.Imaging.ImageFormat.Jpeg);
                            }
                        }
                        FeederImage1.Clear();
                        ImgCode.Clear();
                    }
                    catch (Exception)
                    {
                        FeederImage1.Clear();
                        ImgCode.Clear();
                    }
                    return FCResultType.NEXT;
                }
                else
                {
                    return FCResultType.CASE1;
                }
            }
            else
            {
                SysPara.iVacIndex++;                                                   //if  assemb photo NG,and assemb position  out,robot first back to safe position,then give change feeder tray signal
                if (SysPara.iVacIndex > SysPara.iVacCount)                               //放料拍照NG，若放料穴位超限,机器人回一个确定高度安全的位置，到位后，再给飞达换料信号
                {
                    SysPara.iVacIndex = 0;
                    saveVacIndexToDataSet();
                    SysPara.grapperIndex = 0;
                    // choose disable auto process feeder check ,if not has feeder,alarm and stop
                    if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))   //如果没有飞达，报警后停止，流程不变。
                    {
                        //SysPara.NPShowAlarm("8019");
                        return FCResultType.CASE1;
                    }
                    else if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))       //如果有飞达，先回安全位飞达再换料盘
                    {
                        string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "UnloadPalletPicture");
                        if (Robot.WriteToEpson(pos[2], "003", "FF", 30000))
                        {
                            InitTM.Restart();
                            //SysPara.NPShowAlarm("80192");
                            return FCResultType.CASE2;
                        }                                                            //make sure robot to safety fail,then go else,assemb position change to 1,then until goto this tray 1 position position.
                        else
                        {
                            SysPara.iVacIndex = 16; return FCResultType.IDLE;
                        }//防止机器人去安全高度位置出错，经过else,穴位变1，直接去当前料盘的1穴拍照。确保它会回安全高度的位置。
                    }
                    else
                    { return FCResultType.IDLE; }
                }
                else
                {
                    saveVacIndexToDataSet();
                    SysPara.grapperIndex = 0;
                    return FCResultType.CASE1;
                }
            }
        }



        private FCResultType flowChart28_FlowRun(object sender, EventArgs e)
        {
            OB_FeederSafetySignal.Off();
            if (updownsignal == "up")
            {
                string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "UnloadPutProductThree");
                string posXstr, posYstr, posUstr;
                SysPara.visionPos.x =Math.Round( SysPara.robotPos[SysPara.grapperIndex - 1][0],2);
                SysPara.visionPos.y = Math.Round(SysPara.robotPos[SysPara.grapperIndex - 1][1],2);
                SysPara.visionPos.u = Math.Round(SysPara.robotPos[SysPara.grapperIndex - 1][2],2);
                posXstr = SysPara.visionPos.x >= 0 ? string.Format("{0:000.000}", SysPara.visionPos.x) : string.Format("{0:000.00}", SysPara.visionPos.x);
                posYstr = SysPara.visionPos.y >= 0 ? string.Format("{0:000.000}", SysPara.visionPos.y) : string.Format("{0:000.00}", SysPara.visionPos.y);
                posUstr = SysPara.visionPos.u >= 0 ? string.Format("{0:000.000}", SysPara.visionPos.u) : string.Format("{0:000.00}", SysPara.visionPos.u);
                if (SysPara.cycleRunMode)
                {
                    posXstr = "000.000";
                    posYstr = "000.000";
                    posUstr = "000.000";
                }
                RunTM.Restart();
                int _vacDischargingPosIndex = (SysPara.iVacIndex - 1) * 3 + SysPara.grapperIndex;
                if (SysPara.iVacIndex == 0)
                {
                    _vacDischargingPosIndex = SysPara.grapperIndex;
                }
                MiddleLayer.LogF.AddLog(LogType.Production, "Put product Send to Robot X：" + posXstr + ",Y：" + posYstr + ",U：" + posUstr + ";grapperIndex:" + SysPara.grapperIndex.ToString(), SysPara.bEnableGeneralSaveLog);
                if (Robot.WriteToEpson(pos[2], string.Format("{0:d3}", _vacDischargingPosIndex), string.Format("{0:d2}", SysPara.grapperIndex), 30000, posXstr, posYstr, posUstr))
                {
                    RunTM.Restart();
                    MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + string.Format("{0:d3}", SysPara.iVacIndex * 3) + "AppIndex：" + string.Format("{0:d2}", 1), SysPara.bEnableGeneralSaveLog);
                    return FCResultType.NEXT;
                }
                else
                {
                    if (RunTM.On(3000))
                    {
                        SysPara.NPShowAlarm("1635");
                    }
                    return FCResultType.IDLE;
                }
            }
            return FCResultType.IDLE;
        }

        private FCResultType flowChart45_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            {
                SysPara.iProductCountOnGrapper[SysPara.grapperIndex - 1] = 0;//1-1+0
                SysPara.iProductCountOnGrapper[SysPara.grapperIndex - 1+1] = 0;//1-1+1
                SysPara.iProductCountOnGrapper[SysPara.grapperIndex - 1+2] = 0;//1-1+2
                SysPara.grapperIndex = 3;
                return FCResultType.NEXT;
            }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {
                SysPara.NPShowAlarm("1639");
                RunTM.Restart();
                return FCResultType.IDLE;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart39_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        //all grappers over？
        private FCResultType flowChart40_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        private FCResultType flowChart41_FlowRun(object sender, EventArgs e)
        {
            if (SysPara.pictureOKCount >= 3)
            {
                SysPara.grapperIndex = 1;
            }
            else
            {
                SysPara.grapperIndex = SysPara.pictureOKCount + 1;
            }

            if (SysPara.gotoPictureIndex == 12)
            {
                SysPara.gotoPictureIndex = 1;
                return FCResultType.NEXT;
            }
            else
            {
                if (specialevents2)
                {
                    specialevents2 = false;
                    cleargrapperfinish = true;
                    SysPara.pictureOKCount = 0;
                    SysPara.grapperIndex = 1;
                    SysPara.gotoPictureIndex = 1;
                    SysPara.iProductCountOnGrapper[0] = 0;
                    SysPara.iProductCountOnGrapper[1] = 0;
                    SysPara.iProductCountOnGrapper[2] = 0;
                    return FCResultType.CASE3;
                }
                if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))        //如果没有飞达  if not has feeder  
                {
                    SysPara.iProductCountOnGrapper[0] = 0;
                    SysPara.iProductCountOnGrapper[1] = 0;
                    SysPara.iProductCountOnGrapper[2] = 0;
                    SysPara.pictureOKCount = 0;
                    return FCResultType.CASE1;
                }
                if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))      //如果有飞达 if has feeder
                {
                    //feeder assemb the last group production,convey until have product,robot first to safety,then change feeder tray,then go convey grab product
                    if (SysPara.iVacIndex >= SysPara.iVacCount)                       //飞达放完最后一组的3个料,流道载具上还有料，机器人回安全位，到了安全位,给飞达切换料盘信号,再去流道取剩下的料
                    {
                        string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "UnloadPalletPicture");
                        if (Robot.WriteToEpson(pos[2], "003", "FF", 30000))
                        {
                            InitTM.Restart();
                            //SysPara.NPShowAlarm("80192");
                            SysPara.iProductCountOnGrapper[0] = 0;
                            SysPara.iProductCountOnGrapper[1] = 0;
                            SysPara.iProductCountOnGrapper[2] = 0;
                            SysPara.pictureOKCount = 0;
                            return FCResultType.CASE2;
                        }
                        else { return FCResultType.IDLE; }
                    }
                    else
                    {
                        SysPara.iProductCountOnGrapper[0] = 0;
                        SysPara.iProductCountOnGrapper[1] = 0;
                        SysPara.iProductCountOnGrapper[2] = 0;
                        SysPara.pictureOKCount = 0;
                        return FCResultType.CASE1;
                    }
                }
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart44_FlowRun(object sender, EventArgs e)
        {
            int errCount = 0;
            for (int i = 0; i < SysPara.iProductCount; i++)
            {
                if (SysPara.bProductValid[i] == false)
                {
                    errCount++;
                }
                if (SysPara.bProductValid[i] == true && SysPara.iPictureResults[i] == 0)  //coming valid but picture failed
                {
                    SysPara.FailedIndexList.Add(i + 1);
                    errCount++;
                }
            }
            return FCResultType.NEXT;
        }

        private FCResultType flowChart14_FlowRun(object sender, EventArgs e)
        {
            if (SysPara.grapperIndex == 3)
            {
                if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
                {
                    //SysPara.NPShowAlarm("8023");
                    DisposeFrm(TipsFrm);
                    TipsFrm = new Reintento();
                    TipsFrm.fnSetTextMessageNShow("NG products have been taken away?", true, false, true);
                    if (DialogResult.Yes == TipsFrm.dResult)
                    {
                        MiddleLayer.ConveyorF.UpConveyorAutoFlow.AssembCompeletStatus = true;
                        // SysPara.bUnloadCompleteStatus = true;
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        return FCResultType.IDLE;
                    }
                }
                else
                {
                    //SysPara.NPShowAlarm("80231");
                    MiddleLayer.ConveyorF.UpConveyorAutoFlow.AssembCompeletStatus = true;
                    // SysPara.bUnloadCompleteStatus = true;
                    return FCResultType.NEXT;
                }
            }
            else
            {
                return FCResultType.NEXT;
            }
        }


        private async void WriteMes(string sSerialNumber, List<int> failList, List<int> abortList, bool bStatusOk)
        {
            try
            {
                int j = 0;
                SysPara.MESPara = new MESParameter();
                //int length = failList.Count;
                int[] unloadRes = new int[12];  //
                for (int i = 0; i < failList.Count; i++)
                {
                    //SysPara.MESPara.fails.Clear();
                    //KeyValuePair<string, string> keyTemp = new KeyValuePair<string, string>("Unload picture location" +
                    //    (failList[i]).ToString() + "_FAIL", "");
                    //SysPara.MESPara.fails.Add(keyTemp);
                    unloadRes[failList[i] - 1] = 1;  // record the failed ones to 1
                }
                for (int i = 0; i < abortList.Count; i++)
                {
                    unloadRes[abortList[i] - 1] = 2;  // record the aborted ones to 2
                }
                for (int i = 0; i < 12; i++)   //0 means pass, 1 means fails, 2 means abort
                {
                    Measurement measureData = new Measurement();
                    measureData.measureLabel = "Unload" + (i + 1).ToString();
                    measureData.measureData = "";
                    if (unloadRes[i] == 0)
                    {
                        bStatusOk = true;
                        measureData.measureMessage = "Unload Product" + (i + 1).ToString() + "_PASS";
                    }
                    else if (unloadRes[i] == 1)
                    {
                        SysPara.MESPara.fails.Clear();
                        KeyValuePair<string, string> keyTemp = new KeyValuePair<string, string>("Unload picture location" +
                            (failList[j]).ToString() + "_FAIL", "");
                        SysPara.MESPara.fails.Add(keyTemp);
                        j++;
                        bStatusOk = false;
                        measureData.measureMessage = "Unload Product" + (i + 1).ToString() + "Picture" + "_FAIL";
                    }
                    else
                    {
                        bStatusOk = false;
                        measureData.measureMessage = "Unload Product" + (i + 1).ToString() + " PreviousProcess" + "_FAIL";
                    }
                    SysPara.MESPara.measurements.Add(measureData);
                    sSerialNumber = SysPara.sPalletCodes[i];
                    await MiddleLayer.MesF.WriteUnitMES(sSerialNumber, null, null, true, bStatusOk);
                }
            }
            catch
            { }
            //await MiddleLayer.MesF.WriteUnitMES(sSerialNumber, null, null, true, bStatusOk);
        }

        private FCResultType flowChart32_FlowRun(object sender, EventArgs e)
        {
            if (SysPara.bPhotoFailed)
            {
                SysPara.bPhotoFailed = false;
            }
            //SysPara.bUnloadCompleteStatus = true;
            //SysPara.CFX.WorkCompleted(SysPara.sPalletCodes[0], SysPara.FailedIndexList, SysPara.AbortedIndexList);
            WriteMes(SysPara.sPalletCodes[0], SysPara.FailedIndexList, SysPara.AbortedIndexList, true);

            for (int i = 0; i < 12; i++)
            {
                if (SysPara.FailedIndexList.Contains(i + 1))
                {
                    SysPara.iContinuousNGVac[i]++;
                }
                else
                {
                    SysPara.iContinuousNGVac[i] = 0;
                }
                if (SysPara.iContinuousNGVac[i] >= 3)
                {
                    if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
                    {
                        DisposeFrm(TipsFrm);
                        TipsFrm = new Reintento();
                        TipsFrm.fnSetTextMessageNShow("The " + i.ToString() + "th vacant is abnornal", true, false, true);

                        if (TipsFrm.dResult == DialogResult.Yes)
                            SysPara.iContinuousNGVac[i] = 0;
                    }
                    else
                    { SysPara.iContinuousNGVac[i] = 0; }
                }
            }
            specialtimer.Restart();
            return FCResultType.NEXT;
        }

        #endregion

        #region Feeder
        #endregion


        private FCResultType flowChart19_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        private FCResultType flowChart31_FlowRun(object sender, EventArgs e)
        {
            string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "GobackSafety");
            //Log.log.Write("Command：" + pos[2]
            //   + "Pos：" + pos[3]
            //   + "AppIndex：" + pos[4], Color.Black);
            if (Robot.WriteToEpson(pos[2], pos[3], pos[4], 30000))
            {
                InitTM.Restart();
                //RunTM.Restart();
                MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + pos[3] + "AppIndex：" + pos[4], SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }

        }

        private FCResultType flowChart33_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                //Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                if (Robot.ErorrCode == "E9000" ||
                    Robot.ErorrCode == "E9001" ||
                    Robot.ErorrCode == "E9002")
                {
                    return FCResultType.CASE1;
                }
                else { return FCResultType.CASE2; }
            }
            else if (InitTM.On(SysPara.TimeOutSec)) { SysPara.NPShowAlarm("1639"); return FCResultType.IDLE; }        //R1 timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart37_FlowRun(object sender, EventArgs e)
        {
            string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "FeedInPalletPicture");
            if (Robot.WriteToEpson(pos[2], string.Format("{0:d3}", SysPara.gotoPictureIndex), pos[4], 30000))
            {
                RunTM.Restart();
                MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + string.Format("{0:d3}",
           SysPara.gotoPictureIndex) + "AppIndex：" + pos[4], SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart30_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        private void GantryForm_Load(object sender, EventArgs e)
        {

        }


        private FCResultType flowChart40_FlowRun_1(object sender, EventArgs e)
        {
            if (SysPara.grapperIndex == 3)
            {
                SysPara.grapperIndex = 0;
                SysPara.pictureOKCount = 0;
                OB_FeederSafetySignal.On();
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.CASE1;
            }
        }

        int doorTest = 1;
        private void btnDoorStart_Click(object sender, EventArgs e)
        {
            //    doorTest = 1;
            //    while (doorTest != 0)
            //    {
            //        if (doorTest == 1)
            //        {
            //            MiddleLayer.SystemF.Cy_LeftDoorUnite.On();
            //            MiddleLayer.SystemF.Cy_RightDoorUnite.On();
            //            if (MiddleLayer.SystemF.IB_LeftDoorDownSensor.Off() &&
            //                MiddleLayer.SystemF.IB_LeftDoorUpSensor.On() &&
            //                MiddleLayer.SystemF.IB_RightDoorDownSensor.Off() &&
            //                MiddleLayer.SystemF.IB_RightDoorUpSensor.On()
            //                )
            //            {
            //                doorTest = 2;
            //            }
            //            else
            //            {
            //                DelayMs(1000);
            //            }

            //        }
            //        else
            //        {
            //            MiddleLayer.SystemF.Cy_LeftDoorUnite.Off();
            //            MiddleLayer.SystemF.Cy_RightDoorUnite.Off();
            //            if (MiddleLayer.SystemF.IB_LeftDoorDownSensor.On() &&
            //               MiddleLayer.SystemF.IB_LeftDoorUpSensor.Off() &&
            //               MiddleLayer.SystemF.IB_RightDoorDownSensor.On() &&
            //               MiddleLayer.SystemF.IB_RightDoorUpSensor.Off())
            //            {
            //                doorTest = 1;
            //            }
            //            else
            //            {
            //                DelayMs(1000);
            //            }
            //        }
            //    }
        }

        private void btnDoorStop_Click(object sender, EventArgs e)
        {
            doorTest = 0;
        }

        #region FFU 

        FFUCom ffu = new FFUCom();
        public bool ConnectFFU(string com, string para)
        {
            if (ffu.Connect(com, para))
            {
                return true;
            }
            else { return false; }
        }

        #endregion

        private void btnTeachPickVisPos3_Click(object sender, EventArgs e)
        {
            H1_PickupPos.RunTB();
            //while (!H2_PickupPos.RunTBOk())
            //{ Thread.Sleep(2); }
            DataTable dt = RecipeData.Tables["Rset"];
            if (H1_PickupPos.IsAccept)
            {
                dt.Rows[0]["PickTeachVisX3"] = H1_PickupPos.GetOutput("X").ToString();
                dt.Rows[0]["PickTeachVisY3"] = H1_PickupPos.GetOutput("Y").ToString();
                dt.Rows[0]["PickTeachVisU3"] = H1_PickupPos.GetOutput("Angle").ToString();
                dt.AcceptChanges();
            }
            else
            {
                dt.Rows[0]["PickTeachVisX3"] = Convert.ToString(999.999);
                dt.Rows[0]["PickTeachVisY3"] = Convert.ToString(999.999);
                dt.Rows[0]["PickTeachVisU3"] = Convert.ToString(999.999);
                dt.AcceptChanges();
            }
        }

        private void btnTeachPickRobotPos3_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            //if (RobotZebra.ReadPR(20, ref ReadRobotPR)) //PR20
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "005", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["PickTeachRobotX3"] = x.ToString();
            dt.Rows[0]["PickTeachRobotY3"] = y.ToString();
            dt.Rows[0]["PickTeachRobotU3"] = u.ToString();
            dt.AcceptChanges();
        }

        //take pictrue cycle
        private FCResultType flowChart52_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }
        Stopwatch stopwatch = new Stopwatch();
        //send pick command
        private FCResultType flowChart53_FlowRun(object sender, EventArgs e)
        {
            int gotoPickupIndex = SysPara.pickUpProductIndex[SysPara.grapperIndex - 1];  // 1-12
            string posXstr, posYstr, posUstr;
            SysPara.visionPos.x = SysPara.robotPos[SysPara.grapperIndex - 1][0];
            SysPara.visionPos.y = SysPara.robotPos[SysPara.grapperIndex - 1][1];
            SysPara.visionPos.u = SysPara.robotPos[SysPara.grapperIndex - 1][2];
            posXstr = SysPara.visionPos.x >= 0 ? string.Format("{0:000.000}", SysPara.visionPos.x) : string.Format("{0:00.000}", SysPara.visionPos.x);
            posYstr = SysPara.visionPos.y >= 0 ? string.Format("{0:000.000}", SysPara.visionPos.y) : string.Format("{0:00.000}", SysPara.visionPos.y);
            posUstr = SysPara.visionPos.u >= 0 ? string.Format("{0:000.000}", SysPara.visionPos.u) : string.Format("{0:00.000}", SysPara.visionPos.u);
            string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "FeedInPickProduct");
            if (SysPara.cycleRunMode)
            {
                posXstr = "000.000";
                posYstr = "000.000";
                posUstr = "000.000";
            }
            if (SysPara.iProductCountOnGrapper[SysPara.grapperIndex - 1] == 1)
            { return FCResultType.IDLE; }
            else
            {
                if (Robot.WriteToEpson(pos[2], string.Format("{0:d3}", gotoPickupIndex),
                    string.Format("{0:d2}", SysPara.grapperIndex), 30000,
                    posXstr, posYstr, posUstr))
                {
                    RunTM.Restart();
                    MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + string.Format("{0:d3}", gotoPickupIndex) + "AppIndex：" +
           string.Format("{0:d2}", SysPara.grapperIndex) + posXstr + " " + posYstr + " " + posUstr, SysPara.bEnableGeneralSaveLog);

                    if (string.Format("{0:d2}", SysPara.grapperIndex) == "01")
                    {
                        MiddleLayer.ConveyorF.processData.textBox1.Text = "0";
                    }
                    else if (string.Format("{0:d2}", SysPara.grapperIndex) == "02")
                    {
                        MiddleLayer.ConveyorF.processData.textBox2.Text = "0";
                    }
                    else if (string.Format("{0:d2}", SysPara.grapperIndex) == "03")
                    {
                        MiddleLayer.ConveyorF.processData.textBox3.Text = "0";
                    }
                    stopwatch.Restart();
                    return FCResultType.NEXT;
                }
                else
                {
                    return FCResultType.IDLE;
                }
            }
        }
        //R1 set speed
        private FCResultType flowChart54_FlowRun(object sender, EventArgs e)
        {
            string[] pos = GetDataByAnnotation(MiddleLayer.GantryF.dgv_EpsonPosition, "WriteRobotSpeed");
            //Log.log.Write("Command:" + pos[2]
            //    + "Pos:" + pos[3]
            //    + "AppIndex:" + pos[4], Color.Black);
            //string str = Convert.ToString( MiddleLayer.GantryF.GetSettingValue("PSet", "R1MachineSpeedRatio"));
            if (Robot.WriteToEpson(pos[2], pos[3], pos[4], 30000, string.Format("{0:d7}", Convert.ToInt32(MiddleLayer.GantryF.GetSettingValue("PSet", "R1MachineSpeedRatio")))))
            {
                InitTM.Restart();
                MiddleLayer.LogF.AddLog(LogType.Production, "Command:" + pos[2]
              + "Pos:" + pos[3] + "AppIndex:" + pos[4], SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }
        //wait R1 set speed
        private FCResultType flowChart55_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 104)
            {
                return FCResultType.NEXT;
            }
            else if (ret == -104)
            {
                //Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);

                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec))
            {
                //MiddleLayer.LogF.AddLog(LogType.Production, GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], SysPara.bEnableGeneralSaveLog);

                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }        //R1 timeout
            else { return FCResultType.IDLE; }
        }

        //set vision enable
        private FCResultType flowChart56_FlowRun(object sender, EventArgs e)
        {
            string cmd = "001";
            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
            {
                cmd = "002";
            }
            string[] pos = GetDataByAnnotation(MiddleLayer.GantryF.dgv_EpsonPosition, "DisableVision");

            //Log.log.Write("Command:" + pos[2]
            //    + "Pos:" + cmd
            //    + "AppIndex:" + pos[4], Color.Black);
            if (Robot.WriteToEpson(pos[2], cmd, pos[4], 30000))
            {
                InitTM.Restart();
                MiddleLayer.LogF.AddLog(LogType.Production, "Command:" + pos[2]
     + "Pos:" + cmd + "AppIndex:" + pos[4], SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }
        //wait vision enable
        private FCResultType flowChart57_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            {
                return FCResultType.NEXT;
            }
            else if (ret == 0)
            {
                //Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec))
            {
                //MiddleLayer.LogF.AddLog(LogType.Production, GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], SysPara.bEnableGeneralSaveLog);
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }        //R1 timeout
            else { return FCResultType.IDLE; }
        }
        //开始放料
        private FCResultType flowChart58_FlowRun(object sender, EventArgs e)
        {
            OB_RobotLight.Off();
            SysPara.grapperIndex++;
            if (SysPara.iProductCountOnGrapper[SysPara.grapperIndex - 1] == 1)
            {
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }

        }

        private FCResultType flowChart59_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        private void btnTeachDiscRobotPos3_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "011", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["DischargeTeachRobotX3"] = x;
            dt.Rows[0]["DischargeTeachRobotY3"] = y;
            dt.Rows[0]["DischargeTeachRobotU3"] = u;
            dt.AcceptChanges();
        }

        private void btnTeachDiscVisPos3_Click(object sender, EventArgs e)
        {

            H1_DischargePos.RunTB();
            DataTable dt = RecipeData.Tables["Rset"];
            if (H1_DischargePos.IsAccept)
            {
                dt.Rows[0]["DischargeTeachVisX3"] = H1_DischargePos.GetOutput("X").ToString();
                dt.Rows[0]["DischargeTeachVisY3"] = H1_DischargePos.GetOutput("Y").ToString();
                dt.Rows[0]["DischargeTeachVisU3"] = H1_DischargePos.GetOutput("Angle").ToString();
                dt.AcceptChanges();
            }
            else
            {
                dt.Rows[0]["DischargeTeachVisX3"] = Convert.ToString(999.999);
                dt.Rows[0]["DischargeTeachVisY3"] = Convert.ToString(999.999);
                dt.Rows[0]["DischargeTeachVisU3"] = Convert.ToString(999.999);
                dt.AcceptChanges();
            }
        }


        private FCResultType FlowChart60_FlowRun(object sender, EventArgs e)
        {
            string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "GetPosition");
            //MiddleLayer.LogF.AddLog(LogType.Production,"Command：" + pos[2] + "Pos：" + pos[3] + "AppIndex：" + pos[4], SysPara.bEnableGeneralSaveLog);
            //Log.log.Write("Command：" + pos[2] + "Pos：" + pos[3] + "AppIndex：" + pos[4], Color.Black);
            if (Robot.WriteToEpson(pos[2], pos[3], pos[4], 30000))
            {
                RunTM.Restart();
                MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + pos[3] + "AppIndex：" + pos[4], SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart62_FlowRun(object sender, EventArgs e)
        {
            if (updownsignal == "up")
            {
                double[] robotPos = new double[3];
                robotPos = Robot.ReadPositionFromEpson();
                if (RunTM.On(SysPara.TimeOutSec))
                {
                    RunTM.Restart();
                    SysPara.NPShowAlarm("1639");
                    return FCResultType.CASE1;
                }
                if (robotPos[0] == 0 && robotPos[1] == 0)
                {
                    if (RunTM.On(3000))
                    {
                        RunTM.Restart();
                    }
                    return FCResultType.IDLE;
                }
                H1_DischargePos.TB.Inputs["CurGrabPos1X"].Value = robotPos[0];
                H1_DischargePos.TB.Inputs["CurGrabPos1Y"].Value = robotPos[1];
                return FCResultType.NEXT;
            }
            //if (updownsignal == "down")
            //{
            //    double[] robotPos = new double[3];
            //    robotPos = Robot.ReadPositionFromEpson();
            //    if (RunTM.On(SysPara.TimeOutSec))
            //    {
            //        RunTM.Restart();
            //        SysPara.NPShowAlarm("1153");
            //        return FCResultType.IDLE;
            //    }

            //    if (robotPos[0] == 0 && robotPos[1] == 0)
            //    {
            //        if (RunTM.On(3000))
            //        {
            //            RunTM.Restart();
            //        }
            //        return FCResultType.IDLE;
            //    }
            //    H1_Discharge2Pos.TB.Inputs["CurGrabPos1X"].Value = robotPos[0];
            //    H1_Discharge2Pos.TB.Inputs["CurGrabPos1Y"].Value = robotPos[1];
            //    return FCResultType.NEXT;
            //}
            return FCResultType.IDLE;
        }


        private FCResultType FlowChart65_FlowRun(object sender, EventArgs e)
        {
            if (SysPara.cycleRunMode)
            {
                SysPara.iScanPosIndex++;
                return FCResultType.NEXT;
            }
            string[] codes = SysPara.QRCode1.Split(new char[] { ',' });
            //if (SysPara.iScanPosIndex == 3 || SysPara.iScanPosIndex == 4)
            //{
            //    string temp = codes[0];
            //    codes[0] = codes[2];
            //    codes[2] = temp;
            //}
            string[] codesTemp = SysPara.QRCode1.Split(new char[] { ',' });
            // looking for LG-nT-m
            int codeindex = -1;
            for (int i = 0; i < codes.Length; i++)
            {
                if (codes[i] != null && codes[i].Length == 10 && codes[i].Contains("LG"))
                {
                    codeindex = i;
                    break;
                }
            }
            if (codeindex == -1)
            {
                SDKKernal.ShowAlarm("1301");
                return FCResultType.IDLE;
            }
            // MES TrayQRCode
            string codehead = codes[codeindex].Substring(0, 8);
            for (int i = 0; i < MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs.Length; i++)
            {
                MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[i] =
                    codehead + (i + 1).ToString("0#");
                SysPara.sPalletCodes[i] = MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[i];
            }

            //for (int i = 0; i < codes.Length; i++)
            //{
            //    SysPara.sPalletCodes[(SysPara.iScanPosIndex - 1) * 3 + i] = codes[i];
            //}
            //MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[(SysPara.iScanPosIndex - 1) * 3] = codes[0];
            //MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[(SysPara.iScanPosIndex - 1) * 3 + 1] = codes[1];
            //MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[(SysPara.iScanPosIndex - 1) * 3 + 2] = codes[2];

            SysPara.iScanPosIndex++;
            return FCResultType.NEXT;

        }

        private FCResultType FlowChart66_FlowRun(object sender, EventArgs e)
        {
            //SysPara.ScanAgainCount++;
            return FCResultType.NEXT;
        }

        private FCResultType flowChart67_FlowRun(object sender, EventArgs e)
        {
            double[] robotPos = new double[3];
            robotPos = Robot.ReadPositionFromEpson();
            if (RunTM.On(SysPara.TimeOutSec))
            {
                RunTM.Restart();
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }

            if (robotPos[0] == 0 && robotPos[1] == 0)
            {
                if (RunTM.On(3000))
                {
                    RunTM.Restart();
                }
                return FCResultType.IDLE;
            }
            H1_PickupPos.TB.Inputs["CurGrabPos1X"].Value = robotPos[0];
            H1_PickupPos.TB.Inputs["CurGrabPos1Y"].Value = robotPos[1];
            return FCResultType.NEXT;
        }

        private FCResultType flowChart3_FlowRun(object sender, EventArgs e)
        {
            string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "GetPosition");
            if (Robot.WriteToEpson(pos[2], pos[3], pos[4], 30000))
            {
                RunTM.Restart();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private void tm_CableDetection_Tick()
        {


            //if (MiddleLayer.SystemF.OB_LeftDoorCyDown.GetState())
            //{
            // if (SysPara.LeftDoorAlarmEnable)
            //{
            //if (MiddleLayer.SystemF.IB_LeftDoorDownSensor.Off(200))
            //{
            // SysPara.NPShowAlarm("00421", "The left door was illegally opened!");
            //SysPara.LeftDoorAlarmEnable = false;
            // }
            //}
            //}

            //if (MiddleLayer.SystemF.OB_RightDoorCyDown.GetState())
            //{
            //if (SysPara.RightDoorAlarmEnable)
            //{
            //if (MiddleLayer.SystemF.IB_RightDoorDownSensor.Off(200))
            //{
            // SysPara.NPShowAlarm("00422", "The right door was illegally opened!");
            //SysPara.RightDoorAlarmEnable = false;
            //}
            //}
            //}
            string readeIP = "172.168.100.100";
            string camIp = "192.168.90.201";
            string robotIP = "192.168.100.100";
            while (SysPara.bCableDetectEnable)
            {
                if (!DectNetworkCable(camIp))
                {

                    SysPara.NPShowAlarm("1200");
                }
                if (!DectNetworkCable(readeIP))
                {

                    SysPara.NPShowAlarm("1300");
                }
                //if (!DectNetworkCable(plcIP))
                //{
                //    SysPara.NPShowAlarm("00419");
                //}
                if (!DectNetworkCable(robotIP))
                {
                    SysPara.NPShowAlarm("1634");
                }
                DelayMs(2000);

                #region scan feeder error code
                //if (IB_ST03600.On()) { SysPara.NPShowAlarm("03600"); }
                //if (IB_ST03601.On()) { SysPara.NPShowAlarm("03601"); }
                //if (IB_ST03602.On()) { SysPara.NPShowAlarm("03602"); }
                //if (IB_ST03603.On()) { SysPara.NPShowAlarm("03603"); }
                //if (IB_ST03604.On()) { SysPara.NPShowAlarm("03604"); }
                //if (IB_ST03605.On()) { SysPara.NPShowAlarm("03605"); }
                //if (IB_ST03606.On()) { SysPara.NPShowAlarm("03606"); }
                //if (IB_ST03607.On()) { SysPara.NPShowAlarm("03607"); }
                //if (IB_ST03608.On()) { SysPara.NPShowAlarm("03608"); }
                //if (IB_ST03609.On()) { SysPara.NPShowAlarm("03609"); }
                //if (IB_ST03610.On()) { SysPara.NPShowAlarm("03610"); }
                //if (IB_ST03611.On()) { SysPara.NPShowAlarm("03611"); }
                //if (IB_ST03612.On()) { SysPara.NPShowAlarm("03612"); }
                //if (IB_ST03613.On()) { SysPara.NPShowAlarm("03613"); }
                //if (IB_ST03614.On()) { SysPara.NPShowAlarm("03614"); }
                //if (IB_ST03615.On()) { SysPara.NPShowAlarm("03615"); }

                //if (IB_ST03700.On()) { SysPara.NPShowAlarm("03700"); }
                //if (IB_ST03701.On()) { SysPara.NPShowAlarm("03701"); }
                //if (IB_ST03702.On()) { SysPara.NPShowAlarm("03702"); }
                //if (IB_ST03703.On()) { SysPara.NPShowAlarm("03703"); }
                //if (IB_ST03704.On()) { SysPara.NPShowAlarm("03704"); }
                //if (IB_ST03705.On()) { SysPara.NPShowAlarm("03705"); }
                //if (IB_ST03706.On()) { SysPara.NPShowAlarm("03706"); }
                //if (IB_ST03707.On()) { SysPara.NPShowAlarm("03707"); }
                //if (IB_ST03708.On()) { SysPara.NPShowAlarm("03708"); }

                //if (IB_ST03805.On()) { SysPara.NPShowAlarm("03805"); }
                //if (IB_ST03806.On()) { SysPara.NPShowAlarm("03806"); }
                //if (IB_ST03807.On()) { SysPara.NPShowAlarm("03807"); }
                //if (IB_ST03808.On()) { SysPara.NPShowAlarm("03808"); }
                #endregion
            }


        }
        private bool DectNetworkCable(string ip)
        {
            try
            {
                Ping ping = new Ping();
                PingReply pr = ping.Send(ip);
                if (pr.Status == IPStatus.Success)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        private void BtnPathSelect_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbDialog = new FolderBrowserDialog();
            if (fbDialog.ShowDialog() == DialogResult.OK)
            {
                // txtSavePath.Text = fbDialog.SelectedPath;
                DataTable dt = SettingData.Tables["Pset"];
                dt.Rows[0]["SaveImagePath"] = fbDialog.SelectedPath;
                dt.AcceptChanges();
            }
        }



        private FCResultType flowChart69_FlowRun(object sender, EventArgs e)
        {
            if (SysPara.cycleRunMode)
            {
                return FCResultType.IDLE;
            }
            if (!SysPara.cycleRunMode)
            {
                if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
                {
                    return FCResultType.IDLE;
                }
                else
                {
                    return FCResultType.NEXT;
                }
            }
            return FCResultType.IDLE;
        }

        private FCResultType flowChart75_FlowRun(object sender, EventArgs e)
        {
            if (!IB_FeederAlarm.On())
            {
                return FCResultType.NEXT;
            }
            return FCResultType.IDLE;
        }

        private FCResultType flowChart72_FlowRun(object sender, EventArgs e)
        {
            if (IB_FeederReady.On())
            {
                OB_FeederStart.On();
                FeederTM.Restart();
                return FCResultType.NEXT;
            }
            return FCResultType.IDLE;
        }

        private FCResultType flowChart73_FlowRun(object sender, EventArgs e)
        {
            if (FeederTM.On(40000))
            {

                SysPara.NPShowAlarm("1102");
            }
            if (IB_FeederInPlace.On() || MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder")) // || IB_FeederDownInPlace.On())
            {
                //if (IB_FeederInPlace.On())
                //{
                feedersignal = "up";
                //}
                //if (IB_FeederDownInPlace.On())
                //{
                //    feedersignal = "down";
                //}
                OB_FeederStart.Off();
                OB_FeederCompleted.Off();
                return FCResultType.NEXT;
            }
            return FCResultType.IDLE;
        }

        private FCResultType flowChart74_FlowRun(object sender, EventArgs e)
        {
            if (SysPara.JAGStarytEvent.WaitOne(0))
            {
                if (IB_FeederInPlace.On())
                {
                    feedersignal = "up";
                }
                if (IB_FeederAlarm.On())
                {
                    SysPara.NPShowAlarm("1100");
                    return FCResultType.CASE1;
                }
                if (IB_FeederLack.On())
                {
                    SysPara.NPShowAlarm("1104");
                    return FCResultType.CASE1;
                }
                if (!IB_FeederReady.On())
                {
                    SysPara.NPShowAlarm("1101");
                    return FCResultType.CASE1;
                }
                MiddleLayer.LogF.AddLog(LogForm.LogType.Production, "robot had put all product", SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
            if (IB_FeederAlarm.On())
            {
                SysPara.NPShowAlarm("1100");
            }
            if (IB_FeederLack.On())
            {
                SysPara.NPShowAlarm("1104");
            }
            if (!IB_FeederReady.On())
            {
                SysPara.NPShowAlarm("1101");
            }
            return FCResultType.IDLE;
        }

        private FCResultType flowChart79_FlowRun(object sender, EventArgs e)
        {
            if (IB_FeederAlarm.On())
            {
                SysPara.NPShowAlarm("1100");
                return FCResultType.IDLE;
            }
            if (IB_FeederLack.On())
            {
                SysPara.NPShowAlarm("1104");
                return FCResultType.IDLE;
            }
            if (!IB_FeederReady.On())
            {
                SysPara.NPShowAlarm("1101");
                return FCResultType.IDLE;
            }
            return FCResultType.NEXT;
        }

        private FCResultType flowChart78_FlowRun(object sender, EventArgs e)
        {
            OB_FeederCompleted.Off();
            OB_FeederCompleted.On();
            OB_FeederStart.On();
            DelayMs(50);
            FeederTM.Restart();
            return FCResultType.NEXT;
        }

        private FCResultType flowChart76_FlowRun(object sender, EventArgs e)
        {
            if (FeederTM.On(50000))
            {
                SysPara.NPShowAlarm("1105");
                return FCResultType.IDLE;
            }
            else
            {
                if (IB_FeederInPlace.Off())
                {
                    OB_FeederCompleted.Off();
                    FeederTM.Restart();
                    return FCResultType.NEXT;
                }
                else
                {
                    return FCResultType.IDLE;
                }
            }
        }

        private FCResultType flowChart77_FlowRun(object sender, EventArgs e)
        {
            if (FeederTM.On(50000))
            {

                SysPara.NPShowAlarm("1102");
            }
            if (IB_FeederInPlace.On() || MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
            {
                OB_FeederStart.Off();
                OB_FeederCompleted.Off();
                FeederTM.Restart();
                return FCResultType.NEXT;
            }
            return FCResultType.IDLE;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //H1_Discharge2Pos.EditTB();
        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            this.flowChart49.TaskReset();
            bAutoCalibFlow = false;
            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                while (!bAutoCalibFlow)
                {
                    flowChart49.TaskRun();
                }
            });
        }

        private FCResultType flowChart49_FlowRun(object sender, EventArgs e)
        {
            ResetRobot();
            DelayMs(100);
            startRobot();
            return FCResultType.NEXT;
        }

        private FCResultType flowChart48_FlowRun(object sender, EventArgs e)
        {
            CalibPictureCount = 0;
            visCalibData.Clear();
            if (Robot.WriteToEpson("014", "011", "FF", 30000, "FFFFFFF", "FFFFFFF", "FFFFFFF"))
            {
                RobotPose = Robot.ReadRobotXYU;
                DelayMs(100);
                RunTM.Restart();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart47_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec)) { return FCResultType.IDLE; }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart6_FlowRun_1(object sender, EventArgs e)
        {
            if (SendAutoCalibration(CalibPictureCount + 1, 3))
            {
                DelayMs(100);
                RunTM.Restart();
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType flowChart30_FlowRun_1(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                Log.log.Write(GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[3], Color.Red);
                return FCResultType.IDLE;
            }
            else if (RunTM.On(SysPara.TimeOutSec))
            {

                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }        //R timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart46_FlowRun(object sender, EventArgs e)
        {
            //OB_RobotLight.On();
            //CogImage8Grey img = null;
            //Cog3DVect3 xyu = new Cog3DVect3();
            //if (H1_Discharge2Pos.TakePicture())
            //{
            //    img = H1_Discharge2Pos.InputImage;
            //    if (Robot.ConnectStatus)
            //    {
            //        if (Robot.WriteToEpson("015", "000", "FF", 20000, "FFFFFFF", "FFFFFFF", "FFFFFFF"))//Robot.ReadFromEpson()==1)
            //        {
            //            double[] Pos = new double[3];
            //            Pos = RobotPose;
            //            xyu = new Cog3DVect3(Pos[0], Pos[1], Pos[2]);
            //        }
            //        else { return FCResultType.IDLE; }
            //    }
            //    else { return FCResultType.IDLE; }

            //    Tuple<Cog3DVect3, CogImage8Grey> xyu_Image = new Tuple<Cog3DVect3, CogImage8Grey>(xyu, img);
            //    visCalibData.Add(xyu_Image);
            //    CalibPictureCount++;
            //    return FCResultType.NEXT;
            //}
            //else
            //{
            return FCResultType.IDLE;
            //}
        }

        private FCResultType flowChart5_FlowRun_1(object sender, EventArgs e)
        {
            if (CalibPictureCount >= 11)
            {
                return FCResultType.CASE1;
            }
            else
                return FCResultType.NEXT;
        }




        private FCResultType npFlowChart1_FlowRun(object sender, EventArgs e)
        {
            TerminarReinicioRapidoGantry();   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: la inicializacion termino
            bInitialOk = true;
            SysPara.RIniRet = true;
            bRestartProcessOk = true;
            MiddleLayer.ConveyorF.uC_ResetProcessConveyorSequence.bGantryIsSafe = true;
            return FCResultType.IDLE;
        }

        private FCResultType npFlowChart2_FlowRun(object sender, EventArgs e)
        {

            {
                return FCResultType.NEXT;
            }

        }



        private void ResetPick_Click(object sender, EventArgs e)
        {
            Pickup_Odd_Even_Order = 1;

            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["PickPosIndex"] = Pickup_Odd_Even_Order;
            dt.AcceptChanges();
            MiddleLayer.SystemF.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));

        }

        private void trackBar2_MouseUp(object sender, MouseEventArgs e)
        {
            DataTable dt = SettingData.Tables["PSet"];       //初始化取料索引
            dt.Rows[0]["R1MachineSpeedRatio"] = Convert.ToInt32(lbR2SpeedRatio.Text);
            dt.AcceptChanges();
            MiddleLayer.GantryF.WriteSettingData();
            if (MiddleLayer.GantryF.Robot.ConnectStatus)
            {
                string[] pos = MiddleLayer.GantryF.GetDataByAnnotation(MiddleLayer.GantryF.dgv_EpsonPosition, "WriteRobotSpeed");
                MiddleLayer.GantryF.Robot.SetSpeed(pos[2], pos[3], pos[4], 30000, string.Format("{0:d7}", trackBar2.Value));
            }
        }

        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            lbR2SpeedRatio.Text = trackBar2.Value.ToString();
        }

        private FCResultType flowChart4_FlowRun_1(object sender, EventArgs e)
        {
            //System.Threading.Tasks.Task.Factory.StartNew(() =>
            //{
            //    if (!H1_Discharge2Pos.TB.Inputs.Contains("CalibDatas"))
            //    {
            //        H1_Discharge2Pos.TB.Inputs.Add(new Cognex.VisionPro.ToolBlock.CogToolBlockTerminal("CalibDatas", new List<Tuple<Cog3DVect3, CogImage8Grey>>()));
            //    }
            //    H1_Discharge2Pos.visCalibData = visCalibData;
            //    H1_Discharge2Pos.TB.Inputs["ISCalib"].Value = true;
            //    H1_Discharge2Pos.TB.Inputs["GrabPosIndex"].Value = 0;
            //    H1_Discharge2Pos.RunTB();
            //    H1_Discharge2Pos.TB.Inputs["ISCalib"].Value = false;
            //    OB_RobotLight.Off();
            //    DataTable dt = RecipeData.Tables["R1_Discharge2VisCalib"];
            //    List<Tuple<Cog3DVect2, Cog3DVect2>> visRobotData = new List<Tuple<Cog3DVect2, Cog3DVect2>>();
            //    visRobotData = H1_Discharge2Pos.GetOutput("VisRobotData") as List<Tuple<Cog3DVect2, Cog3DVect2>>;
            //    if (H1_Discharge2Pos.IsAccept)
            //    {
            //        dt.Clear();

            //        for (int i = 0; i < visRobotData.Count; i++)
            //        {
            //            DataRow row = dt.NewRow();
            //            row["Calib_Index"] = (i + 1).ToString();
            //            row["Calib_PixelX"] = visRobotData[i].Item1.X.ToString("f3");
            //            row["Calib_PixelY"] = visRobotData[i].Item1.Y.ToString("f3");
            //            row["Calib_RobotX"] = visRobotData[i].Item2.X.ToString("f3");
            //            row["Calib_RobotY"] = visRobotData[i].Item2.Y.ToString("f3");
            //            dt.Rows.Add(row);
            //        }
            //        dt.AcceptChanges();
            //    }
            //    else
            //    {
            //        dt.Rows[0]["Calib_Index"] = "0";
            //        dt.Rows[0]["Calib_PixelX"] = "999";
            //        dt.Rows[0]["Calib_PixelY"] = "999";
            //        dt.Rows[0]["Calib_RobotX"] = "999";
            //        dt.Rows[0]["Calib_RobotY"] = "999";
            //        dt.AcceptChanges();
            //    }
            //});
            //WriteToRobotR(30, 0);
            bAutoCalibFlow = true;
            return FCResultType.IDLE;
        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            //H1_Discharge2Pos.RunTB();
            //DataTable dt = RecipeData.Tables["Rset"];
            //if (H1_Discharge2Pos.IsAccept)
            //{
            //    dt.Rows[0]["Discharge2TeachVisX"] = H1_Discharge2Pos.GetOutput("X").ToString();
            //    dt.Rows[0]["Discharge2TeachVisY"] = H1_Discharge2Pos.GetOutput("Y").ToString();
            //    dt.Rows[0]["Discharge2TeachVisU"] = H1_Discharge2Pos.GetOutput("Angle").ToString();
            //    dt.AcceptChanges();
            //}
            //else
            //{
            //    dt.Rows[0]["Discharge2TeachVisX"] = Convert.ToString(999.999);
            //    dt.Rows[0]["Discharge2TeachVisY"] = Convert.ToString(999.999);
            //    dt.Rows[0]["Discharge2TeachVisU"] = Convert.ToString(999.999);
            //    dt.AcceptChanges();
            //}
        }

        private void button17_Click_1(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "011", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["Discharge2TeachRobotX"] = x;
            dt.Rows[0]["Discharge2TeachRobotY"] = y;
            dt.Rows[0]["Discharge2TeachRobotU"] = u;
            dt.AcceptChanges();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            //H1_Discharge2Pos.RunTB();
            //DataTable dt = RecipeData.Tables["Rset"];
            //if (H1_Discharge2Pos.IsAccept)
            //{
            //    dt.Rows[0]["Discharge2TeachVisX2"] = H1_Discharge2Pos.GetOutput("X").ToString();
            //    dt.Rows[0]["Discharge2TeachVisY2"] = H1_Discharge2Pos.GetOutput("Y").ToString();
            //    dt.Rows[0]["Discharge2TeachVisU2"] = H1_Discharge2Pos.GetOutput("Angle").ToString();
            //    dt.AcceptChanges();
            //}
            //else
            //{
            //    dt.Rows[0]["Discharge2TeachVisX2"] = Convert.ToString(999.999);
            //    dt.Rows[0]["Discharge2TeachVisY2"] = Convert.ToString(999.999);
            //    dt.Rows[0]["Discharge2TeachVisU2"] = Convert.ToString(999.999);
            //    dt.AcceptChanges();
            //}
        }

        private void button18_Click_1(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "011", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["Discharge2TeachRobotX2"] = x;
            dt.Rows[0]["Discharge2TeachRobotY2"] = y;
            dt.Rows[0]["Discharge2TeachRobotU2"] = u;
            dt.AcceptChanges();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            //H1_Discharge2Pos.RunTB();
            //DataTable dt = RecipeData.Tables["Rset"];
            //if (H1_Discharge2Pos.IsAccept)
            //{
            //    dt.Rows[0]["Discharge2TeachVisX3"] = H1_Discharge2Pos.GetOutput("X").ToString();
            //    dt.Rows[0]["Discharge2TeachVisY3"] = H1_Discharge2Pos.GetOutput("Y").ToString();
            //    dt.Rows[0]["Discharge2TeachVisU3"] = H1_Discharge2Pos.GetOutput("Angle").ToString();
            //    dt.AcceptChanges();
            //}
            //else
            //{
            //    dt.Rows[0]["Discharge2TeachVisX3"] = Convert.ToString(999.999);
            //    dt.Rows[0]["Discharge2TeachVisY3"] = Convert.ToString(999.999);
            //    dt.Rows[0]["Discharge2TeachVisU3"] = Convert.ToString(999.999);
            //    dt.AcceptChanges();
            //}
        }

        private void button22_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["Rset"];
            double? x, y, u;
            if (Robot.ConnectStatus)
            {
                Robot.WriteToEpson("012", "011", "FF", 2000, "FFFFFFF", "FFFFFFF", "FFFFFFF");
                DelayMs(2000);
                double[] p = Robot.ReadPositionFromEpson();
                DelayMs(100);
                p = Robot.ReadPositionFromEpson();
                x = p[0]; y = p[1]; u = p[2];
                RobotPose = p;
            }
            else
            {
                x = 0;
                y = 0;
                u = 0;
            }
            dt.Rows[0]["Discharge2TeachRobotX3"] = x;
            dt.Rows[0]["Discharge2TeachRobotY3"] = y;
            dt.Rows[0]["Discharge2TeachRobotU3"] = u;
            dt.AcceptChanges();
        }

        private FCResultType flowChart50_FlowRun(object sender, EventArgs e)
        {
            //DryRun use top, not think about change feeder tray
            if (SysPara.cycleRunMode)        //空跑 默认上层上层点位 不考虑切换料盘
            {
                updownsignal = "up";
                return FCResultType.NEXT;
            }

            // not have feeder use next if 没有飞达
            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
            {
                updownsignal = "up";
                return FCResultType.NEXT;
            }


            if (IB_FeederInPlace.On())
            {
                updownsignal = "up";

                return FCResultType.NEXT;
            }

            else if (RunTM.On(25000))
            {

                SysPara.NPShowAlarm("1102");
                //DisposeFrm(TipsFrm);
                //TipsFrm = new Reintento();
                //TipsFrm.fnSetTextMessageNShow("feeder not at place,please check feeder,and need to ask tray by manual?", true, false, true);
                //if (DialogResult.Yes == TipsFrm.dResult)
                //{
                //    return FCResultType.IDLE;
                //}
                //else
                //{
                    return FCResultType.IDLE;
                //}
            }


            return FCResultType.IDLE;
        }

        private FCResultType flowChart51_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            { OB_FeederSafetySignal.On(); SysPara.JAGStarytEvent.Set(); DelayMs(500); return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec))
            {

                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }        //R1 timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart61_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            { OB_FeederSafetySignal.On(); SysPara.JAGStarytEvent.Set(); return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec))
            {

                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }        //R1 timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart63_FlowRun(object sender, EventArgs e)
        {
            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))               //if not has feeder
            {
                return FCResultType.NEXT;
            }



            if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))                //if has feeder
            {
                //feeder put fall,robot first to safety,then change feeder tray
                if (SysPara.iVacIndex >= SysPara.iVacCount)            //飞达物料放满,机器人回安全位,到安全位再切换料盘
                {
                    if (specialevents)
                    {
                        return FCResultType.NEXT;
                    }
                    string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "UnloadPalletPicture");
                    if (Robot.WriteToEpson(pos[2], "003", "FF", 30000))
                    {
                        InitTM.Restart();
                        //SysPara.NPShowAlarm("80192");
                        return FCResultType.CASE1;
                    }
                    else { return FCResultType.IDLE; }
                }
                return FCResultType.NEXT;
            }

            return FCResultType.IDLE;
        }

        private FCResultType flowChart64_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            { OB_FeederSafetySignal.On(); SysPara.JAGStarytEvent.Set(); return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec))
            {
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart68_FlowRun(object sender, EventArgs e)
        {
            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))             //if not has feeder
            {
                return FCResultType.NEXT;
            }


            if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))            //if has feeder
            {
                if (SysPara.iVacIndex >= SysPara.iVacCount)
                {
                    string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "UnloadPalletPicture");
                    if (Robot.WriteToEpson(pos[2], "003", "FF", 30000))
                    {
                        InitTM.Restart();

                        //SysPara.NPShowAlarm("80192");
                        SysPara.iProductCountOnGrapper[0] = 0;
                        SysPara.iProductCountOnGrapper[1] = 0;
                        SysPara.iProductCountOnGrapper[2] = 0;
                        SysPara.pictureOKCount = 0;
                        return FCResultType.CASE1;
                    }
                    else { return FCResultType.IDLE; }
                }
                return FCResultType.NEXT;
            }

            return FCResultType.IDLE;
        }

        private FCResultType flowChart70_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            { OB_FeederSafetySignal.On(); SysPara.JAGStarytEvent.Set(); return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec))
            {
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }        //R1 timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart71_FlowRun(object sender, EventArgs e)
        {
            if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))   //if not has feeder,no need to leave robot
            { return FCResultType.CASE1; }

            //one finished,robot may be stop in feeder up,if manually click change feeder tray,may be hit robot
            string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "FeedInPalletScan");   //一块载具完成后，机器人可能会停在飞达上方，防止可能手动点了飞达切换料盘，导致飞达撞机器人，移走机器人。
            if (Robot.WriteToEpson(pos[2], "001", pos[4], 30000))
            {
                RunTM.Restart();
                MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + "001" + "AppIndex：" + pos[4], SysPara.bEnableGeneralSaveLog);
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType flowChart80_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            { return FCResultType.NEXT; }
            else if (ret == 0)
            { return FCResultType.IDLE; }
            else if (RunTM.On(SysPara.TimeOutSec))
            {
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }
            else
            { return FCResultType.IDLE; }
        }

        private FCResultType flowChart81_FlowRun(object sender, EventArgs e)
        {
            if (cleargrapperfinish == true)
            {
                cleargrapperfinish = false;
                //if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
                //{
                //    return FCResultType.NEXT;
                //}
                string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "FeedInPalletScan");
                if (Robot.WriteToEpson(pos[2], "001", pos[4], 30000))
                {
                    RunTM.Restart();
                    MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + pos[2] + "Pos：" + "001" + "AppIndex：" + pos[4], SysPara.bEnableGeneralSaveLog);
                    return FCResultType.CASE1;
                }
                else { cleargrapperfinish = true; return FCResultType.IDLE; }
            }
            return FCResultType.NEXT;
        }

        private FCResultType flowChart82_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            { return FCResultType.NEXT; }
            else if (ret == 0)
            { return FCResultType.IDLE; }
            else if (RunTM.On(SysPara.TimeOutSec))
            {
                SysPara.NPShowAlarm("1639");
                return FCResultType.IDLE;
            }
            else
            { return FCResultType.IDLE; }
        }

        private FCResultType flowChart66_FlowRun_1(object sender, EventArgs e)
        {
            // SysPara.bUnloadCompleteStatus = true;
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.AssembCompeletStatus = true;
            return FCResultType.NEXT;
            //if (MiddleLayer.SystemF.GetSettingValue("PSet", "DisableAutoProcessChooseFeeder"))
            //{
            //    SysPara.NPShowAlarm("8023");
            //    DisposeFrm(TipsFrm);
            //    TipsFrm = new Reintento();
            //    TipsFrm.fnSetTextMessageNShow("NG products have been taken away?", true, false, true);
            //    if (DialogResult.Yes == TipsFrm.dResult)
            //    {
            //        SysPara.bUnloadCompleteStatus = true;
            //        return FCResultType.NEXT;
            //    }
            //    else
            //    {
            //        return FCResultType.IDLE;
            //    }
            //}
            //else
            //{
            //    SysPara.NPShowAlarm("80231");
            //    SysPara.bUnloadCompleteStatus = true;
            //    return FCResultType.NEXT;
            //}

        }

        private FCResultType flowChart83_FlowRun(object sender, EventArgs e)
        {
            OB_FeederCompleted.Off();
            OB_FeederCompleted.On();
            DelayMs(500);
            OB_FeederCompleted.Off();
            return FCResultType.NEXT;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            DataTable dt = SettingData.Tables["PSet"];
            dt.Rows[0]["TodayTaskValue"] = int.Parse(txtTaskValue.Text);
            dt.AcceptChanges();
            WriteSettingData();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            DataTable dt = SettingData.Tables["PSet"];
            dt.Rows[0]["TodayFinishedTaskValue"] = 0;
            dt.AcceptChanges();
            WriteSettingData();
        }

        private FCResultType npFlowChart3_FlowRun(object sender, EventArgs e)
        {
            if (bRestartQuickSkipMes) return FCResultType.NEXT;   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: MES ya en linea, se brinca (OFFLINE)
            if (SysPara.EnableMes)
            {
                if (!MESLib.CommParas.MesManager.LGIT_SETCODE_OFFLINE_REASON_OK)
                {
                    return FCResultType.IDLE;
                }
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart4_FlowRun(object sender, EventArgs e)
        {
            if (bRestartQuickSkipMes) return FCResultType.NEXT;   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: MES ya en linea, se brinca (IDLE REASON)
            if (SysPara.EnableMes)
            {
                if (MESLib.CommParas.MesManager.LGIT_SETCODE_IDLE_REASON_OK)
                    return FCResultType.NEXT;
                else
                    return FCResultType.IDLE;
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart5_FlowRun(object sender, EventArgs e)
        {
            if (bRestartQuickSkipMes) return FCResultType.NEXT;   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: MES ya en linea, se brinca (MODULE LIST)
            if (SysPara.EnableMes)
            {
                if (MESLib.CommParas.MesManager.LGIT_SETCODE_MODEL_LIST_OK)
                {
                    //MESLib.CommFuns.UpdateModuleList();
                    // MainForm Render deal with this event
                }
                else
                {
                    return FCResultType.IDLE;
                }
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart6_FlowRun(object sender, EventArgs e)
        {
            if (bRestartQuickSkipMes) return FCResultType.NEXT;   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: MES ya en linea, se brinca (OP CALL)
            if (SysPara.EnableMes)
            {
                if (MESLib.CommParas.MesManager.LGIT_OP_CALL_OK)
                    return FCResultType.NEXT;
                else
                    return FCResultType.IDLE;
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart7_FlowRun(object sender, EventArgs e)
        {
            if (MESLib.CommParas.EnableMes)
            {
                if (MESLib.CommParas.MesManager.PRODID.Trim() == "")
                {
                    SysPara.NPShowAlarm("70108"); return FCResultType.IDLE;
                }
            }

            return FCResultType.NEXT;
        }
        DateTime Timestamp_10701 = DateTime.Now;
        JTimer Timer_10701 = new JTimer();
        JTimer Timer_LGIT_LOT_START = new JTimer();
        private FCResultType npFlowChart8_FlowRun(object sender, EventArgs e)
        {
            if (mpcActivo) PrepararLoteMpc();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo: el 10701 con todo el pallet

            int gotoPickupIndex = SysPara.pickUpProductIndex[SysPara.grapperIndex - 1];
            bool isLastOne = false;
            if (SysPara.grapperIndex == 3)
            {
                isLastOne = true;
            }
            else
            {
                if (gotoPickupIndex >= SysPara.pickUpProductIndex[SysPara.grapperIndex])
                {
                    isLastOne = true;
                }
            }
            if (!mpcActivo && !isLastOne)   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
            {
                return FCResultType.CASE1;
            }

            if (SysPara.EnableMes)
            {
                //MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[1] = "LG1T-02-02";
                List<string> _PocketID_List = new List<string>();
                List<string> _ModuleID_List = new List<string>();
                for (int i = 0; i < PickedPocketIDs.Count; i++)
                {
                    int index = PickedPocketIDs[i];
                    if (RechazadaPorMes(index)) continue;   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: la rechazo el MES, va al NG buffer
                    string pocketid = MESLib.CommParas.MesManager.POCKETIDs[index];
                    string module = MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[index];


                    _PocketID_List.Add(pocketid);
                    _ModuleID_List.Add(module);
                }

                MESLib.MesLog.AddInfo("10701");
                MESLib.MesLog.AddInfo("Module:" + _ModuleID_List._ToString());
                MESLib.MesLog.AddInfo("Pocket: " + _PocketID_List._ToString());

                Timestamp_10701 = DateTime.Now;
                Timer_10701.Restart();
                Timer_LGIT_LOT_START.Restart();
                MESLib.CommParas.MesManager.LGIT_LOT_START_OK = false;
                MESLib.CommParas.MesManager.LGIT_LOT_FAIL_OK = false;
                MESLib.CommParas.MesManager.LGIT_LOT_START_STR = "";
                MESLib.CommParas.MesManager.MES_S6F11_10701(_PocketID_List, _ModuleID_List,
                    MESLib.CommParas.MesManager.PRODID);
            }
            return FCResultType.NEXT;

        }

        private FCResultType npFlowChart9_FlowRun(object sender, EventArgs e)
        {
            if (MESLib.CommParas.EnableMes)
            {
                if (MESLib.CommParas.MesManager.MES_S6F11_ACK_WithTimeout("10701", Timestamp_10701,
                    Timer_10701, out int ACK, out string data, out bool timeout))
                {
                    if (ACK == 0)
                    {
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        SysPara.NPShowAlarm("70100");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                else
                {
                    if (timeout)
                    {
                        // T3 Fail
                        MESLib.CommParas.MesManager.MES_S6F11_11001("2");
                        SysPara.NPShowAlarm("70102");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                return FCResultType.IDLE;
            }
            return FCResultType.NEXT;

        }
        public string[] Get_LOT_FAIL_Message()
        {
            string[] msg = new string[] { "", "" };
            JObject lotsinfo = MESLib.CommParas.MesManager.LGIT_LOT_START_FAIL_DATA["LOTINFOLIST"].Value<JObject>();

            try
            {
                // module list
                foreach (var p in lotsinfo.Properties())
                {
                    var name = p.Name;
                    var value = JObject.Parse(p.Value.ToString());
                    msg[0] = value["MODULEID"].Value<string>();
                    break;
                }

            }
            catch (Exception ex)
            {
                msg[0] = ex.Message;
            }
            // get text
            try
            {
                msg[1] = MESLib.CommParas.MesManager.LGIT_LOT_START_FAIL_DATA["TEXT"].Value<string>();
            }
            catch (Exception ex)
            {
                msg[1] = ex.Message;
            }
            return msg;
        }

        private FCResultType npFlowChart10_FlowRun(object sender, EventArgs e)
        {
            //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: mientras el operador decide en la ventana, este paso no avanza;
            //  si ya decidio, se aplica aqui (GantryForm_RechazoMes.cs).
            FCResultType decisionMes;
            if (DecisionMesPendiente(out decisionMes)) return decisionMes;
            if (MESLib.CommParas.EnableMes)
            {
                if (MESLib.CommParas.MesManager.LGIT_LOT_START_OK || MESLib.CommParas.MesManager.LGIT_LOT_FAIL_OK)
                {
                    if (MESLib.CommParas.MesManager.LGIT_LOT_START_OK)
                    {
                        Alpha.Classes.ModoNgMes.RegistrarPalletBueno();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: grupo bueno, se reinicia la cuenta de NG seguidas
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: LOT ID FAIL con todas las piezas, la ventana en la
                        //  pantalla y MANDAR A NG (antes: un solo modulo y la ventana del MES dentro de este paso).
                        return LoteFallido(false);
                    }
                }
                else
                {
                    if (Timer_LGIT_LOT_START.On(60000))
                    {
                        // START OUTTIME
                        MESLib.CommParas.MesManager.MES_S6F11_11002("2");
                        Timer_LGIT_LOT_START.Restart();
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                    return FCResultType.IDLE;
                }
            }
            return FCResultType.NEXT;

        }

        private FCResultType npFlowChart19_FlowRun(object sender, EventArgs e)
        {


            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart16_FlowRun(object sender, EventArgs e)
        {
            if (MESLib.CommParas.EnableMes)
            {
                if (SysPara.gotoPictureIndex == 12)
                {
                    Timestamp_10401 = DateTime.Now;
                    Timer_10401.Restart();
                    MESLib.CommParas.MesManager.MES_S6F11_10401(2); // idle
                }
            }
            return FCResultType.NEXT;

        }
        DateTime Timestamp_10401 = DateTime.Now;
        JTimer Timer_10401 = new JTimer();

        private FCResultType npFlowChart18_FlowRun(object sender, EventArgs e)
        {
            if (MESLib.CommParas.EnableMes)
            {
                Timestamp_10401 = DateTime.Now;
                Timer_10401.Restart();
                MESLib.CommParas.MesManager.MES_S6F11_10401(((byte)MESLib.ProcessState.EXECUTING));
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart17_FlowRun(object sender, EventArgs e)
        {
            if (MESLib.CommParas.EnableMes)
            {
                if (MESLib.CommParas.MesManager.MES_S6F11_ACK_WithTimeout("10401", Timestamp_10401,
                    Timer_10401, out int ACK, out string data, out bool timeout))
                {
                    if (ACK == 0)
                    {
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        SysPara.NPShowAlarm("70100");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                else
                {
                    if (timeout)
                    {
                        // T3 Fail
                        MESLib.CommParas.MesManager.MES_S6F11_11001("2");
                        SysPara.NPShowAlarm("70102");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                return FCResultType.IDLE;
            }
            return FCResultType.NEXT;

        }
        DateTime Timestamp_10710 = DateTime.Now;
        JTimer Timer_10710 = new JTimer();

        private FCResultType npFlowChart14_FlowRun(object sender, EventArgs e)
        {
            // update to mes, 10710
            string[] results = new string[12];
            if (MESLib.CommParas.EnableMes)
            {
                List<string> _LotID_List = new List<string>();
                List<string> _PocketID_List = new List<string>();
                List<string> _ModuleID_List = new List<string>();
                List<string> _CarrierID_List2 = new List<string>();
                List<bool> _Result_List = new List<bool>();
                List<string> _Defect_Code_List = new List<string>();

                List<string> _MaterialID_List = new List<string>(); // not used here

                for (int i = 0; i < 12; i++)
                {
                    _Defect_Code_List.Add("");
                    _Result_List.Add(true);
                }

                foreach (var pair in MESLib.CommParas.LOT_START_VALUE_LIST)
                {
                    int key = pair.Key;
                    JObject lotinfo = pair.Value;
                    string lotid = lotinfo["LOTID"].Value<string>();
                    string pocketid = lotinfo["POCKETID"].Value<string>();
                    string moduleid = lotinfo["MODULEID"].Value<string>();

                    _LotID_List.Add(lotid);
                    _PocketID_List.Add(pocketid);
                    _ModuleID_List.Add(moduleid);

                    //_MaterialID_List.Add("");

                    int index = MESLib.CommParas.MesManager.GetIndex(pocketid, MESLib.CommParas.MesManager.POCKETIDs);
                    _CarrierID_List2.Add(MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[index]);
                    _MaterialID_List.Add("");
                }

                MESLib.MesLog.AddInfo("10710");
                MESLib.MesLog.AddInfo("Module:" + _ModuleID_List._ToString());
                MESLib.MesLog.AddInfo("Pocket: " + _PocketID_List._ToString());
                MESLib.MesLog.AddInfo("LotId:" + _LotID_List._ToString());
                MESLib.MesLog.AddInfo("Result:" + _Result_List._ToString());
                MESLib.MesLog.AddInfo("Defect: " + _Defect_Code_List._ToString());

                Timestamp_10710 = DateTime.Now;
                Timer_10710.Restart();
                MESLib.CommParas.MesManager.MES_S6F11_10710(_LotID_List, _PocketID_List, _ModuleID_List,
                    _LotID_List, _PocketID_List, _CarrierID_List2, _ModuleID_List,
                    MESLib.CommParas.MesManager.PROCID, MESLib.CommParas.MesManager.PRODID,
                    _Result_List, _Defect_Code_List,
                    _MaterialID_List, "",
                    "", "");
            }
            return FCResultType.NEXT;

        }

        private FCResultType npFlowChart15_FlowRun(object sender, EventArgs e)
        {
            if (MESLib.CommParas.EnableMes)
            {
                if (MESLib.CommParas.MesManager.MES_S6F11_ACK_WithTimeout("10710", Timestamp_10710,
                    Timer_10710, out int ACK, out string data, out bool timeout))
                {
                    if (ACK == 0)
                    {
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        SysPara.NPShowAlarm("70100");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                else
                {
                    if (timeout)
                    {
                        // T3 Fail
                        MESLib.CommParas.MesManager.MES_S6F11_11001("2");
                        MESLib.CommParas.MesCenter.StopRunning();
                        SysPara.NPShowAlarm("70102");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                return FCResultType.IDLE;
            }
            return FCResultType.NEXT;

        }
        DateTime Timestamp_10704 = DateTime.Now;
        JTimer Timer_10704 = new JTimer();
        JTimer Timer_LGIT_LOT_FAIL = new JTimer();

        private FCResultType npFlowChart11_FlowRun(object sender, EventArgs e)
        {
            PCBCode = new string[12];
            if (MESLib.CommParas.EnableMes)
            {
                string tmpobj = JObject.Parse(MESLib.CommParas.MesManager.LGIT_LOT_START_STR).ToString();

                List<string> _LotID_List = new List<string>();
                List<string> _PocketID_List = new List<string>();
                List<string> _ModuleID_List = new List<string>();
                foreach (var pair in MESLib.CommParas.LOT_START_VALUE_LIST)
                {

                    int key = pair.Key;
                    var lotinfo = pair.Value;

                    string lotid = lotinfo["LOTID"].Value<string>();
                    string pocketid = lotinfo["POCKETID"].Value<string>();
                    string moduleid = lotinfo["MODULEID"].Value<string>();
                    _LotID_List.Add(lotid);
                    _PocketID_List.Add(pocketid);
                    _ModuleID_List.Add(moduleid);

                    MESLib.CommParas.MesManager.PROCID = lotinfo["PROCID"].Value<string>();
                    int index = -1;
                    //string lotid = jobj1["LOTID"].Value<string>();
                    index = MESLib.CommParas.MesManager.GetIndex(pocketid, MESLib.CommParas.MesManager.POCKETIDs);

                    if (index == -1)
                    {
                        // Alarm
                        SysPara.NPShowAlarm("70104"); // report and RCMD not match
                        MESLib.CommParas.MesCenter.PauseRunning();
                    }
                    // fill MesManager Info: lotid, moduleid
                    MESLib.CommParas.MesManager.LOTIDs[index] = lotid;
                    PCBCode[index] = lotid;
                }

                MESLib.MesLog.AddInfo("10701");
                MESLib.MesLog.AddInfo("Module:" + _ModuleID_List._ToString());
                MESLib.MesLog.AddInfo("Pocket: " + _PocketID_List._ToString());
                MESLib.MesLog.AddInfo("LotId:" + _LotID_List._ToString());

                Timestamp_10704 = DateTime.Now;
                Timer_10704.Restart();

                MESLib.CommParas.MesManager.LGIT_LOT_START_OK = false;
                MESLib.CommParas.MesManager.LGIT_LOT_FAIL_OK = false;
                Timer_LGIT_LOT_FAIL.Restart();

                MESLib.CommParas.MesManager.MES_S6F11_10704(_LotID_List,
                    _PocketID_List, _ModuleID_List, MESLib.CommParas.MesManager.PROCID
                    , MESLib.CommParas.MesManager.PRODID);
            }

            return FCResultType.NEXT;

        }

        private FCResultType npFlowChart12_FlowRun(object sender, EventArgs e)
        {
            if (MESLib.CommParas.EnableMes)
            {
                if (MESLib.CommParas.MesManager.MES_S6F11_ACK_WithTimeout("10704", Timestamp_10704,
                    Timer_10704, out int ACK, out string data, out bool timeout))
                {
                    if (ACK == 0)
                    {
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        SysPara.NPShowAlarm("70100");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                else
                {
                    if (timeout)
                    {
                        // T3 Fail
                        MESLib.CommParas.MesManager.MES_S6F11_11001("2");
                        SysPara.NPShowAlarm("70102");
                        MESLib.CommParas.MesCenter.StopRunning();
                        return FCResultType.IDLE;
                    }
                }
                return FCResultType.IDLE;
            }
            return FCResultType.NEXT;

        }

        private FCResultType npFlowChart13_FlowRun(object sender, EventArgs e)
        {
            //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: mientras el operador decide en la ventana, este paso no avanza;
            //  si ya decidio, se aplica aqui (GantryForm_RechazoMes.cs).
            FCResultType decisionMes;
            if (DecisionMesPendiente(out decisionMes)) return decisionMes;
            if (SysPara.EnableMes)
            {
                if (MESLib.CommParas.MesManager.LGIT_LOT_START_OK || MESLib.CommParas.MesManager.LGIT_LOT_FAIL_OK)
                {
                    if (MESLib.CommParas.MesManager.LGIT_LOT_START_OK)
                    {
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: LOT ID FAIL con todas las piezas, la ventana en la
                        //  pantalla y MANDAR A NG (antes: un solo modulo y la ventana del MES dentro de este paso).
                        return LoteFallido(true);
                    }
                }
                if (Timer_LGIT_LOT_FAIL.On(1000))
                    return FCResultType.NEXT;
                return FCResultType.IDLE;
            }
            return FCResultType.NEXT;

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (button5.BackColor == Color.Green)
            {
                OB_RobotLight.Off();
                button5.BackColor = Color.Transparent;

            }
            else if (button5.BackColor == Color.Transparent)
            {
                OB_RobotLight.On();
                button5.BackColor = Color.Green;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button5.BackColor == Color.Green)
            {
                OB_RobotLight.Off();
                button5.BackColor = Color.Transparent;

            }
            else if (button5.BackColor == Color.Transparent)
            {
                OB_RobotLight.On();
                button5.BackColor = Color.Green;

            }
        }

        private void ResetDischarge_Click_2(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["VacIndex"] = 0;
            dt.AcceptChanges();
            this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        private void button11_Click_2(object sender, EventArgs e)
        {

        }

        private FCResultType npFlowChart20_FlowRun(object sender, EventArgs e)
        {
            SysPara.visionPos = new VisionPos();
            try
            {
                //SettingData - MSet.DownCCDExpTime
                double exposure = GetSettingValue("MSet", "DownCCDExpTime");
                if (H1_NGCCDCheck.TakePicture(exposure))         //CCD take picture
                {
                    RefreshDifferentThreadUI(cogRecDisp_H5_Recipe, () =>
                    {
                        cogRecDisp_H5_Recipe.Image = H1_NGCCDCheck.InputImage;
                        cogRecDisp_H5_Recipe.Fit();
                    });
                    //if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
                    //{
                    H1_NGCCDCheck.RunTB();
                    if (Convert.ToBoolean(H1_NGCCDCheck.TB.Outputs["IsHaveProduct"].Value) == false)
                    {
                        MiddleLayer.LogF.AddLog(LogForm.LogType.Production, "robot NG throwing position1 not have product", SysPara.bEnableGeneralSaveLog);
                        OB_RobotLight.Off();
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        MiddleLayer.LogF.AddLog(LogForm.LogType.Production, "robot NG throwing position1 have product!!!need clear", SysPara.bEnableGeneralSaveLog);

                        return FCResultType.CASE1;
                    }
                }
                else
                {
                    CCDAlogrithmStatus = false;

                    return FCResultType.CASE1;
                }
            }
            catch
            {
                CCDAlogrithmStatus = false;
                SDKKernal.ShowAlarm("1205");        //CCD fail
                return FCResultType.CASE1;
            }
        }

        private FCResultType npFlowChart24_FlowRun(object sender, EventArgs e)
        {
            gripper = "00";
            switch (Robot.ErorrCode)
            {
                case "E9000":
                    gripper = "01";
                    break;
                case "E9001":
                    gripper = "02";
                    break;
                case "E9002":
                    gripper = "03";
                    break;
                default:
                    break;
            }
            if (!GetRecipeValue("RSet", "NGbuffer1"))
            {
                SysPara.ngPos = "001";
            }
            else if (!GetRecipeValue("RSet", "NGbuffer2"))
            {
                SysPara.ngPos = "002";
            }
            else if (!GetRecipeValue("RSet", "NGbuffer3"))
            {
                SysPara.ngPos = "003";
            }
            else if (!GetRecipeValue("RSet", "NGbuffer4"))
            {
                SysPara.ngPos = "004";
            }
            else
            {
                //MiddleLayer.LogF.AddLog(LogForm.LogType.Production, "NG had full", SysPara.bEnableGeneralSaveLog);
                //SDKKernal.ShowAlarm("12005");
                reintento.Dispose();
                reintento = new Reintento();
                reintento.fnSetTextMessageNShow("NG tray is full!!! sure has been replaced?", true, false, true);
                npFlowChart25.Enabled = true;
                npFlowChart25.BackColor = Color.Red;
                if (reintento.dResult == DialogResult.Yes)
                {
                    DataTable dt = RecipeData.Tables["RSet"];
                    dt.Rows[0]["NGbuffer1"] = false;
                    dt.Rows[0]["NGbuffer2"] = false;
                    dt.Rows[0]["NGbuffer3"] = false;
                    dt.Rows[0]["NGbuffer4"] = false;
                    dt.AcceptChanges();
                    this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
                    SysPara.ngPos = "001";
                    return FCResultType.NEXT;
                }
                else
                {
                    DelayMs(500);
                    return FCResultType.IDLE;
                }
                //return FCResultType.IDLE;
            }
            string bufferIndex = "NGbuffer1";
            switch (SysPara.ngPos)
            {
                case "001":
                    bufferIndex = "NGbuffer1";
                    break;
                case "002":
                    bufferIndex = "NGbuffer2";
                    break;
                case "003":
                    bufferIndex = "NGbuffer3";
                    break;
                case "004":
                    bufferIndex = "NGbuffer4";
                    break;
                default:
                    break;
            }
            DataTable dt1 = RecipeData.Tables["RSet"];
            dt1.Rows[0][bufferIndex] = true;
            dt1.AcceptChanges();
            this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
            return FCResultType.NEXT;
        }

        private void button77_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["NGbuffer1"] = false;
            dt.Rows[0]["NGbuffer2"] = false;
            dt.Rows[0]["NGbuffer3"] = false;
            dt.Rows[0]["NGbuffer4"] = false;
            dt.AcceptChanges();
            this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));

        }

        private FCResultType npFlowChart23_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart22_FlowRun(object sender, EventArgs e)
        {
            if (Robot.WriteToEpson("017", SysPara.ngPos, "FF", 20000))
            {
                MiddleLayer.LogF.AddLog(LogForm.LogType.Production, "robot to throwing position cammer", SysPara.bEnableGeneralSaveLog);
                InitTM.Restart();
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
        }

        private FCResultType npFlowChart21_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1)
            {
                OB_RobotLight.On();
                //MiddleLayer.LogF.AddLog(LogForm.LogType.Production, "robot to throwing  cammer position ok", SysPara.bEnableGeneralSaveLog); 
                return FCResultType.NEXT;
            }
            else if (ret == 0)
            {
                //MiddleLayer.LogF.AddLog(LogForm.LogType.Production, GetDataByAnnotation(dgv_EpsonErrInfo, Robot.ErorrCode)[1], SysPara.bEnableGeneralSaveLog);
                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec))
            {
                //MiddleLayer.LogF.AddLog(LogForm.LogType.Production, "robot to throwing  cammer position timeout", SysPara.bEnableGeneralSaveLog);
                SDKKernal.ShowAlarm("1639");
                return FCResultType.IDLE;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType npFlowChart25_FlowRun(object sender, EventArgs e)
        {
            //string[] pos = GetDataByAnnotation(dgv_EpsonPosition, "NG Position Assemb");
            if (Robot.WriteToEpson("016", SysPara.ngPos, gripper, 30000))
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Command：" + "016" + "Pos：" + SysPara.ngPos + "AppIndex：" + gripper, SysPara.bEnableGeneralSaveLog);
                InitTM.Restart();
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }

        private FCResultType npFlowChart26_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ret == 1) { return FCResultType.NEXT; }
            else if (ret == 0)
            {
                return FCResultType.IDLE;
            }
            else if (InitTM.On(SysPara.TimeOutSec)) { SDKKernal.ShowAlarm("1153"); return FCResultType.IDLE; }        //R1 timeout
            else { return FCResultType.IDLE; }
        }

        private FCResultType npFlowChart27_FlowRun(object sender, EventArgs e)
        {
            string bufferIndex = "NGbuffer1";
            switch (SysPara.ngPos)
            {
                case "001":
                    bufferIndex = "NGbuffer1";
                    break;
                case "002":
                    bufferIndex = "NGbuffer2";
                    break;
                case "003":
                    bufferIndex = "NGbuffer3";
                    break;
                case "004":
                    bufferIndex = "NGbuffer4";
                    break;
                default:
                    break;
            }
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0][bufferIndex] = true;
            dt.AcceptChanges();
            this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
            return FCResultType.NEXT;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            H1_NGCCDCheck.EditTB();
        }

        private void dgv_EpsonErrInfo_Load(object sender, EventArgs e)
        {

        }

        DateTime Timestamp_10711 = DateTime.Now;
        JTimer Timer_10711 = new JTimer();
        private FCResultType npFlowChart28_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
            // update to mes, 10710
            string[] results = new string[12];
            if (MESLib.CommParas.EnableMes)
            {
                List<string> _LotID_List = new List<string>();
                List<string> _PocketID_List = new List<string>();
                List<string> _ModuleID_List = new List<string>();

                foreach (var pair in MESLib.CommParas.LOT_START_VALUE_LIST)
                {
                    int key = pair.Key;
                    JObject lotinfo = pair.Value;
                    string lotid = lotinfo["LOTID"].Value<string>();
                    string pocketid = lotinfo["POCKETID"].Value<string>();
                    string moduleid = lotinfo["MODULEID"].Value<string>();

                    _LotID_List.Add(lotid);
                    _PocketID_List.Add(pocketid);
                    _ModuleID_List.Add(moduleid);
                }

                MESLib.MesLog.AddInfo("10711");

                Dictionary<string, string> parameters = new Dictionary<string, string>();
                string filename = "";
                filename = DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
                string filepath = @"D:\GMES\APDLog";
                filepath = System.IO.Path.Combine(filepath, DateTime.Now.ToString("yyyyMMdd"));

                // create lotinfo
                for (int i = 0; i < SysPara.bProductValid.Length; i++)
                {
                    if (!SysPara.bProductValid[i])
                    {
                        continue;
                    }

                    int index = i;
                    string pocketid = MESLib.CommParas.MesManager.POCKETIDs[index];
                    string module = MESLib.CommParas.MesManager.TRAY_POSITION_QRCODEs[index];
                    string lotid = MESLib.CommParas.MesManager.LOTIDs[index];
                    _PocketID_List.Add(pocketid);
                    _ModuleID_List.Add(module);
                    _LotID_List.Add(lotid);


                    if (i >= MESLib.CommParas.MesManager.RESULTs.Length)
                        throw new ArgumentOutOfRangeException("FlowResult's length doesn't equal to IsHaveProduct's length");
                }
                // check file path
                if (!System.IO.Directory.Exists(filepath))
                {
                    System.IO.Directory.CreateDirectory(filepath);
                }
                string csv_title = "C/T";
                using (System.IO.StreamWriter sw = new StreamWriter(System.IO.Path.Combine(filepath, filename), true))
                {
                    sw.WriteLine(csv_title);
                }


                // create parameters
                string ct = "";
                string _ct = (processData.swCycleTime.ElapsedMilliseconds / 1000.0).ToString("#.0");

                for (int i = 0; i < MESLib.CommParas.MesManager.POCKETIDs.Length; i++)
                {
                    string pocketid = MESLib.CommParas.MesManager.POCKETIDs[i];

                    if (!SysPara.bProductValid[i])
                    {
                        ct += "";
                    }
                    else
                    {
                        ct += _ct;
                        // csv file parameters                
                        using (System.IO.StreamWriter sw = new StreamWriter(System.IO.Path.Combine(filepath, filename), true))
                        {
                            sw.WriteLine(string.Format("{0}",
                                _ct));
                        }
                    }
                    if (i != MESLib.CommParas.MesManager.POCKETIDs.Length - 1)
                    {
                        ct += ",";
                    }
                }
                parameters.Add("C/T", _ct);

                Timestamp_10711 = DateTime.Now;
                Timer_10711.Restart();

                MESLib.MesLog.AddInfo("_Pocket_List: " + _PocketID_List._ToString());
                MESLib.MesLog.AddInfo("_Module_List: " + _ModuleID_List._ToString());
                MESLib.MesLog.AddInfo("_LotID_List: " + _LotID_List._ToString());


                MESLib.CommParas.MesManager.MES_S6F11_10711(_LotID_List, _PocketID_List,
                    _ModuleID_List, MESLib.CommParas.MesManager.PRODID,
                    MESLib.CommParas.MesManager.PROCID,
                    parameters, filename, filepath, "", "");
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart29_FlowRun(object sender, EventArgs e)
        {
            return FCResultType.NEXT;
            if (MESLib.CommParas.EnableMes)
            {
                if (MESLib.CommParas.MesManager.MES_S6F11_ACK_WithTimeout("10711", Timestamp_10711,
                    Timer_10711, out int ACK, out string data, out bool timeout))
                {
                    if (ACK == 0)
                    {
                        return FCResultType.NEXT;
                    }
                    else
                    {
                        SysPara.NPShowAlarm("70100");
                        return FCResultType.IDLE;
                    }
                }
                else
                {
                    if (timeout)
                    {
                        // T3 Fail
                        MESLib.CommParas.MesManager.MES_S6F11_11001("2");
                        MESLib.CommParas.MesCenter.StopRunning();
                        SysPara.NPShowAlarm("70102");
                        return FCResultType.IDLE;
                    }
                }
                return FCResultType.IDLE;
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart30_FlowRun(object sender, EventArgs e)
        {
            if (global::Alpha.Classes.VelocidadUnloaderB1.ImagenesAparte) return GuardarImagenesDelGrupoAparte();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0 velocidad 3
            try
            {
                string saveImgPath = MiddleLayer.GantryF.GetSettingValue("PSet", "SaveImagePath") + "\\";
                for (int i = 0; i < productImage1.Count; i++)
                {
                    //PickedPocketIDs
                    string pcbCode = PCBCode[PickedPocketIDs[i]];
                    if (pcbCode == "" || pcbCode == null)
                        pcbCode = "NA";

                    string ImageName = string.Format(@"{0}_{1}_NA_NA_{2}_{3}.jpg",//string ImageName = string.Format(@"{0}_{1}_NA_NA_{2}_{3}.bmp",
                           pcbCode,
                            SysPara.sPalletCodes[PickedPocketIDs[i]],
                      productImage1[i].Timer,
                       MiddleLayer.MesF2.GetSettingValue("PSet", "EQPID")
                       );
                    using (Bitmap objImg = new Bitmap(productImage1[i].Image))
                    {
                        if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                        objImg.Save(saveImgPath + ImageName, System.Drawing.Imaging.ImageFormat.Jpeg);
                    }
                    ImageCode code = new ImageCode();
                    code.PalletCode = SysPara.sPalletCodes[PickedPocketIDs[i]];
                    code.PCBCode = pcbCode;
                    ImgCode.Add(code);
                }
                PCBCode = new string[12];
                productImage1.Clear();
                PickedPocketIDs.Clear();
            }
            catch (Exception)
            {
                productImage1.Clear(); PickedPocketIDs.Clear();
                PCBCode = new string[12];
            }
            return FCResultType.NEXT;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["PalletMinValueX"] = (double)num_minPX.Value;
            dt.Rows[0]["PalletMinValueY"] = (double)num_minPY.Value;
            dt.Rows[0]["PalletMaxValueX"] = (double)num_maxPX.Value;
            dt.Rows[0]["PalletMaxValueY"] = (double)num_maxPY.Value;
            dt.AcceptChanges();
            this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        private void num_maxFY_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button25_Click(object sender, EventArgs e)
        {
            DataTable dt = RecipeData.Tables["RSet"];
            dt.Rows[0]["FeederMinValueX"] = (double)num_minFX.Value;
            dt.Rows[0]["FeederMinValueY"] = (double)num_minFY.Value;
            dt.Rows[0]["FeederMaxValueX"] = (double)num_maxFX.Value;
            dt.Rows[0]["FeederMaxValueY"] = (double)num_maxFY.Value;
            dt.AcceptChanges();
            this.WriteRecipeData(string.Format("{0}\\{1}.xml", SysPara.RecipeDataDirectory, SysPara.RecipeName));
        }

        private FCResultType npFlowChart31_FlowRun(object sender, EventArgs e)
        {
            if (bRestartQuickActive) return FCResultType.NEXT;   //MOD@@ Guillermo Carrillo - BTM L1 v1.1.0 REINICIO RAPIDO: se brinca (delete files / FilesMonitor)
            GC.Collect();
            string processName = "FilesMonitor"; // 不包括 .exe
            System.Diagnostics.Process[] processes = System.Diagnostics.Process.GetProcessesByName(processName);

            if (processes.Length > 0)
            {
                Console.WriteLine($"Program: {processName} existed");
            }
            else
            {
                string exePath = @"D:\CurProgram\FilesMonitor\FilesMonitor.exe";
                string workingDirectory = Path.GetDirectoryName(exePath);

                try
                {
                    System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = exePath,
                        WorkingDirectory = workingDirectory,
                        UseShellExecute = false
                    };

                    System.Diagnostics.Process.Start(startInfo);
                    Console.WriteLine($"Program: {processName} started");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Start Program Error: {ex.Message}");
                }
            }
            return FCResultType.NEXT;
        }

        private FCResultType npFlowChart32_FlowRun(object sender, EventArgs e)
        {
                return FCResultType.NEXT;
        }



        private FCResultType flowChart7_FlowRun(object sender, EventArgs e)
        {
            int ret = Robot.ReadFromEpson();
            if (ReadIOTimer.On(20000))
            {
                bReadIOFlow = true;
                bt_ReadIO.Enabled = true;
                Log.log.Write("ReadRobotDI recieve data timeout", Color.Red);
                return FCResultType.NEXT;
            }
            if (ret == 103)
            {
                ReadIO = Robot.Input;
                return FCResultType.NEXT;
            }
            else { return FCResultType.IDLE; }
        }


        private void bt_ReadIO_Click(object sender, EventArgs e)
        {
            bt_ReadIO.Enabled = false;
            this.flowChart11.TaskReset();
            bReadIOFlow = false;
            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {
                while (!bReadIOFlow)
                {
                    flowChart11.TaskRun();
                }
            });

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        #endregion

        #region Reset Gantry Process 

        ResetProcessSequence.Windows.InteractionBox interactionBox;

        private FCResultType RGP_0001_FlowRun(object sender, EventArgs e)
        {
            SysPara.JAGStarytEvent.Reset();
            isServoAlm = false;
            SysPara.RIniRet = false;
            SysPara.cycleRunMode = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsDryCycleMode");
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.DryRunMode = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsDryCycleMode");

            SysPara.myCBNGBypass = MiddleLayer.ProcessF.GetSettingValue("PSet", "dcEnableCheckProcess");
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.ByPassMode = MiddleLayer.ProcessF.GetSettingValue("PSet", "dcEnableCheckProcess");

            productImage1.Clear();
            SysPara.myCBDisableInOutDoor = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsEnabledInOutDoor");
            MiddleLayer.ConveyorF.UpConveyorAutoFlow.DisbleInOutDoor = MiddleLayer.ProcessF.GetSettingValue("PSet", "IsEnabledInOutDoor");
            FeederImage1.Clear();
            ImgCode.Clear();

            interactionBox = new ResetProcessSequence.Windows.InteractionBox(
                "EL ROBOT COMENZARA A MOVERSE", "FAVOR DE CONFIRMAR", true, true);
            interactionBox.ShowInteractionBox();
            if(interactionBox.dResult == DialogResult.OK)
            {
                bRestartProcessOk = false;
                MiddleLayer.ConveyorF.uC_ResetProcessConveyorSequence.bGantryIsSafe = false;
                InitTM.Restart();
                return FCResultType.NEXT;
            }
            else
            {
                return FCResultType.IDLE;
            }
                        
        }
        #endregion  

        #region------------------------------ MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo (como la Top)

        //  Pedido de ingenieria (Mr. Park): que la Bottom trabaje el pallet como la Top Unloader:
        //    1. fotos de las 12 posiciones de corrido, sin tomar;
        //    2. el MES UNA vez por pallet, antes de tomar: 10701 con todas las piezas con foto buena -> LOT START ->
        //       10704 -> 10401 / 10711 / 10710 (los mismos nodos npFlowChart8 a npFlowChart30 de siempre);
        //    3. tomar y dejar de 3 en 3 con la correccion de vision guardada de cada posicion.
        //  Se prende en Sistema (Classes\VelocidadUnloaderB1.cs, ModuleData\PalletCompleto.txt); apagado = como siempre.
        //  El modo se toma al empezar cada pallet (flowChart21): cambiarlo a medio pallet no afecta ese pallet.
        //
        //  Para no tocar la toma, la descarga, el NG buffer ni el feeder, cada grupo se carga en las mismas variables
        //  de 3 (pickUpProductIndex, robotPos, ThreeResultDatas, pictureOKCount, grapperIndex) como si se acabaran de
        //  tomar sus fotos, y gotoPictureIndex queda en el ultimo lugar del grupo (12 en el ultimo grupo), igual que
        //  en el modo de 3 en 3. Los grippers que ya traen pieza del pallet anterior se respetan igual que antes.
        //  Cada foto se calcula para el gripper que la va a tomar (flowChart23 usa grapperIndex), igual que antes.
        //
        //  Cableado de este modo (AplicarCableadoMpc, al empezar cada pallet):
        //    flowChart42 (toma) -> flowChart24, sin el MES por grupo (de fabrica -> npFlowChart8);
        //    npFlowChart30 (fin del MES) -> flowChart20, que reparte los grupos (de fabrica -> flowChart24);
        //    flowChart20 CASE2 = npFlowChart8 (MES) y CASE3 = flowChart36 (tomar); solo se usan en este modo.
        //  Las piezas que rechaza el MES: se marca su lugar (AplicarNgPiezas) y, al cargar su grupo, el gripper que
        //  la toma (gripperRechazado); al descargar va al NG buffer como siempre (fcNgMes).

        private bool mpcActivo = false;                                // modo de ESTE pallet
        private bool mpcFotosHechas = false;
        private readonly List<int> mpcLista = new List<int>();         // lugares (1 a 12) con foto buena, en orden
        private readonly int[] mpcRanura = new int[12];                // gripper (1 a 3) para el que se calculo la foto
        private readonly double[][] mpcPos = new double[12][];         // correccion de vision de cada lugar (x, y, u)
        private int mpcSiguiente = 0;                                  // indice en mpcLista del siguiente grupo
        private int mpcOk = 0;                                         // fotos buenas de este pallet
        private int mpcOcupados = 0;                                   // grippers con pieza del pallet anterior

        //  flowChart21: al empezar cada pallet.
        private void IniciarPalletMpc()
        {
            bool antes = mpcActivo;
            mpcActivo = global::Alpha.Classes.PalletCompletoB1.Activo;
            mpcFotosHechas = false;
            mpcLista.Clear();
            for (int i = 0; i < 12; i++)
            {
                mpcRanura[i] = 0;
                mpcPos[i] = new double[3];
            }
            mpcSiguiente = 0;
            mpcOk = 0;
            mpcOcupados = SysPara.iProductCountOnGrapper[0] + SysPara.iProductCountOnGrapper[1] + SysPara.iProductCountOnGrapper[2];
            if (mpcOcupados < 0 || mpcOcupados > 2) mpcOcupados = 0;
            if (mpcActivo || antes)
            {
                //  En este modo el MES de un pallet ya se reporto completo: no queda nada pendiente de reportar.
                PickedPocketIDs.Clear();
                for (int i = 0; i < rechazadaPorMes.Length; i++) rechazadaPorMes[i] = false;
            }
            if (mpcActivo)
            {
                SysPara.pictureOKCount = mpcOcupados;
                SysPara.grapperIndex = mpcOcupados + 1;   // gripper de la primera foto (como flowChart21)
            }
            AplicarCableadoMpc(mpcActivo);
            if (mpcActivo) LogMpc("pallet nuevo; grippers que ya traen pieza: " + mpcOcupados);
        }

        private void AplicarCableadoMpc(bool modo)
        {
            flowChart42.NEXT = modo ? flowChart24 : npFlowChart8;      // de fabrica: npFlowChart8
            npFlowChart30.NEXT = modo ? flowChart20 : flowChart24;     // de fabrica: flowChart24
            flowChart20.CASE2 = npFlowChart8;                          // solo los usa este modo
            flowChart20.CASE3 = flowChart36;
        }

        //  flowChart20 en este modo: primero las fotos (como siempre, sin el fin de pallet), luego reparte grupos.
        private FCResultType Mpc_Nodo20()
        {
            if (!mpcFotosHechas)
            {
                OB_RobotLight.On();
                SysPara.gotoPictureIndex++;
                if (SysPara.gotoPictureIndex > 12)
                {
                    OB_RobotLight.Off();
                    mpcFotosHechas = true;
                    LogMpc("fotos terminadas: " + mpcLista.Count + " buenas (" + string.Join(",", mpcLista) + ")");
                    if (mpcLista.Count > 0) return FCResultType.CASE2;   // npFlowChart8: el MES una vez
                    return RepartirGrupoMpc();                           // nada que tomar: termina como siempre
                }
                if (!SysPara.cycleRunMode)
                {
                    processData.fnShowSerial(SysPara.sProductCodes[SysPara.gotoPictureIndex - 1]);
                }
                if (SysPara.bProductValid[SysPara.gotoPictureIndex - 1] == false)
                {
                    return FCResultType.IDLE;
                }
                return FCResultType.NEXT;
            }
            return RepartirGrupoMpc();
        }

        //  Carga el siguiente grupo (hasta 3) en las variables de 3 y manda a tomar (flowChart36).
        private FCResultType RepartirGrupoMpc()
        {
            int ocupados = (mpcSiguiente == 0) ? mpcOcupados : 0;   // solo el primer grupo comparte con el pallet anterior
            int n = Math.Min(3 - ocupados, mpcLista.Count - mpcSiguiente);
            if (n < 0) n = 0;
            PickedPocketIDs.Clear();   // el MES de estas piezas ya se reporto
            for (int k = 0; k < n; k++)
            {
                int lugar = mpcLista[mpcSiguiente + k];
                int g = ocupados + k;   // 0 a 2
                SysPara.pickUpProductIndex[g] = lugar;
                SysPara.robotPos[g][0] = mpcPos[lugar - 1][0];
                SysPara.robotPos[g][1] = mpcPos[lugar - 1][1];
                SysPara.robotPos[g][2] = mpcPos[lugar - 1][2];
                SysPara.ThreeResultDatas[g].ProductCode = SysPara.sProductCodes[lugar - 1];
                SysPara.ThreeResultDatas[g].PalletCode = SysPara.sPalletCodes[lugar - 1];
                if (mpcRanura[lugar - 1] != g + 1)
                {
                    LogMpc("aviso: el lugar " + lugar + " se fotografio para el gripper " + mpcRanura[lugar - 1] + " y lo toma el " + (g + 1));
                }
                if (RechazadaPorMes(lugar - 1)) gripperRechazado[g] = true;   // al descargar va al NG buffer
            }
            mpcSiguiente += n;
            SysPara.pictureOKCount = ocupados + n;
            SysPara.grapperIndex = ocupados;   // flowChart36 suma 1 antes de tomar
            bool ultimo = mpcSiguiente >= mpcLista.Count;
            SysPara.gotoPictureIndex = (ultimo || n == 0) ? 12 : mpcLista[mpcSiguiente - 1];
            LogMpc("grupo: " + n + " pieza(s) desde el gripper " + (ocupados + 1) + (ultimo ? " (ultimo grupo del pallet)" : ""));
            return FCResultType.CASE3;   // flowChart36
        }

        //  flowChart34 en este modo: guarda el resultado y la correccion de cada lugar y sigue con la siguiente foto.
        private FCResultType Mpc_Nodo34()
        {
            int lugar = SysPara.gotoPictureIndex;
            bool buena = SysPara.cycleRunMode || CCDAlogrithmStatus;
            SysPara.iPictureResults[lugar - 1] = buena ? 1 : 0;
            if (buena)
            {
                int g = SysPara.grapperIndex;   // gripper para el que flowChart23 calculo la correccion
                if (g < 1 || g > 3) g = ((mpcOcupados + mpcOk) % 3) + 1;
                mpcLista.Add(lugar);
                mpcRanura[lugar - 1] = g;
                double[] p = (!SysPara.cycleRunMode && SysPara.robotPos.Count >= g) ? SysPara.robotPos[g - 1] : new double[3];
                mpcPos[lugar - 1] = new double[] { p[0], p[1], p[2] };
                mpcOk++;
                SysPara.grapperIndex = ((mpcOcupados + mpcOk) % 3) + 1;   // gripper de la siguiente foto buena
            }
            if (!SysPara.cycleRunMode) GuardarFotoDeTomaMpc();
            return FCResultType.CASE1;   // flowChart52 -> flowChart20: la siguiente foto
        }

        //  npFlowChart8 en este modo: el 10701 lleva todas las piezas del pallet con foto buena.
        private void PrepararLoteMpc()
        {
            PickedPocketIDs.Clear();
            foreach (int lugar in mpcLista) PickedPocketIDs.Add(lugar - 1);   // indice del MES = lugar - 1
        }

        //  Las mismas imagenes que guarda flowChart34 ("#region save"), mismo nombre y carpeta.
        private void GuardarFotoDeTomaMpc()
        {
            try
            {
                if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DisableVision"))
                {
                    bool isSave = MiddleLayer.GantryF.GetSettingValue("PSet", "ImgSave");
                    bool isJPGSave = MiddleLayer.GantryF.GetSettingValue("PSet", "JPGImgSave");
                    string imgSaveName = "PickupImageVac" + SysPara.gotoPictureIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpg";
                    if (isSave)
                    {
                        string saveImgPath = CCDAlogrithmStatus ?
                           @"D:\WorkLog\\" + "PickupImageVac_BMP\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\"
                        : @"D:\WorkLog\\" + "PickupImageVac_BMP\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\";
                        using (CogImageFileBMP objImg = new CogImageFileBMP())
                        {
                            if (!Directory.Exists(saveImgPath)) { Directory.CreateDirectory(saveImgPath); }
                            objImg.Open(saveImgPath + imgSaveName, CogImageFileModeConstants.Write);
                            objImg.Append(H1_PickupPos.InputImage);
                            objImg.Close();
                        }
                    }
                    if (isJPGSave)
                    {
                        string saveImgPath1 = CCDAlogrithmStatus ?
                             @"D:\WorkLog\\" + "PickupImageVac_JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\OK\\"
                       : @"D:\WorkLog\\" + "PickupImageVac_JPG\\" + DateTime.Now.ToString("yyyyMMdd") + "\\NG\\";
                        Image img = cogRecordDisplay_Pickup.CreateContentBitmap(CogDisplayContentBitmapConstants.Display);
                        string imgSaveName1 = "PickupImageVac" + SysPara.gotoPictureIndex.ToString() + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".jpeg";
                        using (Bitmap objImg = new Bitmap(img))
                        {
                            if (!Directory.Exists(saveImgPath1)) { Directory.CreateDirectory(saveImgPath1); }
                            objImg.Save(saveImgPath1 + imgSaveName1, System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogMpc("no se pudo guardar la foto del lugar " + SysPara.gotoPictureIndex + ": " + ex.Message);
            }
        }

        private void LogMpc(string texto)
        {
            try
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Pallet completo (como la Top): " + texto, true);
            }
            catch
            {
            }
        }

        #endregion

    }

}
