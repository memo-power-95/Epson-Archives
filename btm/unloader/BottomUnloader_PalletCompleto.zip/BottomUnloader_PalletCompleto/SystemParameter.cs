using Alpha._0.Classes;
using CFX.Structures.JAG;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using static NPSDK.Alarm;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using Alpha._0.ModuleForms;
using System.Drawing;
using Alpha.FunctionForms;
using System.Data;
using NPSDK;

//using Alpha.MES;
using System.Xml.Serialization;
namespace Alpha
{

    public struct AssambData
    {
        public string Time;
        public string MatCode;
        public string BarCode;
        
        public double Press;
        public double Height1;
        public double Height2;
        public double Height3;
        public double Height4;

        //public int ScrewDriver;
        //public int PointIndex;
        //public double Torque;
        //public double Angle;

        public string Result;

        public AssambData(string _t, string _mc, string _bc, string _r)
        {
            Time = _t;
            MatCode = _mc;
            BarCode = _bc;
            Press = 0;
            Height1 = 0;
            Height2 = 0;
            Height3 = 0;
            Height4 = 0;
            Result = _r;
        }
    }
        public struct ResultData
    {
        public string Time;
        public string ProductCode;
        public string PalletCode;
        public int PreasureDirver;
        public double Preasure;
        public double PreasureMax;
        public double PreasureMin;
        public string Result;

        public ResultData(string _ProductCode, string _PalletCode, string _Result)
        {
            Time = "";
            ProductCode = _ProductCode;
            PalletCode = _PalletCode;
            PreasureDirver = 0;
            Preasure = 0;
            PreasureMax = 0;
            PreasureMin = 0;
            Result = _Result;
        }
    }
    public class SysPara
    {
        //System Parameter
        public static string sIniFile = @"C:\Acura\MachineSetup.ini";
        public static string ProgramDir = System.IO.Directory.GetCurrentDirectory();
        public static bool Simulation;
        public static string ProjectName;
        public static string RecipeName;
        public static bool bExpertMode;
        public static bool bEnableGeneralSaveLog;
        public static int iQualityCheckCounter = 0;
        public static bool IsEmcStop = false;
        //
        public static bool bDoubleMarkingValidation = false;
        public static bool bDryCycle = false;
        public static bool bDryCycleNotUnit = false;
        public static bool bBypassMode = false;
        public static bool bUseSMEMA = false;
        public static bool bSkipLaserMarking = false;
        public static bool bFlowValidationMode = false;
        public static bool bTakeBoardOutFlipped = false;
        public static bool bValidateLaserMarking = false;
        public static bool bDisableDoor = false;

        //System Path
        public static string SystemDataDirectory;
        public static string LogDirectory;
        public static string VisionFileDirectory;
        public static string AlarmTableDirectory;
        public static string SettingDataDirectory;
        public static string RecipeDataDirectory;
        public static string MESDirectory;
        public static string LanguageDataDirectory;
        public static string IOPortDirectory;
        public static string AcuraIOTDirectory;
        public static string MESDataDirectory;


// MESDATA
        public static string CurrentName;
        public static string PCName;
        public static string StationName;
        public static string DName;
        public static string RName;

        public static string MPName;
        public static string MCIDName;
        public static string LineName;
        public static string STXT;
        //Barcode Info
        public static string gBarcodeInfo;

        public static CFXHandler CFX = new CFXHandler();
        public static bool AlarmNow = true;
        public static List<int> FailedIndexList = new List<int>();
        public static List<int> AbortedIndexList = new List<int>();
        public static JAGProcessData jagProcessData = new JAGProcessData();

        public static bool LeftDoorAlarmEnable = false;
        public static bool RightDoorAlarmEnable = false;

        //Login Info

        //Temporal, quitar

        public static PermissionType UserPermission = PermissionType.Operator;
		public static string UserName = "Operador";
		//public static PermissionType UserPermission = PermissionType.Administrator;
		//public static string UserName = "Admin";


		//Language
		public static LanguageType LanguageShow = LanguageType.English;
        public static List<ComponentTextInfo>[] ComponentLangurageList;

        //Flow Control
        public static bool IsMaintenanceMode = false;
        public static bool bSaftyReady = false;
        public static bool SystemRun = false;
        public static RunMode SystemMode = RunMode.IDLE;
        public static bool SystemInitialOk = false;
        public static bool RIniRet = false;
        public static bool useDryCycleMode = false;
        public static bool useConveyorBypass = false;
        public static bool useLeftSMEMA = true;
        public static bool useRightSMEMA = false;
        public static bool conveyorEnabled = true;

        //Operation Time Record
        public static int ScanTime_Work = 0;
        public static int ScanTime_AlwaysRun = 0;
        public static int ScanTime_RefreshIOS = 0;


        public static ulong OperationSecond = 0;
        public static ulong RunSecond = 0;
        public static ulong StopSecond = 0;
        public static DateTime StartWorkTM;
        public static DateTime EndWorkTM;
        public static int TimeOutSec = 10000;       
        public static object StatusLock = new object();
        //Module Handshake
        public static SystemParameter SystemPara;       
        public static MESParameter MESPara;


        public static MainParameter MainPara;

        public static CvIntApp interCvApp = new CvIntApp();
        public static string QRCode1 = "";
        public static string PalletCode1 = "";
        public static string PalletCode2 = "";
        public static string PalletCode3 = "";
        public static PreasureData PreasureData1 = new PreasureData();         
        public static PreasureData PreasureData2 = new PreasureData();         
        public static PreasureData PreasureData3 = new PreasureData();         

        public static string PressureDataDirectory = Directory.GetCurrentDirectory() + "\\PressureData";
        public static bool OverPressure = false;
        public static string MESDataPath = "..\\..\\CFX\\MesDueFile.txt";
        public static bool PressureCompelet = false;
        public static List<AlarmTableType> ArmList = new List<AlarmTableType>();


        public static Queue<ProductCode_PickPos> Que_ProductCode_PickPos = new Queue<ProductCode_PickPos>();
    
        public static Queue<string> Que_pallet_Code = new Queue<string>();
 
        public static Queue<Product_Pallet_Code> Que_Product_pallet_Code = new Queue<Product_Pallet_Code>();

        public static ProductCode_PickPos pickPos = new ProductCode_PickPos();
        public static Product_Pallet_Code ProductPalletCode = new Product_Pallet_Code();
        public static VisionPos visionPos = new VisionPos();        

        public static bool R1GrabCompeletStatus = false;            //R1 Grab feeder product compelet flag
        public static int ScanCount = 0;                            
        public static bool R1ScanResult = false;                     
        public static bool R1AssembStatus = false;                  
        public static int ProductCount = 12;                         
        public static int FeederProductCount = 48;                        
        public static bool R1AssembResult = false;                  
        public static bool R1AssembCompeletStatus = false;      //R1 Assemb compelet flag

        public static int ScanAgainCount = 0;

        public static int gotoPictureIndex = 0;
        public static int pictureOKCount = 0;
        public static int[] pickUpProductIndex = new int[12];   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo: 12 como la Top (el modo de 3 en 3 sigue usando 0 a 2)
        public static ResultData[] ThreeResultDatas = new ResultData[12];   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo: 12 como la Top (el modo de 3 en 3 sigue usando 0 a 2)
        public static bool bCanDischarge = true;

        public static AutoResetEvent JAGStarytEvent = new AutoResetEvent(false); 

        //Convery
        public static bool bOB_SMMachineReady = false;

        //Add new 0721
        //Calculate Parameter
        public static int WorkOkPCBCount = 0;
        public static int WorkNgPCBCount = 0; 
        public static Int64 CT_LastWorkFlow = 0;
        public static string WorkPath;
 
        public static Queue<bool> UpST1ProcRets = new Queue<bool>();

        public static float ProductState = 0;
        //Run Parameter
        public static bool ZHomeOk_H1;
        public static bool ZHomeOk_H2;
         
        public static bool CanRunPlace;
        public static bool ScanBarcodeOk;
        public static bool IsWorkOk_H1;
        public static bool IsWorkOk_H2;
        public static bool SvonOk_H1;
        //System Parameter
        public static string MdbPath = "SystemData.mdb"; 
        //System Path
        public static string LogFilePath; 

        //Login Info 
        public static bool UseFingerprint = true;

        //Langurage 

        //Flow Control 
        public static bool IsTryRun = false;

        public static bool InCycleTime = false;

        //Operation Time Record
        public static int ScanTime = 0; 

        public static bool bPCBReady = false;
        public static bool bScrewOK = false;

        public static bool bSacnnerStart = false;

        public static bool bKongpao = false;
        public static bool bZhitong = false;

     
        public static List<ProductCode_PickPos> List_ProductCode_PickPos = new List<ProductCode_PickPos>();
 
        public static Queue<string> Que_ProductCode = new Queue<string>();


        public static int[] iContinuousNGVac = new int[12];

        public static bool bNotifyStartUnloadWork = false;   
        public static bool bUnloadCompleteStatus = false;
        public static bool bPhotoFailed = false;   
        public static int iScanPosIndex = 1;

        public static bool bLRDoorIniFinish = false;

        public static int iProductCount = 12;    
        public static bool bScanResult = false;      
        public static bool bPitureResult = false;
        public static int iScanSuccessCount = 1;

        public static int iVacCount = 16;       
        public static int iVacIndex = 0;

        public static bool cycleRunMode = false;
        public static bool myCBDisableInOutDoor = false;
        public static bool myCBNGBypass = false;
       

        public static int iUnloadGroupIndex = 0;   
        public static string[] sProductCodes = new string[12];  
        public static string[] sPalletCodes = new string[12];  
        public static bool[] bProductValid = new bool[12]; 
        public static int[] iPictureResults = new int[12];  
        public static int grapperIndex = 0;  
        public static int[] iProductCountOnGrapper = new int[3];  
        public static int[] iPutVacIndex = new int[3];  

        public static List<double[]> robotPos = new List<double[]>();
        
        public static int SnapPalletNGNum = 0;
        public static ResultData ResultData = new ResultData("ProductCode", "PalletCode", "OK");        
        public static string curPalletCode = "";          
        public static string curProductCode = "";

        public static int iTodayTaskValue = 0;
        public static int iTodayFinishedTaskValue = 0;

        public static string SerialNum = "";
        //mes  
        public static string NName;
        public static string OName; 
        public static string PName;
        public static string MName;
        public static string PScrew;

        public static string dIGBT;


        public static string ST1_StartTime;
 



        public static string timeFix = ""; 
        public static string QRCode2 = "";
        public static string QRCode3 = "";
        public static AssambData assambData = new AssambData("NULL", "NULL", "NULL", "NG");

        public static double ct = 0;
        public static string AssambDataDirectory = Directory.GetCurrentDirectory() + "\\AssambData";
     
        public static bool IsEnglish = true;
        public static bool ConveyorOn = false;
        public static bool DisableBuzzer = false;


        public static bool bCableDetectEnable = true;
        public static Thread CableDetectTh;

        //清料
        public static bool bPickingClear=false;
        public static bool bUnload=false;

        public static bool EnableMes = false;

        public static string ngPos = "";


        public static bool AutoManualState = false;//  Auto:true   Manual:false
        public static void NPShowAlarm(string code)
        {
            //  Auto:true   Manual:false
            //if (SysPara.AutoManualState)
                MESLib.CommFuns.MES_ShowAlarm(code);
            //else
            //{
            //    MESLib.CommFuns.MES_ShowAlarm("9" + code);
            //}
        }
        public static void NPShowAlarm(string code, string des)
        {
            //  Auto:true   Manual:false
            //if (SysPara.AutoManualState)
                MESLib.CommFuns.MES_ShowAlarm(code, "[Auto]" + des);
            //else
            //{
            //    MESLib.CommFuns.MES_ShowAlarm("9" + code, "[Manual]" + des);
            //}
        }
        //public static void NPShowAlarm(string code)
        //{
        //    //  Auto:true   Manual:false
        //    //if (SysPara.AutoManualState)
        //    string formattedCode = code.StartsWith("A", StringComparison.OrdinalIgnoreCase) ? code : "A" + code;
        //    MESLib.CommFuns.MES_ShowAlarm(formattedCode);
        //    //else
        //    //{
        //    //    MESLib.CommFuns.MES_ShowAlarm("9" + code);
        //    //}
        //}
        //public static void NPShowAlarm(string code, string des)
        //{
        //    //  Auto:true   Manual:false
        //    //if (SysPara.AutoManualState)
        //    string formattedCode = code.StartsWith("A", StringComparison.OrdinalIgnoreCase) ? code : "A" + code;

        //    MESLib.CommFuns.MES_ShowAlarm(formattedCode, des);
        //    //else
        //    //{
        //    //    MESLib.CommFuns.MES_ShowAlarm("9" + code, "[Manual]" + des);
        //    //}
        //}

    }


    public struct PreasureData
    {
        public string Time;
        public string MatCode;
        public int PreasureDirver;
        public double Preasure;
        public double PreasureMax;
        public double PreasureMin;
        public string Result;
    }

    public struct ProductCode_PickPos
    {
        public string Code;
        public double PosIndex;
    }

    public struct Product_Pallet_Code
    {
        public string ProdcutCode;
        public string PalletCode;
        public bool PressureResult;
    }
    public struct Pos4D
    {
        public double x;
        public double y;
        public double z;
        public double u;
    }
    public struct VisionPos
    {
        public double x;
        public double y;
        public double u;
    }
    public struct CalibrationData
    {
        public double PixelX;
        public double PixelY;
        public double MotorPosX;
        public double MotorPosY;
    }

    public struct ComponentTextInfo
    {
        public string FormName;
        public string ComponentName;
        public string ComponentText;
        public Control Component;
    }

    public struct IOPortInfo
    {
        public string FormName;
        public string ComponentName;
        public string Port;
    }

    public enum PermissionType
    {
        Operator = 0,
        Maintenance,
        Administrator,
        None,
    }

    public enum LanguageType
    {
        Chinese = 0,
        English,
    }

    //MOD@@ Reset Process Feature - 2026 march 05
    //Aaron Estrada 
    public enum RunMode
    {
        IDLE = 0,
        AUTO,
        HOME,
        RESETPROCESS,
    }

    public struct MainParameter
    {
        public bool bDarkModeActive;
        public bool bDarkModeButtonEnabled;
    }

    /// <summary>
    /// Enumeracion de los diversos estados en que se pueden encontrar los modulos
    /// </summary>
    public enum status
    {
        /// <summary>
        /// No hay ningun estado seleccionado
        /// </summary>
        None = 0,
        /// <summary>
        /// En espera
        /// </summary>
        Idle,
        /// <summary>
        /// Ocupado / En proceso
        /// </summary>
        Busy,
        /// <summary>
        /// Comienza el modulo de inicializacion
        /// </summary>
        InitialStart,
        /// <summary>
        ///  Esta inicializando
        /// </summary>
        Initializing,
        /// <summary>
        /// La inicialización finalizo
        /// </summary>
        InitialDone,
        /// <summary>
        /// Cargando Unidades en el Slider
        /// </summary>
        Loading,
        /// <summary>
        ///  Comienza el proceso automatico
        /// </summary>
        ProcessStart,
        /// <summary>
        /// El modulo esta en proceso
        /// </summary>
        Processing,
        /// <summary>
        ///  El proceso actual del modulo termino
        /// </summary>
        ProcessDone,
        /// <summary>
        /// Unidad lista para procesar
        /// </summary>
        ReadyToProcess,
        /// <summary>
        ///  El modulo en gral esta en error
        /// </summary>
        Error
    }



    #region Declare module parameter

    public struct SystemParameter
    {
        /// <summary>
        /// Almacena el estado de las seguridades de la maquina
        /// </summary>
        public bool bSaftyReady;

        /// <summary>
        /// Realiza el cambio de estado cuando el equipo esta en modo mantenimiento
        /// </summary>
        public bool IsMaintenanceMode;
        // <summary>
        /// Guarda valor actual de piezas pasadas
        /// </summary>
        public string sCurrentUnits;



    }
    public class MESParameter
    {
        public bool WriteUnitTars;
        public bool WriteUnitTarsOk;
        public string serialNumber;
        public string partNumber;
        public char revision;
        public DateTime startDatetime;
        public DateTime endDateTime;
        public List<KeyValuePair<string, string>> fails;
        public bool status;
        public List<Measurement> measurements;

        public MESParameter()
        {
            fails = new List<KeyValuePair<string, string>>();
            measurements = new List<Measurement>();
            status = true;
        }
    }

    public struct Measurement
    {
        public string measureLabel;
        public string measureData;
        public string measureMessage;

        public Measurement(string measureLabel, string measureData, string measureMessage)
        {
            this.measureLabel = measureLabel;
            this.measureData = measureData;
            this.measureMessage = measureMessage;
        }
    }


    #endregion




    public struct FastenData
    {
        public string Point;
        public double Torque;
        public double Angle;
        //public double RundownAngle;
        // public bool PostViewTorque;
        public string Result;
        // public ResultCode Result;
        //public DateTime FasternTime;
    }

    public struct FastenData2
    {
        public string Point2;
        public double Torque2;
        public double Angle2;
        //public double RundownAngle;
        // public bool PostViewTorque;
        public string Result2;
        // public ResultCode Result;
        //public DateTime FasternTime;
    }

    public class CvIntApp
    {
        public bool bLoadBoardFinish = false;
        public bool bUnloadBoardFinish = false;
        public bool bCanUnloadBoard = false;
        public bool bCanLoadBoard = false;
        public bool bXyHomeFinish = false;
        public bool bCanFlip = false;
        public bool bFlipFinish = false;
        public bool bCvInitCheckFinish = false;
        

        public void Reset()
        {
            bLoadBoardFinish = false;
            bUnloadBoardFinish = false;
            bCanUnloadBoard = false;
            bCanLoadBoard = false;
            bXyHomeFinish = false;
            bCanFlip = false;
            bFlipFinish = false;
            bCvInitCheckFinish = false;
        }


    }
    public static class Extension
    {
        public static string _ToString<T>(this List<T> lst)
        {
            if (lst == null || lst.Count == 0)
                return "";
            string retstr = "";
            for (int i = 0; i < lst.Count; i++)
            {
                if (lst[i] == null)
                {
                    retstr += "";
                }
                else
                {
                    retstr += lst[i].ToString();
                }

                if (i != lst.Count - 1)
                {
                    retstr += ", ";
                }
            }
            return retstr;
        }
        public static string _ToString<T>(this T[] lst)
        {
            if (lst == null || lst.Length == 0)
                return "";
            string retstr = "";
            for (int i = 0; i < lst.Length; i++)
            {
                if (lst[i] == null)
                {
                    retstr += "";
                }
                else
                {
                    retstr += lst[i].ToString();
                }

                if (i != lst.Length - 1)
                {
                    retstr += ", ";
                }
            }
            return retstr;
        }
        public static string _ToString<T>(this Queue<T> lst)
        {
            if (lst == null || lst.Count == 0)
                return "";
            string retstr = "";
            foreach (var q in lst)
            {
                if (q == null)
                    retstr += "";
                else
                    retstr += q.ToString() + ", ";
            }
            return retstr;
        }
    }


}
