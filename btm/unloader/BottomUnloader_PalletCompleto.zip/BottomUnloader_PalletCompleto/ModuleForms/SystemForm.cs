using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Alpha._0.Classes;
using Alpha.Classes;
using Alpha.Forms;
using AcuraLibrary.Forms;
using NPSDK;
using LogSv;
using static Alpha.Forms.SignalTowerForm;

namespace Alpha._0.ModuleForms
{
    public partial class SystemForm : ModuleBaseForm
    {
        private bool StatusChange_Start = false;
        private bool StatusChange_Stop = false;
        private bool StatusChange_AlarmReset = false;
        private bool StatusChange_ModeSwitch = false;
        private bool StatusChange_SafetyDoor = false;
        private bool StatusChange_EmergencyFront = false;
        private bool StatusChange_EmergencyRear = false;
        private bool StatusChange_AirPressure = false;
        private JTimer BlinkTM = new JTimer();
        private JTimer BuzzerTM = new JTimer();
        private bool BlinkIsOn = false;
        private const int BlinkTime = 500;
        public bool BuzzerNeedWork = false;
        private bool DebugMode = false;
        private bool StatusChange_SafetyForntDoor = false;
        private bool StatusChange_SafetyBackDoor = false;
        private bool StatusChange_SafetyLiftDoor = false;
        private bool StatusChange_SafetyRightDoor = false;
        private bool DownConveyorStatus = false;
        private bool StatusChange_SafetyDownForntDoor = false;
        public List<MotorParameter> MotorMaximumParameter = new List<MotorParameter>();
        public struct MotorParameter
        {
            public string Port;
            public double MaximumSpeed;
        }

        public SystemForm()
        {
            InitializeComponent();
            AgregarOpcionesDeVelocidad();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0
        }

        #region------------------------------ MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0 opciones de velocidad y modo NG

        //  Las opciones de velocidad (Classes\VelocidadUnloaderB1.cs, ModuleData\Velocidad.txt) y el modo NG automatico
        //  del MES (Classes\ModoNgMes.cs), con el mismo interruptor que "Buzzer", debajo del recuadro de Buzzer /
        //  Disable visual / Disable Feeder. Solo con la maquina detenida. El modo NG pide admin/admin para prenderlo.
        private tstCkBox.MyCheckBox chkSinEspera3s;
        private tstCkBox.MyCheckBox chkEsperaCorta;
        private tstCkBox.MyCheckBox chkImagenesAparte;
        private tstCkBox.MyCheckBox chkModoNg;
        private tstCkBox.MyCheckBox chkPalletCompleto;   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
        private bool mostrandoOpciones = false;

        private void AgregarOpcionesDeVelocidad()
        {
            global::Alpha.Classes.VelocidadUnloaderB1.LeerArchivo();
            chkSinEspera3s = NuevaOpcion("Velocidad 1: sin la espera fija de 3 s por pallet", 270);
            chkEsperaCorta = NuevaOpcion("Velocidad 2: espera corta entre pasos (1 ms)", 340);
            chkImagenesAparte = NuevaOpcion("Velocidad 3: guardar las fotos del grupo aparte", 410);
            chkModoNg = NuevaOpcion("Modo NG automatico del MES (3 seguidas o 10 en 10 min lo apagan)", 480);
            global::Alpha.Classes.PalletCompletoB1.LeerArchivo();   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
            chkPalletCompleto = NuevaOpcion("Pallet completo como la Top: fotos de las 12 y MES una vez", 550);   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
            MostrarOpciones();
            global::Alpha.Classes.VelocidadUnloaderB1.Cambio += OpcionesCambio;
            plProductionSetting.VisibleChanged += (s, e) => { if (plProductionSetting.Visible) MostrarOpciones(); };
        }

        //  Misma letra y alto que "Buzzer", en la misma columna.
        private tstCkBox.MyCheckBox NuevaOpcion(string texto, int y)
        {
            tstCkBox.MyCheckBox c = new tstCkBox.MyCheckBox();
            c.Checked = false;
            c.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            c.Location = new System.Drawing.Point(39, y);
            c.MaximumSize = new System.Drawing.Size(0, 68);
            c.MinimumSize = new System.Drawing.Size(73, 63);
            c.Size = new System.Drawing.Size(760, 63);
            c.Text = texto;
            plProductionSetting.Controls.Add(c);
            c.BringToFront();
            c.Click += Opcion_Click;
            return c;
        }

        private void OpcionesCambio()
        {
            try
            {
                if (plProductionSetting == null || !plProductionSetting.IsHandleCreated || plProductionSetting.IsDisposed) return;
                plProductionSetting.BeginInvoke(new System.Action(MostrarOpciones));
            }
            catch
            {
            }
        }

        private void MostrarOpciones()
        {
            if (chkSinEspera3s == null) return;
            mostrandoOpciones = true;
            chkSinEspera3s.Checked = global::Alpha.Classes.VelocidadUnloaderB1.SinEsperaDe3s;
            chkEsperaCorta.Checked = global::Alpha.Classes.VelocidadUnloaderB1.EsperaCorta;
            chkImagenesAparte.Checked = global::Alpha.Classes.VelocidadUnloaderB1.ImagenesAparte;
            chkModoNg.Checked = global::Alpha.Classes.ModoNgMes.Activo;
            chkPalletCompleto.Checked = global::Alpha.Classes.PalletCompletoB1.Activo;   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
            mostrandoOpciones = false;
        }

        private void Opcion_Click(object sender, System.EventArgs e)
        {
            if (mostrandoOpciones) return;
            if (SysPara.SystemRun)
            {
                System.Windows.Forms.MessageBox.Show("Detenga la maquina para cambiar estas opciones.",
                    "Opciones", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                MostrarOpciones();
                return;
            }
            if (sender == chkPalletCompleto)   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
            {
                string errorPallet;
                if (!global::Alpha.Classes.PalletCompletoB1.Cambiar(chkPalletCompleto.Checked, out errorPallet))
                {
                    System.Windows.Forms.MessageBox.Show("La opcion cambio, pero no se pudo guardar en ModuleData\\PalletCompleto.txt: " + errorPallet
                        + "\nAl volver a abrir el programa regresaria a lo que dice el archivo.",
                        "Pallet completo", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                }
                MostrarOpciones();
                return;
            }
            if (sender == chkModoNg)
            {
                //  Prenderlo pide admin/admin (ModoNgMes.Cambiar abre la ventana; esto es un clic, no el flujo).
                global::Alpha.Classes.ModoNgMes.Cambiar(chkModoNg.Checked);
                MostrarOpciones();
                return;
            }
            string error;
            if (!global::Alpha.Classes.VelocidadUnloaderB1.Cambiar(chkSinEspera3s.Checked, chkEsperaCorta.Checked,
                    chkImagenesAparte.Checked, out error))
            {
                System.Windows.Forms.MessageBox.Show("La opcion cambio, pero no se pudo guardar en ModuleData\\Velocidad.txt: " + error
                    + "\nAl volver a abrir el programa regresaria a lo que dice el archivo.",
                    "Opciones de velocidad", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
            }
            MostrarOpciones();
        }

        #endregion

        public void setLEDLightON()
        {
            OB_LED.On();
        }
        public void setLEDLightOFF()
        {
            OB_LED.Off();
        }

        public override void AlwaysRun()
        {
            if (SysPara.Simulation)
                return;

            #region BlinkTimer
            if (BlinkTM.On(BlinkTime))
            {
                BlinkIsOn = !BlinkIsOn;
                BlinkTM.Restart();
            }
            #endregion

            #region MaintainMode Scan


            if (IB_FrontAutoOrManualSwich.Off()) 
            {
                if (!StatusChange_ModeSwitch)
                {
                    OB_LED.Off();
                    MiddleLayer.StopRun();
                    RestoreMotorMaximumSpeed();
                    SDKKernal.ClearAlarm("0012");
                    SDKKernal.ClearAlarm("90012");
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} switches to maintain mode");
                    StatusChange_ModeSwitch = true;
                    if (MiddleLayer.GantryF.Robot.ConnectStatus)
                    {
                        string[] pos = MiddleLayer.GantryF.GetDataByAnnotation(MiddleLayer.GantryF.dgv_EpsonPosition, "WriteRobotSpeed");
                        MiddleLayer.GantryF.Robot.SetSpeed(pos[2], pos[3], pos[4], 30000, string.Format("{0:d7}", 100));
                        MiddleLayer.GantryF.RefreshDifferentThreadUI(trackBar1, () =>
                        {
                            trackBar1.Value = 100;
                        });
                    }
                }
                SysPara.IsMaintenanceMode = false;
            }
            else
            {
                if (StatusChange_ModeSwitch)
                {
                    OB_LED.On();
                    MiddleLayer.StopRun();
                    BackupMotorMaximumSpeed();
                    SwitchMotorToMaintenanceSpeed();
                    StatusChange_ModeSwitch = false;
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} switches to run mode");

                    if (!MiddleLayer.SystemF.GetSettingValue("PSet", "DebugMode"))
                    { } SysPara.NPShowAlarm("0012");
                    if (MiddleLayer.GantryF.Robot.ConnectStatus)
                    {
                        string[] pos = MiddleLayer.GantryF.GetDataByAnnotation(MiddleLayer.GantryF.dgv_EpsonPosition, "WriteRobotSpeed");
                        MiddleLayer.GantryF.Robot.SetSpeed(pos[2], pos[3], pos[4], 30000, string.Format("{0:d7}", 10));
                        MiddleLayer.GantryF.RefreshDifferentThreadUI(trackBar1, () =>
                        {
                            trackBar1.Value = 10;
                        });
                    }
                }
                SysPara.IsMaintenanceMode = true;
            }
            #endregion

            #region Emergency Stop Scan
            if (IB_SafetyReady.On())
            {
                if (StatusChange_EmergencyFront)
                {
                    SysPara.SystemRun = false;
                    SysPara.SystemMode = RunMode.IDLE;
                    SysPara.SystemInitialOk = false;
                    StatusChange_EmergencyFront = false;
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} presses front emergency button");
                    SysPara.IsEmcStop = true;

                }
                MiddleLayer.StopRun();
                SysPara.NPShowAlarm("0001");

            }
            else
            {
                if (!StatusChange_EmergencyFront)
                    StatusChange_EmergencyFront = true;
                SysPara.IsEmcStop = false;
            }

            if (MiddleLayer.GantryF.IB_RobotLimit.Off())
            {
                SysPara.SystemRun = false;
                SysPara.SystemInitialOk = false;
                SysPara.SystemMode = RunMode.IDLE;
                MiddleLayer.StopRun();
                MiddleLayer.ServoOff();
                SysPara.NPShowAlarm("1633");
            }

            //if (!IB_SafetyReady.On())
            //{
            //    if (StatusChange_EmergencyFront)
            //    {
            //        SysPara.SystemRun = false;
            //        SysPara.SystemMode = RunMode.IDLE;
            //        SysPara.SystemInitialOk = false;
            //        StatusChange_EmergencyFront = false;
            //        LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} presses front emergency button");
            //    }
            //    MiddleLayer.StopRun();
            //    SysPara.NPShowAlarm("3021");

            //}
            //else
            //{
            //    if (!StatusChange_EmergencyFront)
            //        StatusChange_EmergencyFront = true;
            //}
            #endregion

            #region Safety door Scan
            //if (IB_SafetyDoor.Off())
            //{
            //    if (!StatusChange_SafetyDoor)
            //    {
            //        OB_FluorescentLight.On();
            //        StatusChange_SafetyDoor = true;
            //        LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} open safety door");
            //    }
            //    if (IB_SafetyDoor.Off() && IB_ModeSwitch.Off())
            //        if (!GetSettingValue("PSet", "DisableSafetyDoor"))
            //            SysPara.NPShowAlarm("3026");
            //}
            //else
            //{
            //    if (StatusChange_SafetyDoor)
            //    {
            //        JSDK.Alarm.Clear();
            //        OB_FluorescentLight.Off();
            //        StatusChange_SafetyDoor = false;
            //        LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} close safety door");
            //    }
            //}
            #endregion

            #region Air Pressure Scan
            if (!IB_TotalPressureDetection.On())
            {
                if (StatusChange_AirPressure)
                {
                    StatusChange_AirPressure = false;
                    //StopRun();
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} releases air pressure");
                }
                SysPara.NPShowAlarm("0002");
            }
            else
            {
                if (!StatusChange_AirPressure)
                {
                    SDKPara.Arm.ClearAll();
                    StatusChange_AirPressure = true;
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} turns on air pressure");
                }

            }
            #endregion

            #region Start Button Scan
            if (IB_Start.On())
            {
                if (StatusChange_Start)
                {
                    StatusChange_Start = false;
                    RefreshDifferentThreadUI(MiddleLayer.MainF.btnStart, () =>
                    {
                        if (MiddleLayer.MainF.btnStart.Enabled)
                            MiddleLayer.MainF.btnStart_Click(null,null);
                    });
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} presses start button");
                }
            }
            else
            {
                if (!StatusChange_Start)
                    StatusChange_Start = true;
            }
            #endregion

            #region Pause Button Scan
            if (IB_Stop.On())
            {
                if (StatusChange_Stop)
                {
                    StatusChange_Stop = false;
                    RefreshDifferentThreadUI(MiddleLayer.MainF.btnPause, () =>
                    {
                        if (MiddleLayer.MainF.btnPause.Enabled)
                            MiddleLayer.MainF.btnPause_Click(null,null);
                    });
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} presses pause button");
                }
                //  BuzzOff();
            }
            else
            {
                if (!StatusChange_Stop)
                    StatusChange_Stop = true;
            }
            #endregion

            #region Alarm Reset Button Scan
            if (IB_Reset.On())
            {
                if (StatusChange_AlarmReset)
                {
                    StatusChange_AlarmReset = false;
                    RefreshDifferentThreadUI(MiddleLayer.MainF.btnAlarmReset, () =>
                    {
                        MiddleLayer.MainF.btnAlarmReset.PerformClick();
                    });
                    LogManagement.Instance.SaveLog(LogManagement.LogType.Operation, $"{SysPara.UserName} presses alarm reset button");
                }
                BuzzOff();
                BuzzerTM.Restart();
            }
            else
            {
                if (!StatusChange_AlarmReset)
                    StatusChange_AlarmReset = true;
            }
            #endregion

            #region Button Light
            if (SysPara.SystemInitialOk)
            {
                if (SysPara.IsMaintenanceMode)
                {
                    if (BlinkIsOn)
                        OB_StartOrStopIndecator.On();
                    else
                        OB_StartOrStopIndecator.Off();
                }
                else
                    OB_StartOrStopIndecator.On();
            }
            else
                OB_StartOrStopIndecator.Off();
            #endregion

            #region Signal Tower Control
            if (SysPara.SystemRun)
            {
                if (SDKPara.Arm._WarningNow)
                    MiddleLayer.SignalTowerF.SwitchSignalTowerStatus(SignalTowerForm.SignalTowerStatusType.MessageWarning);
                else if (SDKPara.Arm._InformNow)
                    MiddleLayer.SignalTowerF.SwitchSignalTowerStatus(SignalTowerForm.SignalTowerStatusType.MessageInformation);
                else
                {
                    if (SysPara.SystemMode == RunMode.AUTO)
                        MiddleLayer.SignalTowerF.SwitchSignalTowerStatus(SignalTowerForm.SignalTowerStatusType.MachineRunning);
                    if (SysPara.SystemMode == RunMode.HOME)
                        MiddleLayer.SignalTowerF.SwitchSignalTowerStatus(SignalTowerForm.SignalTowerStatusType.MachineInitialize);
                    if (SysPara.SystemMode == RunMode.RESETPROCESS)
                        MiddleLayer.SignalTowerF.SwitchSignalTowerStatus(SignalTowerForm.SignalTowerStatusType.MachineResetting);
                }
            }
            else
            {
                if (SDKPara.Arm._ErrorNow)
                    MiddleLayer.SignalTowerF.SwitchSignalTowerStatus(SignalTowerForm.SignalTowerStatusType.MessageError);
                else
                    MiddleLayer.SignalTowerF.SwitchSignalTowerStatus(SignalTowerForm.SignalTowerStatusType.MachineIdle);
            }

            //Refresh Output Status
            Control_SignalTower(MiddleLayer.SignalTowerF.GreenLightStatus, OB_AlarmLightGreen);
            Control_SignalTower(MiddleLayer.SignalTowerF.YellowLightStatus, OB_AlarmLightYellow);
            Control_SignalTower(MiddleLayer.SignalTowerF.RedLightStatus, OB_AlarmLightRed);
            if (MiddleLayer.SignalTowerF.bHaveChangeStatus)
            {
                BuzzerNeedWork = true;
                MiddleLayer.SignalTowerF.bHaveChangeStatus = false;
            }
            SysPara.DisableBuzzer = MiddleLayer.SystemF.GetSettingValue("PSet", "DisableSafetyBuzzer");
            if (BuzzerNeedWork && SysPara.DisableBuzzer && BuzzerTM.On(1000))
                Control_SignalTower(MiddleLayer.SignalTowerF.BuzzerStatus, OB_Buzzer);
            else
                BuzzerNeedWork = false;
            #endregion


            //#region Safety fornt door Scan
            //if (IB_ForntDoor.Off())
            //{
            //    if (!StatusChange_SafetyForntDoor)
            //    {
            //        StatusChange_SafetyForntDoor = true;
            //        if (IB_ForntDoor.Off())
            //        {
            //            SDKPara.Arm.ReportAlarm("04303", AcuraIOT.ErrorGroup.Door, AcuraIOT.ErrorSubGroup.Alarm, AcuraIOT.ErrorType.E, mNameAlm.System + "open fornt safety door");
            //            SysPara.NPShowAlarm("04303");
            //        }
            //    }
            //}
            //else
            //{
            //    if (StatusChange_SafetyForntDoor)
            //    {
            //        SDKKernal.ClearAllAlarm();
            //        StatusChange_SafetyForntDoor = false;
            //    }
            //}
            //#endregion

            //#region Safety back door Scan
            //if (IB_BackDoor.Off())
            //{
            //    if (!StatusChange_SafetyBackDoor)
            //    {
            //        //OB_FluorescentLight.On();
            //        StatusChange_SafetyBackDoor = true;
            //        if (IB_BackDoor.Off())
            //        {
            //            SDKPara.Arm.ReportAlarm("04305", AcuraIOT.ErrorGroup.Door, AcuraIOT.ErrorSubGroup.Alarm, AcuraIOT.ErrorType.E, mNameAlm.System + "open back safety door");
            //            SysPara.NPShowAlarm("04305");
            //        }
            //    }
            //}
            //else
            //{
            //    if (StatusChange_SafetyBackDoor)
            //    {
            //        SDKKernal.ClearAllAlarm();
            //        StatusChange_SafetyBackDoor = false;
            //    }
            //}
            //#endregion

            #region Safety Lift door Scan
            if (MiddleLayer.ConveyorF.IB_UpCvyFeedSensor.On() /*&& IB_LeftDoorUpSensor.On()*/)
            {
                if (!StatusChange_SafetyLiftDoor)
                {
                    //OB_FluorescentLight.On();
                    StatusChange_SafetyLiftDoor = true;
                    //OB_LeftDoorCyUp.Enabled = false;
                    //OB_LeftDoorCyDown.Enabled = false;
                    //Cy_LeftDoorUnite.Enabled = false;
                }
            }
            else
            {
                if (StatusChange_SafetyLiftDoor)
                {

                    StatusChange_SafetyLiftDoor = false;
                    //OB_LeftDoorCyUp.Enabled = true;
                    //OB_LeftDoorCyDown.Enabled = true;
                    //Cy_LeftDoorUnite.Enabled = true;
                }
            }
            #endregion

            #region Safety Right door Scan
            if (MiddleLayer.ConveyorF.IB_UpCvyDischargeSensor.On() /*&& IB_RightDoorUpSensor.On()*/)
            {
                if (!StatusChange_SafetyRightDoor)
                {
                    //OB_FluorescentLight.On();
                    StatusChange_SafetyRightDoor = true;
                    //OB_RightDoorCyUp.Enabled = false;
                    //OB_RightDoorCyDown.Enabled = false;
                    //Cy_RightDoorUnite.Enabled = false;
                }
            }
            else
            {
                if (StatusChange_SafetyRightDoor)
                {

                    StatusChange_SafetyRightDoor = false;
                    //OB_RightDoorCyUp.Enabled = true;
                    //OB_RightDoorCyDown.Enabled = true;
                    //Cy_RightDoorUnite.Enabled = true;
                }
            }
            #endregion 

            //if (IB_DownForntDoor.Off() || IB_DownBackDoor.Off())
            //{
            //    if (IB_DownForntDoor.Off())
            //    {
            //        SysPara.NPShowAlarm("04306");
            //    }
            //    else
            //    {
            //        SysPara.NPShowAlarm("04307");
            //    }

            //    MiddleLayer.ConveyorF.OB_DownCvyMtFwd.Off();
            //    if (!StatusChange_SafetyDownForntDoor)
            //    {
            //        DownConveyorStatus = MiddleLayer.ConveyorF.OB_DownCvyMtFwd.GetState();

            //        //OB_FluorescentLight.On();
            //        StatusChange_SafetyDownForntDoor = true;
            //        if (IB_DownForntDoor.Off())
            //        {
            //            //SDKPara.Arm.ReportAlarm("04303", AcuraIOT.ErrorGroup.Door, AcuraIOT.ErrorSubGroup.Alarm, AcuraIOT.ErrorType.E, mNameAlm.System + "open back safety door");

            //        }
            //    }
            //}
            //else
            //{
            //    if (StatusChange_SafetyDownForntDoor)
            //    {
            //        if (DownConveyorStatus)
            //        {
            //            MiddleLayer.ConveyorF.OB_DownCvyMtFwd.On();
            //        }

            //        SDKKernal.ClearAllAlarm();
            //        StatusChange_SafetyDownForntDoor = false;
            //    }
            //}
        }

        public void RefreshDifferentThreadUI(Control control, Action action)
        {
            if (control.InvokeRequired)
            {
                Action refreshUI = new Action(action);
                control.Invoke(refreshUI);
            }
            else
            {
                action.Invoke();
            }
        }

        public void BackupMotorMaximumSpeed()
        {
            MotorMaximumParameter.Clear();
            foreach (ControlBaseInterface control in SDKPara.ControlList)
                if (control is NPMotor)
                {
                    MotorParameter d = new MotorParameter();
                    d.Port = ((NPMotor)control).Port;
                    d.MaximumSpeed = ((NPMotor)control).MaxSpeed;
                    MotorMaximumParameter.Add(d);
                }
        }

        public void RestoreMotorMaximumSpeed()
        {
            foreach (ControlBaseInterface control in SDKPara.ControlList)
                if (control is NPMotor)
                {
                    foreach (MotorParameter d in MotorMaximumParameter)
                    {
                        string port = ((NPMotor)control).Port;
                        if (port == d.Port)
                            ((NPMotor)control).MaxSpeed = d.MaximumSpeed;
                    }
                }
        }

        private void SwitchMotorToMaintenanceSpeed()
        {
            foreach (ControlBaseInterface control in SDKPara.ControlList)
                if (control is NPMotor)
                    if (((NPMotor)control).MaxSpeed > 10)
                    {
                        ((NPMotor)control).MaxSpeed = 10;
                    }
        }

        private void Control_SignalTower(Status status, NPOutput OB)
        {
            switch (status)
            {
                case Status.Off:
                    OB.Off();
                    break;
                case Status.On:
                    OB.On();
                    break;
                case Status.Blink:
                    if (BlinkIsOn)
                        OB.On();
                    else
                        OB.Off();
                    break;
            }
        }

        public void BuzzOff()
        {
            BuzzerNeedWork = false;
            OB_Buzzer.Off();
        }

        public void BuzzOn()
        {
            if(MiddleLayer.SystemF.GetSettingValue("PSet", "DisableSafetyBuzzer"))
            {
                BuzzerNeedWork = true;
                OB_Buzzer.On();

            }

        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            lbSpeedRatio.Text = trackBar1.Value.ToString();
        }

        private void trackBar1_ValueChanged_1(object sender, EventArgs e)
        {
            lbSpeedRatio.Text = trackBar1.Value.ToString();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            MiddleLayer.GantryF.SetSpeed(trackBar1.Value);
        }

        private void btn_SwitchLanguage_Click(object sender, EventArgs e)
        {
            SysPara.IsEnglish = !SysPara.IsEnglish;
            MiddleLayer.switchLanguage.AutoSwitchLanguage(SysPara.IsEnglish);
        }

        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            
            //MiddleLayer.GantryF.WriteToRobotR(7, (int)(this.trackBar2.Value));
        }

        private void TrackBar1_MouseUp(object sender, MouseEventArgs e)
        {
            DataTable dt = SettingData.Tables["PSet"];
            dt.Rows[0]["MachineSpeedRatio"] = Convert.ToInt32(lbSpeedRatio.Text);
            dt.AcceptChanges();
            MiddleLayer.SystemF.WriteSettingData();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            string FileInfoName = "controlText11.txt";
            using (TextWriter fw = new StreamWriter(FileInfoName, false))
            {
                try
                {
                    FileInfo fi = new FileInfo(FileInfoName);
                    for (int i = 0; i < SwitchLanguage.toolList.Count; i++)
                    {
                        fw.WriteLine(SwitchLanguage.toolList[i].Text);
                    }
                    for (int i = 0; i < SwitchLanguage.toolStripList.Count; i++)
                    {
                        fw.WriteLine(SwitchLanguage.toolStripList[i].Text);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    fw.Close();
                    fw.Dispose();
                }
            }
        }

        private void TrackBar2_MouseUp(object sender, MouseEventArgs e)
        {
            //DataTable dt = SettingData.Tables["PSet"];       //初始化取料索引
            //dt.Rows[0]["R1MachineSpeedRatio"] = Convert.ToInt32(lbR2SpeedRatio.Text);
            //dt.AcceptChanges();
            //MiddleLayer.SystemF.WriteSettingData();
            //JTimer JT = new JTimer();
            //JT.Restart();
            //bool ret = false;
            //trackBar2.Enabled = false;
            //System.Threading.Tasks.Task.Factory.StartNew(() =>
            //{
            //    while (true)
            //    {
            //        if (MiddleLayer.GantryF.Robot.ConnectStatus)
            //        {
            //            string[] pos = MiddleLayer.GantryF.GetDataByAnnotation(MiddleLayer.GantryF.dgv_EpsonPosition, "WriteRobotSpeed");
            //            if (MiddleLayer.GantryF.Robot.WriteToEpson(pos[2], pos[3], pos[4], 30000, string.Format("{0:d7}", Convert.ToInt16(lbR2SpeedRatio.Text))))
            //            {
            //                ret = true;
            //                //MiddleLayer.LogF.AddLog(LogType.Production, "写入机器人速度成功", SysPara.bEnableGeneralSaveLog);

            //                Log.log.Write("WriteRobotSpeedSuccess", Color.Black);
            //            }
            //            else
            //            {
            //                ret = false;
            //                //MiddleLayer.LogF.AddLog(LogType.Production, "写入机器人速度失败", SysPara.bEnableGeneralSaveLog);

            //                Log.log.Write("WriteRobotSpeedFailed", Color.Red);
            //            }
            //        }
            //        if (ret || JT.On(5000)) { trackBar2.Enabled = true; break; }
            //    }
            //});
           
        }
        void saveTaskValueToDataSet()
        {
            //DataTable dt = SettingData.Tables["PSet"];
            //dt.Rows[0]["TodayTaskValue"] = int.Parse(txtTaskValue.Text);
            //dt.AcceptChanges();
            //WriteSettingData();
        }
        public void saveTaskFinishedValueToDataSet()
        {
            //DataTable dt = SettingData.Tables["PSet"];
            //dt.Rows[0]["TodayFinishedTaskValue"] = SysPara.iTodayFinishedTaskValue;
            //dt.AcceptChanges();
            //WriteSettingData();
        }
        void ResetTaskValueToDataSet()
        {
            //DataTable dt = SettingData.Tables["PSet"];
            //dt.Rows[0]["TodayFinishedTaskValue"] = 0;
            //dt.AcceptChanges();
            //WriteSettingData();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            saveTaskValueToDataSet();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ResetTaskValueToDataSet();
        }

        private void BtnSwitchLanguage_Click(object sender, EventArgs e)
        {
            //SysPara.IsEnglish = !SysPara.IsEnglish;
            //MiddleLayer.switchLanguage.AutoSwitchLanguage(SysPara.IsEnglish);
        }

        private void MyCBBuzzer_Click(object sender, EventArgs e)
        {
           // SysPara.DisableBuzzer = !myCBBuzzer.Checked;
        }

        private void plProductionSetting_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
