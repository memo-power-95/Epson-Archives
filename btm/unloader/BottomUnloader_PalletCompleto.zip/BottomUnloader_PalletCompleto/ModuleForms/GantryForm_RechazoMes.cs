using Alpha.Classes;
using Alpha.FunctionForms;
using NPSDK;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static Alpha.FunctionForms.LogForm;

namespace Alpha._0.ModuleForms
{
    //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0: piezas que el MES no deja procesar (70106 LOT ID FAIL), como la
    //  Screw y la Unloader de linea 2 (2.1.1), con el modo NG automatico.
    //
    //  En esta Unloader el MES se pide por GRUPO de 3, cuando las piezas ya estan en el gripper: 10701 con las piezas
    //  tomadas (npFlowChart8) -> LOT START (npFlowChart10) -> 10704 -> LOT ID FAIL en 1 s (npFlowChart13).
    //  Antes: la 70106 abria la ventana del MES dentro del paso, con solo el primer modulo; "Si" volvia a mandar el
    //  10701 igual y "No" paraba. No habia forma de sacar esa pieza: habia que parar y quitarla a mano.
    //  Ahora sale la ventana EL MES NO DEJA PROCESAR con cada pieza (lugar del pallet, QR, codigo de la PCB, modelo,
    //  proceso y motivo del MES):
    //    REINTENTAR               el "Si" del proveedor: el 10701 otra vez igual.
    //    CANCELAR Y REINICIAR     el "No" del proveedor: MesCenter.StopRunning().
    //    NO REPORTAR, MANDAR A NG esas piezas no entran al 10701 (se vuelve a pedir el lote sin ellas, y lo demas del
    //                             MES sale de esa respuesta) y, antes de dejar el grupo en la charola, el robot las
    //                             deja en el NG buffer (GantryForm_NgBuffer.cs, los mismos comandos 017 / foto / 016
    //                             que usa el proveedor al Inicializar y la Unloader de linea 2 en produccion).
    //  Con el modo NG automatico prendido (Sistema; Classes\ModoNgMes.cs) se hace solo, con sus limites (3 seguidas o
    //  10 en 10 minutos) y el aviso 1220; si se pasa del limite, se apaga solo (1221) y sale la ventana.
    //  Al MES le llegan los mismos mensajes del proveedor, solo sin esas piezas.
    //  Numeracion: indice del MES = lugar del pallet - 1 (0 a 11), el mismo de PickedPocketIDs y POCKETIDs.
    //  No toca el reinicio de Aaron (RestartProcess, RGP_0001, InteractionBox).
    public partial class GantryForm
    {
        const string ComoVaANgUnloader = "antes de dejar el grupo en la charola, el robot las deja en el NG buffer";

        readonly bool[] rechazadaPorMes = new bool[12];      // por indice del MES
        readonly bool[] gripperRechazado = new bool[3];      // gripper 1 a 3 (indice 0 a 2) con una pieza rechazada
        private volatile bool esperandoDecisionMes = false;
        private volatile List<PiezaRechazada> piezasMesANg = null;
        private volatile bool reintentarLoteMes = false;

        public bool RechazadaPorMes(int indiceMes)
        {
            return indiceMes >= 0 && indiceMes < rechazadaPorMes.Length && rechazadaPorMes[indiceMes];
        }

        //  Inicializar o Start: nada pendiente.
        private void OlvidarRechazosDelMes()
        {
            for (int i = 0; i < rechazadaPorMes.Length; i++) rechazadaPorMes[i] = false;
            for (int i = 0; i < gripperRechazado.Length; i++) gripperRechazado[i] = false;
            esperandoDecisionMes = false;
            piezasMesANg = null;
            reintentarLoteMes = false;
            OlvidarNgBuffer();
        }

        private List<PiezaRechazada> LeerLoteFallido(out string textoMes, out string respuesta)
        {
            textoMes = "";
            respuesta = "";
            try
            {
                var mes = MESLib.CommParas.MesManager;
                respuesta = mes.LGIT_LOT_FAIL_STR ?? "";
                if (respuesta == "" && mes.LGIT_LOT_START_FAIL_DATA != null) respuesta = mes.LGIT_LOT_START_FAIL_DATA.ToString();
                string[] qrsPallet = new string[12];
                string[] codigosPcb = new string[12];
                for (int i = 0; i < 12; i++)
                {
                    try { qrsPallet[i] = SysPara.sPalletCodes[i] ?? ""; } catch { qrsPallet[i] = ""; }
                    try { codigosPcb[i] = SysPara.sProductCodes[i] ?? ""; } catch { codigosPcb[i] = ""; }
                }
                return PiezaRechazada.DeLoteFallido(respuesta, mes.POCKETIDs, mes.TRAY_POSITION_QRCODEs, qrsPallet, codigosPcb, out textoMes);
            }
            catch (Exception ex)
            {
                textoMes = "(no se pudo leer la respuesta del MES: " + ex.Message + ")";
                return new List<PiezaRechazada>();
            }
        }

        //  npFlowChart10 (antes del 10704) y npFlowChart13 (despues del 10704). CASE1 de los dos = npFlowChart8 (10701).
        private FCResultType LoteFallido(bool despuesDel10704)
        {
            string textoMes, respuesta;
            List<PiezaRechazada> piezas = LeerLoteFallido(out textoMes, out respuesta);
            string lista = piezas.Count > 0 ? string.Join(", ", piezas) : "(el MES no mando lista de piezas)";
            MiddleLayer.LogF.AddLog(LogType.Production, "LOT ID FAIL (70106" + (despuesDel10704 ? ", despues del 10704" : "")
                + "): el MES no dejo procesar " + lista + ". Texto del MES: " + textoMes, true);
            MESLib.MesLog.AddInfo("LOT ID FAIL (70106), respuesta: " + respuesta);

            //  Modo NG automatico: lo mismo que el boton MANDAR A NG, con sus limites.
            if (ModoNgMes.Activo)
            {
                string motivoNg;
                if (ModoNgMes.PuedeDescargar(out motivoNg))
                {
                    string porQueNo;
                    if (PuedeMandarANgPiezas(piezas, out porQueNo))
                    {
                        AplicarNgPiezas(piezas);
                        ModoNgMes.RegistrarDescarga(lista, textoMes);
                        SysPara.NPShowAlarm("1220", "Piezas " + lista + " al NG buffer. " + ModoNgMes.Resumen() + ". MES: " + textoMes);
                        return FCResultType.CASE1;
                    }
                    ModoNgMes.RegistrarFallo(porQueNo);
                    SysPara.NPShowAlarm("1221", porQueNo);
                }
                else
                {
                    ModoNgMes.RegistrarFallo(motivoNg);
                    SysPara.NPShowAlarm("1221", motivoNg);
                }
            }

            SysPara.NPShowAlarm("70106");
            PreguntarRechazoDelMes(piezas, textoMes);
            return FCResultType.IDLE;
        }

        //  Al principio de npFlowChart10 y npFlowChart13. true = el paso regresa 'resultado'.
        private bool DecisionMesPendiente(out FCResultType resultado)
        {
            resultado = FCResultType.IDLE;
            if (esperandoDecisionMes) return true;
            List<PiezaRechazada> piezasANg = piezasMesANg;
            if (piezasANg != null)
            {
                piezasMesANg = null;
                AplicarNgPiezas(piezasANg);
                resultado = FCResultType.CASE1;   // el 10701 otra vez, ya sin esas piezas
                return true;
            }
            if (reintentarLoteMes)
            {
                reintentarLoteMes = false;
                resultado = FCResultType.CASE1;   // el "Si" del proveedor: el 10701 otra vez igual
                return true;
            }
            return false;
        }

        //  Gripper (0 a 2) que trae la pieza de ese lugar del pallet, o -1.
        private int GripperDe(int indiceMes)
        {
            for (int g = 0; g < 3; g++)
            {
                try
                {
                    if (SysPara.pickUpProductIndex[g] - 1 == indiceMes && SysPara.iProductCountOnGrapper[g] == 1) return g;
                }
                catch
                {
                }
            }
            return -1;
        }

        //  Se puede mandar a NG solo si cada pieza es de este grupo (esta en un gripper) y si queda al menos una.
        public bool PuedeMandarANgPiezas(List<PiezaRechazada> piezas, out string motivo)
        {
            motivo = "";
            try
            {
                if (piezas == null || piezas.Count == 0)
                {
                    motivo = "el MES no dijo cual pieza es";
                    return false;
                }
                int enLote = 0;
                foreach (int indice in PickedPocketIDs)
                {
                    if (!RechazadaPorMes(indice)) enLote++;
                }
                List<int> sacadas = new List<int>();
                foreach (PiezaRechazada pieza in piezas)
                {
                    if (pieza.IndiceMes < 0 || pieza.IndiceMes > 11)
                    {
                        motivo = "no se encontro en el pallet " + (pieza.Modulo != "" ? pieza.Modulo : pieza.Lote != "" ? "la PCB " + pieza.Lote : "una pieza");
                        return false;
                    }
                    if (!PickedPocketIDs.Contains(pieza.IndiceMes) || (!mpcActivo && GripperDe(pieza.IndiceMes) < 0))   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo: en ese modo el MES contesta antes de tomar
                    {
                        motivo = "el lugar " + pieza.Lugar + " no es del grupo que trae el robot";
                        return false;
                    }
                    if (!sacadas.Contains(pieza.IndiceMes) && !RechazadaPorMes(pieza.IndiceMes)) sacadas.Add(pieza.IndiceMes);
                }
                if (enLote - sacadas.Count < 1)
                {
                    motivo = "quedaria sin piezas el grupo que trae el robot (quitelas a mano)";
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                motivo = ex.Message;
                return false;
            }
        }

        private void AplicarNgPiezas(List<PiezaRechazada> piezas)
        {
            foreach (PiezaRechazada pieza in piezas)
            {
                if (mpcActivo && pieza.IndiceMes >= 0 && pieza.IndiceMes < 12)   //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo
                {
                    //  Todavia no esta en un gripper: se marca el lugar y, cuando le toque su grupo, RepartirGrupoMpc
                    //  marca el gripper que la toma; al descargar va al NG buffer como siempre (fcNgMes).
                    rechazadaPorMes[pieza.IndiceMes] = true;
                    string textoPc = "Pieza rechazada por el MES: " + pieza + " no se reporta; el robot la toma y la deja en el NG buffer (pallet completo)";
                    MiddleLayer.LogF.AddLog(LogType.Production, textoPc, true);
                    MESLib.MesLog.AddInfo(textoPc);
                    continue;
                }
                int g = pieza.IndiceMes >= 0 && pieza.IndiceMes < 12 ? GripperDe(pieza.IndiceMes) : -1;
                if (g < 0)
                {
                    MiddleLayer.LogF.AddLog(LogType.Production, "Pieza rechazada por el MES: " + pieza + " no esta en el gripper, no se marca", true);
                    continue;
                }
                rechazadaPorMes[pieza.IndiceMes] = true;
                gripperRechazado[g] = true;
                try { SysPara.ThreeResultDatas[g].Result = "NG"; } catch { }
                string texto = "Pieza rechazada por el MES: " + pieza + " (gripper " + (g + 1) + ") no se reporta y va al NG buffer";
                MiddleLayer.LogF.AddLog(LogType.Production, texto, true);
                MESLib.MesLog.AddInfo(texto);
            }
        }

        private void PreguntarRechazoDelMes(List<PiezaRechazada> piezas, string textoMes)
        {
            esperandoDecisionMes = true;
            try
            {
                MiddleLayer.MainF.BeginInvoke((MethodInvoker)(() => MostrarRechazoDelMes(piezas, textoMes)));
            }
            catch (Exception ex)
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Piezas rechazadas por el MES: no se pudo abrir la ventana, se para como antes: " + ex.Message, true);
                esperandoDecisionMes = false;
                MESLib.CommParas.MesCenter.StopRunning();
            }
        }

        private void MostrarRechazoDelMes(List<PiezaRechazada> piezas, string textoMes)
        {
            PiezasRechazadasForm.Decision decision = PiezasRechazadasForm.Decision.Cancelar;
            try
            {
                string motivo;
                bool sePuede = PuedeMandarANgPiezas(piezas, out motivo);
                using (PiezasRechazadasForm ventana = new PiezasRechazadasForm(true, piezas, textoMes,
                    MESLib.CommParas.MesManager.PRODID, sePuede, motivo, false, ComoVaANgUnloader))
                {
                    ventana.ShowDialog(MiddleLayer.MainF);
                    decision = ventana.Eleccion;
                    if (decision == PiezasRechazadasForm.Decision.MandarANg && !sePuede) decision = PiezasRechazadasForm.Decision.Cancelar;
                }
            }
            catch (Exception ex)
            {
                MiddleLayer.LogF.AddLog(LogType.Production, "Piezas rechazadas por el MES: error en la ventana, se para como antes: " + ex.Message, true);
                decision = PiezasRechazadasForm.Decision.Cancelar;
            }
            switch (decision)
            {
                case PiezasRechazadasForm.Decision.MandarANg:
                    reintentarLoteMes = false;
                    piezasMesANg = piezas;
                    esperandoDecisionMes = false;
                    MiddleLayer.LogF.AddLog(LogType.Production, "Piezas rechazadas por el MES: el operador eligio MANDAR A NG " + string.Join(", ", piezas), true);
                    break;
                case PiezasRechazadasForm.Decision.Reintentar:
                    piezasMesANg = null;
                    reintentarLoteMes = true;
                    esperandoDecisionMes = false;
                    MiddleLayer.LogF.AddLog(LogType.Production, "Piezas rechazadas por el MES: el operador eligio REINTENTAR", true);
                    break;
                default:
                    piezasMesANg = null;
                    reintentarLoteMes = false;
                    esperandoDecisionMes = false;
                    MiddleLayer.LogF.AddLog(LogType.Production, "Piezas rechazadas por el MES: el operador eligio CANCELAR Y REINICIAR", true);
                    MESLib.CommParas.MesCenter.StopRunning();
                    break;
            }
        }
    }
}
