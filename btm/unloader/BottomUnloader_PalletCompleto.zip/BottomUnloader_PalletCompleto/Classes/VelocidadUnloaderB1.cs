using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using static Alpha.FunctionForms.LogForm;

namespace Alpha.Classes
{
    //MOD@@ Guillermo Carrillo - Unloader B1ST17 v1.0.0 opciones de velocidad (BTM linea 1)
    //
    //  Las de la Unloader 2.1.0 de linea 2 que son solo de la PC, con interruptores en la pantalla de Sistema como la
    //  Screw. Ninguna cambia los movimientos del robot, la vision, el NG ni el MES.
    //  Se guardan en AlphaEXE\ModuleData\Velocidad.txt (se crea solo la primera vez) y cambian en el momento.
    //  Solo se cambian con la maquina detenida.
    //    sin_espera_de_3s   opcion 1: IsTryRun se prende en cada Start (fc_RobotStart) y nunca se apaga, asi que
    //                       "Judge feeder ready" (flowChart15) esperaba 3 s FIJOS en cada pallet con DelayMs, que
    //                       frena todo el flujo. La revision se sigue saltando igual que hoy; solo sin la espera.
    //    espera_corta       opcion 2: reloj de Windows a 1 ms, para que el flujo no espere ~15 ms entre pasos.
    //    imagenes_aparte    opcion 3: las fotos de cada grupo (npFlowChart30 "Save image") se guardan en otro hilo
    //                       (mismo nombre, formato y carpeta) y se liberan al terminar.
    //  Todo queda en el log de produccion con el texto "Velocidad Unloader B1ST17 v1.0.0".
    public static class VelocidadUnloaderB1
    {
        public static bool SinEsperaDe3s { get; private set; } = true;
        public static bool EsperaCorta { get; private set; } = true;
        public static bool ImagenesAparte { get; private set; } = true;

        static bool relojPedido = false;
        static string problema = "";
        static readonly object candado = new object();

        //  Avisa a la pantalla de Sistema que cambiaron (puede llegar desde el hilo del flujo al inicializar).
        public static event Action Cambio;

        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        static extern uint TimeBeginPeriod(uint milisegundos);

        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        static extern uint TimeEndPeriod(uint milisegundos);

        const string PLANTILLA =
            "# Unloader B1ST17 v1.0.0 - opciones de velocidad (si = encendida, no = apagada)\r\n" +
            "# Se cambian en el programa: Sistema. Solo con la maquina detenida.\r\n" +
            "# Ninguna cambia los movimientos del robot, la vision, el NG ni el MES.\r\n" +
            "\r\n" +
            "# Opcion 1: sin la espera fija de 3 s por pallet en Judge feeder ready.\r\n" +
            "sin_espera_de_3s=si\r\n" +
            "\r\n" +
            "# Opcion 2: el flujo espera ~1 ms entre pasos en lugar de ~15 ms.\r\n" +
            "espera_corta=si\r\n" +
            "\r\n" +
            "# Opcion 3: las fotos de cada grupo se guardan en otro hilo.\r\n" +
            "imagenes_aparte=si\r\n";

        static string Archivo
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ModuleData", "Velocidad.txt"); }
        }

        //  Lee el archivo sin escribir en el log (al abrir el programa el log todavia no arranca).
        //  Si no existe lo crea; si no se puede leer, quedan como de fabrica (las tres si).
        public static void LeerArchivo()
        {
            bool sin3s = true, espera = true, imagenes = true;
            problema = "";
            try
            {
                if (!File.Exists(Archivo))
                {
                    File.WriteAllText(Archivo, PLANTILLA, Encoding.ASCII);
                }
                foreach (string renglon in File.ReadAllLines(Archivo))
                {
                    string linea = renglon;
                    int gato = linea.IndexOf('#');
                    if (gato >= 0) linea = linea.Substring(0, gato);
                    int igual = linea.IndexOf('=');
                    if (igual <= 0) continue;
                    string clave = linea.Substring(0, igual).Trim().ToLowerInvariant();
                    string valor = linea.Substring(igual + 1).Trim().ToLowerInvariant();
                    bool si = valor.StartsWith("s") || valor == "1" || valor == "true";
                    if (clave == "sin_espera_de_3s") sin3s = si;
                    else if (clave == "espera_corta") espera = si;
                    else if (clave == "imagenes_aparte") imagenes = si;
                }
            }
            catch (Exception ex)
            {
                problema = " (no se pudo leer " + Archivo + ": " + ex.Message + "; quedan como de fabrica: las tres si)";
            }
            SinEsperaDe3s = sin3s;
            EsperaCorta = espera;
            ImagenesAparte = imagenes;
        }

        //  Al inicializar: lee el archivo, ajusta el reloj y anota en el log lo que quedo.
        public static void Leer()
        {
            lock (candado)
            {
                LeerArchivo();
                AjustarReloj();
            }
            Anotar();
            Avisar();
        }

        //  Cambio desde la pantalla de Sistema: se guarda en el archivo y se aplica en el momento.
        public static bool Cambiar(bool sin3s, bool espera, bool imagenes, out string error)
        {
            error = "";
            bool guardado;
            lock (candado)
            {
                SinEsperaDe3s = sin3s;
                EsperaCorta = espera;
                ImagenesAparte = imagenes;
                AjustarReloj();
                guardado = Guardar(out error);
            }
            Log("Velocidad cambiada en la pantalla de Sistema: " + Resumen()
                + (guardado ? "" : " (NO se pudo guardar en " + Archivo + ": " + error + ")"));
            Avisar();
            return guardado;
        }

        static bool Guardar(out string error)
        {
            error = "";
            try
            {
                string texto = PLANTILLA
                    .Replace("sin_espera_de_3s=si", "sin_espera_de_3s=" + SiNoArchivo(SinEsperaDe3s))
                    .Replace("espera_corta=si", "espera_corta=" + SiNoArchivo(EsperaCorta))
                    .Replace("imagenes_aparte=si", "imagenes_aparte=" + SiNoArchivo(ImagenesAparte));
                File.WriteAllText(Archivo, texto, Encoding.ASCII);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        static void AjustarReloj()
        {
            if (EsperaCorta) AplicarEsperaCorta();
            else QuitarEsperaCorta();
        }

        static void Avisar()
        {
            try
            {
                Action a = Cambio;
                if (a != null) a();
            }
            catch
            {
            }
        }

        static string Resumen()
        {
            return "1 sin espera de 3 s " + SiNo(SinEsperaDe3s)
                + ", 2 espera corta " + SiNo(EsperaCorta) + (relojPedido ? " (reloj de Windows a 1 ms)" : "")
                + ", 3 imagenes aparte " + SiNo(ImagenesAparte);
        }

        public static void Anotar()
        {
            Log("Velocidad Unloader B1ST17 v1.0.0: " + Resumen() + problema);
        }

        public static void Log(string texto)
        {
            try
            {
                if (MiddleLayer.LogF != null) MiddleLayer.LogF.AddLog(LogType.Production, texto, true);
            }
            catch
            {
            }
        }

        //  Opcion 1. El reloj de Windows cambia al instante; Windows lo regresa solo al cerrar el programa.
        public static void AplicarEsperaCorta()
        {
            if (!EsperaCorta || relojPedido) return;
            try
            {
                relojPedido = TimeBeginPeriod(1) == 0;
            }
            catch
            {
                relojPedido = false;
            }
        }

        public static void QuitarEsperaCorta()
        {
            if (!relojPedido) return;
            try
            {
                TimeEndPeriod(1);
            }
            catch
            {
            }
            relojPedido = false;
        }

        static string SiNo(bool valor)
        {
            return valor ? "SI" : "NO";
        }

        static string SiNoArchivo(bool valor)
        {
            return valor ? "si" : "no";
        }
    }

    //MOD@@ Guillermo Carrillo - Unloader B1ST17 pallet completo (pedido de ingenieria, Mr. Park)
    //
    //  Que la Bottom trabaje el pallet como la Top Unloader: fotos de las 12 posiciones, el MES UNA vez por pallet
    //  antes de tomar, y luego tomar y dejar de 3 en 3. Lo hace GantryForm (region "pallet completo").
    //  Se guarda en AlphaEXE\ModuleData\PalletCompleto.txt (se crea solo, apagado). Se cambia en Sistema, con la
    //  maquina detenida; el flujo lo toma al empezar cada pallet (flowChart21).
    public static class PalletCompletoB1
    {
        public static bool Activo { get; private set; } = false;

        const string PLANTILLA =
            "# Unloader B1ST17 - pallet completo como la Top (si = encendido, no = apagado)\r\n" +
            "# Se cambia en el programa: Sistema. Solo con la maquina detenida.\r\n" +
            "# si = fotos de las 12, el MES una vez por pallet y luego tomar de 3 en 3.\r\n" +
            "# no = como siempre: foto, toma y MES de 3 en 3.\r\n" +
            "\r\n" +
            "pallet_completo=no\r\n";

        static string Archivo
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ModuleData", "PalletCompleto.txt"); }
        }

        //  Al abrir el programa. Si no existe lo crea apagado; si no se puede leer, queda apagado.
        public static void LeerArchivo()
        {
            bool activo = false;
            try
            {
                if (!File.Exists(Archivo))
                {
                    File.WriteAllText(Archivo, PLANTILLA, Encoding.ASCII);
                }
                foreach (string renglon in File.ReadAllLines(Archivo))
                {
                    string linea = renglon;
                    int gato = linea.IndexOf('#');
                    if (gato >= 0) linea = linea.Substring(0, gato);
                    int igual = linea.IndexOf('=');
                    if (igual <= 0) continue;
                    string clave = linea.Substring(0, igual).Trim().ToLowerInvariant();
                    string valor = linea.Substring(igual + 1).Trim().ToLowerInvariant();
                    if (clave == "pallet_completo") activo = valor.StartsWith("s") || valor == "1" || valor == "true";
                }
            }
            catch
            {
                activo = false;
            }
            Activo = activo;
        }

        //  Desde la pantalla de Sistema: se guarda y aplica desde el siguiente pallet.
        public static bool Cambiar(bool activo, out string error)
        {
            error = "";
            Activo = activo;
            bool guardado = true;
            try
            {
                File.WriteAllText(Archivo, PLANTILLA.Replace("pallet_completo=no", "pallet_completo=" + (activo ? "si" : "no")), Encoding.ASCII);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                guardado = false;
            }
            VelocidadUnloaderB1.Log("Pallet completo como la Top: " + (activo ? "SI" : "NO") + " (desde el siguiente pallet)"
                + (guardado ? "" : " (NO se pudo guardar en " + Archivo + ": " + error + ")"));
            return guardado;
        }
    }
}
